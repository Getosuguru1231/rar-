import cv2
import time

print("测试摄像头连接...")

backends = [
    cv2.CAP_DSHOW,
    cv2.CAP_MSMF,
    cv2.CAP_ANY,
]

for backend in backends:
    cap = cv2.VideoCapture(0, backend)
    print(f"后端 {backend}: isOpened = {cap.isOpened()}")
    if cap.isOpened():
        ret, frame = cap.read()
        print(f"  read成功: {ret}")
        if ret and frame is not None:
            print(f"  帧形状: {frame.shape}")
            print(f"  帧大小: {frame.size}")
            print(f"  帧数据类型: {frame.dtype}")
        cap.release()
    time.sleep(0.5)

print("\n测试摄像头1...")
cap1 = cv2.VideoCapture(1, cv2.CAP_DSHOW)
print(f"摄像头1 isOpened = {cap1.isOpened()}")
if cap1.isOpened():
    ret, frame = cap1.read()
    print(f"  read成功: {ret}")
    if ret and frame is not None:
        print(f"  帧形状: {frame.shape}")
    cap1.release()

print("\n测试完成")