import os
import sys
import threading
import time

frontend_dir = os.path.join(os.path.dirname(__file__), 'frontend')
dist_dir = os.path.join(frontend_dir, 'dist')

os.chdir(dist_dir)

PORT = 3000

class MyHandler:
    def __init__(self):
        import http.server
        self.handler = http.server.SimpleHTTPRequestHandler
        
    def __call__(self, *args, **kwargs):
        handler = self.handler(*args, **kwargs)
        def new_end_headers():
            handler.send_header('Access-Control-Allow-Origin', '*')
            handler.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
            handler.send_header('Access-Control-Allow-Headers', 'Content-Type')
            http.server.SimpleHTTPRequestHandler.end_headers(handler)
        handler.end_headers = new_end_headers
        return handler

def start_server():
    import socketserver
    with socketserver.TCPServer(("", PORT), MyHandler()) as httpd:
        with open(os.path.join(os.path.dirname(__file__), 'server_started.txt'), 'w') as f:
            f.write(f"Server started on port {PORT}\n")
            f.write(f"Directory: {os.getcwd()}\n")
        httpd.serve_forever()

thread = threading.Thread(target=start_server)
thread.daemon = True
thread.start()

time.sleep(2)

with open(os.path.join(os.path.dirname(__file__), 'server_started.txt'), 'a') as f:
    f.write("Server is running\n")

while True:
    time.sleep(1)
