import sys
import os

# 直接写入结果文件
result_file = open('env_check_result.txt', 'w', encoding='utf-8')

result_file.write("=== 环境信息 ===\n")
result_file.write(f"Python版本: {sys.version}\n")
result_file.write(f"当前目录: {os.getcwd()}\n")
result_file.write(f"操作系统: {sys.platform}\n")

result_file.write("\n=== Python模块 ===\n")
modules = ['uvicorn', 'fastapi', 'redis', 'cv2']
for mod in modules:
    try:
        __import__(mod)
        result_file.write(f"{mod}: 已安装\n")
    except ImportError:
        result_file.write(f"{mod}: 未安装\n")

result_file.write("\n=== 路径检查 ===\n")
frontend_dir = os.path.join(os.getcwd(), 'frontend')
result_file.write(f"前端目录: {frontend_dir} - {'存在' if os.path.exists(frontend_dir) else '不存在'}\n")

backend_dir = os.path.join(os.getcwd(), 'backend')
result_file.write(f"后端目录: {backend_dir} - {'存在' if os.path.exists(backend_dir) else '不存在'}\n")

result_file.write("\n=== 完成 ===\n")
result_file.close()

print("Done")
