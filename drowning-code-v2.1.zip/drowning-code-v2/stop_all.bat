@echo off
chcp 65001 >nul
echo ================================================
echo           智能溺水检测系统 - 停止服务脚本
echo ================================================
echo.

echo [停止Python/uvicorn进程]
tasklist | findstr /i "python.exe" | findstr /i "uvicorn" >nul
if %errorlevel% equ 0 (
    echo 正在停止后端服务...
    taskkill /f /im python.exe /fi "WINDOWTITLE eq Backend*" 2>nul
    taskkill /f /im python.exe /fi "WINDOWTITLE eq *uvicorn*" 2>nul
    echo [OK] 后端服务已停止
) else (
    echo [INFO] 未找到运行中的后端服务
)

echo.
echo [停止Node.js进程]
tasklist | findstr /i "node.exe" >nul
if %errorlevel% equ 0 (
    echo 正在停止前端服务...
    taskkill /f /im node.exe 2>nul
    echo [OK] 前端服务已停止
) else (
    echo [INFO] 未找到运行中的前端服务
)

echo.
echo [停止Redis进程]
tasklist | findstr /i "redis-server.exe" >nul
if %errorlevel% equ 0 (
    echo 正在停止Redis服务...
    taskkill /f /im redis-server.exe 2>nul
    echo [OK] Redis服务已停止
) else (
    echo [INFO] 未找到运行中的Redis服务
)

echo.
echo [停止Docker容器]
docker ps | findstr /i "backend\|frontend\|redis" >nul
if %errorlevel% equ 0 (
    echo 正在停止Docker容器...
    docker-compose down 2>nul
    echo [OK] Docker容器已停止
) else (
    echo [INFO] 未找到运行中的Docker容器
)

echo.
echo ================================================
echo           所有服务已停止
echo ================================================
pause