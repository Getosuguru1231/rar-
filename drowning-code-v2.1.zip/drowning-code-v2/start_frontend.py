import http.server
import socketserver
import os

os.chdir(os.path.join(os.path.dirname(__file__), 'frontend', 'dist'))

PORT = 3000

class MyHTTPRequestHandler(http.server.SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        http.server.SimpleHTTPRequestHandler.end_headers(self)

with socketserver.TCPServer(("", PORT), MyHTTPRequestHandler) as httpd:
    with open('server_log.txt', 'w') as f:
        f.write(f"Server started on port {PORT}\n")
        f.write(f"Directory: {os.getcwd()}\n")
    httpd.serve_forever()
