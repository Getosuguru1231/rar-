"""启动初始化模块

负责系统启动时的资源初始化，包括：
- 数据库连接
- Redis连接
- 监控线程启动
- 检测线程启动
- 配置加载
- 模型加载
"""

import threading
import time
import os
from logging_config import get_logger

logger = get_logger('startup')

def init_environment():
    """初始化环境变量"""
    from dotenv import load_dotenv
    load_dotenv()
    load_dotenv('.env.llm')
    logger.info("[OK] 环境变量加载成功")

def init_config():
    """初始化系统配置"""
    try:
        from settings import Settings
        settings = Settings()
        logger.info(f"[OK] 配置加载成功 - 视频质量: {settings.VIDEO_QUALITY}, 图像尺寸: {settings.IMGSZ}")
        return settings
    except Exception as e:
        logger.error(f"[ERROR] 配置加载失败: {str(e)}")
        return None

def init_database():
    """初始化数据库连接

    Returns:
        db_conn: 数据库连接对象，失败返回None
    """
    from components.utils import get_db_connection

    try:
        db_conn = get_db_connection()
        logger.info("[OK] 数据库连接成功")
        return db_conn
    except Exception as e:
        logger.error(f"[ERROR] 数据库连接失败: {str(e)}")
        logger.warning("[WARNING] 系统将在无数据库模式下运行")
        return None

def init_redis():
    """初始化Redis连接

    Returns:
        redis_client: Redis客户端对象，失败返回None
    """
    from components.utils import get_redis_client

    try:
        redis_client = get_redis_client()
        logger.info("[OK] Redis 连接成功")
        return redis_client
    except Exception as e:
        logger.error(f"[ERROR] Redis 连接失败: {str(e)}")
        logger.warning("[WARNING] 系统将在无Redis模式下运行")
        return None

def init_logging():
    """初始化日志系统"""
    from logging_config import setup_logging
    setup_logging(log_level=20)
    logger.info("[OK] 日志系统初始化成功")

def init_models():
    """初始化检测模型"""
    try:
        from detection.core import init_models
        init_models()
        logger.info("[OK] 检测模型初始化成功")
        return True
    except Exception as e:
        logger.error(f"[ERROR] 模型初始化失败: {str(e)}")
        logger.warning("[WARNING] 系统将在无检测模型模式下运行")
        return False

def start_alert_monitor_thread(redis_client):
    """启动告警监控线程

    Args:
        redis_client: Redis客户端对象
    """
    from main import monitor_alerts

    alert_monitor_thread = threading.Thread(target=monitor_alerts, daemon=True)
    alert_monitor_thread.start()
    logger.info("[OK] 告警监控线程已启动")

def start_detection_thread():
    """启动溺水检测线程

    启动失败不影响系统运行，截图功能仍然可用
    """
    from detection.detect import start_detection

    try:
        detection_thread = threading.Thread(target=start_detection, daemon=True)
        detection_thread.start()
        logger.info("[OK] 检测线程已启动")
    except Exception as e:
        logger.warning(f"[WARNING] 检测线程启动失败（可能是摄像头问题）: {str(e)}")
        logger.info("[INFO] 服务将继续运行，截图功能仍然可用")

def start_video_cleanup_thread():
    """启动视频清理线程"""
    from video_cleaner import start_video_cleanup

    try:
        cleanup_thread = threading.Thread(target=start_video_cleanup, daemon=True)
        cleanup_thread.start()
        logger.info("[OK] 视频清理线程已启动")
    except Exception as e:
        logger.warning(f"[WARNING] 视频清理线程启动失败: {str(e)}")

def startup_system():
    """系统启动入口

    初始化所有资源并启动所有必要的线程

    Returns:
        tuple: (db_conn, redis_client, settings)
    """
    logger.info("="*70)
    logger.info("[INFO] 智能溺水检测系统启动中...")
    logger.info("="*70)

    # 初始化环境变量
    init_environment()

    # 初始化配置
    settings = init_config()

    # 初始化数据库
    db_conn = init_database()

    # 初始化Redis
    redis_client = init_redis()

    # 初始化模型
    init_models()

    # 启动告警监控线程
    start_alert_monitor_thread(redis_client)

    # 启动检测线程
    start_detection_thread()

    # 启动视频清理线程
    start_video_cleanup_thread()

    logger.info("="*70)
    logger.info("[INFO] 系统启动完成")
    logger.info("="*70)
    logger.info(f"[INFO] 服务端口: 8000")
    logger.info(f"[INFO] API文档: http://localhost:8000/docs")
    logger.info(f"[INFO] 前端地址: http://localhost:3001")

    return db_conn, redis_client, settings

def shutdown_system(db_conn=None, redis_client=None):
    """系统关闭清理

    Args:
        db_conn: 数据库连接对象
        redis_client: Redis客户端对象
    """
    logger.info("[INFO] 系统正在关闭...")

    # 关闭数据库连接
    if db_conn:
        try:
            db_conn.close()
            logger.info("[OK] 数据库连接已关闭")
        except Exception as e:
            logger.error(f"[ERROR] 关闭数据库连接失败: {str(e)}")

    # 关闭Redis连接
    if redis_client:
        try:
            redis_client.close()
            logger.info("[OK] Redis连接已关闭")
        except Exception as e:
            logger.error(f"[ERROR] 关闭Redis连接失败: {str(e)}")

    logger.info("[INFO] 系统已关闭")