import cv2
import time
import numpy as np

cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)
if not cap.isOpened():
    print('Failed to open camera')
    exit()

print(f'Backend: {cap.getBackendName()}')
print(f'Width: {cap.get(cv2.CAP_PROP_FRAME_WIDTH)}')
print(f'Height: {cap.get(cv2.CAP_PROP_FRAME_HEIGHT)}')
print(f'FPS: {cap.get(cv2.CAP_PROP_FPS)}')
print(f'Buffer size: {cap.get(cv2.CAP_PROP_BUFFERSIZE)}')

print('\nReading raw frames...')
for i in range(10):
    ret, frame = cap.read()
    if ret and frame is not None:
        mean_val = np.mean(frame)
        std_val = np.std(frame)
        print(f'Frame {i}: mean={mean_val:.2f}, std={std_val:.2f}, shape={frame.shape}')
    else:
        print(f'Frame {i}: read failed')
    time.sleep(0.1)

cap.release()

print('\nDone')