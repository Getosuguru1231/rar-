﻿﻿from pydantic import BaseSettings, Field
from typing import Dict, Optional
import os

class RedisSettings(BaseSettings):
    host: str = Field(default='localhost', env='REDIS_HOST')
    port: int = Field(default=6379, env='REDIS_PORT')
    db: int = Field(default=0, env='REDIS_DB')
    password: Optional[str] = Field(default=None, env='REDIS_PASSWORD')
    decode_responses: bool = Field(default=False, env='REDIS_DECODE_RESPONSES')
    
    class Config:
        env_file = '.env'

class DatabaseSettings(BaseSettings):
    host: str = Field(default='localhost', env='DB_HOST')
    port: int = Field(default=3306, env='DB_PORT')
    user: str = Field(default='root', env='DB_USER')
    password: str = Field(default='root', env='DB_PASSWORD')
    database: str = Field(default='drowning_db', env='DB_NAME')
    
    class Config:
        env_file = '.env'

class DetectionSettings(BaseSettings):
    model_path: str = Field(default='./best.pt', env='MODEL_PATH')
    conf_threshold: float = Field(default=0.5, env='CONF_THRESHOLD')
    iou_threshold: float = Field(default=0.4, env='IOU_THRESHOLD')
    imgsz: int = Field(default=320, env='IMG_SIZE')
    frame_skip_rate: int = Field(default=1, env='FRAME_SKIP_RATE')
    video_quality: int = Field(default=100, env='VIDEO_QUALITY')
    target_fps: int = Field(default=45, env='TARGET_FPS')
    
    class Config:
        env_file = '.env'

class CameraSettings(BaseSettings):
    default_source: int = Field(default=0, env='CAMERA_DEFAULT_SOURCE')
    heartbeat_interval: int = Field(default=30, env='CAMERA_HEARTBEAT_INTERVAL')
    max_same_frames: int = Field(default=3, env='CAMERA_MAX_SAME_FRAMES')
    
    class Config:
        env_file = '.env'

class AlertSettings(BaseSettings):
    enabled: bool = Field(default=True, env='ALERT_ENABLED')
    sound_enabled: bool = Field(default=True, env='ALERT_SOUND_ENABLED')
    call_enabled: bool = Field(default=False, env='ALERT_CALL_ENABLED')
    delay: int = Field(default=1, env='ALERT_DELAY')
    
    class Config:
        env_file = '.env'

class Settings(BaseSettings):
    redis: RedisSettings = RedisSettings()
    database: DatabaseSettings = DatabaseSettings()
    detection: DetectionSettings = DetectionSettings()
    camera: CameraSettings = CameraSettings()
    alert: AlertSettings = AlertSettings()
    debug: bool = Field(default=False, env='DEBUG')
    port: int = Field(default=8000, env='PORT')
    
    class Config:
        env_file = '.env'
    
    @property
    def project_dir(self) -> str:
        return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    
    @property
    def backend_dir(self) -> str:
        return os.path.dirname(os.path.abspath(__file__))

settings = Settings()