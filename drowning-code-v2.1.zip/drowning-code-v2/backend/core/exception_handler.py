﻿from fastapi import FastAPI, HTTPException
from fastapi.requests import Request
from fastapi.responses import JSONResponse
from fastapi.exceptions import RequestValidationError
from starlette.exceptions import HTTPException as StarletteHTTPException
import logging

logger = logging.getLogger(__name__)

class AppException(Exception):
    def __init__(self, status_code: int, message: str, error_code: str = None):
        self.status_code = status_code
        self.message = message
        self.error_code = error_code or f"ERR_{status_code}"

class ValidationException(AppException):
    def __init__(self, message: str):
        super().__init__(status_code=422, message=message, error_code="ERR_VALIDATION")

class DatabaseException(AppException):
    def __init__(self, message: str):
        super().__init__(status_code=500, message=message, error_code="ERR_DATABASE")

class RedisException(AppException):
    def __init__(self, message: str):
        super().__init__(status_code=500, message=message, error_code="ERR_REDIS")

class DetectionException(AppException):
    def __init__(self, message: str):
        super().__init__(status_code=500, message=message, error_code="ERR_DETECTION")

async def app_exception_handler(request: Request, exc: AppException) -> JSONResponse:
    logger.error(f"AppException: {exc.error_code} - {exc.message}")
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "error": {
                "code": exc.error_code,
                "message": exc.message,
                "status_code": exc.status_code
            }
        }
    )

async def http_exception_handler(request: Request, exc: HTTPException) -> JSONResponse:
    logger.error(f"HTTPException: {exc.status_code} - {exc.detail}")
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "error": {
                "code": f"ERR_{exc.status_code}",
                "message": exc.detail,
                "status_code": exc.status_code
            }
        }
    )

async def validation_exception_handler(request: Request, exc: RequestValidationError) -> JSONResponse:
    errors = []
    for error in exc.errors():
        field = ".".join(str(e) for e in error["loc"])
        errors.append(f"{field}: {error['msg']}")
    message = "; ".join(errors)
    logger.error(f"ValidationError: {message}")
    return JSONResponse(
        status_code=422,
        content={
            "error": {
                "code": "ERR_VALIDATION",
                "message": message,
                "status_code": 422
            }
        }
    )

async def generic_exception_handler(request: Request, exc: Exception) -> JSONResponse:
    logger.error(f"Unexpected error: {str(exc)}", exc_info=True)
    return JSONResponse(
        status_code=500,
        content={
            "error": {
                "code": "ERR_UNEXPECTED",
                "message": "An unexpected error occurred",
                "status_code": 500
            }
        }
    )

def register_exception_handlers(app: FastAPI) -> None:
    app.add_exception_handler(AppException, app_exception_handler)
    app.add_exception_handler(HTTPException, http_exception_handler)
    app.add_exception_handler(RequestValidationError, validation_exception_handler)
    app.add_exception_handler(Exception, generic_exception_handler)