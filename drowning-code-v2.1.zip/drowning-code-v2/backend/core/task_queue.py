import asyncio
import uuid
import time
from typing import Dict, List, Optional, Callable, Any, Set
from enum import Enum
from dataclasses import dataclass, field
import logging

logger = logging.getLogger(__name__)

class TaskStatus(Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    TIMEOUT = "timeout"

class TaskPriority(Enum):
    LOW = 1
    NORMAL = 2
    HIGH = 3
    CRITICAL = 4

class QueueFullStrategy(Enum):
    REJECT = "reject"
    WAIT = "wait"
    DROP_LOWEST = "drop_lowest"
    DROP_OLD = "drop_old"

@dataclass(order=True)
class QueuedTask:
    priority: int
    task_id: str = field(compare=False)
    func: Callable = field(compare=False)
    args: tuple = field(compare=False)
    kwargs: dict = field(compare=False)
    created_at: float = field(compare=False, default_factory=lambda: time.time())
    status: TaskStatus = field(compare=False, default=TaskStatus.PENDING)
    result: Any = field(compare=False, default=None)
    error: str = field(compare=False, default=None)
    started_at: Optional[float] = field(compare=False, default=None)
    completed_at: Optional[float] = field(compare=False, default=None)
    retry_count: int = field(compare=False, default=0)
    max_retries: int = field(compare=False, default=0)
    timeout: Optional[float] = field(compare=False, default=None)
    group_id: Optional[str] = field(compare=False, default=None)

class TaskQueueManager:
    def __init__(
        self, 
        max_concurrent_tasks: int = 5, 
        queue_maxsize: int = 200,
        full_strategy: QueueFullStrategy = QueueFullStrategy.WAIT,
        default_timeout: float = 60.0
    ):
        self._queue: asyncio.PriorityQueue = asyncio.PriorityQueue(maxsize=queue_maxsize)
        self._tasks: Dict[str, QueuedTask] = {}
        self._running_tasks: int = 0
        self._max_concurrent_tasks = max_concurrent_tasks
        self._lock = asyncio.Lock()
        self._worker_tasks: List[asyncio.Task] = []
        self._is_running = False
        self._full_strategy = full_strategy
        self._default_timeout = default_timeout
        
        self._stats = {
            "total_tasks": 0,
            "completed_tasks": 0,
            "failed_tasks": 0,
            "cancelled_tasks": 0,
            "timeout_tasks": 0,
            "pending_tasks": 0,
            "running_tasks": 0,
            "average_wait_time": 0,
            "average_execution_time": 0,
            "total_wait_time": 0,
            "total_execution_time": 0,
            "retry_count": 0,
            "dropped_tasks": 0,
            "peak_queue_size": 0,
            "peak_concurrent": 0,
            "throughput": 0,
            "last_reset_time": time.time()
        }
        
        self._group_limits: Dict[str, int] = {}
        self._group_counts: Dict[str, int] = {}
        self._shutdown_event = asyncio.Event()

    async def start(self, worker_count: int = None):
        """启动队列管理器"""
        if self._is_running:
            return
        
        self._is_running = True
        count = worker_count or max(2, min(self._max_concurrent_tasks, 4))
        
        for i in range(count):
            worker = asyncio.create_task(self._worker_loop(f"worker-{i+1}"))
            self._worker_tasks.append(worker)
        
        asyncio.create_task(self._stats_monitor())
        logger.info(f"任务队列管理器已启动，工作线程数: {count}，最大并发: {self._max_concurrent_tasks}")

    async def stop(self, timeout: float = 10.0):
        """停止队列管理器"""
        self._is_running = False
        self._shutdown_event.set()
        
        for worker in self._worker_tasks:
            worker.cancel()
        
        try:
            await asyncio.wait(self._worker_tasks, timeout=timeout)
        except asyncio.TimeoutError:
            logger.warning("停止超时，强制退出")
        
        self._worker_tasks.clear()
        logger.info("任务队列管理器已停止")

    def submit(
        self, 
        func: Callable, 
        *args, 
        priority: TaskPriority = TaskPriority.NORMAL,
        timeout: Optional[float] = None,
        max_retries: int = 0,
        group_id: Optional[str] = None,
        **kwargs
    ) -> str:
        """
        提交任务到队列
        
        Args:
            func: 任务函数
            args: 位置参数
            priority: 优先级，默认NORMAL
            timeout: 任务超时时间（秒），默认使用全局配置
            max_retries: 最大重试次数
            group_id: 任务分组ID，用于限流
            kwargs: 关键字参数
        
        Returns:
            task_id: 任务ID
        """
        if not self._is_running:
            raise RuntimeError("任务队列管理器未启动")
        
        task_id = str(uuid.uuid4())[:8]
        queued_task = QueuedTask(
            priority=priority.value,
            task_id=task_id,
            func=func,
            args=args,
            kwargs=kwargs,
            timeout=timeout or self._default_timeout,
            max_retries=max_retries,
            group_id=group_id
        )
        
        try:
            self._queue.put_nowait(queued_task)
        except asyncio.QueueFull:
            if self._full_strategy == QueueFullStrategy.REJECT:
                raise RuntimeError("任务队列已满")
            elif self._full_strategy == QueueFullStrategy.WAIT:
                asyncio.create_task(self._wait_and_put(queued_task))
            elif self._full_strategy == QueueFullStrategy.DROP_LOWEST:
                self._drop_lowest_priority()
                self._queue.put_nowait(queued_task)
            elif self._full_strategy == QueueFullStrategy.DROP_OLD:
                self._drop_oldest()
                self._queue.put_nowait(queued_task)
        
        self._tasks[task_id] = queued_task
        self._stats["total_tasks"] += 1
        
        self._update_peak_queue_size()
        logger.debug(f"任务已提交: {task_id}, 优先级: {priority.name}")
        return task_id

    async def _wait_and_put(self, task: QueuedTask):
        """等待队列有空间后放入任务"""
        try:
            await asyncio.wait_for(self._queue.put(task), timeout=30.0)
        except asyncio.TimeoutError:
            self._stats["dropped_tasks"] += 1
            task.status = TaskStatus.FAILED
            task.error = "队列等待超时"
            logger.warning(f"任务等待超时被丢弃: {task.task_id}")

    def _drop_lowest_priority(self):
        """移除最低优先级的任务"""
        tasks = []
        while not self._queue.empty():
            try:
                tasks.append(self._queue.get_nowait())
            except asyncio.QueueEmpty:
                break
        
        if tasks:
            tasks.sort(key=lambda t: t.priority)
            dropped = tasks.pop(0)
            self._stats["dropped_tasks"] += 1
            self._tasks[dropped.task_id].status = TaskStatus.CANCELLED
            logger.warning(f"队列已满，丢弃低优先级任务: {dropped.task_id}")
            
            for t in tasks:
                self._queue.put_nowait(t)

    def _drop_oldest(self):
        """移除最老的任务"""
        tasks = []
        while not self._queue.empty():
            try:
                tasks.append(self._queue.get_nowait())
            except asyncio.QueueEmpty:
                break
        
        if tasks:
            oldest = min(tasks, key=lambda t: t.created_at)
            tasks.remove(oldest)
            self._stats["dropped_tasks"] += 1
            self._tasks[oldest.task_id].status = TaskStatus.CANCELLED
            logger.warning(f"队列已满，丢弃最老任务: {oldest.task_id}")
            
            for t in tasks:
                self._queue.put_nowait(t)

    def _update_peak_queue_size(self):
        """更新队列峰值大小"""
        current_size = self._queue.qsize()
        if current_size > self._stats["peak_queue_size"]:
            self._stats["peak_queue_size"] = current_size

    def set_group_limit(self, group_id: str, max_concurrent: int):
        """设置任务组的并发限制"""
        self._group_limits[group_id] = max_concurrent
        if group_id not in self._group_counts:
            self._group_counts[group_id] = 0

    async def _check_group_limit(self, group_id: str) -> bool:
        """检查任务组并发限制"""
        if group_id not in self._group_limits:
            return True
        
        limit = self._group_limits[group_id]
        count = self._group_counts.get(group_id, 0)
        
        return count < limit

    async def get_task_status(self, task_id: str) -> Optional[QueuedTask]:
        """获取任务状态"""
        return self._tasks.get(task_id)

    async def cancel_task(self, task_id: str) -> bool:
        """取消任务"""
        task = self._tasks.get(task_id)
        if not task:
            return False
        
        async with self._lock:
            if task.status == TaskStatus.PENDING:
                task.status = TaskStatus.CANCELLED
                self._stats["cancelled_tasks"] += 1
                logger.info(f"任务已取消: {task_id}")
                return True
            
            return False

    async def get_queue_stats(self) -> Dict[str, Any]:
        """获取队列统计信息"""
        async with self._lock:
            pending_count = sum(1 for t in self._tasks.values() if t.status == TaskStatus.PENDING)
            running_count = sum(1 for t in self._tasks.values() if t.status == TaskStatus.RUNNING)
            
            completed = self._stats["completed_tasks"] + self._stats["failed_tasks"] + self._stats["timeout_tasks"]
            elapsed = time.time() - self._stats["last_reset_time"]
            
            throughput = completed / elapsed if elapsed > 0 else 0
            
            return {
                "max_concurrent_tasks": self._max_concurrent_tasks,
                "current_running_tasks": self._running_tasks,
                "pending_tasks": pending_count,
                "running_tasks": running_count,
                "queue_size": self._queue.qsize(),
                "peak_queue_size": self._stats["peak_queue_size"],
                "peak_concurrent": self._stats["peak_concurrent"],
                "throughput": throughput,
                **self._stats
            }

    async def clear_queue(self):
        """清空队列"""
        async with self._lock:
            while not self._queue.empty():
                try:
                    self._queue.get_nowait()
                except asyncio.QueueEmpty:
                    pass
            
            for task_id, task in list(self._tasks.items()):
                if task.status == TaskStatus.PENDING:
                    task.status = TaskStatus.CANCELLED
                    self._stats["cancelled_tasks"] += 1
            
            logger.info("队列已清空")

    def resize(self, max_concurrent_tasks: int):
        """动态调整最大并发数"""
        self._max_concurrent_tasks = max_concurrent_tasks
        logger.info(f"队列并发数已调整为: {max_concurrent_tasks}")

    async def reset_stats(self):
        """重置统计信息"""
        async with self._lock:
            self._stats = {
                "total_tasks": 0,
                "completed_tasks": 0,
                "failed_tasks": 0,
                "cancelled_tasks": 0,
                "timeout_tasks": 0,
                "pending_tasks": 0,
                "running_tasks": 0,
                "average_wait_time": 0,
                "average_execution_time": 0,
                "total_wait_time": 0,
                "total_execution_time": 0,
                "retry_count": 0,
                "dropped_tasks": 0,
                "peak_queue_size": 0,
                "peak_concurrent": 0,
                "throughput": 0,
                "last_reset_time": time.time()
            }

    async def _worker_loop(self, worker_name: str):
        """工作线程主循环"""
        while self._is_running:
            try:
                queued_task = await asyncio.wait_for(
                    self._queue.get(), 
                    timeout=1.0
                )
            except asyncio.TimeoutError:
                continue
            
            try:
                if queued_task.status == TaskStatus.CANCELLED:
                    self._queue.task_done()
                    continue
                
                async with self._lock:
                    if self._running_tasks >= self._max_concurrent_tasks:
                        await self._queue.put(queued_task)
                        await asyncio.sleep(0.05)
                        continue
                    
                    if queued_task.group_id:
                        if not await self._check_group_limit(queued_task.group_id):
                            await self._queue.put(queued_task)
                            await asyncio.sleep(0.1)
                            continue
                    
                    self._running_tasks += 1
                    if queued_task.group_id:
                        self._group_counts[queued_task.group_id] = self._group_counts.get(queued_task.group_id, 0) + 1
                    
                    if self._running_tasks > self._stats["peak_concurrent"]:
                        self._stats["peak_concurrent"] = self._running_tasks
                    
                    queued_task.status = TaskStatus.RUNNING
                    queued_task.started_at = time.time()
                
                await self._execute_task(queued_task)
            
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"工作线程 {worker_name} 异常: {str(e)}")
            finally:
                async with self._lock:
                    self._running_tasks -= 1
                    if queued_task.group_id:
                        self._group_counts[queued_task.group_id] = max(0, self._group_counts.get(queued_task.group_id, 0) - 1)
                
                self._queue.task_done()

    async def _execute_task(self, queued_task: QueuedTask):
        """执行任务（带超时和重试）"""
        wait_time = queued_task.started_at - queued_task.created_at
        self._stats["total_wait_time"] += wait_time
        
        try:
            if asyncio.iscoroutinefunction(queued_task.func):
                if queued_task.timeout:
                    result = await asyncio.wait_for(
                        queued_task.func(*queued_task.args, **queued_task.kwargs),
                        timeout=queued_task.timeout
                    )
                else:
                    result = await queued_task.func(*queued_task.args, **queued_task.kwargs)
            else:
                if queued_task.timeout:
                    result = await asyncio.wait_for(
                        asyncio.to_thread(queued_task.func, *queued_task.args, **queued_task.kwargs),
                        timeout=queued_task.timeout
                    )
                else:
                    result = await asyncio.to_thread(
                        queued_task.func, *queued_task.args, **queued_task.kwargs
                    )
            
            execution_time = time.time() - queued_task.started_at
            self._stats["total_execution_time"] += execution_time
            
            queued_task.result = result
            queued_task.status = TaskStatus.COMPLETED
            queued_task.completed_at = time.time()
            
            self._stats["completed_tasks"] += 1
            logger.debug(f"任务完成: {queued_task.task_id}, 耗时: {execution_time:.2f}s")
        
        except asyncio.TimeoutError:
            queued_task.error = "任务执行超时"
            queued_task.status = TaskStatus.TIMEOUT
            queued_task.completed_at = time.time()
            
            self._stats["timeout_tasks"] += 1
            logger.warning(f"任务超时: {queued_task.task_id}")
            
            await self._handle_retry(queued_task)
        
        except Exception as e:
            queued_task.error = str(e)
            queued_task.status = TaskStatus.FAILED
            queued_task.completed_at = time.time()
            
            self._stats["failed_tasks"] += 1
            logger.error(f"任务失败: {queued_task.task_id}, 错误: {str(e)}")
            
            await self._handle_retry(queued_task)

    async def _handle_retry(self, queued_task: QueuedTask):
        """处理任务重试"""
        if queued_task.retry_count < queued_task.max_retries:
            queued_task.retry_count += 1
            queued_task.status = TaskStatus.PENDING
            queued_task.created_at = time.time()
            queued_task.started_at = None
            queued_task.completed_at = None
            queued_task.error = None
            
            self._stats["retry_count"] += 1
            
            delay = min(2 ** queued_task.retry_count * 0.5, 10.0)
            await asyncio.sleep(delay)
            
            self._queue.put_nowait(queued_task)
            logger.info(f"任务重试 {queued_task.retry_count}/{queued_task.max_retries}: {queued_task.task_id}")

    async def _stats_monitor(self):
        """统计信息监控"""
        while self._is_running:
            await asyncio.sleep(60)
            stats = await self.get_queue_stats()
            
            completed = stats["completed_tasks"]
            if completed > 0:
                stats["average_wait_time"] = stats["total_wait_time"] / completed
                stats["average_execution_time"] = stats["total_execution_time"] / completed
            
            logger.debug(f"队列统计: 完成={stats['completed_tasks']}, 失败={stats['failed_tasks']}, "
                        f"超时={stats['timeout_tasks']}, 等待时间={stats['average_wait_time']:.2f}s, "
                        f"执行时间={stats['average_execution_time']:.2f}s")

task_queue_manager = TaskQueueManager(
    max_concurrent_tasks=5,
    queue_maxsize=200,
    full_strategy=QueueFullStrategy.WAIT,
    default_timeout=60.0
)