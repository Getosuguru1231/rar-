﻿import asyncio
import aiomysql
from typing import Optional, Dict, Any, List
from settings import MYSQL_CONFIG

class AsyncDBManager:
    def __init__(self):
        self.pool: Optional[aiomysql.Pool] = None
        self._initialized = False
    
    async def init_pool(self) -> None:
        if self._initialized and self.pool:
            return
        
        try:
            self.pool = await aiomysql.create_pool(
                host=MYSQL_CONFIG['host'],
                port=MYSQL_CONFIG['port'],
                user=MYSQL_CONFIG['user'],
                password=MYSQL_CONFIG['password'],
                db=MYSQL_CONFIG['database'],
                minsize=5,
                maxsize=20,
                echo=False,
                autocommit=True
            )
            self._initialized = True
        except Exception as e:
            raise RuntimeError(f"Failed to initialize database pool: {str(e)}")
    
    async def execute(self, sql: str, args: Optional[tuple] = None) -> List[Dict[str, Any]]:
        if not self.pool:
            await self.init_pool()
        
        async with self.pool.acquire() as conn:
            async with conn.cursor(aiomysql.DictCursor) as cur:
                await cur.execute(sql, args)
                return await cur.fetchall()
    
    async def execute_one(self, sql: str, args: Optional[tuple] = None) -> Optional[Dict[str, Any]]:
        results = await self.execute(sql, args)
        return results[0] if results else None
    
    async def execute_update(self, sql: str, args: Optional[tuple] = None) -> int:
        if not self.pool:
            await self.init_pool()
        
        async with self.pool.acquire() as conn:
            async with conn.cursor() as cur:
                await cur.execute(sql, args)
                return cur.rowcount
    
    async def close(self) -> None:
        if self.pool:
            self.pool.close()
            await self.pool.wait_closed()
            self._initialized = False

async_db_manager = AsyncDBManager()