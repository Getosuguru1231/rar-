import cv2
import numpy as np
import time
import redis
import sys

REDIS_HOST = "localhost"
REDIS_PORT = 6379
REDIS_DB = 0
REDIS_FRAME_EXPIRE = 60

def create_test_frame(camera_id, frame_num):
    frame = np.zeros((480, 640, 3), dtype=np.uint8)
    
    bg_color = [(50, 50, 50), (30, 60, 30), (30, 30, 60), (60, 60, 30)][camera_id % 4]
    frame[:] = bg_color
    
    cv2.putText(frame, f"摄像头 {camera_id}", (100, 150), cv2.FONT_HERSHEY_SIMPLEX, 2, (255, 255, 255), 3)
    cv2.putText(frame, f"帧: {frame_num}", (150, 220), cv2.FONT_HERSHEY_SIMPLEX, 1.5, (255, 200, 100), 2)
    cv2.putText(frame, time.strftime("%H:%M:%S", time.localtime()), (180, 280), cv2.FONT_HERSHEY_SIMPLEX, 1, (100, 255, 200), 2)
    
    status_color = (0, 255, 0) if camera_id == 1 else (255, 165, 0)
    cv2.circle(frame, (580, 60), 25, status_color, -1)
    cv2.putText(frame, "ON", (570, 67), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 0), 2)
    
    cv2.rectangle(frame, (20, 350), (620, 460), (255, 255, 255), 2)
    cv2.putText(frame, "溺水监测系统 - 智能AI检测", (50, 400), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)
    cv2.putText(frame, "实时监控中...", (200, 440), cv2.FONT_HERSHEY_SIMPLEX, 1, (100, 255, 100), 2)
    
    encode_params = [int(cv2.IMWRITE_JPEG_QUALITY), 85]
    _, buffer = cv2.imencode('.jpg', frame, encode_params)
    return buffer.tobytes()

def main():
    try:
        r = redis.Redis(host=REDIS_HOST, port=REDIS_PORT, db=REDIS_DB)
        r.ping()
        print("[OK] Redis连接成功")
    except Exception as e:
        print(f"[ERROR] Redis连接失败: {e}")
        sys.exit(1)
    
    frame_num = 0
    cameras = [1, 2, 3, 4]
    
    print(f"开始生成测试帧... (摄像头: {cameras})")
    print("按 Ctrl+C 停止")
    
    try:
        while True:
            frame_num += 1
            for camera_id in cameras:
                frame_data = create_test_frame(camera_id, frame_num)
                r.setex(f"current_frame_{camera_id}", REDIS_FRAME_EXPIRE, frame_data)
                r.setex(f"current_frame_timestamp_{camera_id}", REDIS_FRAME_EXPIRE, str(time.time()))
                
                if camera_id == 1:
                    r.setex("current_frame", REDIS_FRAME_EXPIRE, frame_data)
                    r.setex("current_frame_timestamp", REDIS_FRAME_EXPIRE, str(time.time()))
            
            if frame_num % 30 == 0:
                print(f"已生成 {frame_num} 帧")
            
            time.sleep(0.033)
            
    except KeyboardInterrupt:
        print(f"\n停止生成，共生成 {frame_num} 帧")
        sys.exit(0)

if __name__ == "__main__":
    main()