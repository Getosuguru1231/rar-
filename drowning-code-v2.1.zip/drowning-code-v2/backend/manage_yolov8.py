# YOLOv8 模型信息查看和管理工具
# 用于检查模型状态、切换模型等

import os
import sys

# 添加项目根目录到路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from settings import MODEL_PATH, YOLOV8_PROJECT_DIR, CUSTOM_MODEL_PATH, DEFAULT_MODEL_PATH

def print_section(title):
    """打印分隔线"""
    print("\n" + "="*60)
    print(f"  {title}")
    print("="*60)

def check_model_files():
    """检查所有可能的模型文件位置"""
    print_section("模型文件检查")
    
    paths_to_check = [
        ("自定义训练模型", CUSTOM_MODEL_PATH),
        ("默认预训练模型", DEFAULT_MODEL_PATH),
        ("当前使用模型", MODEL_PATH),
        ("YOLOv8 项目目录", YOLOV8_PROJECT_DIR),
    ]
    
    for name, path in paths_to_check:
        if os.path.exists(path):
            size = os.path.getsize(path) / 1024 / 1024 if os.path.isfile(path) else 0
            print(f"✅ {name}: {path}")
            if size > 0:
                print(f"   文件大小：{size:.2f} MB")
        else:
            print(f"❌ {name}: {path} (不存在)")
    
    # 检查外部项目中的其他可能位置
    print_section("外部项目中的模型文件")
    possible_paths = [
        os.path.join(YOLOV8_PROJECT_DIR, "runs", "detect", "train", "weights", "best.pt"),
        os.path.join(YOLOV8_PROJECT_DIR, "runs", "detect", "train", "weights", "last.pt"),
        os.path.join(YOLOV8_PROJECT_DIR, "weights", "best.pt"),
        os.path.join(YOLOV8_PROJECT_DIR, "best.pt"),
        os.path.join(YOLOV8_PROJECT_DIR, "yolov8n.pt"),
        os.path.join(YOLOV8_PROJECT_DIR, "yolov8s.pt"),
        os.path.join(YOLOV8_PROJECT_DIR, "yolov8m.pt"),
        os.path.join(YOLOV8_PROJECT_DIR, "yolov8l.pt"),
        os.path.join(YOLOV8_PROJECT_DIR, "yolov8x.pt"),
    ]
    
    found_models = []
    for path in possible_paths:
        if os.path.exists(path):
            size = os.path.getsize(path) / 1024 / 1024
            found_models.append((path, size))
            print(f"✅ 找到模型：{path}")
            print(f"   大小：{size:.2f} MB")
    
    if not found_models:
        print("⚠️  未在外部项目中找到任何模型文件")
    
    return found_models

def verify_model():
    """验证模型是否可以正常加载"""
    print_section("模型验证")
    
    try:
        from ultralytics import YOLO
        
        print(f"尝试加载模型：{MODEL_PATH}")
        model = YOLO(MODEL_PATH)
        
        print(f"✅ 模型加载成功！")
        print(f"   类别数量：{len(model.names)}")
        print(f"   类别列表：")
        for idx, name in model.names.items():
            print(f"     {idx}: {name}")
        
        return True
        
    except Exception as e:
        print(f"❌ 模型加载失败：{str(e)}")
        return False

def list_available_models(found_models):
    """列出可用的模型"""
    print_section("可用模型列表")
    
    if not found_models:
        print("⚠️  未找到可用模型")
        return
    
    for i, (path, size) in enumerate(found_models, 1):
        print(f"{i}. {os.path.basename(path)}")
        print(f"   路径：{path}")
        print(f"   大小：{size:.2f} MB")
        print()

def switch_model(found_models):
    """切换模型"""
    print_section("切换模型")
    
    if not found_models:
        print("⚠️  没有可用模型")
        return
    
    print("请选择要切换的模型编号：")
    for i, (path, size) in enumerate(found_models, 1):
        print(f"{i}. {os.path.basename(path)} ({size:.2f} MB)")
    
    try:
        choice = int(input("\n输入编号 (或按 Enter 取消): ").strip())
        if 1 <= choice <= len(found_models):
            selected_path = found_models[choice - 1][0]
            
            # 更新 settings.py（临时）
            print(f"\n✅ 已选择模型：{os.path.basename(selected_path)}")
            print(f"💡 提示：要永久切换模型，请编辑 backend/settings.py")
            print(f"   将 MODEL_PATH 设置为：{selected_path}")
            
            # 测试加载
            from ultralytics import YOLO
            print("\n🔄 测试加载模型...")
            model = YOLO(selected_path)
            print(f"✅ 模型加载成功！")
            
        else:
            print("⚠️  无效的选择")
    except ValueError:
        print("ℹ️  已取消")
    except Exception as e:
        print(f"❌ 错误：{str(e)}")

def main():
    """主函数"""
    print("="*60)
    print("  YOLOv8 模型管理工具")
    print("="*60)
    
    # 1. 检查模型文件
    found_models = check_model_files()
    
    # 2. 验证当前模型
    if os.path.exists(MODEL_PATH):
        verify_model()
    
    # 3. 列出可用模型
    list_available_models(found_models)
    
    # 4. 询问是否切换模型
    if found_models:
        choice = input("\n是否要切换模型？(y/n): ").strip().lower()
        if choice == 'y':
            switch_model(found_models)
    
    print_section("完成")
    print("💡 下一步操作:")
    print("  1. 启动系统：python main.py")
    print("  2. 查看实时检测效果")
    print("  3. 如需切换模型，再次运行此脚本")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n⚠️  用户中断")
    except Exception as e:
        print(f"\n❌ 发生错误：{str(e)}")
        import traceback
        traceback.print_exc()
