#!/usr/bin/env python
"""生产环境启动脚本 - 禁用reloader避免重复启动检测线程"""

import subprocess
import sys

if __name__ == "__main__":
    # 使用--reload-dir指定只监视特定目录，避免不必要的重启
    cmd = [
        sys.executable, "-m", "uvicorn",
        "main:app",
        "--host", "0.0.0.0",
        "--port", "8002",
        "--workers", "1",
        "--loop", "asyncio"
    ]
    
    print("🚀 启动智能溺水检测系统（生产模式）...")
    print(f"命令: {' '.join(cmd)}")
    
    subprocess.run(cmd)
