import torch
import torch.nn as nn
import os
import sys
import ast
import contextlib
from typing import Optional

# 添加根目录到路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

# 导入外部模块
from extra_modules import (
    ReflectionReduction, ShadowReduction, EdgeAwareAttention,
    TripletAtt, SE, CBAM, SimAM, EMA, SpatialAttention,
    HybridC2fC3K2, EnhancedC2f, HighPrecisionC2f, MANet,
    ASPP, DySample, CARAFE, DepthwiseConv, CoordConv, CustomConcat,
)

class CompatibleDetect(nn.Module):
    def __init__(self, nc=3, anchors=None, ch=()):
        super().__init__()
        self.nc = nc
        self.no = nc + 5
        if anchors is None:
            anchors = [[10,13, 16,30, 33,23], [30,61, 62,45, 59,119], [116,90, 156,198, 373,326]]
        self.anchors = torch.tensor(anchors).float().view(3, -1, 2)
        self.stride = torch.tensor([8., 16., 32.])
        self.grid = [torch.zeros(1)] * 3
        self.register_buffer('anchor_grid', self.anchors.clone().view(3, 1, -1, 1, 1, 2))
        self.na = len(anchors[0]) // 2
        if ch:
            self.m = nn.ModuleList(nn.Conv2d(x, self.no * self.na, 1) for x in ch)
        else:
            self.m = None

    def forward(self, x):
        z = []
        for i in range(3):
            if self.m is not None:
                x[i] = self.m[i](x[i])
            bs, _, ny, nx = x[i].shape
            x[i] = x[i].view(bs, self.na, self.no, ny, nx).permute(0, 1, 3, 4, 2).contiguous()

            if not self.training:
                if self.grid[i].shape[2:4] != x[i].shape[2:4]:
                    self.grid[i] = self._make_grid(nx, ny).to(x[i].device)

                y = x[i].sigmoid()
                y[..., 0:2] = (y[..., 0:2] * 2. - 0.5 + self.grid[i]) * self.stride[i]
                y[..., 2:4] = (y[..., 2:4] * 2) ** 2 * self.anchor_grid[i]
                z.append(y.view(bs, -1, self.no))

        return x if self.training else (torch.cat(z, 1),)

    def _make_grid(self, nx=20, ny=20):
        yv, xv = torch.meshgrid([torch.arange(ny), torch.arange(nx)], indexing='ij')
        return torch.stack((xv, yv), 2).view((1, 1, ny, nx, 2)).float()

def make_divisible(x, divisor=8, min_value=None):
    if min_value is None:
        min_value = divisor
    return int(max(min_value, ((int(x) + divisor - 1) // divisor) * divisor))

def patch_yolo_modules():
    """补丁YOLO模块以支持自定义模块"""
    try:
        import ultralytics.nn.tasks as tasks_module
        
        modules_to_register = {
            'ReflectionReduction': ReflectionReduction,
            'ShadowReduction': ShadowReduction,
            'EdgeAwareAttention': EdgeAwareAttention,
            'TripletAtt': TripletAtt,
            'SE': SE,
            'CBAM': CBAM,
            'SimAM': SimAM,
            'EMA': EMA,
            'SpatialAttention': SpatialAttention,
            'HybridC2fC3K2': HybridC2fC3K2,
            'EnhancedC2f': EnhancedC2f,
            'HighPrecisionC2f': HighPrecisionC2f,
            'MANet': MANet,
            'ASPP': ASPP,
            'DySample': DySample,
            'CARAFE': CARAFE,
            'DepthwiseConv': DepthwiseConv,
            'CoordConv': CoordConv,
            'CustomConcat': CustomConcat,
            'CompatibleDetect': CompatibleDetect,
        }

        for name, module in modules_to_register.items():
            setattr(tasks_module, name, module)

        original_parse_model = tasks_module.parse_model

        def patched_parse_model(d, ch, verbose=True):
            from ultralytics.nn.modules import Conv, ConvTranspose, GhostConv, Bottleneck, GhostBottleneck
            from ultralytics.nn.modules import SPP, SPPF, DWConv, Focus, BottleneckCSP, Concat
            from ultralytics.nn.modules import C1, C2, C2f, RepNCSPELAN4, ADown, SPPELAN, C2fAttn
            from ultralytics.nn.modules import C3, C3TR, C3Ghost, RepC3, C3x
            from ultralytics.nn.modules.head import Detect, WorldDetect, Segment, Pose, OBB
            from ultralytics.nn.modules.block import ResNetLayer, HGStem, HGBlock
            from ultralytics.nn.modules.transformer import AIFI

            same_channel_modules = {
                ReflectionReduction, ShadowReduction, EdgeAwareAttention,
                TripletAtt, SE, CBAM, SimAM, EMA, SpatialAttention,
                ASPP, DySample
            }

            change_channel_modules = {
                DepthwiseConv, CoordConv, HybridC2fC3K2,
                EnhancedC2f, HighPrecisionC2f, MANet, CARAFE
            }

            module_dict = {
                'Conv': Conv, 'ConvTranspose': ConvTranspose, 'GhostConv': GhostConv,
                'Bottleneck': Bottleneck, 'GhostBottleneck': GhostBottleneck,
                'SPP': SPP, 'SPPF': SPPF, 'DWConv': DWConv, 'Focus': Focus,
                'BottleneckCSP': BottleneckCSP, 'C1': C1, 'C2': C2, 'C2f': C2f,
                'RepNCSPELAN4': RepNCSPELAN4, 'ADown': ADown, 'SPPELAN': SPPELAN,
                'C2fAttn': C2fAttn, 'C3': C3, 'C3TR': C3TR, 'C3Ghost': C3Ghost,
                'C3x': C3x, 'RepC3': RepC3, 'Concat': Concat,
                'Detect': Detect, 'WorldDetect': WorldDetect, 'Segment': Segment,
                'Pose': Pose, 'OBB': OBB,
                'ResNetLayer': ResNetLayer, 'HGStem': HGStem, 'HGBlock': HGBlock,
                'AIFI': AIFI,
                'ReflectionReduction': ReflectionReduction,
                'ShadowReduction': ShadowReduction,
                'EdgeAwareAttention': EdgeAwareAttention,
                'TripletAtt': TripletAtt, 'SE': SE, 'CBAM': CBAM, 'SimAM': SimAM,
                'EMA': EMA, 'SpatialAttention': SpatialAttention,
                'HybridC2fC3K2': HybridC2fC3K2, 'EnhancedC2f': EnhancedC2f,
                'HighPrecisionC2f': HighPrecisionC2f, 'MANet': MANet,
                'ASPP': ASPP, 'DySample': DySample, 'CARAFE': CARAFE,
                'DepthwiseConv': DepthwiseConv, 'CoordConv': CoordConv,
                'CustomConcat': CustomConcat,
                'CompatibleDetect': CompatibleDetect,
            }

            max_channels = float("inf")
            nc, act, scales = (d.get(x) for x in ("nc", "activation", "scales"))
            depth, width, kpt_shape = (d.get(x, 1.0) for x in ("depth_multiple", "width_multiple", "kpt_shape"))

            if scales:
                scale = d.get("scale")
                if not scale:
                    scale = tuple(scales.keys())[0]
                depth, width, max_channels = scales[scale]

            if act:
                Conv.default_act = eval(act)

            if verbose:
                from ultralytics.utils import LOGGER, colorstr
                LOGGER.info(f"{colorstr('activation:')} {act}")
                LOGGER.info(f"\n{'':>3}{'from':>20}{'n':>3}{'params':>10} {'module':<45}{'arguments':<30}")

            ch = [ch]
            layers, save, c2 = [], [], ch[-1]

            for i, (f, n, m, args) in enumerate(d["backbone"] + d["head"]):
                if "nn." in m:
                    m = getattr(torch.nn, m[3:])
                elif m in module_dict:
                    m = module_dict[m]
                else:
                    m = globals()[m]

                for j, a in enumerate(args):
                    if isinstance(a, str):
                        with contextlib.suppress(ValueError):
                            args[j] = locals()[a] if a in locals() else ast.literal_eval(a)

                n = n_ = max(round(n * depth), 1) if n > 1 else n

                if isinstance(f, list):
                    if m is Concat or m is CustomConcat:
                        c2 = sum(ch[x] for x in f)
                        if len(args) == 1:
                            args = [c2, c2, args[0]]
                    elif m in {Detect, WorldDetect, Segment, Pose, OBB, CompatibleDetect}:
                        reg_max = d.get('reg_max', 16)
                        end2end = d.get('end2end', False)
                        if isinstance(f, list):
                            c2 = max(ch[x] for x in f)
                            args.extend([reg_max, end2end, [ch[x] for x in f]])
                        else:
                            c2 = ch[f]
                            args.extend([reg_max, end2end, [ch[f]]])
                        if m is Segment:
                            if len(args) > 2:
                                args[2] = make_divisible(min(args[2], max_channels) * width, 8)
                    else:
                        c1 = max(ch[x] for x in f)
                        c2 = args[0] if args else c1
                        if c2 != nc:
                            c2 = make_divisible(min(c2, max_channels) * width, 8)
                        args = [c1, c2, *args[1:]]
                elif m in same_channel_modules:
                    c1, c2 = ch[f], ch[f]
                    args = [c1, *args]
                    n = 1
                elif m in change_channel_modules:
                    if isinstance(f, list):
                        c1 = sum(ch[x] for x in f) if m is CustomConcat else max(ch[x] for x in f)
                    else:
                        c1 = ch[f]
                    c2 = args[0] if args else c1
                    if c2 != nc:
                        c2 = make_divisible(min(c2, max_channels) * width, 8)
                    args = [c1, c2, *args[1:]]
                    if m in (HybridC2fC3K2, EnhancedC2f, HighPrecisionC2f, MANet):
                        args.insert(2, n)
                        n = 1
                else:
                    if m in {
                        Conv, ConvTranspose, GhostConv, Bottleneck, GhostBottleneck,
                        SPP, SPPF, DWConv, Focus, BottleneckCSP,
                        C1, C2, C2f, RepNCSPELAN4, ADown, SPPELAN, C2fAttn,
                        C3, C3TR, C3Ghost, C3x, RepC3,
                        torch.nn.ConvTranspose2d,
                    }:
                        c1, c2 = ch[f], args[0]
                        if c2 != nc:
                            c2 = make_divisible(min(c2, max_channels) * width, 8)
                        args = [c1, c2, *args[1:]]
                        if m in (BottleneckCSP, C1, C2, C2f, C2fAttn, C3, C3TR, C3Ghost, C3x, RepC3):
                            args.insert(2, n)
                            n = 1
                    elif m is AIFI:
                        args = [ch[f], *args]
                    elif m in {HGStem, HGBlock}:
                        c1, cm, c2 = ch[f], args[0], args[1]
                        args = [c1, cm, c2, *args[2:]]
                        if m is HGBlock:
                            args.insert(4, n)
                            n = 1
                    elif m is ResNetLayer:
                        c2 = args[1] if args[3] else args[1] * 4
                    elif m is torch.nn.BatchNorm2d:
                        args = [ch[f]]
                    else:
                        c2 = ch[f]

                m_ = torch.nn.Sequential(*(m(*args) for _ in range(n))) if n > 1 else m(*args)
                t = str(m)[8:-2].replace("__main__.", "")
                m.np = sum(x.numel() for x in m_.parameters())
                m_.i, m_.f, m_.type = i, f, t

                if verbose:
                    from ultralytics.utils import LOGGER
                    LOGGER.info(f"{i:>3}{str(f):>20}{n_:>3}{m.np:10.0f} {t:<45}{str(args):<30}")

                save.extend(x % i for x in ([f] if isinstance(f, int) else f) if x != -1)
                layers.append(m_)
                if i == 0:
                    ch = []
                ch.append(c2)

            return torch.nn.Sequential(*layers), sorted(save)

        tasks_module.parse_model = patched_parse_model
        print("[YOLO Patch] ✅ 自定义模块补丁成功")
        return True
    except Exception as e:
        print(f"[YOLO Patch] ❌ 补丁失败: {e}")
        import traceback
        traceback.print_exc()
        return False

def load_yolo_model(config_path: Optional[str] = None, weights_path: Optional[str] = None) -> Optional[torch.nn.Module]:
    """加载YOLO模型"""
    try:
        # 先应用补丁
        patch_yolo_modules()
        
        from ultralytics import YOLO
        
        # 检测GPU可用性
        device = 'cuda' if torch.cuda.is_available() else 'cpu'
        print(f"[YOLO Model] 计算设备: {device}")
        if device == 'cuda':
            print(f"[YOLO Model] GPU: {torch.cuda.get_device_name(0)}")
        else:
            print(f"[YOLO Model] ⚠️ GPU不可用，使用CPU模式")
        
        # 确定模型路径
        root_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        if weights_path is None:
            weights_path = os.path.join(root_dir, 'best.pt')
        
        print(f"[YOLO Model] 权重文件: {weights_path}")
        
        # 检查权重文件是否存在
        if not os.path.exists(weights_path):
            print(f"[YOLO Model] ❌ 权重文件不存在: {weights_path}")
            return None
        
        # 尝试加载模型
        # 优先尝试使用配置文件，如果不存在则直接从权重文件加载
        if config_path is None:
            config_path = os.path.join(root_dir, '3model.yaml')
        
        if os.path.exists(config_path):
            print(f"[YOLO Model] 配置文件: {config_path}")
            model = YOLO(config_path)
            model.load(weights_path)
        else:
            print(f"[YOLO Model] ⚠️ 配置文件不存在，直接从权重文件加载")
            model = YOLO(weights_path)
        
        # 将模型移动到指定设备
        model.to(device)
        print(f"[YOLO Model] ✅ 模型加载成功，已移动到 {device}")
        
        # 切换到评估模式
        model.eval()
        return model
    
    except Exception as e:
        print(f"[YOLO Model] ❌ 加载失败: {e}")
        import traceback
        traceback.print_exc()
        return None
