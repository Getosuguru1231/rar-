# backend/models/__init__.py
"""
Models Package

提供 YOLO 模型加载和管理功能
"""

import os
from ultralytics import YOLO
from settings import MODEL_PATH

# 全局模型实例
_model_instance = None

def get_yolo_model():
    """
    获取 YOLO 模型单例
    :return: YOLO 模型实例
    """
    global _model_instance
    if _model_instance is None:
        print(f"[Models] 加载 YOLO 模型: {MODEL_PATH}")
        _model_instance = YOLO(MODEL_PATH)
        print(f"[Models] YOLO 模型加载完成")
    return _model_instance

def reload_yolo_model(new_model_path=None):
    """
    重新加载 YOLO 模型
    :param new_model_path: 新的模型路径，如果为 None 则使用 settings 中的 MODEL_PATH
    :return: 新的 YOLO 模型实例
    """
    global _model_instance
    if new_model_path:
        model_path = new_model_path
    else:
        model_path = MODEL_PATH
    
    print(f"[Models] 重新加载 YOLO 模型: {model_path}")
    _model_instance = YOLO(model_path)
    print(f"[Models] YOLO 模型重新加载完成")
    return _model_instance

__all__ = ['get_yolo_model', 'reload_yolo_model']
