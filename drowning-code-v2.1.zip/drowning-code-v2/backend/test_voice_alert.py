"""语音告警测试脚本"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def test_voice_alert():
    """测试语音告警功能"""
    print("=" * 50)
    print("        语音播报功能测试")
    print("=" * 50)
    
    # 测试1: 测试基础语音播报
    print("\n[测试1] 基础语音播报测试")
    from alert import voice_alert, test_voice
    try:
        result = test_voice()
        if result:
            print("  ✅ 基础语音播报测试通过")
        else:
            print("  ❌ 基础语音播报测试失败")
    except Exception as e:
        print(f"  ❌ 基础语音播报测试异常: {e}")
    
    # 测试2: 测试告警级别转换
    print("\n[测试2] 告警级别转换测试")
    try:
        level_text = {
            "high": "高",
            "medium": "中",
            "low": "低"
        }
        assert level_text["high"] == "高"
        assert level_text["medium"] == "中"
        assert level_text["low"] == "低"
        print("  ✅ 告警级别转换测试通过")
    except Exception as e:
        print(f"  ❌ 告警级别转换测试异常: {e}")
    
    # 测试3: 测试语音配置
    print("\n[测试3] 语音配置测试")
    try:
        from settings import VOICE_ENABLED, VOICE_RATE, VOICE_VOLUME, VOICE_WAIT_INTERVAL
        print(f"  - VOICE_ENABLED: {VOICE_ENABLED}")
        print(f"  - VOICE_RATE: {VOICE_RATE}")
        print(f"  - VOICE_VOLUME: {VOICE_VOLUME}")
        print(f"  - VOICE_WAIT_INTERVAL: {VOICE_WAIT_INTERVAL}")
        print("  ✅ 语音配置测试通过")
    except Exception as e:
        print(f"  ❌ 语音配置测试异常: {e}")
    
    # 测试4: 测试告警管理器集成
    print("\n[测试4] 告警管理器集成测试")
    try:
        from components.alert_manager import get_alert_manager
        alert_manager = get_alert_manager()
        
        test_alert = {
            "area": "测试区域",
            "reason": "有人在水中",
            "level": "high"
        }
        
        alert_manager._send_notification(test_alert)
        print("  ✅ 告警管理器集成测试通过")
    except Exception as e:
        print(f"  ❌ 告警管理器集成测试异常: {e}")
    
    print("\n" + "=" * 50)
    print("        测试完成")
    print("=" * 50)

if __name__ == "__main__":
    test_voice_alert()
