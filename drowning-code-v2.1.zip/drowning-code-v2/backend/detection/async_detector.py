﻿import asyncio
from concurrent.futures import ProcessPoolExecutor
from ultralytics import YOLO
import cv2
import numpy as np
from typing import List, Dict, Optional, Tuple

class AsyncDetector:
    def __init__(self, model_path: str):
        self.model = None
        self.executor = ProcessPoolExecutor(max_workers=2)
        self._init_model(model_path)
    
    def _init_model(self, model_path: str):
        self.model = YOLO(model_path)
    
    async def detect(self, frame: np.ndarray) -> List[Dict[str, float]]:
        loop = asyncio.get_event_loop()
        result = await loop.run_in_executor(
            self.executor,
            self._detect_sync,
            frame
        )
        return result
    
    def _detect_sync(self, frame: np.ndarray) -> List[Dict[str, float]]:
        results = self.model(
            frame,
            imgsz=640,
            conf=0.35,
            iou=0.4,
            max_det=50,
            verbose=False
        )
        return self._parse_results(results)
    
    def _parse_results(self, results) -> List[Dict[str, float]]:
        detections = []
        for result in results:
            for box in result.boxes:
                detections.append({
                    'class_id': int(box.cls[0].item()),
                    'confidence': float(box.conf[0].item()),
                    'x1': float(box.xyxy[0][0].item()),
                    'y1': float(box.xyxy[0][1].item()),
                    'x2': float(box.xyxy[0][2].item()),
                    'y2': float(box.xyxy[0][3].item())
                })
        return detections
    
    def close(self):
        self.executor.shutdown(wait=True)