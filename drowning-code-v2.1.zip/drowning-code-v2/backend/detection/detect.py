import threading
import cv2
import time
import json
import os
import queue
import hashlib
from datetime import datetime
import numpy as np
import torch

from settings import *
from components.redis_pool import get_redis_connection
from components.frame_buffer import shared_frame_buffer
from components.camera_health import camera_monitor
from components.alert_manager import get_alert_manager
from logging_config import get_logger

logger = get_logger('detection')
camera_logger = get_logger('camera')
performance_logger = get_logger('performance')


class DetectionContext:
    """检测上下文，管理共享资源"""
    
    def __init__(self):
        self.running = True
        self.detection_threads = {}
        self.encode_threads = {}
        self.camera_status = {}
        self.last_detection_times = {}
        self.performance_stats = {}
        self.in_water_consecutive_counts = {}


detection_context = DetectionContext()

redis_client = None

FRAME_QUEUE_MAX_SIZE = 5

SMOOTHING_WINDOW = 2
MIN_CONFIRMED_FRAMES = 1
MAX_LOST_FRAMES = 3


class TrackedObject:
    def __init__(self, track_id, x1, y1, x2, y2, cls, conf):
        self.track_id = track_id
        self.cls = cls
        self.conf = conf
        
        self.history = [(x1, y1, x2, y2)]
        self.smoothed_box = (x1, y1, x2, y2)
        
        self.status = "seen"
        self.confirmed_frames = 1
        self.lost_frames = 0
        
        self.last_seen = datetime.now()
    
    def update(self, x1, y1, x2, y2, conf):
        self.history.append((x1, y1, x2, y2))
        if len(self.history) > SMOOTHING_WINDOW:
            self.history.pop(0)
        
        self.conf = conf
        self.last_seen = datetime.now()
        self.lost_frames = 0
        
        self._smooth_box()
        
        if self.status == "seen":
            self.confirmed_frames += 1
            if self.confirmed_frames >= MIN_CONFIRMED_FRAMES:
                self.status = "confirmed"
    
    def mark_lost(self):
        self.lost_frames += 1
        if self.lost_frames >= MAX_LOST_FRAMES:
            self.status = "lost"
    
    def _smooth_box(self):
        if len(self.history) >= 2:
            x1_vals = [h[0] for h in self.history]
            y1_vals = [h[1] for h in self.history]
            x2_vals = [h[2] for h in self.history]
            y2_vals = [h[3] for h in self.history]
            
            weights = np.linspace(0.2, 1.0, len(self.history))
            weights = weights / weights.sum()
            
            x1 = np.average(x1_vals, weights=weights)
            y1 = np.average(y1_vals, weights=weights)
            x2 = np.average(x2_vals, weights=weights)
            y2 = np.average(y2_vals, weights=weights)
            
            self.smoothed_box = (x1, y1, x2, y2)
        else:
            self.smoothed_box = self.history[-1]
    
    def is_active(self):
        return self.status != "lost"


def get_device():
    if torch.cuda.is_available():
        return "cuda"
    elif torch.backends.mps.is_available():
        return "mps"
    return "cpu"


def get_detection_redis_client(decode_responses=False):
    client = get_redis_connection(decode_responses=decode_responses)
    if client is None:
        logger.error("无法获取Redis连接")
        return None
    try:
        client.ping()
        return client
    except Exception as e:
        logger.error(f"Redis连接验证失败: {str(e)}")
        return None


def update_camera_status(camera_id, status, error=None):
    """更新摄像头状态"""
    detection_context.camera_status[camera_id] = {
        "status": status,
        "error": error,
        "timestamp": datetime.now().isoformat()
    }
    try:
        client = get_detection_redis_client(decode_responses=True)
        if client:
            client.set(
                f"camera_status_{camera_id}",
                json.dumps(detection_context.camera_status[camera_id]),
                ex=60
            )
    except Exception as e:
        camera_logger.error(f"更新摄像头{camera_id}状态失败: {str(e)}")


def start_detection():
    global detection_context
    detection_context.running = True
    detection_context.detection_threads = {}
    detection_context.encode_threads = {}
    
    logger.info("启动检测系统...")
    
    model = None
    device = get_device()
    logger.info(f"检测设备: {device}")
    
    try:
        from ultralytics import YOLO
        model = YOLO(MODEL_PATH)
        logger.info(f"YOLO模型加载成功: {MODEL_PATH}")
        
        logger.info("执行模型warmup...")
        warmup_frame = np.zeros((480, 640, 3), dtype=np.uint8)
        model(
            warmup_frame,
            imgsz=IMGSZ,
            device=device,
            half=device != "cpu",
            verbose=False
        )
        logger.info("模型warmup完成")
    except Exception as e:
        logger.error(f"YOLO模型加载失败: {str(e)}")
        return
    
    enabled_cameras = []
    for camera_id, config in CAMERA_CONFIG.items():
        if config.get("enabled", False) and config.get("source") is not None:
            enabled_cameras.append(camera_id)
            detection_context.camera_status[camera_id] = {
                "status": "starting",
                "error": None,
                "timestamp": datetime.now().isoformat()
            }
    
    if not enabled_cameras:
        logger.warning("没有启用的摄像头")
        return
    
    for camera_id in enabled_cameras:
        cap = None
        try:
            source = get_local_camera_id(camera_id)
            config = CAMERA_CONFIG[camera_id]
            camera_type = config.get("type", "local")
            
            opened = False
            frame_read_success = False
            
            if isinstance(source, str) and (source.startswith("http://") or source.startswith("https://") or source.startswith("rtsp://")):
                camera_logger.info(f"摄像头{camera_id}使用网络流地址: {source}")
                cap = cv2.VideoCapture(source, cv2.CAP_FFMPEG)
                if cap.isOpened():
                    camera_logger.info(f"摄像头{camera_id}网络流打开成功")
                    
                    cap.set(cv2.CAP_PROP_FRAME_WIDTH, config.get("width", 1280))
                    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, config.get("height", 720))
                    cap.set(cv2.CAP_PROP_FPS, config.get("fps", 30))
                    cap.set(cv2.CAP_PROP_BUFFERSIZE, 2)
                    
                    for retry in range(5):
                        ret, test_frame = cap.read()
                        if ret and test_frame is not None and test_frame.size > 0:
                            camera_logger.info(f"摄像头{camera_id}帧获取成功，分辨率: {test_frame.shape[1]}x{test_frame.shape[0]}")
                            opened = True
                            frame_read_success = True
                            break
                        time.sleep(0.2)
                    
                    if not frame_read_success:
                        camera_logger.error(f"摄像头{camera_id}网络流帧获取失败")
                else:
                    camera_logger.error(f"摄像头{camera_id}网络流打开失败")
            elif camera_type == "file":
                camera_logger.info(f"摄像头{camera_id}使用视频文件: {source}")
                cap = cv2.VideoCapture(source)
                if cap.isOpened():
                    camera_logger.info(f"摄像头{camera_id}视频文件打开成功")
                    
                    for retry in range(5):
                        ret, test_frame = cap.read()
                        if ret and test_frame is not None and test_frame.size > 0:
                            camera_logger.info(f"摄像头{camera_id}帧获取成功，分辨率: {test_frame.shape[1]}x{test_frame.shape[0]}")
                            opened = True
                            frame_read_success = True
                            break
                        time.sleep(0.1)
                    
                    if not frame_read_success:
                        camera_logger.error(f"摄像头{camera_id}视频文件帧获取失败")
                else:
                    camera_logger.error(f"摄像头{camera_id}视频文件打开失败")
            else:
                backends = [
                    cv2.CAP_MSMF,
                    cv2.CAP_DSHOW,
                    cv2.CAP_ANY,
                ]
                
                camera_indices = []
                if camera_type == "usb":
                    camera_logger.info(f"摄像头{camera_id}配置为USB摄像头，尝试索引0-2...")
                    camera_indices = [0, 1, 2]
                else:
                    camera_indices = [source]
                
                for camera_idx in camera_indices:
                    for backend in backends:
                        if cap:
                            cap.release()
                        
                        cap = cv2.VideoCapture(camera_idx, backend)
                        if cap.isOpened():
                            camera_logger.info(f"摄像头{camera_id}使用后端{backend}打开成功 (索引={camera_idx})")
                            
                            target_width = config.get("width", 640)
                            target_height = config.get("height", 480)
                            target_fps = config.get("fps", 30)
                            
                            cap.set(cv2.CAP_PROP_FRAME_WIDTH, target_width)
                            cap.set(cv2.CAP_PROP_FRAME_HEIGHT, target_height)
                            cap.set(cv2.CAP_PROP_FPS, target_fps)
                            cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
                            
                            actual_width = cap.get(cv2.CAP_PROP_FRAME_WIDTH)
                            actual_height = cap.get(cv2.CAP_PROP_FRAME_HEIGHT)
                            actual_fps = cap.get(cv2.CAP_PROP_FPS)
                            
                            camera_logger.info(f"摄像头{camera_id}配置: 目标分辨率={target_width}x{target_height}, 实际={actual_width:.0f}x{actual_height:.0f}, 目标FPS={target_fps}, 实际={actual_fps:.1f}")
                            
                            for retry in range(5):
                                ret, test_frame = cap.read()
                                if ret and test_frame is not None and test_frame.size > 0:
                                    frame_std = np.std(test_frame)
                                    camera_logger.info(f"摄像头{camera_id}帧获取成功，分辨率: {test_frame.shape[1]}x{test_frame.shape[0]}, 帧标准差: {frame_std:.2f}")
                                    opened = True
                                    frame_read_success = True
                                    break
                                time.sleep(0.1)
                            
                            if frame_read_success:
                                break
                        else:
                            camera_logger.warning(f"摄像头{camera_id}使用后端{backend}打开索引{camera_idx}失败，尝试下一个...")
                    
                    if frame_read_success:
                        break
            
            if not opened or not frame_read_success:
                camera_logger.error(f"无法打开摄像头{camera_id} (source={source})")
                update_camera_status(camera_id, "error", "无法打开摄像头")
                if cap:
                    cap.release()
                continue
            
            update_camera_status(camera_id, "running")
            
            frame_queue = queue.Queue(maxsize=FRAME_QUEUE_MAX_SIZE)
            
            det_thread = threading.Thread(
                target=detection_worker, 
                args=(model, cap, device, camera_id, frame_queue, config), 
                daemon=True,
                name=f"detection_thread_{camera_id}"
            )
            det_thread.start()
            detection_context.detection_threads[camera_id] = det_thread
            
            enc_thread = threading.Thread(
                target=encode_worker, 
                args=(camera_id, frame_queue), 
                daemon=True,
                name=f"encode_thread_{camera_id}"
            )
            enc_thread.start()
            detection_context.encode_threads[camera_id] = enc_thread
            
        except Exception as e:
            camera_logger.error(f"摄像头{camera_id}打开失败: {str(e)}")
            update_camera_status(camera_id, "error", str(e))
            if cap:
                cap.release()
    
    active_count = len(detection_context.detection_threads)
    if active_count > 0:
        logger.info(f"检测系统已启动 (设备: {device}, 摄像头数: {active_count})")
    else:
        logger.error("没有成功启动任何摄像头")


def _reconnect_camera(camera_id, config):
    """尝试重新连接摄像头"""
    source = get_local_camera_id(camera_id)
    camera_type = config.get("type", "local")
    
    if isinstance(source, str) and (source.startswith("http://") or source.startswith("https://") or source.startswith("rtsp://")):
        camera_logger.info(f"摄像头{camera_id}尝试重连网络流: {source}")
        cap = cv2.VideoCapture(source, cv2.CAP_FFMPEG)
        if cap.isOpened():
            cap.set(cv2.CAP_PROP_FRAME_WIDTH, config.get("width", 1280))
            cap.set(cv2.CAP_PROP_FRAME_HEIGHT, config.get("height", 720))
            cap.set(cv2.CAP_PROP_FPS, config.get("fps", 30))
            cap.set(cv2.CAP_PROP_BUFFERSIZE, 2)
            
            for retry in range(5):
                ret, test_frame = cap.read()
                if ret and test_frame is not None and test_frame.size > 0:
                    camera_logger.info(f"摄像头{camera_id}网络流重连成功，分辨率: {test_frame.shape[1]}x{test_frame.shape[0]}")
                    return cap
                time.sleep(0.2)
            cap.release()
        camera_logger.error(f"摄像头{camera_id}网络流重连失败")
        return None
    
    backends = [cv2.CAP_MSMF, cv2.CAP_DSHOW, cv2.CAP_ANY]
    
    camera_indices = []
    if camera_type == "usb":
        camera_logger.info(f"摄像头{camera_id}配置为USB摄像头，正在枚举所有可用摄像头...")
        for i in range(5):
            temp_cap = cv2.VideoCapture(i, cv2.CAP_DSHOW)
            if temp_cap.isOpened():
                camera_indices.append(i)
                temp_cap.release()
        camera_logger.info(f"摄像头{camera_id}发现可用摄像头索引: {camera_indices}")
        if not camera_indices:
            camera_logger.error(f"摄像头{camera_id}未发现任何可用摄像头")
            return None
        camera_indices.sort(reverse=True)
    else:
        camera_indices = [source]
    
    for camera_idx in camera_indices:
        for backend in backends:
            cap = cv2.VideoCapture(camera_idx, backend)
            if cap.isOpened():
                cap.set(cv2.CAP_PROP_FRAME_WIDTH, config.get("width", 1280))
                cap.set(cv2.CAP_PROP_FRAME_HEIGHT, config.get("height", 720))
                cap.set(cv2.CAP_PROP_FPS, config.get("fps", 30))
                cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
                
                for retry in range(3):
                    ret, test_frame = cap.read()
                    if ret and test_frame is not None and test_frame.size > 0:
                        camera_logger.info(f"摄像头{camera_id}重连成功，索引={camera_idx}")
                        return cap
                    time.sleep(0.1)
                cap.release()
    
    camera_logger.error(f"摄像头{camera_id}所有后端都无法打开")
    return None


def detection_worker(model, cap, device, camera_id, frame_queue, config):
    frame_count = 0
    people_count = 0
    in_water_count = 0
    out_water_count = 0
    
    tracked_objects = {}
    
    redis_write_counter = 0
    REDIS_WRITE_INTERVAL = 10
    
    target_fps = config.get("fps", 30)
    frame_interval = 1.0 / target_fps
    last_frame_time = time.time()
    logger.info(f"检测线程启动，目标帧率: {target_fps} FPS")
    
    stop_check_counter = 0
    STOP_CHECK_INTERVAL = 240
    
    redis_client_string = get_detection_redis_client(decode_responses=True)
    redis_client_binary = get_detection_redis_client(decode_responses=False)
    
    consecutive_failures = 0
    max_consecutive_failures = 15
    reconnect_attempts = 0
    max_reconnect_attempts = 5
    reconnect_delay = 2
    
    frame_time_accumulator = 0.0
    
    last_frame_hash = None
    consecutive_duplicate_frames = 0
    max_duplicate_frames = 10
    buffer_flush_interval = 20
    max_consecutive_flushes = 5
    consecutive_flush_count = 0
    invalid_frame_threshold = 50
    consecutive_invalid_frames = 0
    
    while detection_context.running:
        try:
            ret, frame = cap.read()
            if not ret:
                consecutive_failures += 1
                time.sleep(0.01)
                
                if consecutive_failures >= max_consecutive_failures:
                    camera_logger.error(f"摄像头{camera_id}连续{max_consecutive_failures}次读取失败，尝试重新连接")
                    update_camera_status(camera_id, "reconnecting")
                    
                    if reconnect_attempts < max_reconnect_attempts:
                        reconnect_attempts += 1
                        camera_logger.info(f"摄像头{camera_id}第{reconnect_attempts}次重连尝试...")
                        time.sleep(reconnect_delay)
                        
                        new_cap = _reconnect_camera(camera_id, config)
                        if new_cap:
                            if cap:
                                cap.release()
                            cap = new_cap
                            consecutive_failures = 0
                            reconnect_attempts = 0
                            update_camera_status(camera_id, "running")
                            camera_logger.info(f"摄像头{camera_id}重连成功")
                            continue
                        else:
                            camera_logger.error(f"摄像头{camera_id}重连失败，{reconnect_delay}秒后重试")
                            time.sleep(reconnect_delay)
                    else:
                        camera_logger.error(f"摄像头{camera_id}重连次数已达上限({max_reconnect_attempts}次)")
                        break
                
                continue
            
            consecutive_failures = 0
            
            frame_count += 1
            
            current_time = time.time()
            frame_time_accumulator += current_time - last_frame_time
            last_frame_time = current_time
            
            frame_to_send = frame
            
            if frame_count % FRAME_SKIP_RATE == 0:
                frame_std = np.std(frame[::4, ::4])
                if frame_std < invalid_frame_threshold:
                    consecutive_invalid_frames += 1
                    camera_logger.warning(f"摄像头{camera_id}检测到无效帧(标准差={frame_std:.2f})，连续{consecutive_invalid_frames}帧")
                    if consecutive_invalid_frames >= max_consecutive_flushes:
                        camera_logger.error(f"摄像头{camera_id}连续{consecutive_invalid_frames}帧无效，尝试重新连接...")
                        update_camera_status(camera_id, "reconnecting")
                        new_cap = _reconnect_camera(camera_id, config)
                        if new_cap:
                            if cap:
                                cap.release()
                            cap = new_cap
                            consecutive_invalid_frames = 0
                            update_camera_status(camera_id, "running")
                            camera_logger.info(f"摄像头{camera_id}重连成功")
                        else:
                            camera_logger.error(f"摄像头{camera_id}重连失败")
                else:
                    consecutive_invalid_frames = 0
                
                    frame_hash = hashlib.md5(frame[::8, ::8].tobytes()).hexdigest()
                    if last_frame_hash is not None and frame_hash == last_frame_hash:
                        consecutive_duplicate_frames += 1
                        if consecutive_duplicate_frames >= max_duplicate_frames:
                            camera_logger.warning(f"摄像头{camera_id}连续{consecutive_duplicate_frames}帧相同，清空缓冲区...")
                            for _ in range(buffer_flush_interval):
                                cap.read()
                            time.sleep(0.05)
                            consecutive_duplicate_frames = 0
                            consecutive_flush_count += 1
                            if consecutive_flush_count >= max_consecutive_flushes:
                                camera_logger.error(f"摄像头{camera_id}连续{consecutive_flush_count}次清空缓冲区后仍为重复帧，尝试重新连接...")
                                update_camera_status(camera_id, "reconnecting")
                                new_cap = _reconnect_camera(camera_id, config)
                                if new_cap:
                                    if cap:
                                        cap.release()
                                    cap = new_cap
                                    consecutive_flush_count = 0
                                    update_camera_status(camera_id, "running")
                                    camera_logger.info(f"摄像头{camera_id}重连成功")
                                else:
                                    camera_logger.error(f"摄像头{camera_id}重连失败")
                    else:
                        consecutive_duplicate_frames = 0
                        consecutive_flush_count = 0
                    last_frame_hash = frame_hash
                
                detection_start_time = current_time
                
                try:
                    frame_height, frame_width = frame.shape[:2]
                    
                    try:
                        results = model(
                            frame,
                            imgsz=IMGSZ,
                            conf=CONF_THRESHOLD,
                            iou=IOU_THRESHOLD,
                            max_det=12,
                            device=device,
                            half=device != "cpu",
                            verbose=False,
                            stream=False
                        )
                    except Exception as model_err:
                        logger.error(f"摄像头{camera_id} 模型推理异常: {str(model_err)}")
                        continue
                    
                    people_count = 0
                    in_water_count = 0
                    out_water_count = 0
                    max_in_water_confidence = 0.0
                    
                    total_detected = 0
                    has_detections = False
                    frame_with_boxes = None
                    
                    try:
                        if isinstance(results, (list, tuple)) and len(results) > 0:
                            result = results[0]
                        else:
                            result = results
                    except Exception as e:
                        logger.error(f"摄像头{camera_id} 结果获取异常: {str(e)}")
                        continue
                    
                    try:
                        has_boxes_attr = hasattr(result, 'boxes')
                    except Exception as e:
                        logger.error(f"摄像头{camera_id} 属性检查异常: {str(e)}")
                        has_boxes_attr = False
                    
                    if has_boxes_attr:
                        boxes_data = None
                        try:
                            boxes_obj = result.boxes
                            if boxes_obj is not None:
                                if hasattr(boxes_obj, 'data'):
                                    boxes_data = boxes_obj.data
                                elif isinstance(boxes_obj, np.ndarray):
                                    boxes_data = boxes_obj
                        except Exception as e:
                            logger.error(f"摄像头{camera_id} boxes获取异常: {str(e)}")
                        
                        if boxes_data is not None and isinstance(boxes_data, np.ndarray) and boxes_data.size > 0:
                            try:
                                boxes_arr = boxes_data.cpu().numpy() if hasattr(boxes_data, 'cpu') else boxes_data
                            except Exception:
                                boxes_arr = boxes_data
                            
                            try:
                                num_boxes = int(boxes_arr.shape[0])
                            except Exception:
                                num_boxes = 0
                            
                            def _get_scalar_val(arr, idx):
                                try:
                                    val = arr[idx]
                                    if isinstance(val, (np.ndarray, torch.Tensor)):
                                        if val.size > 0:
                                            return float(val.flatten()[0])
                                        return 0.0
                                    return float(val)
                                except Exception:
                                    return 0.0
                            
                            for i in range(num_boxes):
                                try:
                                    row = boxes_arr[i]
                                    row_size = int(row.size) if hasattr(row, 'size') else len(row)
                                    
                                    if row_size < 6:
                                        continue
                                    
                                    x1 = _get_scalar_val(row, 0)
                                    y1 = _get_scalar_val(row, 1)
                                    x2 = _get_scalar_val(row, 2)
                                    y2 = _get_scalar_val(row, 3)
                                    conf = _get_scalar_val(row, 4)
                                    cls_val = _get_scalar_val(row, 5)
                                    cls = int(cls_val)
                                    
                                    if cls < 0 or cls > 2:
                                        continue
                                    
                                    x1 = float(max(0.0, min(float(x1), float(frame_width) - 1)))
                                    y1 = float(max(0.0, min(float(y1), float(frame_height) - 1)))
                                    x2 = float(max(0.0, min(float(x2), float(frame_width) - 1)))
                                    y2 = float(max(0.0, min(float(y2), float(frame_height) - 1)))
                                    
                                    box_area = float((x2 - x1) * (y2 - y1))
                                    area_ratio = float(box_area / (float(frame_width) * float(frame_height)))
                                    
                                    min_area = float(MIN_DETECTION_AREA)
                                    max_area = float(MAX_DETECTION_AREA)
                                    
                                    if box_area < min_area or area_ratio > 0.85 or box_area > max_area:
                                        continue
                                    
                                    total_detected += 1
                                    has_detections = True
                                    
                                    if not frame_with_boxes:
                                        frame_with_boxes = frame.copy()
                                    
                                    people_count += 1
                                    if cls == 0 or cls == 1:
                                        in_water_count += 1
                                        if conf > max_in_water_confidence:
                                            max_in_water_confidence = conf
                                    elif cls == 2:
                                        out_water_count += 1
                                    
                                    color = (0, 0, 255) if cls in [0, 1] else (0, 255, 0)
                                    cv2.rectangle(frame_with_boxes, (int(x1), int(y1)), (int(x2), int(y2)), color, 2)
                                    label = f"{CLASS_NAMES.get(cls, 'unknown')}: {conf:.2f}"
                                    cv2.putText(frame_with_boxes, label, (int(x1), int(y1) - 10),
                                                cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)
                                except Exception as box_err:
                                    logger.error(f"摄像头{camera_id} 处理检测框{i}异常: {str(box_err)}")
                    detection_time = time.time() - detection_start_time
                    detection_context.performance_stats[camera_id] = {
                        "fps": 1.0 / detection_time if detection_time > 0 else 0,
                        "detection_time_ms": detection_time * 1000,
                        "people_count": people_count,
                        "timestamp": datetime.now().isoformat()
                    }
                    
                    redis_write_counter += 1
                    if redis_write_counter >= REDIS_WRITE_INTERVAL:
                        if redis_client_string:
                            try:
                                stats = {
                                    "people_count": people_count,
                                    "in_water_count": in_water_count,
                                    "out_water_count": out_water_count,
                                    "total_detected": total_detected,
                                    "timestamp": datetime.now().isoformat()
                                }
                                redis_client_string.set(f"people_count_{camera_id}", json.dumps(stats))
                                redis_client_string.expire(f"people_count_{camera_id}", REDIS_FRAME_EXPIRE)
                                
                                redis_write_counter = 0
                            except Exception as redis_err:
                                logger.error(f"摄像头{camera_id} Redis操作失败，重新获取连接: {str(redis_err)}")
                                redis_client_string = get_detection_redis_client(decode_responses=True)
                    
                    if frame_with_boxes is not None:
                        frame_to_send = frame_with_boxes
                    
                    detection_context.last_detection_times[camera_id] = datetime.now().isoformat()
                    
                    camera_monitor.update_metrics(camera_id, success=True, frame_count=1)

                    if in_water_count > 0:
                        detection_context.in_water_consecutive_counts[camera_id] = (
                            detection_context.in_water_consecutive_counts.get(camera_id, 0) + 1
                        )
                        
                        if detection_context.in_water_consecutive_counts[camera_id] >= MIN_CONSECUTIVE_FRAMES:
                            try:
                                alert_manager = get_alert_manager()
                                
                                if in_water_count >= 3:
                                    risk_level = "high"
                                    reason = f"检测到{in_water_count}人在水中"
                                elif in_water_count == 2:
                                    risk_level = "medium"
                                    reason = f"检测到{in_water_count}人在水中"
                                else:
                                    risk_level = "low"
                                    reason = "检测到1人在水中"
                                
                                area = CAMERA_CONFIG.get(camera_id, {}).get("area", "未知区域")
                                
                                alert_result = alert_manager.trigger_alert(
                                    camera_id=camera_id,
                                    area=area,
                                    level=risk_level,
                                    reason=reason,
                                    confidence=max_in_water_confidence
                                )
                                if alert_result.get("success"):
                                    logger.info(f"溺水告警已触发 (ID: {alert_result.get('data', {}).get('id')})")
                            except Exception as e:
                                logger.error(f"触发告警失败: {str(e)}")
                    else:
                        detection_context.in_water_consecutive_counts[camera_id] = 0
            
                except Exception as e:
                    logger.error(f"摄像头{camera_id} 检测异常: {str(e)}")
            
            shared_frame_buffer.set_frame(camera_id, frame_to_send)
            
            while frame_time_accumulator >= frame_interval:
                if not frame_queue.full():
                    frame_queue.put((frame_to_send, current_time))
                frame_time_accumulator -= frame_interval
            
            time.sleep(0.001)
            
            stop_check_counter += 1
            if stop_check_counter >= STOP_CHECK_INTERVAL:
                if redis_client_string:
                    try:
                        if redis_client_string.get("stop_detection") == "1":
                            logger.info(f"摄像头{camera_id} 收到停止信号，退出检测")
                            break
                    except Exception:
                        redis_client_string = None
                
                stop_check_counter = 0
                
        except Exception as e:
            logger.error(f"摄像头{camera_id} 主循环异常: {str(e)}")
            time.sleep(0.005)
    
    if cap:
        cap.release()
    update_camera_status(camera_id, "stopped")
    logger.info(f"摄像头{camera_id} 检测线程已退出")


def encode_worker(camera_id, frame_queue):
    config = CAMERA_CONFIG.get(camera_id, CAMERA_CONFIG[1])
    encode_fps = config.get("fps", 30) * 1.2
    encode_interval = 1.0 / encode_fps
    last_encode_time = time.time()
    
    redis_client_binary = get_detection_redis_client(decode_responses=False)
    
    encode_param = [
        int(cv2.IMWRITE_JPEG_QUALITY), VIDEO_QUALITY,
        int(cv2.IMWRITE_JPEG_OPTIMIZE), 0,
        int(cv2.IMWRITE_JPEG_PROGRESSIVE), 0,
    ]
    
    frame_count = 0
    last_stats_time = time.time()
    frame_accumulator = 0.0
    
    while detection_context.running:
        try:
            frame, timestamp = frame_queue.get(timeout=0.01)
            frame_count += 1
            frame_accumulator += 1
            
            current_time = time.time()
            
            if frame_accumulator >= 1:
                try:
                    _, jpeg_frame = cv2.imencode('.jpg', frame, encode_param)
                    frame_data = jpeg_frame.tobytes()
                    
                    if redis_client_binary:
                        try:
                            redis_client_binary.setex(f"current_frame_{camera_id}", REDIS_FRAME_EXPIRE, frame_data)
                            
                            if camera_id == 1:
                                redis_client_binary.setex("current_frame", REDIS_FRAME_EXPIRE, frame_data)
                        except Exception as redis_err:
                            logger.error(f"摄像头{camera_id} 编码线程Redis操作失败，重新获取连接: {str(redis_err)}")
                            redis_client_binary = get_detection_redis_client(decode_responses=False)
                    
                    frame_accumulator -= 1
                    last_encode_time = current_time
                
                except Exception as e:
                    logger.error(f"摄像头{camera_id} 编码/Redis写入失败: {str(e)}")
            
            if current_time - last_stats_time >= 5.0:
                elapsed = current_time - last_stats_time
                actual_fps = frame_count / elapsed
                logger.info(f"摄像头{camera_id} 编码线程 | FPS: {actual_fps:.2f}")
                frame_count = 0
                last_stats_time = current_time
                
        except queue.Empty:
            time.sleep(0.001)
            continue
        except Exception as e:
            logger.error(f"摄像头{camera_id} 编码线程异常: {str(e)}")
            time.sleep(0.002)
    
    logger.info(f"摄像头{camera_id} 编码线程已退出")


def stop_detection():
    detection_context.running = False
    client = get_detection_redis_client(decode_responses=True)
    if client:
        client.set("stop_detection", "1")
    
    for camera_id, thread in detection_context.detection_threads.items():
        if thread and thread.is_alive():
            thread.join(timeout=5.0)
    
    for camera_id, thread in detection_context.encode_threads.items():
        if thread and thread.is_alive():
            thread.join(timeout=5.0)
    
    logger.info("检测系统已停止")


def get_camera_status(camera_id=None):
    """获取摄像头状态"""
    if camera_id:
        return detection_context.camera_status.get(camera_id, {
            "status": "unknown",
            "error": None,
            "timestamp": datetime.now().isoformat()
        })
    return detection_context.camera_status


def get_performance_stats(camera_id=None):
    """获取性能统计"""
    if camera_id:
        return detection_context.performance_stats.get(camera_id, {})
    return detection_context.performance_stats


class CameraDetectionThread(threading.Thread):
    def __init__(self, camera_id):
        super().__init__(daemon=True)
        self.camera_id = camera_id
        self._stop_event = threading.Event()
    
    def stop(self):
        self._stop_event.set()
        detection_context.running = False
    
    def run(self):
        start_detection()


if __name__ == "__main__":
    start_detection()