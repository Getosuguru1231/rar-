"""检测工具函数模块

包含图像预处理、结果后处理和风险计算等辅助函数
"""

import cv2
import numpy as np
from typing import Dict, List, Tuple, Optional

def preprocess_image(image: np.ndarray, target_size: Tuple[int, int] = (640, 640)) -> np.ndarray:
    """图像预处理
    
    Args:
        image: 输入图像
        target_size: 目标尺寸
        
    Returns:
        预处理后的图像
    """
    # 调整图像大小
    resized = cv2.resize(image, target_size)
    
    # 转换为RGB格式
    if len(resized.shape) == 3 and resized.shape[2] == 3:
        # 已经是RGB格式
        pass
    elif len(resized.shape) == 2:
        # 灰度图像转换为RGB
        resized = cv2.cvtColor(resized, cv2.COLOR_GRAY2RGB)
    
    # 归一化
    resized = resized / 255.0
    
    return resized

def postprocess_results(results: any, confidence_threshold: float = 0.4) -> List[Dict]:
    """处理检测结果
    
    Args:
        results: 模型检测结果
        confidence_threshold: 置信度阈值
        
    Returns:
        处理后的检测结果列表
    """
    detections = []
    
    for result in results:
        boxes = result.boxes
        for box in boxes:
            x1, y1, x2, y2 = box.xyxy[0].tolist()
            conf = box.conf[0].item()
            cls = int(box.cls[0].item())
            
            if conf >= confidence_threshold:
                detections.append({
                    "class": cls,
                    "confidence": conf,
                    "bbox": [x1, y1, x2, y2]
                })
    
    return detections

def calculate_drowning_risk(detections: List[Dict], class_names: Dict[int, str], drowning_classes: List[int]) -> str:
    """计算溺水风险
    
    Args:
        detections: 检测结果
        class_names: 类别名称映射
        drowning_classes: 溺水相关类别
        
    Returns:
        风险等级："high", "medium", "low", "none"
    """
    if not detections:
        return "none"
    
    total_count = len(detections)
    in_water_count = 0
    
    for detection in detections:
        cls = detection["class"]
        if cls in drowning_classes:
            in_water_count += 1
    
    if total_count == 0:
        return "none"
    
    # 计算在水中的比例
    water_ratio = in_water_count / total_count
    
    # 根据比例评估风险
    if water_ratio > 0.8 and in_water_count >= 3:
        return "high"
    elif water_ratio > 0.5 and in_water_count >= 2:
        return "medium"
    elif water_ratio > 0:
        return "low"
    else:
        return "none"

def draw_detections(image: np.ndarray, detections: List[Dict], class_names: Dict[int, str]) -> np.ndarray:
    """在图像上绘制检测结果
    
    Args:
        image: 输入图像
        detections: 检测结果
        class_names: 类别名称映射
        
    Returns:
        绘制后的图像
    """
    for detection in detections:
        bbox = detection["bbox"]
        cls = detection["class"]
        confidence = detection["confidence"]
        
        class_name = class_names.get(cls, f"Class {cls}")
        
        # 绘制边界框
        color = (0, 255, 0) if class_name == "out_of_water" else (0, 0, 255)
        cv2.rectangle(image, (int(bbox[0]), int(bbox[1])), (int(bbox[2]), int(bbox[3])), color, 2)
        
        # 添加标签
        label = f"{class_name}: {confidence:.2f}"
        cv2.putText(image, label, (int(bbox[0]), int(bbox[1]) - 10),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)
    
    return image

def calculate_people_count(detections: List[Dict], class_names: Dict[int, str]) -> Tuple[int, int]:
    """计算人数统计
    
    Args:
        detections: 检测结果
        class_names: 类别名称映射
        
    Returns:
        (总人数, 水中人数)
    """
    total_count = len(detections)
    in_water_count = 0
    
    for detection in detections:
        cls = detection["class"]
        class_name = class_names.get(cls, "")
        if class_name in ["in_water", "in_water2"]:
            in_water_count += 1
    
    return total_count, in_water_count