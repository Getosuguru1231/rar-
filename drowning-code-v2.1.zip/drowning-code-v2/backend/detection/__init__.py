"""检测模块

包含核心检测逻辑和相关工具函数
"""

from .detect import start_detection, redis_client

db_conn = None

__all__ = [
    "start_detection",
    "redis_client",
    "db_conn"
]