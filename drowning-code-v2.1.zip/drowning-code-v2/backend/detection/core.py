"""核心检测逻辑模块

实现YoloDetector类，用于目标检测和溺水风险评估
高性能版本：GPU加速 + 半精度推理 + 快速处理
"""

import cv2
import numpy as np
import torch
from ultralytics import YOLO
from typing import Dict, List, Tuple, Optional

def get_device():
    if torch.cuda.is_available():
        return "cuda"
    elif torch.backends.mps.is_available():
        return "mps"
    return "cpu"

class YoloDetector:
    """YOLO目标检测器（高性能版）
    
    负责加载模型、执行目标检测、评估溺水风险等核心功能
    支持GPU加速和半精度推理
    """
    
    def __init__(self, model_path: str, confidence_threshold: float = 0.4):
        """初始化检测器
        
        Args:
            model_path: 模型路径
            confidence_threshold: 置信度阈值
        """
        self.model_path = model_path
        self.confidence_threshold = confidence_threshold
        self.model = None
        self.device = get_device()
        self.use_fp16 = self.device != "cpu"
        self.class_names = {
            0: 'in_water',
            1: 'in_water2',
            2: 'out_of_water'
        }
        self.drowning_classes = [0, 1]
        self._load_model()
    
    def _load_model(self):
        """加载YOLO模型（支持GPU加速）"""
        try:
            self.model = YOLO(self.model_path)
            if self.device != "cpu":
                self.model = self.model.to(self.device)
            print(f"[OK] 模型加载成功: {self.model_path} (设备: {self.device}, FP16: {self.use_fp16})")
        except Exception as e:
            print(f"[ERROR] 模型加载失败: {e}")
            self.model = None
    
    def detect(self, image: np.ndarray) -> Dict[str, any]:
        """执行目标检测（高性能版）
        
        Args:
            image: 输入图像
            
        Returns:
            检测结果，包含检测到的目标和风险评估
        """
        if self.model is None:
            return {
                "success": False,
                "message": "模型未加载",
                "detections": [],
                "risk": "none",
                "people_count": 0
            }
        
        try:
            results = self.model(
                image,
                conf=self.confidence_threshold,
                iou=0.5,
                max_det=100,
                device=self.device,
                half=self.use_fp16,
                verbose=False,
                stream=False
            )
            
            detections = []
            people_count = 0
            in_water_count = 0
            
            for result in results:
                boxes = result.boxes
                for box in boxes:
                    x1, y1, x2, y2 = box.xyxy[0].tolist()
                    conf = box.conf[0].item()
                    cls = int(box.cls[0].item())
                    
                    if cls in self.class_names:
                        class_name = self.class_names[cls]
                        detections.append({
                            "class": class_name,
                            "confidence": conf,
                            "bbox": [x1, y1, x2, y2]
                        })
                        
                        people_count += 1
                        if cls in self.drowning_classes:
                            in_water_count += 1
            
            risk = self._assess_drowning_risk(detections, in_water_count, people_count)
            
            return {
                "success": True,
                "message": "检测成功",
                "detections": detections,
                "risk": risk,
                "people_count": people_count,
                "in_water_count": in_water_count
            }
        except Exception as e:
            return {
                "success": False,
                "message": f"检测失败: {e}",
                "detections": [],
                "risk": "none",
                "people_count": 0
            }
    
    def _assess_drowning_risk(self, detections: List[Dict], in_water_count: int, total_count: int) -> str:
        """评估溺水风险
        
        Args:
            detections: 检测结果
            in_water_count: 在水中的人数
            total_count: 总人数
            
        Returns:
            风险等级："high", "medium", "low", "none"
        """
        if total_count == 0:
            return "none"
        
        water_ratio = in_water_count / total_count
        
        if water_ratio > 0.8 and in_water_count >= 3:
            return "high"
        elif water_ratio > 0.5 and in_water_count >= 2:
            return "medium"
        elif water_ratio > 0:
            return "low"
        else:
            return "none"
    
    def process_video_frame(self, frame: np.ndarray, skip_detection: bool = False) -> Dict[str, any]:
        """处理视频帧（高性能版）
        
        Args:
            frame: 视频帧
            skip_detection: 是否跳过检测（仅用于快速传输）
            
        Returns:
            处理结果，包含检测信息和风险评估
        """
        if skip_detection:
            return {
                "success": True,
                "message": "跳过检测",
                "detections": [],
                "risk": "none",
                "people_count": 0,
                "in_water_count": 0,
                "processed_frame": frame
            }
        
        result = self.detect(frame)
        
        if result["success"] and result["detections"]:
            for detection in result["detections"]:
                bbox = detection["bbox"]
                class_name = detection["class"]
                confidence = detection["confidence"]
                
                color = (0, 255, 0) if class_name == "out_of_water" else (0, 0, 255)
                cv2.rectangle(frame, (int(bbox[0]), int(bbox[1])), (int(bbox[2]), int(bbox[3])), color, 2)
                
                label = f"{class_name}: {confidence:.2f}"
                cv2.putText(frame, label, (int(bbox[0]), int(bbox[1]) - 10),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)
        
        return {
            **result,
            "processed_frame": frame
        }
    
    def reload_model(self, model_path: Optional[str] = None):
        """重新加载模型
        
        Args:
            model_path: 新的模型路径，如果不提供则使用原来的路径
        """
        if model_path:
            self.model_path = model_path
        self._load_model()
    
    def get_model_info(self) -> Dict[str, any]:
        """获取模型信息
        
        Returns:
            模型信息
        """
        return {
            "model_path": self.model_path,
            "confidence_threshold": self.confidence_threshold,
            "class_names": self.class_names,
            "drowning_classes": self.drowning_classes,
            "device": self.device,
            "use_fp16": self.use_fp16
        }