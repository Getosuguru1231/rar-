import asyncio
from webrtc.video_handler import VideoFrameHandler

async def test():
    handler = VideoFrameHandler(camera_id=1)
    frame = await handler.get_frame()
    print('Frame shape:', frame.shape if frame is not None else 'None')
    print('Frame dtype:', frame.dtype if frame is not None else 'None')

asyncio.run(test())