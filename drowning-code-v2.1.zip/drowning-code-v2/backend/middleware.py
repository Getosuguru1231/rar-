# backend/middleware.py
"""
FastAPI 中间件
包含CORS、缓存、压缩、请求日志等
"""
import time
import json
from fastapi import Request, Response
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.middleware.cors import CORSMiddleware
from starlette.middleware.gzip import GZipMiddleware
from logging_config import get_logger

logger = get_logger('api')


class RequestLoggingMiddleware(BaseHTTPMiddleware):
    """
    请求日志中间件
    记录每个请求的详细信息和响应时间
    """
    
    # 不需要日志的路径（高频请求）
    SKIP_LOG_PATHS = [
        "/api/video_feed",
        "/ws/"
    ]
    
    async def dispatch(self, request: Request, call_next):
        start_time = time.time()
        
        # 生成请求ID用于追踪
        import uuid
        request_id = str(uuid.uuid4())[:8]
        
        # 记录请求信息
        client_host = request.client.host if request.client else "unknown"
        method = request.method
        url = str(request.url)
        
        # 跳过高频请求的日志
        path = request.url.path
        should_log = not any(path.startswith(p) for p in self.SKIP_LOG_PATHS)
        
        if should_log:
            logger.info(f"[INFO] [{request_id}] {method} {url} from {client_host}")
        
        try:
            # 处理请求
            response = await call_next(request)
            
            # 计算响应时间
            process_time = time.time() - start_time
            
            # 记录响应信息
            if should_log:
                logger.info(
                    f"[INFO] [{request_id}] {method} {url} - "
                    f"Status: {response.status_code} - "
                    f"Time: {process_time:.3f}s"
                )
            
            # 添加响应头
            response.headers["X-Process-Time"] = str(process_time)
            response.headers["X-Request-ID"] = request_id
            
            return response
        
        except Exception as e:
            process_time = time.time() - start_time
            logger.error(
                f"[ERROR] [{request_id}] {method} {url} - "
                f"Error: {str(e)} - "
                f"Time: {process_time:.3f}s",
                exc_info=True
            )
            raise


class CacheControlMiddleware(BaseHTTPMiddleware):
    """
    缓存控制中间件
    为不同类型的响应设置合适的缓存策略
    """
    
    # 不需要缓存的路径
    NO_CACHE_PATHS = [
        "/api/video_feed",
        "/api/camera/health",
        "/ws/"
    ]
    
    # 短时间缓存的路径 (5分钟)
    SHORT_CACHE_PATHS = [
        "/api/alerts/",
        "/api/stats/"
    ]
    
    # 长时间缓存的路径 (1小时)
    LONG_CACHE_PATHS = [
        "/api/config/",
        "/static/"
    ]
    
    async def dispatch(self, request: Request, call_next):
        response = await call_next(request)
        
        path = request.url.path
        
        # 跳过流式响应和WebSocket
        if any(path.startswith(p) for p in self.NO_CACHE_PATHS):
            response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
            response.headers["Pragma"] = "no-cache"
            response.headers["Expires"] = "0"
        
        # 短时间缓存
        elif any(path.startswith(p) for p in self.SHORT_CACHE_PATHS):
            response.headers["Cache-Control"] = "public, max-age=300"  # 5分钟
        
        # 长时间缓存
        elif any(path.startswith(p) for p in self.LONG_CACHE_PATHS):
            response.headers["Cache-Control"] = "public, max-age=3600"  # 1小时
        
        # 默认不缓存
        else:
            response.headers["Cache-Control"] = "no-cache"
        
        return response


class CustomGZipMiddleware(BaseHTTPMiddleware):
    """
    自定义GZip压缩中间件
    跳过视频流等已经压缩的内容
    """
    
    # 跳过压缩的路径
    SKIP_COMPRESS_PATHS = [
        "/api/video_feed",
        "/ws/"
    ]
    
    def __init__(self, app, minimum_size: int = 1000):
        super().__init__(app)
        self.minimum_size = minimum_size
    
    async def dispatch(self, request: Request, call_next):
        path = request.url.path
        
        # 跳过视频流等已经压缩的内容
        if any(path.startswith(p) for p in self.SKIP_COMPRESS_PATHS):
            response = await call_next(request)
            return response
        
        # 使用标准GZipMiddleware的逻辑
        response = await call_next(request)
        
        # 如果响应已经是压缩的或者太小，不进行压缩
        if response.headers.get("Content-Encoding"):
            return response
        
        body = b""
        async for chunk in response.body_iterator:
            body += chunk
        
        if len(body) < self.minimum_size:
            # 创建新的响应，不压缩
            new_response = Response(
                content=body,
                status_code=response.status_code,
                headers=dict(response.headers),
                media_type=response.media_type
            )
            return new_response
        
        # 进行gzip压缩
        import gzip
        compressed_body = gzip.compress(body)
        
        new_response = Response(
            content=compressed_body,
            status_code=response.status_code,
            headers=dict(response.headers),
            media_type=response.media_type
        )
        new_response.headers["Content-Encoding"] = "gzip"
        new_response.headers["Content-Length"] = str(len(compressed_body))
        
        return new_response


class SecurityHeadersMiddleware(BaseHTTPMiddleware):
    """
    安全头中间件
    添加常见的安全响应头
    """
    
    async def dispatch(self, request: Request, call_next):
        response = await call_next(request)
        
        # 安全响应头
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "SAMEORIGIN"
        response.headers["X-XSS-Protection"] = "1; mode=block"
        response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
        response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        
        # CSP
        csp_policy = (
            "default-src 'self'; "
            "script-src 'self' 'unsafe-inline' 'unsafe-eval'; "
            "style-src 'self' 'unsafe-inline'; "
            "img-src 'self' data: blob: http: https:; "
            "media-src 'self' blob: http: https:; "
            "connect-src 'self' ws://localhost:* wss://localhost:* http://localhost:* https://localhost:* ws: wss: http: https:; "
            "font-src 'self';"
        )
        response.headers["Content-Security-Policy"] = csp_policy
        
        return response


class RateLimitMiddleware(BaseHTTPMiddleware):
    """
    限流中间件
    基于令牌桶算法实现多层限流（全局、IP、路径级别）
    """
    
    SKIP_PATHS = [
        "/ws/",
        "/docs",
        "/redoc",
        "/openapi.json",
        "/favicon.ico"
    ]
    
    async def dispatch(self, request: Request, call_next):
        path = request.url.path
        
        if any(path.startswith(p) for p in self.SKIP_PATHS):
            return await call_next(request)
        
        client_ip = request.client.host if request.client else "unknown"
        
        from components.rate_limiter import rate_limiter
        allowed, info = rate_limiter.check(path, client_ip)
        
        if not allowed:
            response = JSONResponse(
                status_code=429,
                content={
                    "code": 429,
                    "success": False,
                    "message": info["message"],
                    "reason": info["reason"],
                    "retry_after": 60
                }
            )
            response.headers["Retry-After"] = "60"
            response.headers["X-RateLimit-Reason"] = info["reason"]
            return response
        
        response = await call_next(request)
        return response


def setup_middleware(app):
    """
    配置所有中间件
    
    Args:
        app: FastAPI应用实例
    """
    # 1. CORS 中间件
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    
    # 2. 限流中间件（基于令牌桶算法，多层限流）
    app.add_middleware(RateLimitMiddleware)
    
    # 3. 自定义GZip压缩 (跳过视频流等已压缩内容)
    app.add_middleware(CustomGZipMiddleware, minimum_size=1000)
    
    # 4. 请求日志
    app.add_middleware(RequestLoggingMiddleware)
    
    # 5. 缓存控制
    app.add_middleware(CacheControlMiddleware)
    
    # 6. 安全头
    app.add_middleware(SecurityHeadersMiddleware)
    
    logger.info("[OK] 中间件配置完成")
    logger.info("   - CORS")
    logger.info("   - 限流中间件 (令牌桶算法)")
    logger.info("   - GZip 压缩 (自定义)")
    logger.info("   - 请求日志")
    logger.info("   - 缓存控制")
    logger.info("   - 安全头")
