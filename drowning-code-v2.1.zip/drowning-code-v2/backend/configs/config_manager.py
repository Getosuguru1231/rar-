"""配置管理模块

集中管理所有配置文件，提供统一的配置访问接口
"""

import os
import yaml
import json
from typing import Dict, Any, Optional

class ConfigManager:
    """配置管理器
    
    负责加载、管理和提供配置文件的访问接口
    """
    
    def __init__(self):
        """初始化配置管理器"""
        self.configs = {}
        self.config_dir = os.path.dirname(__file__)
        self._load_all_configs()
    
    def _load_all_configs(self):
        """加载所有配置文件"""
        # 加载YAML配置文件
        yaml_files = [f for f in os.listdir(self.config_dir) if f.endswith('.yaml') or f.endswith('.yml')]
        for yaml_file in yaml_files:
            config_name = os.path.splitext(yaml_file)[0]
            config_path = os.path.join(self.config_dir, yaml_file)
            try:
                with open(config_path, 'r', encoding='utf-8') as f:
                    self.configs[config_name] = yaml.safe_load(f)
            except Exception as e:
                print(f"加载配置文件 {yaml_file} 失败: {e}")
        
        # 加载JSON配置文件
        json_files = [f for f in os.listdir(self.config_dir) if f.endswith('.json')]
        for json_file in json_files:
            config_name = os.path.splitext(json_file)[0]
            config_path = os.path.join(self.config_dir, json_file)
            try:
                with open(config_path, 'r', encoding='utf-8') as f:
                    self.configs[config_name] = json.load(f)
            except Exception as e:
                print(f"加载配置文件 {json_file} 失败: {e}")
    
    def get_config(self, config_name: str) -> Optional[Dict[str, Any]]:
        """获取指定配置
        
        Args:
            config_name: 配置名称
            
        Returns:
            配置字典，如果配置不存在则返回None
        """
        return self.configs.get(config_name)
    
    def get(self, config_name: str, key: str, default: Any = None) -> Any:
        """获取配置中的指定键值
        
        Args:
            config_name: 配置名称
            key: 配置键
            default: 默认值，如果配置或键不存在则返回
            
        Returns:
            配置值或默认值
        """
        config = self.get_config(config_name)
        if config is None:
            return default
        
        # 支持嵌套键，如 "database.host"
        keys = key.split('.')
        value = config
        for k in keys:
            if isinstance(value, dict) and k in value:
                value = value[k]
            else:
                return default
        
        return value
    
    def reload(self):
        """重新加载所有配置文件"""
        self.configs.clear()
        self._load_all_configs()
    
    def update_config(self, config_name: str, config: Dict[str, Any]):
        """更新配置
        
        Args:
            config_name: 配置名称
            config: 配置字典
        """
        self.configs[config_name] = config
    
    def save_config(self, config_name: str, config: Dict[str, Any], format: str = 'yaml'):
        """保存配置到文件
        
        Args:
            config_name: 配置名称
            config: 配置字典
            format: 保存格式，支持 'yaml' 或 'json'
        """
        if format == 'yaml':
            file_path = os.path.join(self.config_dir, f"{config_name}.yaml")
            with open(file_path, 'w', encoding='utf-8') as f:
                yaml.dump(config, f, default_flow_style=False, allow_unicode=True)
        elif format == 'json':
            file_path = os.path.join(self.config_dir, f"{config_name}.json")
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(config, f, ensure_ascii=False, indent=2)
        else:
            raise ValueError(f"不支持的配置格式: {format}")

# 创建全局配置管理器实例
config_manager = ConfigManager()

def get_config_manager() -> ConfigManager:
    """获取配置管理器实例
    
    Returns:
        配置管理器实例
    """
    return config_manager