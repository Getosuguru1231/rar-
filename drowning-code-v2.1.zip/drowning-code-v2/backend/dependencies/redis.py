﻿from typing import Annotated
from fastapi import Depends
from components.redis_pool import get_redis_connection

def get_redis_client(decode_responses: bool = False):
    """FastAPI依赖注入：获取Redis连接"""
    client = get_redis_connection(decode_responses)
    if not client:
        raise RuntimeError("Failed to get Redis connection")
    return client

RedisClient = Annotated[object, Depends(get_redis_client)]
StringRedisClient = Annotated[object, Depends(lambda: get_redis_client(decode_responses=True))]