import cv2
import time
import hashlib

cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)
if not cap.isOpened():
    print('Failed to open camera')
    exit()

print(f'Default width: {cap.get(cv2.CAP_PROP_FRAME_WIDTH)}')
print(f'Default height: {cap.get(cv2.CAP_PROP_FRAME_HEIGHT)}')
print(f'Default FPS: {cap.get(cv2.CAP_PROP_FPS)}')

print('\nReading frames...')
hashes = []
for i in range(20):
    ret, frame = cap.read()
    if ret and frame is not None:
        frame_hash = hashlib.md5(frame.tobytes()).hexdigest()
        hashes.append(frame_hash)
        if i % 5 == 0:
            print(f'Frame {i}: shape={frame.shape}, hash={frame_hash[:8]}')
    else:
        print(f'Frame {i}: read failed')
    time.sleep(0.05)

cap.release()

print(f'\nUnique hashes: {len(set(hashes))}/{len(hashes)}')
if len(set(hashes)) == 1:
    print('WARNING: Camera is stuck on single frame')
else:
    print('Frames are updating')