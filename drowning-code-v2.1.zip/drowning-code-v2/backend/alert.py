"""语音告警模块 - 提供语音播报功能"""
import sys
import time
import threading
from settings import VOICE_ENABLED, VOICE_RATE, VOICE_VOLUME, VOICE_WAIT_INTERVAL

# 状态机状态
_STATE_IDLE = "idle"
_STATE_SPEAKING = "speaking"
_STATE_PENDING = "pending"

# 共享状态
_current_state = _STATE_IDLE
_current_message = None
_pending_message = None
_last_voice_time = 0
_voice_lock = threading.Lock()

def voice_alert(message: str, area: str = "") -> None:
    """
    语音播报告警信息
    
    Args:
        message: 告警信息
        area: 告警区域
    """
    if not VOICE_ENABLED:
        print(f"[语音告警] 语音播报已禁用")
        return
    
    global _current_state, _current_message, _pending_message, _last_voice_time
    
    with _voice_lock:
        current_time = time.time()
        
        # 检查是否正在播报相同消息
        if _current_message == message:
            print(f"[语音告警] 正在播报相同消息，跳过: {message}")
            return
        
        # 检查待播报队列中是否已有相同消息
        if _pending_message == message:
            print(f"[语音告警] 待播报队列已有相同消息，跳过: {message}")
            return
        
        # 相同消息的冷却检查：只对相同消息生效
        if _current_state == _STATE_IDLE:
            # 空闲状态下检查冷却
            if current_time - _last_voice_time < VOICE_WAIT_INTERVAL:
                print(f"[语音告警] 语音播报冷却中，跳过本次播报: {message}")
                return
            
            # 空闲状态，直接开始播报
            _current_state = _STATE_SPEAKING
            _current_message = message
            _last_voice_time = current_time
            threading.Thread(target=_speak_windows, args=(message,), daemon=True).start()
            print(f"[语音告警] 开始播报: {message}")
            
        elif _current_state == _STATE_SPEAKING:
            # 正在播报，不同消息加入待播报队列（覆盖旧的待播报消息）
            _pending_message = message
            print(f"[语音告警] 当前正在播报，不同消息加入待播报队列: {message}")
            
        elif _current_state == _STATE_PENDING:
            # 已有待播报消息，不同消息覆盖它
            _pending_message = message
            print(f"[语音告警] 更新待播报消息: {message}")

def _speak_windows(text: str) -> None:
    """Windows平台语音播报"""
    global _current_state, _current_message, _pending_message
    
    try:
        import win32com.client
        speaker = win32com.client.Dispatch("SAPI.SpVoice")
        
        # 设置语音速率
        speaker.Rate = VOICE_RATE
        
        # 设置音量
        speaker.Volume = VOICE_VOLUME
        
        print(f"[语音告警] 语音引擎开始播报")
        speaker.Speak(text)
        print(f"[语音告警] 播报完成: {text}")
        
    except ImportError:
        print(f"[语音告警] 缺少pywin32库，无法语音播报，请安装: pip install pywin32")
    except Exception as e:
        print(f"[语音告警] Windows语音播报失败: {e}")
    finally:
        # 播报完成，检查是否有待播报消息
        with _voice_lock:
            _current_state = _STATE_IDLE
            _current_message = None
            
            if _pending_message:
                # 有待播报消息，立即开始播报
                pending_msg = _pending_message
                _pending_message = None
                _current_state = _STATE_SPEAKING
                _current_message = pending_msg
                threading.Thread(target=_speak_windows, args=(pending_msg,), daemon=True).start()
                print(f"[语音告警] 开始播报待播消息: {pending_msg}")

def stop_voice() -> None:
    """停止当前语音播报"""
    global _current_state, _current_message, _pending_message
    
    with _voice_lock:
        _current_state = _STATE_IDLE
        _current_message = None
        _pending_message = None
        print(f"[语音告警] 语音播报已停止")

def get_voice_status() -> dict:
    """获取语音播报状态"""
    return {
        "state": _current_state,
        "current_message": _current_message,
        "pending_message": _pending_message,
        "enabled": VOICE_ENABLED
    }

def test_voice() -> bool:
    """测试语音播报功能"""
    print("[语音告警] 测试语音播报...")
    try:
        voice_alert("语音测试，智能溺水检测系统")
        return True
    except Exception as e:
        print(f"[语音告警] 测试失败: {e}")
        return False

if __name__ == "__main__":
    test_voice()
