import ffmpeg
import numpy as np
import time

stream_url = 'http://10.64.90.195:8899'

print(f'Trying to open stream: {stream_url}')

try:
    probe = ffmpeg.probe(stream_url)
    print('Stream probe successful:')
    for stream in probe['streams']:
        print(f"  - Type: {stream['codec_type']}, Resolution: {stream.get('width', 'N/A')}x{stream.get('height', 'N/A')}, FPS: {stream.get('r_frame_rate', 'N/A')}")
except Exception as e:
    print(f'Probe failed: {e}')

try:
    process = (
        ffmpeg
        .input(stream_url, rtsp_transport='tcp')
        .output('pipe:', format='rawvideo', pix_fmt='bgr24')
        .run_async(pipe_stdout=True)
    )
    
    print('FFmpeg process started')
    
    frame_width = 1280
    frame_height = 720
    frame_size = frame_width * frame_height * 3
    
    for i in range(5):
        in_bytes = process.stdout.read(frame_size)
        if in_bytes:
            frame = np.frombuffer(in_bytes, np.uint8).reshape([frame_height, frame_width, 3])
            print(f'Frame {i}: shape={frame.shape}, mean={np.mean(frame):.2f}')
        else:
            print(f'Frame {i}: empty')
        time.sleep(0.1)
    
    process.terminate()
    print('Process terminated')
    
except Exception as e:
    print(f'FFmpeg read failed: {e}')
    import traceback
    traceback.print_exc()