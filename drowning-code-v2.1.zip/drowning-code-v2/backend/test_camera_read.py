import cv2
import time
import hashlib

cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)
if not cap.isOpened():
    cap = cv2.VideoCapture(0, cv2.CAP_MSMF)

if not cap.isOpened():
    print('Failed to open camera')
    exit()

cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)
cap.set(cv2.CAP_PROP_FPS, 30)

print('Reading camera frames for 3 seconds...')
hashes = []
for i in range(30):
    ret, frame = cap.read()
    if ret and frame is not None:
        frame_hash = hashlib.md5(frame.tobytes()).hexdigest()
        hashes.append(frame_hash)
        print(f'Frame {i}: shape={frame.shape}, hash={frame_hash[:8]}')
    else:
        print(f'Frame {i}: read failed')
    time.sleep(0.1)

cap.release()

print(f'\nTotal frames read: {len(hashes)}')
print(f'Unique hashes: {len(set(hashes))}')
if len(set(hashes)) == 1:
    print('WARNING: Camera is returning duplicate frames!')
else:
    print('Camera is reading new frames normally')