# 智能溺水检测系统 - 路径配置总结与调整报告

## 📅 更新日期
2026-04-12

## ✅ 路径配置验证结果

### 验证状态：全部通过 ✅

```
✅ BASE_DIR的父目录 = PROJECT_ROOT (正确)
✅ 未发现重复的路径片段
✅ 所有路径使用os.path.join拼接 (跨平台兼容)
✅ Windows路径已规范化
```

## 📁 当前路径结构

```
132456/                              # PROJECT_ROOT (项目根目录)
├── backend/                         # BASE_DIR (后端目录)
│   ├── models_dir/                  # MODEL_DIR
│   │   └── best.pt                  # ✅ 当前使用的训练模型
│   ├── configs/                     # 配置目录
│   │   └── dataset_config.yaml      # 数据集配置
│   ├── models/                      # Python模块目录
│   │   └── manet_module.py          # MANet模块副本
│   ├── detect.py                    # 检测逻辑
│   ├── main.py                      # 主程序
│   ├── video_storage.py             # 视频存储
│   ├── settings.py                  # 配置中心
│   └── requirements.txt             # 依赖清单
│
├── data/                            # DATA_DIR (数据目录)
│   ├── video/                       # VIDEO_DIR (视频存储)
│   └── dataset/                     # DATASET_DIR (数据集)
│
├── yolov8_project/                  # YOLOV8_PROJECT_DIR (外部项目)
│   ├── extra_modules.py             # MANet原始模块
│   ├── data.yaml                    # 原始数据集配置
│   ├── yolov8n.pt                   # ❌ 不存在
│   └── runs/detect/train/weights/
│       └── best.pt                  # ❌ 不存在
│
└── frontend/                        # 前端项目
```

## 🔧 路径配置规则

### 1. **基础路径定义**

```python
# settings.py
BASE_DIR = os.path.dirname(os.path.abspath(__file__))     # backend目录
PROJECT_ROOT = os.path.dirname(BASE_DIR)                  # 项目根目录 (132456)
```

### 2. **路径拼接规范**

```python
# ✅ 正确示例
DATA_DIR = os.path.join(PROJECT_ROOT, "data")             # 从项目根目录出发
MODEL_DIR = os.path.join(BASE_DIR, "models_dir")          # 从backend目录出发

# ❌ 错误示例（会导致重复）
MODEL_DIR = os.path.join(PROJECT_ROOT, "backend", "models_dir")  # 错误！
```

### 3. **路径防错原则**

根据记忆中的**"Python项目路径配置防错经验"**：

| 场景 | BASE_DIR定义 | 拼接方式 | 示例 |
|------|-------------|---------|------|
| backend子目录 | `backend/` | `os.path.join(BASE_DIR, "subdir")` | `models_dir`, `configs` |
| 项目级目录 | `132456/` | `os.path.join(PROJECT_ROOT, "dir")` | `data`, `yolov8_project` |
| 跨目录引用 | 使用`PROJECT_ROOT` | `os.path.join(PROJECT_ROOT, "target", "file")` | 从backend引用yolov8_project |

## 📦 模型加载路径优先级

### 当前生效配置

```
✅ 优先级1: 本地训练模型
   路径: backend/models_dir/best.pt
   状态: ✅ 存在 (将被使用)

❌ 优先级2: 外部训练模型
   路径: yolov8_project/runs/detect/train/weights/best.pt
   状态: ❌ 不存在

❌ 优先级3: 本地预训练模型
   路径: backend/models_dir/yolov8n.pt
   状态: ❌ 不存在

❌ 优先级4: 外部预训练模型
   路径: yolov8_project/yolov8n.pt
   状态: ❌ 不存在
```

### 环境变量覆盖

```bash
# 最高优先级：通过环境变量指定模型
YOLO_MODEL_PATH=C:\path\to\custom_model.pt

# 指定YOLOv8外部项目路径
YOLOV8_PROJECT_DIR=C:\Users\shuang\Desktop\132456\yolov8_project

# 启用/禁用MANet模块
ENABLE_MANET=true
```

## 🎯 路径配置建议

### 已完成优化

1. ✅ **使用相对路径** - 所有路径基于`PROJECT_ROOT`或`BASE_DIR`
2. ✅ **避免路径重复** - 未发现`backend/backend`等重复片段
3. ✅ **跨平台兼容** - 使用`os.path.join`而非硬编码分隔符
4. ✅ **环境变量支持** - 关键路径可通过环境变量覆盖
5. ✅ **自动目录创建** - 启动时自动创建缺失目录

### 待优化项

1. **模型文件缺失** - 建议将预训练模型`yolov8n.pt`复制到`backend/models_dir/`
2. **训练模型同步** - 在`yolov8_project`训练后运行`sync_models.ps1`
3. **数据集路径** - 如果需要实际数据集，配置`DATASET_DIR`指向真实路径

## 🔍 验证方法

### 运行路径验证脚本

```bash
cd backend
.\yolo_env\Scripts\python.exe verify_paths.py
```

### 预期输出

```
✅ BASE_DIR的父目录 = PROJECT_ROOT (正确)
✅ 未发现重复的路径片段
✅ 所有路径使用os.path.join拼接 (跨平台兼容)
✨ 路径配置验证完成 - 全部通过！
```

### 常见问题排查

| 问题 | 原因 | 解决方案 |
|------|------|---------|
| 路径重复 (backend/backend) | BASE_DIR定义错误 | 检查settings.py中的BASE_DIR定义 |
| 文件找不到 | 相对路径计算错误 | 使用verify_paths.py验证 |
| 跨平台路径错误 | 硬编码\或/ | 改用os.path.join |
| 权限错误 | 目录不存在 | 确保自动创建逻辑正常 |

## 📚 相关文件

- [settings.py](./backend/settings.py) - 路径配置中心
- [verify_paths.py](./backend/verify_paths.py) - 路径验证脚本
- [README_PATH.md](../README_PATH.md) - 路径配置说明
- [sync_models.ps1](../sync_models.ps1) - 模型同步脚本

## ⚠️ 重要提示

1. **不要修改BASE_DIR定义** - 会导致所有路径计算错误
2. **使用verify_paths.py验证** - 每次修改路径配置后运行
3. **优先使用PROJECT_ROOT** - 跨目录引用时使用项目根目录
4. **检查日志输出** - 启动时确认路径加载正确

---

**验证时间**: 2026-04-12  
**验证状态**: ✅ 全部通过  
**维护人**: Lingma AI助手