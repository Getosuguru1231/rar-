import cv2
import time
import hashlib

backends = [
    ('CAP_DSHOW', cv2.CAP_DSHOW),
    ('CAP_MSMF', cv2.CAP_MSMF),
    ('CAP_ANY', cv2.CAP_ANY),
]

for name, backend in backends:
    cap = cv2.VideoCapture(0, backend)
    if not cap.isOpened():
        print(f'{name}: Failed to open')
        continue
    
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)
    cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
    
    print(f'\nTesting {name}...')
    hashes = []
    for i in range(10):
        ret, frame = cap.read()
        if ret and frame is not None:
            frame_hash = hashlib.md5(frame.tobytes()).hexdigest()
            hashes.append(frame_hash)
        else:
            print(f'  Frame {i}: read failed')
    
    cap.release()
    
    print(f'  Unique hashes: {len(set(hashes))}/{len(hashes)}')
    if len(set(hashes)) == 1:
        print(f'  WARNING: All frames are identical!')
    else:
        print(f'  SUCCESS: Frames are different')