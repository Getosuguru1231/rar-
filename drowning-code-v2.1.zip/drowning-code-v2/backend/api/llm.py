"""LLM相关API端点

管理语言模型、智能分析等相关API
"""

from fastapi import APIRouter
from pydantic import BaseModel
from services.llm_service import LLMService

router = APIRouter()

class AnalyzeRequest(BaseModel):
    event_data: dict

@router.post("/analyze")
async def analyze_event(request: AnalyzeRequest):
    """分析视频事件"""
    try:
        llm_service = LLMService()
        result = llm_service.analyze_video_event(request.event_data)
        
        if not result.get("success", True):
            return {"code": 200, "data": {"analysis": "LLM服务未配置，跳过AI分析"}}
        
        return {"code": 200, "data": result}
    except Exception as e:
        return {"code": 500, "message": f"分析失败: {str(e)}"}

@router.get("/status")
async def get_llm_status():
    """获取LLM服务状态"""
    try:
        llm_service = LLMService()
        if llm_service.api_key:
            return {"code": 200, "data": {"status": "configured", "message": "LLM服务已配置"}}
        else:
            return {"code": 200, "data": {"status": "not_configured", "message": "LLM服务未配置API密钥"}}
    except Exception as e:
        return {"code": 500, "message": f"获取状态失败: {str(e)}"}

@router.get("/test")
async def test_llm():
    """测试LLM服务连接"""
    try:
        llm_service = LLMService()
        if llm_service.api_key:
            try:
                result = llm_service.test_connection()
                return {"code": 200, "data": {"success": True, "message": result}}
            except Exception as e:
                return {"code": 200, "data": {"success": False, "message": f"LLM服务连接失败: {str(e)}"}}
        else:
            return {"code": 200, "data": {"success": False, "message": "LLM服务未配置API密钥"}}
    except Exception as e:
        return {"code": 500, "message": f"测试失败: {str(e)}"}

@router.get("/config")
async def get_llm_config():
    """获取LLM配置信息"""
    try:
        llm_service = LLMService()
        return {
            "code": 200,
            "data": {
                "api_key_configured": bool(llm_service.api_key),
                "model": llm_service.model,
                "api_base": llm_service.base_url
            }
        }
    except Exception as e:
        return {"code": 500, "message": f"获取配置失败: {str(e)}"}

class GenerateAlertRequest(BaseModel):
    event_data: dict

@router.post("/generate-alert")
async def generate_alert(request: GenerateAlertRequest):
    """使用LLM生成告警"""
    try:
        llm_service = LLMService()
        result = llm_service.generate_alert(request.event_data)
        
        if not result.get("success", True):
            return {"code": 200, "data": {"alert": None, "message": "LLM服务未配置，跳过AI告警生成"}}
        
        return {"code": 200, "data": result}
    except Exception as e:
        return {"code": 500, "message": f"生成告警失败: {str(e)}"}

class AskRequest(BaseModel):
    question: str
    context: dict = {}

@router.post("/ask")
async def ask_llm(request: AskRequest):
    """向LLM提问"""
    try:
        llm_service = LLMService()
        result = llm_service.ask(request.question, request.context)
        
        if not result.get("success", True):
            return {"code": 200, "data": {"answer": "LLM服务未配置，无法回答", "message": "LLM服务未配置"}}
        
        return {"code": 200, "data": result}
    except Exception as e:
        return {"code": 500, "message": f"提问失败: {str(e)}"}

__all__ = ["router"]