"""视频相关API端点

管理视频流、视频管理等相关API
"""

from fastapi import APIRouter

router = APIRouter()

__all__ = ["router"]