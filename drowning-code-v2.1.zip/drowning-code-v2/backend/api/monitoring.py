"""监控相关API端点

管理系统监控、性能指标等相关API
"""

from fastapi import APIRouter
from components.alert_manager import get_alert_manager

router = APIRouter()

@router.get("/stats")
async def get_stats():
    """获取系统统计信息"""
    try:
        from components.utils import get_redis_client
        
        alert_manager = get_alert_manager()
        alert_stats = alert_manager.get_alert_statistics()
        
        people_count = 0
        in_water_count = 0
        out_water_count = 0
        
        try:
            redis_client = get_redis_client()
            people_count_data = redis_client.get("people_count")
            if people_count_data:
                import json
                data = json.loads(people_count_data)
                people_count = data.get("people_count", 0)
                in_water_count = data.get("in_water_count", 0)
                out_water_count = data.get("out_water_count", 0)
        except Exception as e:
            pass
        
        return {
            "code": 200,
            "data": {
                "people_count": people_count,
                "in_water_count": in_water_count,
                "out_water_count": out_water_count,
                "alert_count": alert_stats.get("total", 0),
                "today_alerts": alert_stats.get("today", 0)
            }
        }
    except Exception as e:
        return {"code": 500, "message": f"获取统计信息失败: {str(e)}"}

@router.get("/metrics")
async def get_metrics():
    """获取系统监控指标"""
    try:
        from components.monitoring import get_system_monitor
        monitor = get_system_monitor()
        metrics = monitor.get_system_metrics()
        return {"code": 200, "data": metrics}
    except Exception as e:
        return {"code": 500, "message": f"获取监控指标失败: {str(e)}"}

__all__ = ["router"]