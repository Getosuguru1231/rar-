"""视频清理API端点"""

from fastapi import APIRouter
from pydantic import BaseModel
from services.video_cleaner_service import VideoCleanerService
import logging

logger = logging.getLogger(__name__)

router = APIRouter()

class CleanupRequest(BaseModel):
    retention_days: int = 3

@router.post("/cleanup")
async def cleanup_videos(request: CleanupRequest):
    """清理过期视频文件"""
    try:
        cleaner = VideoCleanerService()
        result = cleaner.cleanup_videos(days_to_keep=request.retention_days)

        logger.info(f"[视频清理] 扫描: {result.get('total_files_deleted', 0)}个")

        return {
            "code": 200,
            "message": "清理完成",
            "data": result
        }
    except Exception as e:
        logger.error(f"[视频清理] 清理失败: {e}")
        return {"code": 500, "message": f"清理失败: {str(e)}"}

@router.get("/folders")
async def list_video_folders():
    """列出所有视频文件夹"""
    try:
        cleaner = VideoCleanerService()
        result = cleaner.list_video_folders()

        return {
            "code": 200,
            "message": "获取成功",
            "data": result
        }
    except Exception as e:
        logger.error(f"[视频文件夹] 获取失败: {e}")
        return {"code": 500, "message": f"获取失败: {str(e)}"}

@router.delete("/folder/{folder_name}")
async def delete_video_folder(folder_name: str):
    """删除指定文件夹的视频"""
    try:
        cleaner = VideoCleanerService()
        result = cleaner.delete_by_folder(folder_name)

        if result["success"]:
            logger.info(f"[视频文件夹删除] 已删除: {folder_name}")
            return {
                "code": 200,
                "message": result["message"],
                "data": result
            }
        else:
            return {
                "code": 404,
                "message": result["message"],
                "data": result
            }
    except Exception as e:
        logger.error(f"[视频文件夹删除] 删除失败: {e}")
        return {"code": 500, "message": f"删除失败: {str(e)}"}

@router.delete("/upload/all")
async def delete_all_uploaded_videos():
    """删除所有上传的视频文件"""
    try:
        cleaner = VideoCleanerService()
        result = cleaner.delete_all_uploaded_videos()

        if result["success"]:
            logger.info(f"[上传视频删除] 已删除全部: {result['deleted_files']}个")
            return {
                "code": 200,
                "message": result["message"],
                "data": result
            }
        else:
            return {
                "code": 500,
                "message": result["message"],
                "data": result
            }
    except Exception as e:
        logger.error(f"[上传视频删除] 删除全部失败: {e}")
        return {"code": 500, "message": f"删除失败: {str(e)}"}

@router.delete("/upload/{filename}")
async def delete_uploaded_video(filename: str):
    """删除上传的视频文件"""
    try:
        cleaner = VideoCleanerService()
        result = cleaner.delete_uploaded_video(filename)

        if result["success"]:
            logger.info(f"[上传视频删除] 已删除: {filename}")
            return {
                "code": 200,
                "message": result["message"],
                "data": result
            }
        else:
            return {
                "code": 404,
                "message": result["message"],
                "data": result
            }
    except Exception as e:
        logger.error(f"[上传视频删除] 删除失败: {e}")
        return {"code": 500, "message": f"删除失败: {str(e)}"}

__all__ = ["router"]