"""告警相关API端点

管理系统告警、告警历史等相关API
"""

from fastapi import APIRouter, HTTPException
from typing import List, Dict
from components.alert_manager import get_alert_manager

router = APIRouter()

@router.post("/trigger")
async def trigger_alert(camera_id: int, area: str, level: str, reason: str):
    """触发告警"""
    alert_manager = get_alert_manager()
    result = alert_manager.trigger_alert(camera_id, area, level, reason)
    
    if not result["success"]:
        raise HTTPException(status_code=400, detail=result["message"])
    
    return result

@router.post("/test-alert")
async def test_alert():
    """测试告警推送"""
    alert_manager = get_alert_manager()
    result = alert_manager.trigger_alert(
        camera_id=1,
        area="游泳池",
        level="high",
        reason="检测到溺水行为"
    )
    
    if not result["success"]:
        raise HTTPException(status_code=400, detail=result["message"])
    
    return {"code": 200, "message": "测试告警已触发"}

@router.get("/list")
async def get_alert_list(page: int = 1, size: int = 20):
    """获取告警列表"""
    alert_manager = get_alert_manager()
    alerts = alert_manager.get_alerts(page=page, size=size)
    return {"code": 200, "message": "success", "data": alerts}

@router.get("/drowning-timeline")
async def get_drowning_timeline(camera_id: int = None):
    """获取溺水事件时间线"""
    alert_manager = get_alert_manager()
    timeline = alert_manager.get_drowning_timeline(camera_id=camera_id)
    return {"code": 200, "data": timeline}

@router.get("/unacknowledged")
async def get_unacknowledged_alerts():
    """获取未处理告警"""
    alert_manager = get_alert_manager()
    alerts = alert_manager.get_unacknowledged_alerts()
    return {"code": 200, "data": alerts}

@router.post("/acknowledge/{alert_id}")
async def acknowledge_alert(alert_id: int):
    """确认告警"""
    alert_manager = get_alert_manager()
    result = alert_manager.acknowledge_alert(alert_id)
    
    if not result:
        raise HTTPException(status_code=400, detail="确认告警失败")
    
    return {"code": 200, "message": "告警已确认"}

@router.post("/resolve/{alert_id}")
async def resolve_alert(alert_id: int):
    """解决告警"""
    alert_manager = get_alert_manager()
    result = alert_manager.resolve_alert(alert_id)
    
    if not result:
        raise HTTPException(status_code=400, detail="解决告警失败")
    
    return {"code": 200, "message": "告警已解决"}

@router.get("/today")
async def get_today_alerts():
    """获取今日告警统计"""
    alert_manager = get_alert_manager()
    stats = alert_manager.get_today_stats()
    return {"code": 200, "data": stats}

@router.get("/statistics")
async def get_alert_statistics():
    """获取告警统计信息"""
    alert_manager = get_alert_manager()
    stats = alert_manager.get_alert_statistics()
    return {"code": 200, "data": stats}

@router.get("/recent")
async def get_recent_alerts(limit: int = 10):
    """获取最近告警"""
    alert_manager = get_alert_manager()
    alerts = alert_manager.get_alerts(page=1, size=limit)
    return {"code": 200, "data": alerts}

@router.get("/stats")
async def get_alert_stats():
    """获取告警统计"""
    alert_manager = get_alert_manager()
    stats = alert_manager.get_stats()
    return {"code": 200, "data": stats}

@router.delete("/delete/{alert_id}")
async def delete_alert(alert_id: str):
    """删除单个告警"""
    try:
        if ':' in alert_id:
            alert_id = alert_id.split(':')[0]
        alert_id_int = int(alert_id)
    except ValueError:
        raise HTTPException(status_code=400, detail="无效的告警ID")
    
    alert_manager = get_alert_manager()
    result = alert_manager.delete_alert(alert_id_int)
    
    if not result:
        raise HTTPException(status_code=400, detail="删除告警失败")
    
    return {"code": 200, "message": "告警已删除"}

@router.delete("/delete-all")
async def delete_all_alerts():
    """删除所有告警"""
    alert_manager = get_alert_manager()
    count = alert_manager.delete_all_alerts()
    
    return {"code": 200, "message": f"已删除{count}条告警"}

__all__ = ["router"]