"""WebSocket视频流端点

提供低延迟的WebSocket视频流服务，支持前端实时显示监控画面
高性能版本：帧队列 + 快速传输 + 自动帧率适配
"""

import asyncio
import json
import time
import queue
from fastapi import APIRouter, WebSocket, WebSocketDisconnect

router = APIRouter()

active_connections = {}
client_frame_queues = {}

FRAME_STALE_THRESHOLD = 3.0


@router.websocket("/ws/video/{camera_id}")
async def video_websocket(websocket: WebSocket, camera_id: int):
    """
    WebSocket视频流端点（高性能低延迟版）
    
    连接方式: ws://localhost:8000/ws/video/{camera_id}?quality=85&fps=30&width=1280&height=720
    
    参数:
        camera_id: 摄像头ID
        quality: JPEG质量(1-100)，默认85（高质量）
        fps: 帧率(5-60)，默认30（流畅）
        width: 帧宽度，默认1280
        height: 帧高度，默认720
    
    返回:
        二进制JPEG帧数据
    """
    await websocket.accept()
    
    query_params = websocket.query_params
    quality = max(50, min(100, int(query_params.get("quality", 85))))
    fps = max(5, min(60, int(query_params.get("fps", 30))))
    width = max(640, min(1920, int(query_params.get("width", 1280))))
    height = max(480, min(1080, int(query_params.get("height", 720))))
    
    frame_interval = 1.0 / fps
    last_frame_time = time.time()
    consecutive_errors = 0
    max_consecutive_errors = 15
    frame_skip_count = 0
    last_sent_frame_hash = None
    
    frame_queue = queue.Queue(maxsize=30)
    
    client_key = f"{camera_id}_{id(websocket)}"
    client_frame_queues[client_key] = frame_queue
    
    print(f"[WebSocket视频流] 新连接 - 摄像头{camera_id}, 质量:{quality}, 帧率:{fps}, 分辨率:{width}x{height}")
    
    try:
        from components.utils import get_redis_client
        redis_client = get_redis_client(decode_responses=False)
        
        redis_task = asyncio.create_task(redis_reader(redis_client, camera_id, frame_queue))
        
        while True:
            try:
                current_time = time.time()
                elapsed = current_time - last_frame_time
                
                if elapsed < frame_interval:
                    sleep_time = frame_interval - elapsed
                    if sleep_time > 0.005:
                        await asyncio.sleep(sleep_time)
                
                try:
                    frame_data, frame_timestamp = frame_queue.get_nowait()
                    frame_skip_count = 0
                except queue.Empty:
                    frame_skip_count += 1
                    if frame_skip_count > fps * 2:
                        await websocket.send_json({
                            "type": "warning",
                            "message": f"帧率不足，连续{frame_skip_count}帧丢失"
                        })
                    continue
                
                if frame_data:
                    current_hash = hash(frame_data)
                    
                    if current_hash != last_sent_frame_hash:
                        is_stale = False
                        if frame_timestamp:
                            elapsed_since_frame = time.time() - frame_timestamp
                            if elapsed_since_frame > FRAME_STALE_THRESHOLD:
                                is_stale = True
                                await websocket.send_json({
                                    "type": "stale_frame",
                                    "message": f"帧延迟{elapsed_since_frame:.2f}s"
                                })
                        
                        await websocket.send_bytes(frame_data)
                        last_sent_frame_time = time.time()
                        last_sent_frame_hash = current_hash
                
            except asyncio.CancelledError:
                break
            except Exception as e:
                consecutive_errors += 1
                print(f"[WebSocket视频流] 发送失败: {e}")
                if consecutive_errors >= max_consecutive_errors:
                    break
                await asyncio.sleep(0.05)
                
    except WebSocketDisconnect:
        print(f"[WebSocket视频流] 连接断开 - 摄像头{camera_id}")
    except Exception as e:
        print(f"[WebSocket视频流] 错误: {e}")
    finally:
        try:
            redis_task.cancel()
        except:
            pass
        try:
            await websocket.close()
        except:
            pass
        del client_frame_queues[client_key]
        print(f"[WebSocket视频流] 连接关闭 - 摄像头{camera_id}")


async def redis_reader(redis_client, camera_id, frame_queue):
    """
    Redis帧读取器（异步）
    持续从Redis读取最新帧，放入帧队列
    """
    camera_key = f"current_frame_{camera_id}"
    camera_ts_key = f"current_frame_timestamp_{camera_id}"
    fallback_key = "current_frame"
    
    last_frame_hash = None
    consecutive_failures = 0
    
    while True:
        try:
            if redis_client is None:
                from components.utils import get_redis_client
                redis_client = get_redis_client(decode_responses=False)
                consecutive_failures = 0
            
            frame_data = None
            frame_timestamp = None
            
            try:
                frame_data = redis_client.get(camera_key)
                if not frame_data:
                    frame_data = redis_client.get(fallback_key)
                
                ts_data = redis_client.get(camera_ts_key)
                if ts_data:
                    try:
                        frame_timestamp = float(ts_data)
                    except (ValueError, TypeError):
                        frame_timestamp = None
            except Exception as redis_err:
                print(f"[Redis读取器] 错误: {redis_err}")
                redis_client = None
                consecutive_failures += 1
                if consecutive_failures > 10:
                    await asyncio.sleep(0.5)
                else:
                    await asyncio.sleep(0.1)
                continue
            
            if frame_data:
                current_hash = hash(frame_data)
                
                if current_hash != last_frame_hash:
                    is_stale = False
                    if frame_timestamp:
                        elapsed = time.time() - frame_timestamp
                        if elapsed > FRAME_STALE_THRESHOLD:
                            is_stale = True
                    
                    if frame_queue.full():
                        try:
                            frame_queue.get_nowait()
                        except queue.Empty:
                            pass
                    
                    frame_queue.put((frame_data, frame_timestamp))
                    last_frame_hash = current_hash
                    consecutive_failures = 0
            
            await asyncio.sleep(0.008)
            
        except asyncio.CancelledError:
            break
        except Exception as e:
            print(f"[Redis读取器] 异常: {e}")
            await asyncio.sleep(0.1)