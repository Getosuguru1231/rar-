"""统一实时监控通道

提供 WebSocket 接口，同时推送：
- 视频帧
- 人数统计
- 告警信息
- 系统状态
"""

import asyncio
import json
import time
import base64
import cv2
import numpy as np
from fastapi import APIRouter, WebSocket, WebSocketDisconnect
from typing import Dict, Set

from components.utils import get_redis_client

router = APIRouter()

class UnifiedMonitorServer:
    """统一监控服务器 - 管理所有监控连接"""
    
    def __init__(self):
        self.active_connections: Set[WebSocket] = set()
        self.redis_client = None
        self._last_frame_data = None
        self._last_people_count = None
        self._last_frame_time = 0
        self._frame_interval = 0.1  # 10 FPS for metadata push
        
    def init_redis(self):
        """初始化 Redis 连接（使用统一的连接池管理）"""
        try:
            self.redis_client = get_redis_client(decode_responses=False)
            print("[UnifiedMonitor] Redis 连接成功")
        except Exception as e:
            print(f"[UnifiedMonitor] Redis 连接失败: {e}")
            self.redis_client = None
    
    async def connect(self, websocket: WebSocket):
        """接受新的 WebSocket 连接"""
        await websocket.accept()
        self.active_connections.add(websocket)
        print(f"[UnifiedMonitor] 新连接，当前连接数: {len(self.active_connections)}")
        
        # 初始化 Redis（如果尚未初始化）
        if self.redis_client is None:
            self.init_redis()
    
    def disconnect(self, websocket: WebSocket):
        """断开 WebSocket 连接"""
        self.active_connections.discard(websocket)
        print(f"[UnifiedMonitor] 断开连接，当前连接数: {len(self.active_connections)}")
    
    def get_people_count_data(self) -> dict:
        """从 Redis 获取人数统计数据（支持多摄像头，只返回已连接摄像头的数据）"""
        if not self.redis_client:
            return {
                "people_count": 0,
                "in_water_count": 0,
                "out_water_count": 0,
                "timestamp": time.time(),
                "cameras": {}
            }
        
        try:
            from settings import CAMERA_CONFIG
            
            total_stats_raw = self.redis_client.get("people_count")
            total_stats = {}
            if total_stats_raw:
                if isinstance(total_stats_raw, bytes):
                    total_stats_raw = total_stats_raw.decode('utf-8')
                try:
                    total_stats = json.loads(total_stats_raw)
                except:
                    pass
            
            cameras_data = {}
            for camera_id in CAMERA_CONFIG:
                config = CAMERA_CONFIG[camera_id]
                if not config.get("enabled", True):
                    continue
                
                source = config.get("source")
                if source is None:
                    continue
                
                cam_stats_raw = self.redis_client.get(f"people_count_{camera_id}")
                if cam_stats_raw:
                    if isinstance(cam_stats_raw, bytes):
                        cam_stats_raw = cam_stats_raw.decode('utf-8')
                    try:
                        cam_stats = json.loads(cam_stats_raw)
                        cameras_data[camera_id] = {
                            "people_count": cam_stats.get("people_count", 0),
                            "in_water_count": cam_stats.get("in_water_count", 0),
                            "out_water_count": cam_stats.get("out_water_count", 0)
                        }
                    except:
                        pass
            
            return {
                "people_count": total_stats.get("people_count", 0),
                "in_water_count": total_stats.get("in_water_count", 0),
                "out_water_count": total_stats.get("out_water_count", 0),
                "timestamp": total_stats.get("timestamp", time.time()),
                "cameras": cameras_data
            }
        except Exception as e:
            print(f"[UnifiedMonitor] 获取人数统计失败: {e}")
            return {
                "people_count": 0,
                "in_water_count": 0,
                "out_water_count": 0,
                "timestamp": time.time(),
                "cameras": {}
            }
    
    def get_frame_data(self, camera_id: int = 1) -> dict:
        """从 Redis 获取视频帧数据（支持多摄像头）"""
        return {"has_frame": False}
    
    def get_all_frame_data(self) -> dict:
        """从 Redis 获取所有摄像头的视频帧数据（已禁用，使用MJPEG视频流）"""
        return {}
    
    def get_detection_data(self) -> dict:
        """从 Redis 获取检测状态数据"""
        if not self.redis_client:
            return {"is_drowning": False, "confidence": 0}
        
        try:
            is_drowning = self.redis_client.get("is_drowning")
            confidence = self.redis_client.get("drowning_confidence")
            
            if is_drowning is not None:
                is_drowning_val = is_drowning.decode('utf-8') == 'true' if isinstance(is_drowning, bytes) else is_drowning == 'true'
                conf_val = float(confidence.decode('utf-8')) if isinstance(confidence, bytes) else float(confidence or 0)
                return {
                    "is_drowning": is_drowning_val,
                    "confidence": conf_val
                }
        except Exception:
            pass
        
        return {"is_drowning": False, "confidence": 0}
    
    async def broadcast_update(self):
        """广播最新的监控数据给所有连接"""
        if not self.active_connections:
            return
        
        current_time = time.time()
        
        # 节流：限制元数据更新频率
        if current_time - self._last_frame_time >= self._frame_interval:
            self._last_frame_time = current_time
            
            # 收集所有数据
            data = {
                "type": "monitor_update",
                "people_count": self.get_people_count_data(),
                "detection": self.get_detection_data(),
                "timestamp": current_time
            }
            
            # 广播给所有连接
            disconnected = set()
            for connection in self.active_connections:
                try:
                    await connection.send_json(data)
                except Exception:
                    disconnected.add(connection)
            
            # 清理断开的连接
            for conn in disconnected:
                self.active_connections.discard(conn)
    
    async def broadcast_frame_update(self):
        """广播所有摄像头的帧数据给所有连接（已禁用，使用MJPEG视频流）"""
        pass
    
    async def broadcast_alert(self, alert: dict):
        """广播告警消息给所有连接"""
        if not self.active_connections:
            return
        
        data = {
            "type": "alert",
            "data": alert,
            "timestamp": time.time()
        }
        
        disconnected = set()
        for connection in self.active_connections:
            try:
                await connection.send_json(data)
            except Exception:
                disconnected.add(connection)
        
        for conn in disconnected:
            self.active_connections.discard(conn)
    
    async def broadcast_alert_update(self, alert: dict):
        """广播告警状态更新给所有连接"""
        if not self.active_connections:
            return
        
        data = {
            "type": "alert_update",
            "data": alert,
            "timestamp": time.time()
        }
        
        disconnected = set()
        for connection in self.active_connections:
            try:
                await connection.send_json(data)
            except Exception:
                disconnected.add(connection)
        
        for conn in disconnected:
            self.active_connections.discard(conn)
    
    async def broadcast_alert_delete(self, alert_id: int):
        """广播告警删除消息给所有连接"""
        if not self.active_connections:
            return
        
        data = {
            "type": "alert_delete",
            "data": {"id": alert_id},
            "timestamp": time.time()
        }
        
        disconnected = set()
        for connection in self.active_connections:
            try:
                await connection.send_json(data)
            except Exception:
                disconnected.add(connection)
        
        for conn in disconnected:
            self.active_connections.discard(conn)
    
    async def broadcast_alert_clear(self):
        """广播清空告警消息给所有连接"""
        if not self.active_connections:
            return
        
        data = {
            "type": "alert_clear",
            "data": {},
            "timestamp": time.time()
        }
        
        disconnected = set()
        for connection in self.active_connections:
            try:
                await connection.send_json(data)
            except Exception:
                disconnected.add(connection)
        
        for conn in disconnected:
            self.active_connections.discard(conn)


# 全局单例
monitor_server = UnifiedMonitorServer()


@router.websocket("/ws/monitor")
async def unified_monitor_websocket(websocket: WebSocket):
    """统一监控 WebSocket 端点（仅传输元数据，视频帧使用MJPEG）"""
    await monitor_server.connect(websocket)
    
    try:
        broadcast_task = asyncio.create_task(broadcast_loop(websocket))
        
        while True:
            try:
                data = await websocket.receive_text()
                message = json.loads(data)
                
                if message.get("type") == "ping":
                    await websocket.send_json({"type": "pong", "timestamp": time.time()})
                elif message.get("type") == "request_frame":
                    await websocket.send_json({
                        "type": "frame_data",
                        "camera_id": message.get("camera_id", 1),
                        "has_frame": False,
                        "message": "请使用MJPEG视频流获取帧数据"
                    })
                elif message.get("type") == "request_all_frames":
                    await websocket.send_json({
                        "type": "frame_update",
                        "frames": {},
                        "message": "请使用MJPEG视频流获取帧数据"
                    })
                        
            except json.JSONDecodeError:
                pass
            except WebSocketDisconnect:
                break
            except Exception as e:
                print(f"[UnifiedMonitor] 接收消息错误: {e}")
                
    except WebSocketDisconnect:
        pass
    except Exception as e:
        print(f"[UnifiedMonitor] WebSocket 错误: {e}")
    finally:
        broadcast_task.cancel()
        monitor_server.disconnect(websocket)


async def broadcast_loop(websocket: WebSocket):
    """定期广播监控数据（人数统计、检测状态）"""
    try:
        while True:
            await monitor_server.broadcast_update()
            await asyncio.sleep(0.1)
    except asyncio.CancelledError:
        pass
    except Exception as e:
        print(f"[UnifiedMonitor] 广播循环错误: {e}")


async def frame_broadcast_loop():
    """定期广播帧数据（已禁用）"""
    pass


@router.get("/monitor/stats")
async def get_monitor_stats():
    """获取监控服务器状态"""
    return {
        "active_connections": len(monitor_server.active_connections),
        "redis_connected": monitor_server.redis_client is not None
    }


__all__ = ["router"]
