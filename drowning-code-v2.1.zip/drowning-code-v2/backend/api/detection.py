"""检测相关API端点

提供视频上传检测、检测结果查询等功能
"""

import os
import uuid
import shutil
import time
from datetime import datetime
from fastapi import APIRouter, UploadFile, File, BackgroundTasks
from fastapi.responses import FileResponse
from pydantic import BaseModel
import cv2
from ultralytics import YOLO

from settings import *

router = APIRouter()

tasks = {}

class DetectionRequest(BaseModel):
    video_path: str = None

@router.post("/upload")
async def upload_video(file: UploadFile = File(...), background_tasks: BackgroundTasks = None):
    """上传视频进行检测"""
    try:
        filename = file.filename
        task_id = str(uuid.uuid4())[:8]
        
        upload_path = os.path.join(UPLOAD_DIR, filename)
        os.makedirs(UPLOAD_DIR, exist_ok=True)
        
        with open(upload_path, 'wb') as f:
            f.write(await file.read())
        
        file_type = 'image' if filename.lower().endswith(('.jpg', '.jpeg', '.png', '.bmp')) else 'video'
        
        tasks[task_id] = {
            "task_id": task_id,
            "status": "processing",
            "progress": 0,
            "filename": filename,
            "file_type": file_type,
            "upload_path": upload_path,
            "people_count": 0,
            "drowning_risk": "normal",
            "drowning_events": [],
            "saved_images": [],
            "result": None
        }
        
        background_tasks.add_task(process_video, task_id)
        
        return {"code": 200, "message": "上传成功", "task_id": task_id}
    except Exception as e:
        return {"code": 500, "message": f"上传失败: {str(e)}"}

def process_video(task_id: str):
    """处理视频检测（后台任务）"""
    task = tasks.get(task_id)
    if not task:
        return
    
    try:
        model = YOLO(MODEL_PATH)
        cap = cv2.VideoCapture(task["upload_path"])
        
        if not cap.isOpened():
            tasks[task_id] = {"task_id": task_id, "status": "failed", "message": "无法打开视频", "filename": task["filename"], "file_type": task["file_type"]}
            return
        
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        results_dir = os.path.join(RESULTS_DIR, task_id)
        os.makedirs(results_dir, exist_ok=True)
        
        frame_count = 0
        saved_count = 0
        max_screenshots = 20
        last_frame_time = 0
        people_count_total = 0
        drowning_events = []
        saved_images = []
        max_confidence = 0.0
        in_water_count = 0
        
        while True:
            ret, frame = cap.read()
            if not ret:
                break
            
            frame_count += 1
            
            current_time = time.time()
            
            if frame_count % 5 == 0:
                results = model(frame, imgsz=IMGSZ, conf=CONF_THRESHOLD)
                
                has_dangerous = False
                detected_persons = []
                current_people = 0
                current_in_water = 0
                
                for result in results:
                    for box in result.boxes:
                        cls = int(box.cls[0])
                        conf = float(box.conf[0])
                        x1, y1, x2, y2 = map(int, box.xyxy[0])
                        
                        detected_persons.append({
                            "x": x1,
                            "y": y1,
                            "width": x2 - x1,
                            "height": y2 - y1,
                            "class": cls,
                            "class_name": CLASS_NAMES.get(cls, f'class_{cls}'),
                            "confidence": conf
                        })
                        
                        current_people += 1
                        
                        if cls == 0 or cls == 1:
                            current_in_water += 1
                            has_dangerous = True
                            max_confidence = max(max_confidence, conf)
                            
                            if conf > CONF_THRESHOLD:
                                drowning_events.append({
                                    "frame": frame_count,
                                    "timestamp": current_time,
                                    "type": "溺水检测",
                                    "confidence": conf,
                                    "class": cls,
                                    "class_name": CLASS_NAMES.get(cls, f'class_{cls}'),
                                    "bbox": {"x": x1, "y": y1, "width": x2 - x1, "height": y2 - y1}
                                })
                
                people_count_total = max(people_count_total, current_people)
                in_water_count += current_in_water
                
                if has_dangerous and saved_count < max_screenshots:
                    screenshot_path = os.path.join(results_dir, f"alert_frame_{frame_count}.jpg")
                    cv2.imwrite(screenshot_path, frame)
                    saved_images.append({
                        "filename": f"alert_frame_{frame_count}.jpg",
                        "frame": frame_count,
                        "timestamp": current_time,
                        "confidence": max_confidence
                    })
                    saved_count += 1
            
            if current_time - last_frame_time >= 0.15:
                live_frame_path = os.path.join(results_dir, "_live_frame.jpg")
                cv2.imwrite(live_frame_path, frame)
                last_frame_time = current_time
                
                tasks[task_id]["current_frame"] = {
                    "timestamp": current_time,
                    "frame_count": frame_count,
                    "detected_persons": detected_persons if 'detected_persons' in locals() else []
                }
            
            tasks[task_id]["progress"] = int((frame_count / total_frames) * 100)
            tasks[task_id]["people_count"] = people_count_total
            tasks[task_id]["drowning_events"] = drowning_events
            tasks[task_id]["saved_images"] = saved_images
        
        cap.release()
        
        drowning_risk = "normal"
        if in_water_count > 0:
            if max_confidence >= HIGH_CONFIDENCE_THRESHOLD:
                drowning_risk = "high"
            else:
                drowning_risk = "medium"
        
        tasks[task_id].update({
            "status": "completed",
            "progress": 100,
            "people_count": people_count_total,
            "drowning_risk": drowning_risk,
            "drowning_events": drowning_events,
            "saved_images": saved_images,
            "result": {
                "total_frames": total_frames,
                "screenshots_saved": saved_count,
                "task_id": task_id,
                "images": [img["filename"] for img in saved_images]
            }
        })
        
    except Exception as e:
        tasks[task_id] = {"task_id": task_id, "status": "failed", "message": str(e), "filename": task.get("filename", ""), "file_type": task.get("file_type", "video")}

@router.get("/result/{task_id}")
async def get_result(task_id: str):
    """获取检测结果"""
    task = tasks.get(task_id)
    if not task:
        return {"code": 404, "message": "任务不存在"}
    
    if task["status"] == "completed":
        result_dir = os.path.join(RESULTS_DIR, task_id)
        images = []
        if os.path.exists(result_dir):
            for f in sorted(os.listdir(result_dir)):
                if f.endswith('.jpg') and not f.startswith('_'):
                    images.append(f)
        
        task["result"]["images"] = images
    
    return {"code": 200, "data": task}

@router.get("/tasks")
async def get_tasks():
    """获取任务列表"""
    return {"code": 200, "data": list(tasks.values())}

@router.delete("/task/{task_id}")
async def delete_task(task_id: str):
    """删除任务"""
    if task_id in tasks:
        task = tasks[task_id]
        upload_path = task.get("upload_path")
        if upload_path and os.path.exists(upload_path):
            os.remove(upload_path)
        
        result_dir = os.path.join(RESULTS_DIR, task_id)
        if os.path.exists(result_dir):
            shutil.rmtree(result_dir)
        
        del tasks[task_id]
        return {"code": 200, "message": "删除成功"}
    return {"code": 404, "message": "任务不存在"}

@router.get("/videos/list")
async def list_videos():
    """获取视频列表"""
    videos = []
    if os.path.exists(UPLOAD_DIR):
        for f in os.listdir(UPLOAD_DIR):
            if f.endswith(('.mp4', '.avi', '.mov')):
                filepath = os.path.join(UPLOAD_DIR, f)
                stat = os.stat(filepath)
                videos.append({
                    "filename": f,
                    "size": stat.st_size,
                    "created_at": datetime.fromtimestamp(stat.st_ctime).isoformat()
                })
    
    return {"code": 200, "data": videos}

@router.delete("/videos/cleanup")
async def cleanup_videos():
    """清理旧视频"""
    if os.path.exists(UPLOAD_DIR):
        for f in os.listdir(UPLOAD_DIR):
            if f.endswith(('.mp4', '.avi', '.mov')):
                os.remove(os.path.join(UPLOAD_DIR, f))
    
    if os.path.exists(RESULTS_DIR):
        shutil.rmtree(RESULTS_DIR)
        os.makedirs(RESULTS_DIR, exist_ok=True)
    
    return {"code": 200, "message": "清理完成"}

@router.get("/results/images/{task_id}")
async def get_result_images(task_id: str):
    """获取任务图片列表"""
    result_dir = os.path.join(RESULTS_DIR, task_id)
    images = []
    
    if os.path.exists(result_dir):
        for f in sorted(os.listdir(result_dir)):
            if f.endswith('.jpg'):
                images.append(f)
    
    return {"code": 200, "data": images}

@router.get("/results/images/{task_id}/{filename}")
async def get_result_image(task_id: str, filename: str):
    """获取任务图片"""
    filepath = os.path.join(RESULTS_DIR, task_id, filename)
    if os.path.exists(filepath):
        return FileResponse(filepath)
    return {"code": 404, "message": "图片不存在"}

@router.get("/performance")
async def get_detection_performance():
    """获取检测性能统计"""
    try:
        from detection.detect import get_performance_stats
        performance_stats = get_performance_stats()
        return {"code": 200, "data": performance_stats}
    except Exception as e:
        logger.error(f"获取检测性能统计失败: {str(e)}")
        return {"code": 500, "message": "获取检测性能统计失败"}

@router.get("/live-frame/{task_id}")
async def get_live_frame(task_id: str):
    """获取检测任务的实时帧"""
    task = tasks.get(task_id)
    if not task:
        return {"code": 404, "message": "任务不存在"}
    
    result_dir = os.path.join(RESULTS_DIR, task_id)
    if not os.path.exists(result_dir):
        return {"code": 200, "data": {"frame": None, "task_id": task_id, "status": task["status"]}}
    
    live_frame_path = os.path.join(result_dir, "_live_frame.jpg")
    if os.path.exists(live_frame_path):
        with open(live_frame_path, 'rb') as f:
            import base64
            frame_data = base64.b64encode(f.read()).decode('utf-8')
        
        current_frame_info = task.get("current_frame", {})
        
        return {
            "code": 200,
            "data": {
                "frame": frame_data,
                "task_id": task_id,
                "status": task["status"],
                "progress": task.get("progress", 0),
                "timestamp": current_frame_info.get("timestamp", 0),
                "frame_count": current_frame_info.get("frame_count", 0),
                "detected_persons": current_frame_info.get("detected_persons", [])
            }
        }
    
    images = []
    for f in sorted(os.listdir(result_dir)):
        if f.endswith('.jpg') and not f.startswith('_'):
            images.append(f)
    
    if images:
        latest_image = images[-1]
        image_path = os.path.join(result_dir, latest_image)
        with open(image_path, 'rb') as f:
            import base64
            frame_data = base64.b64encode(f.read()).decode('utf-8')
        return {
            "code": 200,
            "data": {
                "frame": frame_data,
                "task_id": task_id,
                "status": task["status"],
                "progress": task.get("progress", 0),
                "detected_persons": []
            }
        }
    
    return {"code": 200, "data": {"frame": None, "task_id": task_id, "status": task["status"], "detected_persons": []}}

__all__ = ["router"]
