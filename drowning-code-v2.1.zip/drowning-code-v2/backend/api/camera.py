"""摄像头相关API端点

管理摄像头状态、摄像头连接等相关API
"""

import json
from fastapi import APIRouter, HTTPException
from settings import CAMERA_CONFIG, get_camera_config
from components.utils import get_redis_client

router = APIRouter()

@router.get("/status")
async def get_camera_status(camera_id: int = None):
    """获取摄像头状态"""
    if camera_id:
        config = get_camera_config(camera_id)
        redis_client = get_redis_client()
        
        status = {
            "camera_id": camera_id,
            "name": config["name"],
            "area": config["area"],
            "enabled": config["enabled"],
            "type": config["type"],
            "connected": False,
            "fps": 0,
            "people_count": 0
        }
        
        if config["enabled"]:
            try:
                frame_key = f"camera_{camera_id}_frame"
                frame_data = redis_client.get(frame_key)
                if frame_data:
                    status["connected"] = True
                
                stats_key = f"camera_{camera_id}_stats"
                stats_data = redis_client.get(stats_key)
                if stats_data:
                    stats = json.loads(stats_data)
                    status["fps"] = stats.get("fps", 0)
                    status["people_count"] = stats.get("people_count", 0)
            except Exception as e:
                pass
        
        return {"code": 200, "data": status}
    
    all_status = []
    for cam_id in CAMERA_CONFIG:
        config = CAMERA_CONFIG[cam_id]
        all_status.append({
            "camera_id": cam_id,
            "name": config["name"],
            "area": config["area"],
            "enabled": config["enabled"],
            "type": config["type"],
            "connected": config["enabled"]
        })
    
    return {"code": 200, "data": all_status}

@router.get("/health")
async def get_camera_health():
    """获取摄像头健康状态"""
    redis_client = get_redis_client()
    health = {}
    
    for cam_id in CAMERA_CONFIG:
        config = CAMERA_CONFIG[cam_id]
        if not config["enabled"]:
            health[cam_id] = {"status": "disabled", "name": config["name"]}
            continue
        
        try:
            frame_key = f"camera_{cam_id}_frame"
            frame_data = redis_client.get(frame_key)
            
            if frame_data:
                health[cam_id] = {"status": "healthy", "name": config["name"]}
            else:
                health[cam_id] = {"status": "unhealthy", "name": config["name"]}
        except Exception as e:
            health[cam_id] = {"status": "error", "name": config["name"], "error": str(e)}
    
    return {"code": 200, "data": health}

@router.get("/list")
async def get_camera_list():
    """获取摄像头列表"""
    cameras = []
    for cam_id in CAMERA_CONFIG:
        config = CAMERA_CONFIG[cam_id]
        cameras.append({
            "camera_id": cam_id,
            "name": config["name"],
            "area": config["area"],
            "enabled": config["enabled"],
            "type": config["type"],
            "width": config["width"],
            "height": config["height"],
            "fps": config["fps"]
        })
    
    return {"code": 200, "data": cameras}

@router.get("/stats")
async def get_camera_stats(camera_id: int = None):
    """获取摄像头统计信息"""
    redis_client = get_redis_client()
    
    if camera_id:
        try:
            stats_key = f"camera_{camera_id}_stats"
            stats_data = redis_client.get(stats_key)
            if stats_data:
                stats = json.loads(stats_data)
                return {"code": 200, "data": stats}
        except Exception as e:
            pass
        
        return {"code": 200, "data": {
            "camera_id": camera_id,
            "people_count": 0,
            "in_water_count": 0,
            "out_water_count": 0,
            "fps": 0
        }}
    
    all_stats = {}
    for cam_id in CAMERA_CONFIG:
        try:
            stats_key = f"camera_{cam_id}_stats"
            stats_data = redis_client.get(stats_key)
            if stats_data:
                all_stats[cam_id] = json.loads(stats_data)
            else:
                all_stats[cam_id] = {
                    "camera_id": cam_id,
                    "people_count": 0,
                    "in_water_count": 0,
                    "out_water_count": 0,
                    "fps": 0
                }
        except Exception as e:
            all_stats[cam_id] = {
                "camera_id": cam_id,
                "people_count": 0,
                "in_water_count": 0,
                "out_water_count": 0,
                "fps": 0,
                "error": str(e)
            }
    
    return {"code": 200, "data": all_stats}

@router.post("/reconnect")
async def reconnect_camera(camera_id: int):
    """重新连接摄像头"""
    if camera_id not in CAMERA_CONFIG:
        raise HTTPException(status_code=404, detail="摄像头不存在")
    
    config = CAMERA_CONFIG[camera_id]
    if not config["enabled"]:
        raise HTTPException(status_code=400, detail="摄像头未启用")
    
    try:
        redis_client = get_redis_client()
        redis_client.set(f"camera_{camera_id}_reconnect", "1")
        
        return {"code": 200, "message": f"已触发摄像头 {camera_id} 重新连接"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"重新连接失败: {str(e)}")

__all__ = ["router"]