"""视频流端点模块

提供摄像头视频流访问接口，支持前端显示实时监控画面
高性能稳定版本：极速传输 + 高稳定性 + 低延迟
"""

from fastapi import APIRouter, Query, Body
from fastapi.responses import StreamingResponse
import asyncio
import cv2
import numpy as np
from datetime import datetime
import time
import logging

logger = logging.getLogger(__name__)

router = APIRouter(prefix="", tags=["video_feed"])

frame_cache = {
    1: {"data": None, "timestamp": 0},
    2: {"data": None, "timestamp": 0},
    3: {"data": None, "timestamp": 0},
    4: {"data": None, "timestamp": 0}
}

MIN_FPS = 5
MAX_FPS = 60
DEFAULT_FPS = 25

FRAME_STALE_THRESHOLD = 1.0
MAX_CONSECUTIVE_EMPTY = 30

performance_metrics = {
    "total_frames_sent": 0,
    "total_bytes_sent": 0,
    "cache_hits": 0,
    "cache_misses": 0,
    "encoding_time_total": 0,
    "encoding_time_count": 0,
    "stale_frames": 0,
    "placeholder_frames": 0,
    "start_time": time.time()
}

from components.utils import get_jpeg_encoding_params
from components.redis_pool import get_redis_connection


@router.get("/api/video_feed")
async def video_feed(
    camera: int = Query(1, description="摄像头ID"),
    quality: int = Query(85, description="视频质量(1-100)"),
    width: int = Query(1280, description="帧宽度"),
    height: int = Query(720, description="帧高度"),
    fps: int = Query(30, description="帧率(5-60)"),
    cache: str = Query("false", description="禁用缓存")
):
    """
    获取摄像头视频流（高性能低延迟版）
    
    Args:
        camera: 摄像头ID，默认1
        quality: JPEG压缩质量，默认85（高质量模式）
        width: 帧宽度，默认1280
        height: 帧高度，默认720
        fps: 帧率，默认30（流畅画面）
        
    Returns:
        MJPEG视频流
    """
    quality = max(60, min(95, quality))
    width = max(800, min(1920, width))
    height = max(600, min(1080, height))
    fps = max(MIN_FPS, min(MAX_FPS, fps))
    
    camera_key = f"current_frame_{camera}"
    camera_ts_key = f"current_frame_timestamp_{camera}"
    
    async def generate_frames():
        encode_params = get_jpeg_encoding_params(quality, optimize=True)
        
        last_frame_time = time.time()
        frame_interval = 1.0 / fps
        consecutive_empty = 0
        last_sent_frame_hash = None
        
        redis_client = None
        redis_retry_count = 0
        max_redis_retries = 3
        
        while True:
            try:
                frame_data = None
                frame_timestamp = None
                
                if redis_client is None:
                    redis_client = get_redis_connection(decode_responses=False)
                    redis_retry_count = 0
                
                if redis_client:
                    try:
                        pipe = redis_client.pipeline()
                        pipe.get(camera_key)
                        pipe.get(camera_ts_key)
                        pipe.get("current_frame")
                        pipe.get("current_frame_timestamp")
                        results = pipe.execute()
                        
                        frame_data = results[0]
                        ts_data = results[1]
                        
                        if not frame_data:
                            frame_data = results[2]
                            if ts_data is None:
                                ts_data = results[3]
                            
                        if ts_data:
                            try:
                                frame_timestamp = float(ts_data)
                            except (ValueError, TypeError):
                                frame_timestamp = None
                            
                        redis_retry_count = 0
                    except Exception as redis_err:
                        redis_retry_count += 1
                        if redis_retry_count >= max_redis_retries:
                            logger.warning(f"Redis读取失败{max_redis_retries}次，重置连接: {str(redis_err)}")
                            redis_client = None
                            await asyncio.sleep(0.1)
                        else:
                            await asyncio.sleep(0.005)
                        continue
                
                if frame_data:
                    consecutive_empty = 0
                    current_hash = hash(frame_data)
                    
                    if current_hash != last_sent_frame_hash:
                        is_stale = False
                        if frame_timestamp:
                            elapsed = time.time() - frame_timestamp
                            if elapsed > FRAME_STALE_THRESHOLD:
                                is_stale = True
                                performance_metrics["stale_frames"] += 1
                                logger.debug(f"摄像头{camera} 发送过期帧，延迟{elapsed:.2f}s")
                        
                        if camera in frame_cache:
                            frame_cache[camera]["data"] = frame_data
                            frame_cache[camera]["timestamp"] = frame_timestamp or time.time()
                        
                        yield format_frame(frame_data)
                        performance_metrics["total_frames_sent"] += 1
                        performance_metrics["total_bytes_sent"] += len(frame_data)
                        last_sent_frame_hash = current_hash
                    else:
                        pass
                else:
                    consecutive_empty += 1
                    if consecutive_empty >= MAX_CONSECUTIVE_EMPTY:
                        error_frame = create_placeholder_frame(f"摄像头{camera}等待视频源...", encode_params)
                        yield format_frame(error_frame)
                        performance_metrics["placeholder_frames"] += 1
                        consecutive_empty = 0
                
                elapsed = time.time() - last_frame_time
                if elapsed < frame_interval:
                    sleep_time = frame_interval - elapsed
                    if sleep_time > 0.005:
                        await asyncio.sleep(sleep_time)
                last_frame_time = time.time()
                
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"视频流生成异常: {str(e)}")
                redis_client = None
                await asyncio.sleep(0.1)
    
    return StreamingResponse(
        generate_frames(),
        media_type="multipart/x-mixed-replace; boundary=frame",
        headers={
            "Cache-Control": "no-cache, no-store, must-revalidate, max-age=0",
            "Connection": "keep-alive",
            "Pragma": "no-cache",
            "X-Accel-Buffering": "no",
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
            "Access-Control-Allow-Headers": "*",
            "X-Frame-Rate": str(fps),
            "X-Frame-Quality": str(quality)
        }
    )


def format_frame(frame_data):
    """格式化帧数据为MJPEG格式"""
    if isinstance(frame_data, bytes):
        return (b'--frame\r\n'
                b'Content-Type: image/jpeg\r\n'
                b'Content-Length: ' + str(len(frame_data)).encode() + b'\r\n\r\n' 
                + frame_data + b'\r\n')
    else:
        encode_params = get_jpeg_encoding_params(85, optimize=True)
        _, buffer = cv2.imencode('.jpg', frame_data, encode_params)
        frame_bytes = buffer.tobytes()
        return (b'--frame\r\n'
                b'Content-Type: image/jpeg\r\n'
                b'Content-Length: ' + str(len(frame_bytes)).encode() + b'\r\n\r\n' 
                + frame_bytes + b'\r\n')


def create_error_frame(message, encode_params=None):
    """创建错误帧"""
    frame = np.zeros((480, 640, 3), dtype=np.uint8)
    cv2.putText(frame, message, (50, 240), 
                cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
    if encode_params is None:
        encode_params = get_jpeg_encoding_params(70, optimize=True)
    _, buffer = cv2.imencode('.jpg', frame, encode_params)
    return buffer.tobytes()


def create_placeholder_frame(message, encode_params=None):
    """创建占位帧"""
    frame = np.zeros((480, 640, 3), dtype=np.uint8)
    cv2.putText(frame, message, (50, 240), 
                cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)
    timestamp = datetime.now().strftime("%H:%M:%S")
    cv2.putText(frame, timestamp, (50, 440), 
                cv2.FONT_HERSHEY_SIMPLEX, 0.8, (128, 128, 128), 1)
    if encode_params is None:
        encode_params = get_jpeg_encoding_params(70, optimize=True)
    _, buffer = cv2.imencode('.jpg', frame, encode_params)
    return buffer.tobytes()


@router.get("/api/video_feed/snapshot")
async def video_snapshot(camera: int = Query(1, description="摄像头ID")):
    """
    获取摄像头快照
    
    Args:
        camera: 摄像头ID，默认1
        
    Returns:
        JPEG图片
    """
    from components.utils import get_redis_client
    
    try:
        redis_client = get_redis_client(decode_responses=False)
        camera_key = f"current_frame_{camera}"
        frame_data = redis_client.get(camera_key)
        if not frame_data:
            frame_data = redis_client.get("current_frame")
        
        if frame_data:
            return StreamingResponse(
                iter([frame_data]),
                media_type="image/jpeg"
            )
        else:
            placeholder_frame = np.zeros((480, 640, 3), dtype=np.uint8)
            cv2.putText(placeholder_frame, "无视频数据", (50, 240), 
                        cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)
            _, buffer = cv2.imencode('.jpg', placeholder_frame, get_jpeg_encoding_params(85, optimize=True))
            return StreamingResponse(
                iter([buffer.tobytes()]),
                media_type="image/jpeg"
            )
    except Exception as e:
        error_frame = np.zeros((480, 640, 3), dtype=np.uint8)
        cv2.putText(error_frame, f"获取失败: {str(e)[:20]}", (50, 240), 
                    cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
        _, buffer = cv2.imencode('.jpg', error_frame, get_jpeg_encoding_params(70, optimize=True))
        return StreamingResponse(
            iter([buffer.tobytes()]),
            media_type="image/jpeg"
        )


@router.get("/api/video_feed/stats")
async def get_video_feed_stats():
    """
    获取视频流性能统计信息
    """
    uptime = time.time() - performance_metrics["start_time"]
    avg_encoding_time = (
        performance_metrics["encoding_time_total"] / performance_metrics["encoding_time_count"]
        if performance_metrics["encoding_time_count"] > 0 else 0
    )
    
    total_cache_ops = performance_metrics["cache_hits"] + performance_metrics["cache_misses"]
    cache_hit_rate = (
        performance_metrics["cache_hits"] / total_cache_ops * 100
        if total_cache_ops > 0 else 0
    )
    
    return {
        "code": 200,
        "message": "success",
        "data": {
            "total_frames_sent": performance_metrics["total_frames_sent"],
            "total_bytes_sent": performance_metrics["total_bytes_sent"],
            "cache_hits": performance_metrics["cache_hits"],
            "cache_misses": performance_metrics["cache_misses"],
            "cache_hit_rate": round(cache_hit_rate, 2),
            "avg_encoding_time_ms": round(avg_encoding_time * 1000, 2),
            "stale_frames": performance_metrics["stale_frames"],
            "placeholder_frames": performance_metrics["placeholder_frames"],
            "uptime_seconds": round(uptime, 2),
            "avg_bandwidth_kbps": round(
                (performance_metrics["total_bytes_sent"] * 8) / (uptime * 1000), 2
            ) if uptime > 0 else 0
        }
    }


@router.get("/api/video_feed/fps")
async def get_video_fps(camera: int = Query(1, description="摄像头ID")):
    """
    获取摄像头实时帧率统计
    """
    from components.utils import get_redis_client
    
    try:
        redis_client = get_redis_client(decode_responses=True)
        if not redis_client:
            return {
                "code": 500,
                "message": "Redis连接失败",
                "data": {"camera_id": camera, "current_fps": 0, "target_fps": 15}
            }
        
        camera_ts_key = f"current_frame_timestamp_{camera}"
        ts_str = redis_client.get(camera_ts_key)
        
        if ts_str:
            try:
                frame_timestamp = float(ts_str)
                elapsed = time.time() - frame_timestamp
                current_fps = 1.0 / elapsed if elapsed > 0.01 else 0
            except (ValueError, TypeError):
                current_fps = 0
        else:
            current_fps = 0
        
        from settings import CAMERA_CONFIG
        config = CAMERA_CONFIG.get(camera, {})
        target_fps = config.get("fps", 15)
        
        return {
            "code": 200,
            "message": "success",
            "data": {
                "camera_id": camera,
                "current_fps": round(current_fps, 2),
                "target_fps": target_fps,
                "frame_age_ms": round(elapsed * 1000, 2) if 'elapsed' in locals() else 0,
                "status": "active" if current_fps > 0 else "inactive",
                "is_stale": elapsed > FRAME_STALE_THRESHOLD if 'elapsed' in locals() else False
            }
        }
    except Exception as e:
        logger.error(f"获取帧率失败: {str(e)}")
        return {
            "code": 500,
            "message": f"获取帧率失败: {str(e)}",
            "data": {"camera_id": camera, "current_fps": 0, "target_fps": 15}
        }


@router.post("/api/video_feed/reset-stats")
async def reset_video_feed_stats():
    """
    重置视频流性能统计
    """
    global performance_metrics
    performance_metrics = {
        "total_frames_sent": 0,
        "total_bytes_sent": 0,
        "cache_hits": 0,
        "cache_misses": 0,
        "encoding_time_total": 0,
        "encoding_time_count": 0,
        "stale_frames": 0,
        "placeholder_frames": 0,
        "start_time": time.time()
    }
    
    return {
        "code": 200,
        "message": "Performance metrics reset successfully"
    }


@router.post("/api/video_feed/init-camera/{camera_id}")
async def init_camera(camera_id: int):
    """
    初始化指定摄像头（支持RDK X5 Edge自动检测）
    """
    from components.camera_connection import camera_connection
    from settings import CAMERA_CONFIG
    
    try:
        config = CAMERA_CONFIG.get(camera_id)
        if not config:
            return {
                "code": 404,
                "message": f"摄像头{camera_id}不存在",
                "data": {"camera_id": camera_id}
            }
        
        if not config.get("enabled", True):
            return {
                "code": 400,
                "message": f"摄像头{camera_id}未启用，请先在配置中启用",
                "data": {"camera_id": camera_id}
            }
        
        source = config["source"]
        if source is None:
            return {
                "code": 400,
                "message": f"摄像头{camera_id}未配置视频源，请先配置source",
                "data": {"camera_id": camera_id}
            }
        
        width = config.get("width", 1280)
        height = config.get("height", 720)
        fps = config.get("fps", 30)
        
        logger.info(f"初始化摄像头 {camera_id}: source={source}, {width}x{height}@{fps}fps")
        
        success = camera_connection.open(source, width, height, fps, str(camera_id))
        
        if success:
            stats = camera_connection.get_stats()
            return {
                "code": 200,
                "message": f"摄像头{camera_id}初始化成功",
                "data": {
                    "camera_id": camera_id,
                    "source": source,
                    "source_type": stats.get("source_type"),
                    "is_opened": stats.get("is_opened"),
                    "width": width,
                    "height": height,
                    "fps": fps,
                    "status": "connected" if stats.get("is_opened") else "error"
                }
            }
        else:
            return {
                "code": 500,
                "message": f"摄像头{camera_id}初始化失败",
                "data": {
                    "camera_id": camera_id,
                    "source": source,
                    "status": "failed"
                }
            }
    except Exception as e:
        logger.error(f"初始化摄像头 {camera_id} 失败: {str(e)}")
        return {
            "code": 500,
            "message": f"初始化摄像头{camera_id}失败: {str(e)}",
            "data": {
                "camera_id": camera_id,
                "status": "error"
            }
        }


@router.get("/api/video_feed/camera-list")
async def get_camera_list():
    """
    获取所有摄像头列表及其状态
    """
    from components.camera_connection import camera_connection
    from settings import CAMERA_CONFIG
    
    camera_list = []
    
    for camera_id, config in CAMERA_CONFIG.items():
        cameras = camera_connection.get_camera_list()
        camera_info = next((c for c in cameras if c["camera_id"] == str(camera_id)), None)
        
        is_enabled = config.get("enabled", True)
        has_source = config.get("source") is not None
        
        status = "disconnected"
        if is_enabled and has_source:
            status = "connected" if (camera_info and camera_info.get("is_opened")) else "connecting"
        elif not is_enabled:
            status = "disabled"
        elif not has_source:
            status = "not_configured"
        
        camera_list.append({
            "camera_id": camera_id,
            "name": config.get("name", f"摄像头{camera_id}"),
            "area": config.get("area", ""),
            "source": config.get("source", ""),
            "source_type": config.get("type", "unknown"),
            "width": config.get("width", 1280),
            "height": config.get("height", 720),
            "fps": config.get("fps", 30),
            "enabled": is_enabled,
            "has_source": has_source,
            "is_opened": camera_info.get("is_opened", False) if camera_info else False,
            "is_active": camera_info.get("is_active", False) if camera_info else False,
            "status": status
        })
    
    return {
        "code": 200,
        "message": "success",
        "data": {
            "cameras": camera_list,
            "total": len(camera_list)
        }
    }


@router.post("/api/video/camera/{camera_id}/toggle")
async def toggle_camera(camera_id: int, enabled: bool = Body(..., embed=True)):
    """
    切换摄像头启用/禁用状态
    """
    from settings import CAMERA_CONFIG
    
    try:
        if camera_id not in CAMERA_CONFIG:
            return {
                "code": 404,
                "message": f"Camera {camera_id} not found"
            }
        
        config = CAMERA_CONFIG[camera_id]
        source = config.get("source")
        
        if enabled:
            if source is None or source == "" or source == "none":
                return {
                    "code": 400,
                    "message": f"Camera {camera_id} has no video source configured"
                }
            
            CAMERA_CONFIG[camera_id]["enabled"] = True
            
            from detection.detect import CameraDetectionThread
            import threading
            
            for thread in threading.enumerate():
                if isinstance(thread, CameraDetectionThread) and thread.camera_id == camera_id:
                    if not thread.is_alive():
                        new_thread = CameraDetectionThread(camera_id)
                        new_thread.start()
                    break
            else:
                new_thread = CameraDetectionThread(camera_id)
                new_thread.start()
            
            return {
                "code": 200,
                "message": f"Camera {camera_id} enabled",
                "data": {
                    "camera_id": camera_id,
                    "enabled": True,
                    "source": source
                }
            }
        else:
            CAMERA_CONFIG[camera_id]["enabled"] = False
            
            from detection.detect import CameraDetectionThread
            import threading
            
            for thread in threading.enumerate():
                if isinstance(thread, CameraDetectionThread) and thread.camera_id == camera_id:
                    thread.stop()
                    break
            
            return {
                "code": 200,
                "message": f"Camera {camera_id} disabled",
                "data": {
                    "camera_id": camera_id,
                    "enabled": False
                }
            }
    
    except Exception as e:
        logger.error(f"Toggle camera {camera_id} failed: {str(e)}")
        return {
            "code": 500,
            "message": f"Operation failed: {str(e)}"
        }