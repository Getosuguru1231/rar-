"""认证路由

提供用户登录、注册功能
"""

import jwt
from datetime import datetime, timedelta
from fastapi import APIRouter, Request

from logging_config import get_logger

logger = get_logger('auth_routes')

router = APIRouter(prefix="", tags=["auth"])

registered_users = {}

# 固定的JWT密钥（用于token验证）
JWT_SECRET_KEY = "your-secret-key-change-in-production-12345678901234567890"
JWT_ALGORITHM = "HS256"

@router.post("/api/login")
async def login(request: Request):
    """用户登录接口

    支持管理员和普通用户登录
    - 管理员：admin / 123456
    - 普通用户：user / 123456
    """
    try:
        body = await request.json()
        username = body.get("username")
        password = body.get("password")

        if not username or not password:
            return {"success": False, "message": "用户名和密码不能为空"}

        if username == "admin" and password == "123456":
            token_data = {
                "username": username,
                "userType": "admin",
                "exp": (datetime.now() + timedelta(minutes=1440)).timestamp()
            }
            token = jwt.encode(token_data, JWT_SECRET_KEY, algorithm=JWT_ALGORITHM)
            return {
                "success": True,
                "message": "登录成功",
                "token": token,
                "username": username,
                "userType": "admin"
            }
        elif username == "user" and password == "123456":
            token_data = {
                "username": username,
                "userType": "user",
                "exp": (datetime.now() + timedelta(minutes=1440)).timestamp()
            }
            token = jwt.encode(token_data, JWT_SECRET_KEY, algorithm=JWT_ALGORITHM)
            return {
                "success": True,
                "message": "登录成功",
                "token": token,
                "username": username,
                "userType": "user"
            }
        elif username in registered_users and registered_users[username]["password"] == password:
            token_data = {
                "username": username,
                "userType": registered_users[username]["userType"],
                "exp": (datetime.now() + timedelta(minutes=1440)).timestamp()
            }
            token = jwt.encode(token_data, JWT_SECRET_KEY, algorithm=JWT_ALGORITHM)
            return {
                "success": True,
                "message": "登录成功",
                "token": token,
                "username": username,
                "userType": registered_users[username]["userType"]
            }
        else:
            return {"success": False, "message": "用户名或密码错误"}
    except Exception as e:
        logger.error(f"登录失败：{str(e)}")
        return {"success": False, "message": f"登录失败：{str(e)}"}

@router.post("/api/register")
async def register(request: Request):
    """用户注册接口"""
    global registered_users

    try:
        body = await request.json()
        username = body.get("username")
        password = body.get("password")
        userType = body.get("userType", "user")

        if not username or not password:
            return {"success": False, "message": "用户名和密码不能为空"}

        if username in registered_users:
            return {"success": False, "message": "用户名已存在"}

        registered_users[username] = {
            "password": password,
            "userType": userType
        }
        logger.info(f"新用户注册: {username}, 类型: {userType}")

        return {
            "success": True,
            "message": "注册成功"
        }
    except Exception as e:
        logger.error(f"注册失败：{str(e)}")
        return {"success": False, "message": f"注册失败：{str(e)}"}

def get_registered_users():
    """获取注册用户字典（供外部访问）"""
    return registered_users