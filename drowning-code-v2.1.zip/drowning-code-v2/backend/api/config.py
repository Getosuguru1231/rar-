"""配置相关API端点

管理系统配置、模型配置等相关API
"""

from fastapi import APIRouter
from settings import *

router = APIRouter()

@router.get("/system")
async def get_system_config():
    """获取系统配置"""
    return {
        "code": 200,
        "data": {
            "model_path": MODEL_PATH,
            "conf_threshold": CONF_THRESHOLD,
            "imgsz": IMGSZ,
            "video_quality": VIDEO_QUALITY,
            "frame_skip_rate": FRAME_SKIP_RATE,
            "redis_frame_expire": REDIS_FRAME_EXPIRE,
            "camera_config": CAMERA_CONFIG,
            "alert_config": ALERT_CONFIG
        }
    }

@router.get("/model")
async def get_model_config():
    """获取模型配置"""
    return {
        "code": 200,
        "data": {
            "model_path": MODEL_PATH,
            "class_names": CLASS_NAMES,
            "conf_threshold": CONF_THRESHOLD,
            "imgsz": IMGSZ
        }
    }

@router.get("/camera")
async def get_camera_config_api(camera_id: int = None):
    """获取摄像头配置"""
    if camera_id:
        config = get_camera_config(camera_id)
        return {"code": 200, "data": config}
    
    return {"code": 200, "data": CAMERA_CONFIG}

__all__ = ["router"]