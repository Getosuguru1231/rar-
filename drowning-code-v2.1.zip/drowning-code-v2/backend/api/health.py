"""健康检查和系统状态API端点

提供健康检查、心跳检测和系统状态监控接口
"""

import os
import time
import psutil
from datetime import datetime
from fastapi import APIRouter, Request
from fastapi.responses import Response
import json

from logging_config import get_logger

logger = get_logger('health_api')

router = APIRouter()

@router.get("/health")
def health_check():
    """健康检查端点"""
    return {
        "status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "version": "2.0.0"
    }

@router.get("/ping")
async def ping_test():
    """快速连接测试端点"""
    return {
        "pong": True,
        "timestamp": int(time.time() * 1000)
    }

@router.get("/model/confidence")
def model_confidence_stats():
    """模型置信度统计端点"""
    try:
        from settings import (
            CONF_THRESHOLD, ALERT_DELAY, MIN_CONSECUTIVE_FRAMES,
            MAX_MISS_FRAMES, IOU_THRESHOLD, MIN_DETECTION_AREA,
            HIGH_CONFIDENCE_THRESHOLD, TEMPORAL_WINDOW, IMGSZ
        )
        
        return {
            "status": "success",
            "confidence_settings": {
                "detection_threshold": CONF_THRESHOLD,
                "high_confidence_threshold": HIGH_CONFIDENCE_THRESHOLD,
                "alert_delay_seconds": ALERT_DELAY,
                "min_consecutive_frames": MIN_CONSECUTIVE_FRAMES,
                "max_miss_frames": MAX_MISS_FRAMES,
                "iou_threshold": IOU_THRESHOLD,
                "min_detection_area": MIN_DETECTION_AREA,
                "temporal_window": TEMPORAL_WINDOW,
                "image_size": IMGSZ
            },
            "trust_level": "high" if CONF_THRESHOLD >= 0.65 else "medium" if CONF_THRESHOLD >= 0.5 else "low",
            "description": "高置信度阈值确保只有高度可靠的检测才会触发告警"
        }
    except Exception as e:
        logger.error(f"[ERROR] 获取模型置信度统计失败: {str(e)}")
        return {
            "status": "error",
            "message": str(e)
        }

@router.get("/heartbeat")
async def api_heartbeat():
    """心跳检测端点"""
    try:
        redis_status = "connected"
        try:
            from components.utils import get_redis_client
            redis_client = get_redis_client()
            redis_client.ping()
        except Exception as e:
            redis_status = f"error: {str(e)}"

        import asyncio
        cpu_percent = await asyncio.to_thread(lambda: psutil.cpu_percent(interval=0.01))
        memory = psutil.virtual_memory()

        return {
            "status": "healthy",
            "timestamp": datetime.now().isoformat(),
            "server_time": time.time(),
            "redis_status": redis_status,
            "system": {
                "cpu_percent": cpu_percent,
                "memory_percent": memory.percent
            }
        }
    except Exception as e:
        logger.error(f"[ERROR] 心跳检测失败: {str(e)}")
        return {
            "status": "unhealthy",
            "timestamp": datetime.now().isoformat(),
            "error": str(e)
        }

@router.get("/system/status")
def system_status():
    """系统状态监控端点"""
    cpu_percent = 0
    memory_used = memory_total = memory_percent = 0
    disk_used = disk_total = disk_percent = 0
    bytes_sent = bytes_recv = 0
    load_avg = [0, 0, 0]
    process_memory = process_cpu = 0
    process_pid = os.getpid()

    try:
        cpu_percent = psutil.cpu_percent(interval=0.1)
    except Exception: pass

    try:
        memory = psutil.virtual_memory()
        memory_used = memory.used / (1024**3)
        memory_total = memory.total / (1024**3)
        memory_percent = memory.percent
    except Exception: pass

    try:
        disk = psutil.disk_usage(os.path.abspath('.')[:2])
        disk_used = disk.used / (1024**3)
        disk_total = disk.total / (1024**3)
        disk_percent = disk.percent
    except Exception: pass

    try:
        net_io = psutil.net_io_counters()
        bytes_sent = net_io.bytes_sent / (1024**2)
        bytes_recv = net_io.bytes_recv / (1024**2)
    except Exception: pass

    try:
        load_avg = psutil.getloadavg() if hasattr(psutil, 'getloadavg') else [0, 0, 0]
    except Exception: pass

    try:
        process = psutil.Process(os.getpid())
        process_memory = process.memory_info().rss / (1024**2)
        process_cpu = process.cpu_percent(interval=0.01)
    except Exception: pass

    return {
        "code": 200,
        "data": {
            "cpu": {"percent": cpu_percent},
            "memory": {
                "used": round(memory_used, 2),
                "total": round(memory_total, 2),
                "percent": memory_percent
            },
            "disk": {
                "used": round(disk_used, 2),
                "total": round(disk_total, 2),
                "percent": disk_percent
            },
            "network": {
                "bytes_sent": round(bytes_sent, 2),
                "bytes_recv": round(bytes_recv, 2)
            },
            "system": {
                "load_avg": [round(l, 2) for l in load_avg],
                "timestamp": datetime.now().isoformat()
            },
            "process": {
                "memory_used": round(process_memory, 2),
                "cpu_percent": round(process_cpu, 2),
                "pid": process_pid
            }
        }
    }

@router.get("/")
def root():
    """根路径"""
    return {
        "message": "智能溺水检测系统 API",
        "version": "2.0.0",
        "docs": "/docs"
    }

__all__ = ["router"]