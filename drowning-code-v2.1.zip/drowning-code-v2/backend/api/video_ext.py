"""视频扩展API端点

提供视频流时间戳、人数统计、图片查询等功能
"""

import os
import json
import time
import glob
from fastapi import APIRouter
from fastapi.responses import FileResponse

from logging_config import get_logger
from settings import REDIS_FRAME_EXPIRE, RESULTS_DIR
from components.redis_pool import get_redis_connection

logger = get_logger('video_api')

router = APIRouter()

@router.get("/api/video/timestamp")
async def video_timestamp():
    """获取视频流时间戳信息"""
    stream_running = False
    video_duration = 0
    frame_age = 0
    is_fresh = False
    fps_estimate = 0

    try:
        redis_client = get_redis_connection(decode_responses=True)
        if not redis_client:
            return {
                "code": 200,
                "data": {
                    "stream_running": False,
                    "video_duration": 0,
                    "frame_age": 0,
                    "is_fresh": False,
                    "fps_estimate": 0
                },
                "message": "Redis连接不可用"
            }

        try:
            frame_timestamp_str = redis_client.get("current_frame_timestamp")
            start_time_str = redis_client.get("stream_start_time")

            current_time = time.time()
            frame_timestamp = 0
            start_time = 0

            if frame_timestamp_str:
                try:
                    frame_timestamp = float(frame_timestamp_str)
                except (ValueError, TypeError):
                    frame_timestamp = 0

            if start_time_str:
                try:
                    start_time = float(start_time_str)
                except (ValueError, TypeError):
                    start_time = 0

            if start_time > 0:
                video_duration = current_time - start_time

            if frame_timestamp > 0:
                frame_age = current_time - frame_timestamp

            is_fresh = frame_age <= REDIS_FRAME_EXPIRE and frame_age > 0

            last_frame_timestamp_str = redis_client.get("last_frame_timestamp")
            if last_frame_timestamp_str and frame_timestamp > 0:
                try:
                    last_frame_timestamp = float(last_frame_timestamp_str)
                    if frame_timestamp > last_frame_timestamp and (frame_timestamp - last_frame_timestamp) > 0:
                        fps_estimate = 1.0 / (frame_timestamp - last_frame_timestamp)
                except (ValueError, TypeError):
                    pass

            if frame_timestamp > 0:
                try:
                    redis_client.set("last_frame_timestamp", str(frame_timestamp))
                except Exception as e:
                    logger.warning(f"[WARNING] 保存上一帧时间戳失败: {str(e)}")

            stream_running = frame_timestamp > 0 and is_fresh

            return {
                "code": 200,
                "data": {
                    "stream_running": stream_running,
                    "video_duration": video_duration,
                    "frame_age": frame_age,
                    "is_fresh": is_fresh,
                    "fps_estimate": fps_estimate
                }
            }
        except Exception as e:
            logger.error(f"[ERROR] Redis操作失败: {str(e)}")
            return {
                "code": 200,
                "data": {
                    "stream_running": False,
                    "video_duration": 0,
                    "frame_age": 0,
                    "is_fresh": False,
                    "fps_estimate": 0
                },
                "message": f"Redis操作失败: {str(e)}"
            }
    except Exception as e:
        logger.error(f"[ERROR] 获取视频时间戳失败: {str(e)}")
        return {
            "code": 200,
            "data": {
                "stream_running": False,
                "video_duration": 0,
                "frame_age": 0,
                "is_fresh": False,
                "fps_estimate": 0
            },
            "message": f"获取失败: {str(e)}"
        }

@router.get("/api/video/people-count")
def get_people_count():
    """获取实时人数统计"""
    try:
        from settings import CAMERA_CONFIG
        redis_client = get_redis_connection(decode_responses=True)

        people_count = 0
        in_water_count = 0
        out_water_count = 0
        stats = {}
        cameras = {}

        if not redis_client:
            return {
                "code": 200,
                "data": {
                    "people_count": 0,
                    "in_water_count": 0,
                    "out_water_count": 0,
                    "stats": {},
                    "cameras": {}
                },
                "message": "Redis连接不可用"
            }

        try:
            people_count_val = redis_client.get("people_count")
            if people_count_val:
                try:
                    stats_data = json.loads(people_count_val)
                    if isinstance(stats_data, dict):
                        people_count = stats_data.get("people_count", 0)
                        in_water_count = stats_data.get("in_water_count", 0)
                        out_of_water_count = stats_data.get("out_water_count", 0)
                except (json.JSONDecodeError, ValueError):
                    try:
                        people_count = int(people_count_val)
                    except (ValueError, TypeError):
                        pass

            in_water_count_val = redis_client.get("people_count_in_water")
            if in_water_count_val:
                try:
                    in_water_count = int(in_water_count_val)
                except (ValueError, TypeError):
                    pass

            out_water_count_val = redis_client.get("people_count_out_water")
            if out_water_count_val:
                try:
                    out_water_count = int(out_water_count_val)
                except (ValueError, TypeError):
                    pass

            stats_json = redis_client.get("people_count_stats")
            if stats_json:
                try:
                    stats = json.loads(stats_json)
                except Exception: pass

            for camera_id in CAMERA_CONFIG:
                config = CAMERA_CONFIG[camera_id]
                if not config.get("enabled", True):
                    continue
                
                source = config.get("source")
                if source is None:
                    continue
                
                cam_stats_val = redis_client.get(f"people_count_{camera_id}")
                cam_count = 0
                cam_in_water = 0
                cam_out_water = 0
                
                if cam_stats_val:
                    try:
                        cam_stats = json.loads(cam_stats_val)
                        if isinstance(cam_stats, dict):
                            cam_count = cam_stats.get("people_count", 0)
                            cam_in_water = cam_stats.get("in_water_count", 0)
                            cam_out_water = cam_stats.get("out_water_count", 0)
                    except (json.JSONDecodeError, ValueError):
                        try:
                            cam_count = int(cam_stats_val)
                        except (ValueError, TypeError):
                            pass
                
                if cam_count > 0 or cam_in_water > 0:
                    cameras[camera_id] = {
                        "people_count": cam_count,
                        "in_water_count": cam_in_water,
                        "out_water_count": cam_out_water
                    }

        except Exception as e:
            logger.error(f"[ERROR] 获取人数统计失败: {str(e)}")

        return {
            "code": 200,
            "data": {
                "people_count": people_count,
                "in_water_count": in_water_count,
                "out_water_count": out_water_count,
                "stats": stats,
                "cameras": cameras
            }
        }
    except Exception as e:
        logger.error(f"[ERROR] 获取人数统计失败: {str(e)}")
        return {
            "code": 200,
            "data": {
                "people_count": 0,
                "in_water_count": 0,
                "out_water_count": 0,
                "stats": {}
            },
            "message": f"获取人数统计失败: {str(e)}"
        }

@router.get("/api/video-results/images/{task_id}")
def get_task_images(task_id: str):
    """获取指定任务的保存图片列表"""
    try:
        task_results_dir = os.path.join(RESULTS_DIR, task_id)
        if not os.path.exists(task_results_dir):
            return {"code": 200, "data": {"images": []}}

        image_files = []
        for ext in ["*.jpg", "*.jpeg", "*.png"]:
            image_files.extend(glob.glob(os.path.join(task_results_dir, ext)))

        images = []
        for img_path in image_files:
            filename = os.path.basename(img_path)
            timestamp = 0
            frame = 0
            try:
                parts = filename.split("_")
                if len(parts) >= 3:
                    frame = int(parts[1])
                    timestamp = float(parts[2].split(".")[0])
            except Exception: pass

            img_url = f"/api/video-results/images/{task_id}/{filename}"
            images.append({
                "filename": filename,
                "url": img_url,
                "timestamp": timestamp,
                "frame": frame
            })

        return {"code": 200, "data": {"images": images}}
    except Exception as e:
        logger.error(f"[ERROR] 获取任务图片失败: {str(e)}")
        return {"code": 500, "data": {"images": []}}

@router.get("/api/video-results/images/{task_id}/{filename}")
def get_task_image(task_id: str, filename: str):
    """获取指定任务的单张图片"""
    try:
        image_path = os.path.join(RESULTS_DIR, task_id, filename)

        if not os.path.exists(image_path):
            return {"code": 404, "message": "图片不存在"}

        return FileResponse(image_path)
    except Exception as e:
        logger.error(f"[ERROR] 获取图片失败: {str(e)}")
        return {"code": 500, "message": f"获取图片失败: {str(e)}"}

@router.get("/api/people-count")
def get_people_count_legacy():
    """获取实时人数统计（兼容旧路径）"""
    return get_people_count()

@router.get("/api/video/status")
def get_video_status():
    """获取视频状态信息"""
    try:
        from settings import VIDEO_DIR
        
        total_files = 0
        total_size_bytes = 0
        
        if os.path.exists(VIDEO_DIR):
            video_extensions = {'.mp4', '.avi', '.mov', '.mkv'}
            for root, dirs, files in os.walk(VIDEO_DIR):
                dirs[:] = [d for d in dirs if not d.startswith('.')]
                for file in files:
                    if any(file.lower().endswith(ext) for ext in video_extensions):
                        total_files += 1
                        file_path = os.path.join(root, file)
                        try:
                            total_size_bytes += os.path.getsize(file_path)
                        except Exception:
                            pass
                    if total_files > 1000:
                        break
                if total_files > 1000:
                    break
        
        total_size_gb = round(total_size_bytes / (1024 * 1024 * 1024), 2)
        
        return {
            "code": 200,
            "message": "success",
            "data": {
                "total_files": total_files,
                "total_size_gb": total_size_gb,
                "limit_reached": total_files >= 1000
            }
        }
    except Exception as e:
        logger.error(f"[ERROR] 获取视频状态失败: {str(e)}")
        return {
            "code": 200,
            "message": "success",
            "data": {
                "total_files": 0,
                "total_size_gb": 0,
                "limit_reached": False
            }
        }

__all__ = ["router"]