"""统一响应包装器

提供一致的API响应格式，简化错误处理和日志记录
"""

from fastapi import HTTPException
from fastapi.responses import JSONResponse
from typing import Any, Optional, Dict


class APIResponse:
    """统一API响应类"""
    
    @staticmethod
    def success(
        data: Any = None,
        message: str = "操作成功",
        code: int = 200,
        **kwargs
    ) -> JSONResponse:
        """成功响应"""
        response = {
            "code": code,
            "success": True,
            "message": message,
            "data": data
        }
        response.update(kwargs)
        return JSONResponse(response)
    
    @staticmethod
    def error(
        message: str = "操作失败",
        code: int = 500,
        data: Any = None,
        **kwargs
    ) -> JSONResponse:
        """错误响应"""
        response = {
            "code": code,
            "success": False,
            "message": message,
            "data": data
        }
        response.update(kwargs)
        return JSONResponse(response, status_code=code)
    
    @staticmethod
    def not_found(
        message: str = "资源未找到",
        data: Any = None
    ) -> JSONResponse:
        """资源未找到响应"""
        return APIResponse.error(message=message, code=404, data=data)
    
    @staticmethod
    def bad_request(
        message: str = "请求参数错误",
        data: Any = None
    ) -> JSONResponse:
        """请求参数错误响应"""
        return APIResponse.error(message=message, code=400, data=data)
    
    @staticmethod
    def unauthorized(
        message: str = "未授权访问",
        data: Any = None
    ) -> JSONResponse:
        """未授权响应"""
        return APIResponse.error(message=message, code=401, data=data)
    
    @staticmethod
    def forbidden(
        message: str = "禁止访问",
        data: Any = None
    ) -> JSONResponse:
        """禁止访问响应"""
        return APIResponse.error(message=message, code=403, data=data)
    
    @staticmethod
    def validation_error(
        errors: Dict[str, str],
        message: str = "验证失败"
    ) -> JSONResponse:
        """验证错误响应"""
        return APIResponse.error(
            message=message,
            code=422,
            data={"errors": errors}
        )
    
    @staticmethod
    def paginated(
        data: Any,
        total: int,
        page: int,
        size: int,
        message: str = "操作成功"
    ) -> JSONResponse:
        """分页响应"""
        total_pages = (total + size - 1) // size if total > 0 else 0
        has_next = page < total_pages
        has_prev = page > 1
        
        return APIResponse.success(
            data=data,
            message=message,
            total=total,
            page=page,
            size=size,
            total_pages=total_pages,
            has_next=has_next,
            has_prev=has_prev
        )


class APIException(HTTPException):
    """统一API异常"""
    
    def __init__(
        self,
        message: str = "操作失败",
        code: int = 500,
        data: Any = None
    ):
        super().__init__(
            status_code=code,
            detail={
                "code": code,
                "success": False,
                "message": message,
                "data": data
            }
        )
        self.message = message
        self.data = data


def api_success(
    data: Any = None,
    message: str = "操作成功",
    **kwargs
) -> JSONResponse:
    """便捷函数：成功响应"""
    return APIResponse.success(data=data, message=message, **kwargs)


def api_error(
    message: str = "操作失败",
    code: int = 500,
    **kwargs
) -> JSONResponse:
    """便捷函数：错误响应"""
    return APIResponse.error(message=message, code=code, **kwargs)


def api_paginated(
    data: Any,
    total: int,
    page: int,
    size: int,
    message: str = "操作成功"
) -> JSONResponse:
    """便捷函数：分页响应"""
    return APIResponse.paginated(
        data=data,
        total=total,
        page=page,
        size=size,
        message=message
    )


__all__ = [
    "APIResponse",
    "APIException",
    "api_success",
    "api_error",
    "api_paginated"
]