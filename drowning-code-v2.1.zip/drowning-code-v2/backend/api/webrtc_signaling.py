import asyncio
import json
import time
from fastapi import APIRouter, WebSocket, WebSocketDisconnect
from typing import Dict
from webrtc.peer_manager import peer_manager

router = APIRouter()

class SignalingManager:
    def __init__(self):
        self.connections: Dict[str, WebSocket] = {}
        self.peer_connections: Dict[WebSocket, str] = {}
        self.last_activity: Dict[str, float] = {}
        self.last_pong: Dict[str, float] = {}
        self.missed_pongs: Dict[str, int] = {}
        self.timeout_seconds = 120.0
        self.heartbeat_interval = 30.0
        self.pong_timeout = 60.0
        self.max_missed_pongs = 5
        self._cleanup_task = None
        self._heartbeat_task = None
        self._lock = asyncio.Lock()
        
    async def start_cleanup_task(self):
        if self._cleanup_task is None:
            self._cleanup_task = asyncio.create_task(self._cleanup_loop())
            print(f"[WebRTC 信令] 启动连接清理任务 (超时时间: {self.timeout_seconds}秒)")
        
        if self._heartbeat_task is None:
            self._heartbeat_task = asyncio.create_task(self._heartbeat_loop())
            print(f"[WebRTC 信令] 启动心跳检测任务 (心跳间隔: {self.heartbeat_interval}秒)")
    
    async def _cleanup_loop(self):
        while True:
            try:
                await asyncio.sleep(15)
                await self._cleanup_timeout_connections()
            except asyncio.CancelledError:
                break
            except Exception as e:
                print(f"[WebRTC 信令] 清理任务异常: {e}")
    
    async def _heartbeat_loop(self):
        """主动发送心跳检测，确保连接活跃"""
        while True:
            try:
                await asyncio.sleep(self.heartbeat_interval)
                await self._send_heartbeats()
            except asyncio.CancelledError:
                break
            except Exception as e:
                print(f"[WebRTC 信令] 心跳任务异常: {e}")
    
    async def _send_heartbeats(self):
        """发送心跳给所有连接的客户端"""
        now = time.time()
        timeout_peer_ids = []
        disconnected_peer_ids = []
        
        async with self._lock:
            for peer_id, ws in list(self.connections.items()):
                try:
                    if ws.client_state.value == 1:
                        last_pong_time = self.last_pong.get(peer_id, 0)
                        if now - last_pong_time >= self.pong_timeout:
                            self.missed_pongs[peer_id] = self.missed_pongs.get(peer_id, 0) + 1
                            missed_count = self.missed_pongs[peer_id]
                            
                            if missed_count >= self.max_missed_pongs:
                                timeout_peer_ids.append(peer_id)
                                print(f"[WebRTC 信令] PONG超时次数过多 ({missed_count}/{self.max_missed_pongs})，断开 peer_id={peer_id}")
                            else:
                                await ws.send_json({"type": "ping"})
                                print(f"[WebRTC 信令] 发送心跳给 peer_id={peer_id}")
                    else:
                        disconnected_peer_ids.append(peer_id)
                        print(f"[WebRTC 信令] 连接已断开，移除 peer_id={peer_id}")
                except Exception as e:
                    disconnected_peer_ids.append(peer_id)
                    print(f"[WebRTC 信令] 发送心跳失败 peer_id={peer_id}: {e}")
        
        for peer_id in timeout_peer_ids:
            try:
                await self.disconnect(peer_id)
            except Exception as e:
                print(f"[WebRTC 信令] 断开超时连接失败: {e}")
        
        for peer_id in disconnected_peer_ids:
            try:
                async with self._lock:
                    if peer_id in self.connections:
                        del self.connections[peer_id]
                        if peer_id in self.last_pong:
                            del self.last_pong[peer_id]
                        if peer_id in self.missed_pongs:
                            del self.missed_pongs[peer_id]
            except Exception as e:
                print(f"[WebRTC 信令] 清理断开连接失败: {e}")
    
    async def _cleanup_timeout_connections(self):
        now = time.time()
        timeout_peer_ids = []
        
        async with self._lock:
            for peer_id, last_time in self.last_activity.items():
                if now - last_time > self.timeout_seconds:
                    timeout_peer_ids.append(peer_id)
        
        for peer_id in timeout_peer_ids:
            print(f"[WebRTC 信令] 连接超时，断开 peer_id={peer_id}")
            try:
                await self.disconnect(peer_id)
            except Exception as e:
                print(f"[WebRTC 信令] 断开超时连接失败: {e}")
    
    async def stop_cleanup_task(self):
        if self._cleanup_task:
            self._cleanup_task.cancel()
            await self._cleanup_task
            self._cleanup_task = None
        
    async def connect(self, websocket: WebSocket, camera_id: int) -> str:
        await websocket.accept()
        print(f"[WebRTC 信令] 创建Peer...")
        peer = await peer_manager.create_peer(camera_id, websocket)
        
        async with self._lock:
            self.connections[peer.peer_id] = websocket
            self.peer_connections[websocket] = peer.peer_id
            self.last_activity[peer.peer_id] = time.time()
        
        print(f"[WebRTC 信令] 新连接 - 摄像头{camera_id}, peer_id={peer.peer_id}")
        
        @peer.pc.on("icecandidate")
        async def on_ice_candidate(candidate):
            if candidate:
                try:
                    await websocket.send_json({
                        "type": "ice_candidate",
                        "candidate": {
                            "candidate": candidate.candidate,
                            "sdpMid": candidate.sdpMid,
                            "sdpMLineIndex": candidate.sdpMLineIndex
                        }
                    })
                    async with self._lock:
                        if peer.peer_id in self.last_activity:
                            self.last_activity[peer.peer_id] = time.time()
                    print(f"[WebRTC 信令] 发送ICE候选")
                except Exception as e:
                    print(f"[WebRTC 信令] 发送ICE候选失败: {e}")
        
        @peer.pc.on("connectionstatechange")
        def on_connection_state_change():
            state = peer.pc.connectionState
            print(f"[WebRTC 信令] 连接状态变化: {state}")
            asyncio.create_task(self._update_activity(peer.peer_id))
        
        @peer.pc.on("iceconnectionstatechange")
        def on_ice_connection_state_change():
            state = peer.pc.iceConnectionState
            print(f"[WebRTC 信令] ICE连接状态: {state}")
            asyncio.create_task(self._update_activity(peer.peer_id))
        
        return peer.peer_id
    
    async def _update_activity(self, peer_id: str):
        async with self._lock:
            if peer_id in self.last_activity:
                self.last_activity[peer_id] = time.time()
        
    async def disconnect(self, peer_id: str):
        async with self._lock:
            if peer_id in self.connections:
                ws = self.connections[peer_id]
                del self.connections[peer_id]
                if ws in self.peer_connections:
                    del self.peer_connections[ws]
            if peer_id in self.last_activity:
                del self.last_activity[peer_id]
            if peer_id in self.last_pong:
                del self.last_pong[peer_id]
            if peer_id in self.missed_pongs:
                del self.missed_pongs[peer_id]
        await peer_manager.remove_peer(peer_id)
        print(f"[WebRTC 信令] 断开连接 - peer_id={peer_id}")
        
    async def handle_message(self, peer_id: str, message: dict):
        msg_type = message.get("type")
        
        if msg_type in ["offer", "answer", "error"]:
            print(f"[WebRTC 信令] 收到消息: {msg_type} (peer_id={peer_id})", flush=True)
        
        async with self._lock:
            if peer_id in self.last_activity:
                self.last_activity[peer_id] = time.time()
        
        try:
            if msg_type == "offer":
                print(f"[WebRTC 信令] 处理Offer")
                answer_sdp = await peer_manager.handle_offer(peer_id, message.get("sdp"), message.get("sdp_semantics", "unified-plan"))
                print(f"[WebRTC 信令] Answer生成: {'成功' if answer_sdp else '失败'}")
                
                if answer_sdp and peer_id in self.connections:
                    print(f"[WebRTC 信令] 发送Answer")
                    await self.connections[peer_id].send_json({
                        "type": "answer",
                        "sdp": answer_sdp
                    })
                    async with self._lock:
                        if peer_id in self.last_activity:
                            self.last_activity[peer_id] = time.time()
                    print(f"[WebRTC 信令] Answer发送成功")
                elif not answer_sdp:
                    print(f"[WebRTC 信令] Answer创建失败")
                    if peer_id in self.connections:
                        await self.connections[peer_id].send_json({
                            "type": "error",
                            "message": "Answer创建失败"
                        })
                    
            elif msg_type == "ice_candidate":
                candidate = message.get("candidate")
                if candidate:
                    print(f"[WebRTC 信令] 添加ICE候选")
                    await peer_manager.add_ice_candidate(peer_id, candidate)
                    
            elif msg_type == "close":
                print(f"[WebRTC 信令] 收到关闭请求")
                await self.disconnect(peer_id)
                
            elif msg_type == "ping":
                if peer_id in self.connections:
                    await self.connections[peer_id].send_json({"type": "pong"})
                    async with self._lock:
                        if peer_id in self.last_activity:
                            self.last_activity[peer_id] = time.time()
                    print(f"[WebRTC 信令] 收到PING，回复PONG (peer_id={peer_id})")
                    
            elif msg_type == "pong":
                async with self._lock:
                    self.last_pong[peer_id] = time.time()
                    self.missed_pongs[peer_id] = 0
                print(f"[WebRTC 信令] 收到PONG (peer_id={peer_id})")
                    
        except Exception as e:
            print(f"[WebRTC 信令] 处理消息失败: {type(e).__name__}: {e}")
            import traceback
            traceback.print_exc()
            if peer_id in self.connections:
                try:
                    await self.connections[peer_id].send_json({
                        "type": "error",
                        "message": str(e)
                    })
                except:
                    pass

    def get_peer_count(self) -> int:
        return peer_manager.get_peer_count()


signaling_manager = SignalingManager()

async def startup():
    await signaling_manager.start_cleanup_task()


@router.websocket("/ws/webrtc/{camera_id}")
async def webrtc_signaling(websocket: WebSocket, camera_id: int):
    peer_id = None
    try:
        print(f"[WebRTC 信令] ===== 收到WebSocket连接请求 ===== camera_id={camera_id}", flush=True)
        peer_id = await signaling_manager.connect(websocket, camera_id)
        print(f"[WebRTC 信令] ===== 连接建立成功 ===== peer_id={peer_id}", flush=True)
        
        while True:
            try:
                data = await websocket.receive_text()
                try:
                    message = json.loads(data)
                    await signaling_manager.handle_message(peer_id, message)
                except json.JSONDecodeError as e:
                    print(f"[WebRTC 信令] 无效的JSON: {data[:100]}...")
            except Exception as e:
                print(f"[WebRTC 信令] 接收消息异常: {type(e).__name__}: {e}")
                raise
                
    except WebSocketDisconnect as e:
        print(f"[WebRTC 信令] WebSocket断开 - code={e.code}, reason={e.reason}")
    except Exception as e:
        print(f"[WebRTC 信令] 错误: {type(e).__name__}: {e}")
        import traceback
        traceback.print_exc()
    finally:
        if peer_id:
            await signaling_manager.disconnect(peer_id)


@router.get("/stats")
async def get_webrtc_stats():
    return {
        "total_peers": signaling_manager.get_peer_count(),
        "status": "running"
    }