"""API端点管理模块

集中管理所有API路由和端点，提供清晰的API注册入口
"""

from fastapi import APIRouter

api_router = APIRouter(prefix="")

from .health import router as health_router
from .alerts import router as alert_router
from .camera import router as camera_router
from .monitoring import router as monitoring_router
from .llm import router as llm_router
from .config import router as config_router
from .video import router as video_router
from .video_cleanup import router as video_cleanup_router
from .video_ext import router as video_ext_router
from .video_feed import router as video_feed_router
from .webrtc_signaling import router as webrtc_signaling_router
from .video_websocket import router as video_ws_router
from .auth import router as auth_router
from .unified_monitor import router as unified_monitor_router
from .detection import router as detection_router
from .device_api import router as device_api_router

api_router.include_router(health_router, prefix="/api", tags=["health"])
api_router.include_router(alert_router, prefix="/api/alerts", tags=["alerts"])
api_router.include_router(camera_router, prefix="/api/camera", tags=["camera"])
api_router.include_router(monitoring_router, prefix="/api/monitoring", tags=["monitoring"])
api_router.include_router(llm_router, prefix="/api/llm", tags=["llm"])
api_router.include_router(config_router, prefix="/api/config", tags=["config"])
api_router.include_router(video_router, prefix="/api/video", tags=["video"])
api_router.include_router(video_cleanup_router, prefix="/api/video", tags=["video"])
api_router.include_router(video_ext_router, tags=["video_ext"])
api_router.include_router(video_feed_router, tags=["video_feed"])
api_router.include_router(webrtc_signaling_router, tags=["webrtc"])
api_router.include_router(video_ws_router, tags=["video_websocket"])
api_router.include_router(auth_router, tags=["auth"])
api_router.include_router(unified_monitor_router, tags=["unified_monitor"])
api_router.include_router(detection_router, prefix="/api/detection", tags=["detection"])
api_router.include_router(device_api_router, prefix="/api/device", tags=["device"])

__all__ = ["api_router"]