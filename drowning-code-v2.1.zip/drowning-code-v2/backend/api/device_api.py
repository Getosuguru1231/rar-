from fastapi import APIRouter, Request, HTTPException
from fastapi.responses import StreamingResponse
from datetime import datetime
import time
import json
import random
from typing import List, Dict

router = APIRouter()

device_data_store = []
device_status = {
    "deviceId": "boat_001",
    "status": "online",
    "battery": 85,
    "speed": 0,
    "heading": 0,
    "latitude": 30.5728,
    "longitude": 104.0668
}

def generate_mock_data() -> Dict:
    timestamp = int(time.time() * 1000)
    
    ir_temp = round(25 + random.uniform(-5, 5), 2)
    radar_echo = round(10 + random.uniform(0, 15), 2)
    sonar_depth = round(5 + random.uniform(0, 10), 2)
    signal_str = round(-60 + random.uniform(-20, 10), 2)
    
    lat = device_status["latitude"] + random.uniform(-0.0001, 0.0001)
    lng = device_status["longitude"] + random.uniform(-0.0001, 0.0001)
    
    return {
        "deviceId": "boat",
        "timestamp": timestamp,
        "irTempValue": ir_temp,
        "radarValue": radar_echo,
        "sonarValue": sonar_depth,
        "signalValue": signal_str,
        "gpsData": {
            "latitude": round(lat, 6),
            "longitude": round(lng, 6),
            "Lat": str(round(lat, 6)),
            "Lon": str(round(lng, 6)),
            "Sig": round(random.uniform(50, 100), 0)
        }
    }

@router.get("/history")
async def get_device_history(limit: int = 100):
    global device_data_store
    
    if len(device_data_store) < limit:
        for _ in range(limit - len(device_data_store)):
            device_data_store.append(generate_mock_data())
    
    return {
        "code": 200,
        "data": device_data_store[-limit:]
    }

@router.get("/stream")
async def device_stream(request: Request, clientId: str = None):
    async def event_generator():
        while True:
            if await request.is_disconnected():
                break
            
            data = generate_mock_data()
            device_data_store.append(data)
            if len(device_data_store) > 1000:
                device_data_store = device_data_store[-1000:]
            
            yield f"event: deviceData\ndata: {json.dumps(data)}\n\n"
            
            time.sleep(1)
    
    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream"
    )

@router.get("/status")
async def get_device_status():
    return {
        "code": 200,
        "data": device_status
    }

@router.post("/control")
async def control_device(command: Dict):
    action = command.get("action")
    speed = command.get("speed", 0)
    heading = command.get("heading", 0)
    
    if action == "move":
        device_status["speed"] = speed
        device_status["heading"] = heading
        device_status["status"] = "moving"
    elif action == "stop":
        device_status["speed"] = 0
        device_status["status"] = "idle"
    elif action == "return":
        device_status["status"] = "returning"
        device_status["speed"] = 5
    
    return {
        "code": 200,
        "message": f"命令已执行: {action}",
        "data": device_status
    }

@router.post("/waypoint")
async def set_waypoint(waypoints: List[Dict]):
    return {
        "code": 200,
        "message": f"已设置 {len(waypoints)} 个航点",
        "data": waypoints
    }

@router.post("/navigation/start")
async def start_navigation():
    device_status["status"] = "navigating"
    return {
        "code": 200,
        "message": "导航已启动"
    }

@router.post("/navigation/stop")
async def stop_navigation():
    device_status["speed"] = 0
    device_status["status"] = "idle"
    return {
        "code": 200,
        "message": "导航已停止"
    }

@router.post("/navigation/home")
async def return_to_home():
    device_status["status"] = "returning"
    device_status["speed"] = 5
    return {
        "code": 200,
        "message": "正在返回母港"
    }