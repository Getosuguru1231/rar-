# backend/logging_config.py
"""
结构化日志配置
支持日志轮转、分级输出、JSON格式
"""
import logging
import os
from logging.handlers import RotatingFileHandler, TimedRotatingFileHandler
from datetime import datetime


def setup_logging(log_dir='logs', log_level=logging.INFO):
    """
    配置结构化日志系统
    
    Args:
        log_dir: 日志目录
        log_level: 日志级别
    """
    # 创建日志目录
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)
    
    # 根日志器
    root_logger = logging.getLogger()
    root_logger.setLevel(log_level)
    
    # 清除已有处理器
    root_logger.handlers.clear()
    
    # 日志格式
    detailed_format = logging.Formatter(
        '[%(asctime)s] [%(levelname)s] [%(name)s:%(lineno)d] %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    
    simple_format = logging.Formatter(
        '[%(asctime)s] %(levelname)s: %(message)s',
        datefmt='%H:%M:%S'
    )
    
    # 1. 控制台处理器 (彩色输出)
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    console_handler.setFormatter(simple_format)
    root_logger.addHandler(console_handler)
    
    # 2. 通用日志文件 (按时间轮转,保留7天)
    general_log = os.path.join(log_dir, 'app.log')
    file_handler = TimedRotatingFileHandler(
        general_log,
        when='midnight',
        interval=1,
        backupCount=7,
        encoding='utf-8'
    )
    file_handler.setLevel(logging.INFO)
    file_handler.setFormatter(detailed_format)
    root_logger.addHandler(file_handler)
    
    # 3. 错误日志文件 (单独记录ERROR及以上)
    error_log = os.path.join(log_dir, 'error.log')
    error_handler = TimedRotatingFileHandler(
        error_log,
        when='midnight',
        interval=1,
        backupCount=30,
        encoding='utf-8'
    )
    error_handler.setLevel(logging.ERROR)
    error_handler.setFormatter(detailed_format)
    root_logger.addHandler(error_handler)
    
    # 4. 摄像头专用日志
    camera_log = os.path.join(log_dir, 'camera.log')
    camera_handler = TimedRotatingFileHandler(
        camera_log,
        when='midnight',
        interval=1,
        backupCount=14,
        encoding='utf-8'
    )
    camera_handler.setLevel(logging.INFO)
    camera_handler.setFormatter(detailed_format)
    
    camera_logger = logging.getLogger('camera')
    camera_logger.addHandler(camera_handler)
    camera_logger.propagate = False  # 不传播到根日志器
    
    # 5. 数据库操作日志
    db_log = os.path.join(log_dir, 'database.log')
    db_handler = TimedRotatingFileHandler(
        db_log,
        when='midnight',
        interval=1,
        backupCount=14,
        encoding='utf-8'
    )
    db_handler.setLevel(logging.WARNING)
    db_handler.setFormatter(detailed_format)
    
    db_logger = logging.getLogger('database')
    db_logger.addHandler(db_handler)
    db_logger.propagate = False
    
    # 6. 性能监控日志
    performance_log = os.path.join(log_dir, 'performance.log')
    performance_handler = TimedRotatingFileHandler(
        performance_log,
        when='midnight',
        interval=1,
        backupCount=7,
        encoding='utf-8'
    )
    performance_handler.setLevel(logging.INFO)
    performance_handler.setFormatter(detailed_format)
    
    performance_logger = logging.getLogger('performance')
    performance_logger.addHandler(performance_handler)
    performance_logger.propagate = False
    
    # 7. 视频流监控日志
    video_log = os.path.join(log_dir, 'video.log')
    video_handler = TimedRotatingFileHandler(
        video_log,
        when='midnight',
        interval=1,
        backupCount=7,
        encoding='utf-8'
    )
    video_handler.setLevel(logging.INFO)
    video_handler.setFormatter(detailed_format)
    
    video_logger = logging.getLogger('video')
    video_logger.addHandler(video_handler)
    video_logger.propagate = False
    
    print(f"[OK] 日志系统初始化完成")
    print(f"   日志目录: {os.path.abspath(log_dir)}")
    print(f"   日志级别: {logging.getLevelName(log_level)}")


def get_logger(name):
    """
    获取命名日志器
    
    Args:
        name: 日志器名称
        
    Returns:
        logging.Logger: 配置好的日志器
    """
    return logging.getLogger(name)


# 便捷函数
def log_camera_info(message, *args):
    """摄像头信息日志"""
    logger = get_logger('camera')
    logger.info(message, *args)


def log_camera_error(message, *args):
    """摄像头错误日志"""
    logger = get_logger('camera')
    logger.error(message, *args)


def log_db_warning(message, *args):
    """数据库警告日志"""
    logger = get_logger('database')
    logger.warning(message, *args)


def log_performance_info(message, *args):
    """性能监控信息日志"""
    logger = get_logger('performance')
    logger.info(message, *args)


def log_performance_warning(message, *args):
    """性能监控警告日志"""
    logger = get_logger('performance')
    logger.warning(message, *args)


def log_video_info(message, *args):
    """视频流监控信息日志"""
    logger = get_logger('video')
    logger.info(message, *args)


def log_video_error(message, *args):
    """视频流监控错误日志"""
    logger = get_logger('video')
    logger.error(message, *args)
