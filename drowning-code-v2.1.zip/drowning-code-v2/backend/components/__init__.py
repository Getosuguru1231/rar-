# backend/components/__init__.py
"""
Backend Components Package

此包包含后端的可复用组件模块:
- utils: 通用工具函数(Redis, MySQL连接等)
- camera_connection: 摄像头连接管理
- camera_health: 摄像头健康检查
- redis_pool: Redis连接池管理
"""

from .utils import (
    get_redis_client,
    get_db_connection,
    get_alert_logs,
    close_db_connection,
    save_frame_to_redis,
    release_video_writer,
    release_video_capture,
    save_alert_log,
    generate_video_filename,
    get_jpeg_encoding_params
)
from .camera_connection import CameraConnectionManager, camera_connection
from .camera_health import CameraHealthMonitor
from .redis_pool import get_redis_connection, close_redis_pool

__all__ = [
    'get_redis_client',
    'get_redis_connection',
    'close_redis_pool',
    'get_db_connection',
    'get_alert_logs',
    'close_db_connection',
    'save_frame_to_redis',
    'release_video_writer',
    'release_video_capture',
    'save_alert_log',
    'generate_video_filename',
    'get_jpeg_encoding_params',
    'CameraConnectionManager',
    'camera_connection',
    'CameraHealthMonitor'
]