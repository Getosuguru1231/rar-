"""WebSocket管理器

提供实时告警推送功能，支持前端实时接收告警通知
"""

import asyncio
import json
from typing import Set
from fastapi import WebSocket

class WebSocketManager:
    """WebSocket连接管理器"""
    
    def __init__(self):
        self.active_connections: Set[WebSocket] = set()
        self.broadcast_queue = asyncio.Queue(maxsize=1000)
        self.broadcast_task = None
    
    async def connect(self, websocket: WebSocket):
        """建立新的WebSocket连接"""
        await websocket.accept()
        self.active_connections.add(websocket)
        print(f"[WebSocket] 新连接建立，当前连接数: {len(self.active_connections)}")
        # 启动广播工作线程（确保至少有一个连接时启动）
        if not self.broadcast_task:
            await self.start_broadcast_worker()
    
    def disconnect(self, websocket: WebSocket):
        """断开WebSocket连接"""
        self.active_connections.remove(websocket)
        print(f"[WebSocket] 连接断开，当前连接数: {len(self.active_connections)}")
    
    async def send_personal_message(self, message: dict, websocket: WebSocket):
        """向单个客户端发送消息"""
        try:
            await websocket.send_json(message)
        except Exception as e:
            print(f"[WebSocket] 发送消息失败: {e}")
            self.disconnect(websocket)
    
    async def broadcast(self, message: dict):
        """广播消息到所有连接的客户端"""
        if not self.active_connections:
            print(f"[WebSocket] 广播失败: 没有活跃连接")
            return
        
        print(f"[WebSocket] 开始广播消息到 {len(self.active_connections)} 个客户端")
        disconnected = []
        for connection in self.active_connections:
            try:
                await connection.send_json(message)
                print(f"[WebSocket] 消息发送成功")
            except Exception as e:
                print(f"[WebSocket] 广播失败，移除连接: {e}")
                disconnected.append(connection)
        
        # 移除断开的连接
        for conn in disconnected:
            self.disconnect(conn)
    
    async def start_broadcast_worker(self):
        """启动广播工作线程"""
        if self.broadcast_task:
            return
        
        async def worker():
            while True:
                try:
                    message = await self.broadcast_queue.get()
                    await self.broadcast(message)
                    self.broadcast_queue.task_done()
                except asyncio.CancelledError:
                    break
                except Exception as e:
                    print(f"[WebSocket] 广播工作线程错误: {e}")
        
        self.broadcast_task = asyncio.create_task(worker())
        print("[WebSocket] 广播工作线程已启动")
    
    async def broadcast_alert(self, alert: dict):
        """广播告警消息"""
        message = {
            "type": "alert",
            "data": alert,
            "timestamp": alert.get("time", "")
        }
        
        # 如果队列满了，丢弃最旧的消息
        if self.broadcast_queue.full():
            try:
                await self.broadcast_queue.get_nowait()
            except asyncio.QueueEmpty:
                pass
        
        await self.broadcast_queue.put(message)
        print(f"[WebSocket] 告警已加入广播队列")
    
    async def broadcast_raw(self, message: dict):
        """广播原始消息到所有客户端"""
        # 如果队列满了，丢弃最旧的消息
        if self.broadcast_queue.full():
            try:
                await self.broadcast_queue.get_nowait()
            except asyncio.QueueEmpty:
                pass
        
        await self.broadcast_queue.put(message)
        print(f"[WebSocket] 原始消息已加入广播队列")

# 创建全局WebSocket管理器实例
websocket_manager = WebSocketManager()

def get_websocket_manager() -> WebSocketManager:
    """获取WebSocket管理器实例"""
    return websocket_manager