import threading
import time
import numpy as np
from typing import Optional, Dict


class SharedFrameBuffer:
    def __init__(self):
        self._frames_a: Dict[int, np.ndarray] = {}
        self._frames_b: Dict[int, np.ndarray] = {}
        self._timestamps_a: Dict[int, float] = {}
        self._timestamps_b: Dict[int, float] = {}
        self._read_idx = 0
        self._lock = threading.Lock()
        self._swap_lock = threading.Lock()

    def set_frame(self, camera_id: int, frame: np.ndarray):
        with self._lock:
            write_idx = 1 - self._read_idx
            if write_idx == 0:
                self._frames_a[camera_id] = frame
                self._timestamps_a[camera_id] = time.time()
            else:
                self._frames_b[camera_id] = frame
                self._timestamps_b[camera_id] = time.time()

    def get_frame(self, camera_id: int) -> Optional[np.ndarray]:
        with self._lock:
            if self._read_idx == 0:
                return self._frames_a.get(camera_id, None)
            else:
                return self._frames_b.get(camera_id, None)

    def get_timestamp(self, camera_id: int) -> float:
        with self._lock:
            if self._read_idx == 0:
                return self._timestamps_a.get(camera_id, 0.0)
            else:
                return self._timestamps_b.get(camera_id, 0.0)

    def has_frame(self, camera_id: int) -> bool:
        with self._lock:
            if self._read_idx == 0:
                return camera_id in self._frames_a
            else:
                return camera_id in self._frames_b

    def clear(self, camera_id: int):
        with self._lock:
            self._frames_a.pop(camera_id, None)
            self._frames_b.pop(camera_id, None)
            self._timestamps_a.pop(camera_id, None)
            self._timestamps_b.pop(camera_id, None)


shared_frame_buffer = SharedFrameBuffer()