"""
摄像头健康监控模块
用于实时监控摄像头状态、自动恢复和性能统计
支持多摄像头健康监控和自动重连
"""
import time
import threading
import cv2
from datetime import datetime
from settings import CAMERA_CONFIG, get_local_camera_id
from logging_config import get_logger

logger = get_logger('camera')


class CameraHealthMonitor:
    """摄像头健康监控器（多摄像头版本）"""
    
    def __init__(self):
        self.is_running = False
        self.monitor_thread = None
        
        self.camera_metrics = {}
        self.camera_reconnect_timers = {}
        
        self.thresholds = {
            "max_idle_time": 10.0,
            "max_consecutive_failures": 10,
            "check_interval": 5.0,
            "reconnect_delay": 30.0,
            "max_reconnect_attempts": 5
        }
        
        for camera_id in CAMERA_CONFIG:
            self._init_camera_metrics(camera_id)
    
    def _init_camera_metrics(self, camera_id):
        """初始化单个摄像头的监控指标"""
        self.camera_metrics[camera_id] = {
            "total_frames": 0,
            "failed_reads": 0,
            "reconnect_count": 0,
            "last_frame_time": None,
            "start_time": None,
            "consecutive_failures": 0,
            "max_consecutive_failures": 0,
            "current_reconnect_attempt": 0,
            "status": "unknown"
        }
    
    def start(self):
        """启动监控线程"""
        if self.is_running:
            logger.warning("健康监控已在运行")
            return
        
        self.is_running = True
        for camera_id in self.camera_metrics:
            self.camera_metrics[camera_id]["start_time"] = time.time()
        
        self.monitor_thread = threading.Thread(target=self._monitor_loop, daemon=True)
        self.monitor_thread.start()
        logger.info("摄像头健康监控已启动")
    
    def stop(self):
        """停止监控线程"""
        self.is_running = False
        
        for timer in self.camera_reconnect_timers.values():
            timer.cancel()
        self.camera_reconnect_timers.clear()
        
        if self.monitor_thread:
            self.monitor_thread.join(timeout=5)
        logger.info("摄像头健康监控已停止")
    
    def update_metrics(self, camera_id, success=True, frame_count=0, reconnect=False):
        """更新监控指标"""
        if camera_id not in self.camera_metrics:
            self._init_camera_metrics(camera_id)
        
        metrics = self.camera_metrics[camera_id]
        
        if success:
            metrics["total_frames"] += frame_count
            metrics["last_frame_time"] = time.time()
            metrics["consecutive_failures"] = 0
            metrics["current_reconnect_attempt"] = 0
            metrics["status"] = "running"
        else:
            metrics["failed_reads"] += 1
            metrics["consecutive_failures"] += 1
            
            if metrics["consecutive_failures"] > metrics["max_consecutive_failures"]:
                metrics["max_consecutive_failures"] = metrics["consecutive_failures"]
            
            if metrics["consecutive_failures"] >= self.thresholds["max_consecutive_failures"]:
                metrics["status"] = "error"
                self._trigger_reconnect(camera_id)
        
        if reconnect:
            metrics["reconnect_count"] += 1
            metrics["consecutive_failures"] = 0
    
    def _trigger_reconnect(self, camera_id):
        """触发摄像头重连"""
        if camera_id in self.camera_reconnect_timers:
            return
        
        metrics = self.camera_metrics[camera_id]
        if metrics["current_reconnect_attempt"] >= self.thresholds["max_reconnect_attempts"]:
            logger.error(f"摄像头{camera_id}重连次数已达上限({self.thresholds['max_reconnect_attempts']}次)")
            return
        
        logger.warning(f"摄像头{camera_id}将在{self.thresholds['reconnect_delay']}秒后尝试重连")
        
        def reconnect():
            try:
                self._do_reconnect(camera_id)
            except Exception as e:
                logger.error(f"摄像头{camera_id}重连失败: {str(e)}")
            finally:
                if camera_id in self.camera_reconnect_timers:
                    del self.camera_reconnect_timers[camera_id]
        
        timer = threading.Timer(self.thresholds["reconnect_delay"], reconnect)
        timer.daemon = True
        timer.start()
        self.camera_reconnect_timers[camera_id] = timer
    
    def _do_reconnect(self, camera_id):
        """执行摄像头重连 - 通知检测线程处理，避免资源冲突"""
        metrics = self.camera_metrics[camera_id]
        metrics["current_reconnect_attempt"] += 1
        
        logger.info(f"健康监控通知摄像头{camera_id}重新连接 (第{metrics['current_reconnect_attempt']}次尝试)")
        
        try:
            from detection.detect import stop_detection, start_detection
            stop_detection()
            time.sleep(1)
            start_detection()
            
            logger.info(f"摄像头{camera_id}重连触发成功")
            self.update_metrics(camera_id, success=True, reconnect=True)
            return True
            
        except Exception as e:
            logger.error(f"摄像头{camera_id}重连异常: {str(e)}")
            self.update_metrics(camera_id, success=False)
            
            if metrics["current_reconnect_attempt"] < self.thresholds["max_reconnect_attempts"]:
                self._trigger_reconnect(camera_id)
            
            return False
    
    def get_status_report(self, camera_id=None):
        """获取状态报告"""
        if camera_id:
            return self._get_single_camera_report(camera_id)
        
        reports = {}
        for cid in self.camera_metrics:
            reports[cid] = self._get_single_camera_report(cid)
        return reports
    
    def _get_single_camera_report(self, camera_id):
        """获取单个摄像头的状态报告"""
        if camera_id not in self.camera_metrics:
            self._init_camera_metrics(camera_id)
        
        metrics = self.camera_metrics[camera_id]
        
        if not metrics["start_time"]:
            return {"camera_id": camera_id, "status": "未启动"}
        
        uptime = time.time() - metrics["start_time"]
        total_frames = metrics["total_frames"]
        fps = total_frames / uptime if uptime > 0 else 0
        
        idle_time = 0
        if metrics["last_frame_time"]:
            idle_time = time.time() - metrics["last_frame_time"]
        
        health_status = "healthy"
        issues = []
        
        config = CAMERA_CONFIG.get(camera_id, {})
        if not config.get("enabled", False):
            health_status = "disabled"
            issues.append("摄像头已禁用")
        elif metrics["status"] == "unknown":
            health_status = "not_running"
            issues.append("摄像头未运行")
        elif metrics["status"] == "error":
            health_status = "critical"
            issues.append("摄像头错误")
        elif idle_time > self.thresholds["max_idle_time"]:
            health_status = "unhealthy"
            issues.append(f"帧超时: {idle_time:.1f}s")
        elif metrics["consecutive_failures"] > self.thresholds["max_consecutive_failures"]:
            health_status = "critical"
            issues.append(f"连续失败: {metrics['consecutive_failures']}次")
        
        return {
            "camera_id": camera_id,
            "status": health_status,
            "issues": issues,
            "uptime_seconds": round(uptime, 2),
            "total_frames": total_frames,
            "fps": round(fps, 2),
            "failed_reads": metrics["failed_reads"],
            "reconnect_count": metrics["reconnect_count"],
            "consecutive_failures": metrics["consecutive_failures"],
            "max_consecutive_failures": metrics["max_consecutive_failures"],
            "idle_time_seconds": round(idle_time, 2),
            "current_reconnect_attempt": metrics["current_reconnect_attempt"],
            "max_reconnect_attempts": self.thresholds["max_reconnect_attempts"]
        }
    
    def _monitor_loop(self):
        """监控循环"""
        last_check_time = time.time()
        
        while self.is_running:
            try:
                current_time = time.time()
                
                if current_time - last_check_time >= self.thresholds["check_interval"]:
                    for camera_id in self.camera_metrics:
                        report = self._get_single_camera_report(camera_id)
                        
                        if report["status"] == "healthy":
                            logger.debug(f"摄像头{camera_id}健康: FPS={report['fps']:.2f}, 总帧数={report['total_frames']}, 重连={report['reconnect_count']}次")
                        elif report["status"] == "unhealthy":
                            logger.warning(f"摄像头{camera_id}警告: {', '.join(report['issues'])}")
                        else:
                            logger.error(f"摄像头{camera_id}严重异常: {', '.join(report['issues'])}")
                    
                    last_check_time = current_time
                
                time.sleep(1)
            
            except Exception as e:
                logger.error(f"健康监控异常：{str(e)}")
                time.sleep(2)


camera_monitor = CameraHealthMonitor()