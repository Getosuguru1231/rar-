# backend/components/camera_connection.py
"""
增强型摄像头连接管理器
确保摄像头连接的稳定性和持续性
支持多种视频源类型和多摄像头管理
"""
import cv2
import time
import threading
from datetime import datetime
from typing import Optional, Callable, Dict, Any
from logging_config import get_logger

logger = get_logger('camera')


class CameraConnectionManager:
    """
    摄像头连接管理器
    
    功能:
    1. 自动重连机制 - 检测断开并自动恢复
    2. 心跳检测 - 定期检查连接状态
    3. 资源保护 - 防止重复打开和内存泄漏
    4. 优雅降级 - 多次失败后进入安全模式
    5. 多摄像头管理 - 支持同时管理多个摄像头
    6. 多视频源支持 - 本地摄像头、RTSP、视频文件、网络流
    7. 动态视频源切换 - 运行时切换视频源
    """
    
    def __init__(self, max_retries=20, retry_interval=2, heartbeat_interval=5):
        """
        初始化摄像头管理器
        
        Args:
            max_retries: 最大重试次数
            retry_interval: 重试间隔(秒)
            heartbeat_interval: 心跳检测间隔(秒)
        """
        self.max_retries = max_retries
        self.retry_interval = retry_interval
        self.heartbeat_interval = heartbeat_interval
        
        # 当前摄像头状态
        self.cap: Optional[cv2.VideoCapture] = None
        self.is_opened = False
        self.source = None
        self.source_type = None  # 视频源类型: camera, rtsp, file, network
        
        # 多摄像头管理
        self.cameras: Dict[str, Dict[str, Any]] = {}  # 摄像头ID -> 摄像头信息
        self.active_camera_id: Optional[str] = None  # 当前活跃摄像头
        
        # 统计信息
        self.total_reads = 0
        self.failed_reads = 0
        self.reconnect_count = 0
        self.last_success_time = None
        self.start_time = None
        
        # 控制标志
        self._stop_event = threading.Event()
        self._heartbeat_thread = None
        self._lock = threading.Lock()
        
        # 回调函数
        self.on_reconnect: Optional[Callable] = None
        self.on_disconnect: Optional[Callable] = None
        self.on_source_change: Optional[Callable] = None
        
        logger.info("📹 摄像头连接管理器已初始化")
        logger.info(f"   最大重试次数: {max_retries}")
        logger.info(f"   重试间隔: {retry_interval}秒")
        logger.info(f"   心跳间隔: {heartbeat_interval}秒")
    
    def _detect_source_type(self, source) -> str:
        """
        检测视频源类型
        
        Args:
            source: 视频源
            
        Returns:
            str: 视频源类型
        """
        if isinstance(source, int):
            return "camera"
        elif isinstance(source, str):
            source_lower = source.lower()
            if source_lower.startswith("rtsp://"):
                return "rtsp"
            elif source_lower.startswith("http://") or source_lower.startswith("https://"):
                return "network"
            elif any(source_lower.endswith(ext) for ext in [".mp4", ".avi", ".mov", ".mkv", ".wmv", ".flv", ".mpg", ".mpeg"]):
                return "file"
            elif source_lower.startswith("usb:"):
                return "usb_camera"
            elif source_lower.startswith("ip:"):
                return "ip_camera"
            elif source_lower == "rdk_x5":
                return "rdk_x5_camera"
        return "unknown"
    
    def open(self, source, width=1280, height=720, fps=30, camera_id="default") -> bool:
        """
        打开摄像头

        Args:
            source: 视频源 (摄像头索引/RTSP地址/文件路径/网络流/USB摄像头/IP摄像头)
            width: 帧宽度
            height: 帧高度
            fps: 帧率
            camera_id: 摄像头ID，用于多摄像头管理

        Returns:
            bool: 是否成功打开
        """
        with self._lock:
            # 如果已经打开,先关闭
            if self.is_opened and self.cap:
                logger.warning(f"⚠️ 摄像头 {self.active_camera_id} 已打开,先关闭再重新打开")
                self.close()
            
            try:
                # 处理特殊格式的视频源
                processed_source = source
                if isinstance(source, str):
                    source_lower = source.lower()
                    # 处理 USB 摄像头格式: usb:0, usb:1 等
                    if source_lower.startswith("usb:"):
                        try:
                            camera_index = int(source_lower.split(":")[1])
                            processed_source = camera_index
                            logger.info(f"🔧 解析 USB 摄像头: {source} -> 索引 {camera_index}")
                        except (ValueError, IndexError):
                            logger.error(f"❌ 无效的 USB 摄像头格式: {source}")
                            return False
                    # 处理 IP 摄像头格式: ip:192.168.1.100:554 等
                    elif source_lower.startswith("ip:"):
                        # 提取 IP 地址和端口
                        ip_part = source_lower[3:]
                        # 构建 RTSP URL（默认使用 rtsp:// 协议）
                        processed_source = f"rtsp://{ip_part}"
                        logger.info(f"🔧 解析 IP 摄像头: {source} -> RTSP {processed_source}")
                    # 处理 RDK X5 Edge 摄像头格式: rdk_x5
                    elif source_lower == "rdk_x5":
                        # RDK X5通过USB连接，自动检测可用的USB摄像头设备
                        rdk_x5_index = self._find_rdk_x5_camera()
                        if rdk_x5_index is not None:
                            processed_source = rdk_x5_index
                            logger.info(f"🔧 检测到 RDK X5 Edge USB 摄像头: 索引 {rdk_x5_index}")
                        else:
                            logger.warning(f"⚠️ 未检测到 RDK X5 Edge USB 摄像头,尝试使用摄像头索引1")
                            processed_source = 1
                
                # 检测视频源类型
                source_type = self._detect_source_type(processed_source)
                logger.info(f"📷 正在打开视频源: {processed_source} (类型: {source_type})")
                
                # 创建 VideoCapture
                # 针对网络流添加FFmpeg参数，提高兼容性
                if source_type == "network":
                    self.cap = cv2.VideoCapture(processed_source, cv2.CAP_FFMPEG)
                    # 设置FFmpeg参数，支持MJPEG流
                    self.cap.set(cv2.CAP_PROP_BUFFERSIZE, 2)
                else:
                    backends = [
                        (cv2.CAP_DSHOW, "DirectShow"),
                        (cv2.CAP_MSMF, "MediaFoundation"),
                        (cv2.CAP_ANY, "Auto"),
                    ]
                    
                    self.cap = None
                    for backend, backend_name in backends:
                        if self.cap:
                            try:
                                self.cap.release()
                            except:
                                pass
                        
                        self.cap = cv2.VideoCapture(processed_source, backend)
                        if self.cap.isOpened():
                            logger.info(f"📷 使用后端 {backend_name} 打开摄像头成功")
                            break
                        else:
                            logger.debug(f"⚠️ 使用后端 {backend_name} 打开摄像头失败，尝试下一个")
                
                if not self.cap or not self.cap.isOpened():
                    logger.error(f"❌ 无法打开视频源: {processed_source}")
                    return False
                
                # 设置参数
                self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
                self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
                self.cap.set(cv2.CAP_PROP_FPS, fps)
                
                # 验证能否读取第一帧
                ret, frame = self.cap.read()
                if not ret or frame is None:
                    logger.warning("❌ 视频源打开但首次读取帧失败，尝试重试...")
                    for retry in range(5):
                        time.sleep(0.2)
                        ret, frame = self.cap.read()
                        if ret and frame is not None:
                            logger.info("✅ 重试后帧读取成功")
                            break
                    if not ret or frame is None:
                        logger.error("❌ 所有重试均失败")
                        self.cap.release()
                        self.cap = None
                        return False
                
                # 更新状态
                self.source = source  # 保存原始源，便于显示
                self.processed_source = processed_source  # 保存处理后的源，用于重连
                self.source_type = source_type
                self.is_opened = True
                self.start_time = time.time()
                self.last_success_time = time.time()
                self.total_reads = 0
                self.failed_reads = 0
                self.active_camera_id = camera_id
                
                # 检查摄像头ID是否已存在
                if camera_id in self.cameras:
                    logger.info(f"🔄 更新已存在的摄像头: {camera_id}")
                else:
                    logger.info(f"➕ 添加新摄像头: {camera_id}")
                
                # 保存摄像头信息
                self.cameras[camera_id] = {
                    "source": source,
                    "processed_source": processed_source,
                    "source_type": source_type,
                    "width": width,
                    "height": height,
                    "fps": fps,
                    "is_opened": True,
                    "start_time": self.start_time,
                    "last_activity": self.start_time
                }
                
                logger.info(f"✅ 视频源打开成功: {width}x{height}@{fps}fps, 类型: {source_type}")
                
                # 启动心跳检测
                self._start_heartbeat()
                
                # 触发源变更回调
                if self.on_source_change:
                    try:
                        self.on_source_change(source, source_type, camera_id)
                    except Exception as e:
                        logger.error(f"回调执行失败: {str(e)}")
                
                return True
            
            except Exception as e:
                logger.error(f"❌ 打开视频源异常: {str(e)}", exc_info=True)
                if self.cap:
                    self.cap.release()
                    self.cap = None
                return False
    
    def switch_camera(self, camera_id: str) -> bool:
        """
        切换到指定摄像头
        
        Args:
            camera_id: 摄像头ID
            
        Returns:
            bool: 是否切换成功
        """
        with self._lock:
            if camera_id not in self.cameras:
                logger.error(f"❌ 摄像头 {camera_id} 不存在")
                return False
            
            camera_info = self.cameras[camera_id]
            source = camera_info["source"]
            processed_source = camera_info.get("processed_source", source)
            width = camera_info["width"]
            height = camera_info["height"]
            fps = camera_info["fps"]
            
            logger.info(f"🔄 切换到摄像头: {camera_id}, 视频源: {source}, 处理后: {processed_source}")
            return self.open(processed_source, width, height, fps, camera_id)
    
    def read(self, timeout=5) -> tuple:
        """
        读取一帧(带超时和自动重连)

        Args:
            timeout: 读取超时时间(秒)

        Returns:
            tuple: (success, frame)
        """
        if not self.is_opened or not self.cap:
            logger.warning("⚠️ 视频源未打开,尝试重新打开")
            if self.source:
                self.open(self.source)
            return False, None
        
        try:
            # 设置超时
            start_time = time.time()
            
            while time.time() - start_time < timeout:
                ret, frame = self.cap.read()
                
                if ret and frame is not None:
                    # 成功读取
                    with self._lock:
                        self.total_reads += 1
                        self.last_success_time = time.time()
                        # 更新当前摄像头的最后活动时间
                        if self.active_camera_id and self.active_camera_id in self.cameras:
                            self.cameras[self.active_camera_id]["last_activity"] = self.last_success_time
                    return True, frame
                else:
                    # 读取失败
                    with self._lock:
                        self.failed_reads += 1
                    
                    # 短暂等待后重试
                    time.sleep(0.01)
            
            # 超时仍未成功
            logger.warning(f"⚠️ 读取帧超时 ({timeout}秒)")
            return False, None
        
        except Exception as e:
            logger.error(f"❌ 读取帧异常: {str(e)}")
            return False, None
    
    def _start_heartbeat(self):
        """启动心跳检测线程"""
        if self._heartbeat_thread and self._heartbeat_thread.is_alive():
            return
        
        self._stop_event.clear()
        self._heartbeat_thread = threading.Thread(
            target=self._heartbeat_loop,
            daemon=True,
            name="CameraHeartbeat"
        )
        self._heartbeat_thread.start()
        logger.debug("💓 心跳检测线程已启动")
    
    def _heartbeat_loop(self):
        """心跳检测循环"""
        consecutive_failures = 0
        consecutive_read_failures = 0
        
        while not self._stop_event.is_set():
            try:
                if not self.is_opened or not self.cap:
                    logger.warning("⚠️ 心跳检测: 视频源未打开")
                    consecutive_failures += 1
                else:
                    try:
                        ret, _ = self.cap.read()
                        
                        if ret:
                            consecutive_failures = 0
                            consecutive_read_failures = 0
                        else:
                            consecutive_read_failures += 1
                            if consecutive_read_failures <= 5:
                                logger.debug(f"⚠️ 单次读取失败 ({consecutive_read_failures}/5)")
                                consecutive_failures = 0
                            else:
                                consecutive_failures += 1
                                logger.warning(f"⚠️ 心跳检测失败 ({consecutive_failures}/{self.max_retries})")
                    
                    except Exception as read_e:
                        logger.warning(f"⚠️ 心跳检测读取异常: {str(read_e)}")
                        consecutive_failures += 1
                
                if consecutive_failures >= 3:
                    logger.warning("🔄 连续心跳失败,触发自动重连...")
                    self._auto_reconnect()
                    consecutive_failures = 0
                    consecutive_read_failures = 0
                
                self._stop_event.wait(timeout=self.heartbeat_interval)
            
            except Exception as e:
                logger.error(f"❌ 心跳检测异常: {str(e)}")
                self._stop_event.wait(timeout=self.heartbeat_interval)
    
    def _auto_reconnect(self):
        """自动重连逻辑"""
        with self._lock:
            if self.reconnect_count >= self.max_retries:
                logger.error(f"❌ 已达到最大重试次数 ({self.max_retries}),停止重连")
                
                if self.on_disconnect:
                    try:
                        self.on_disconnect()
                    except Exception as e:
                        logger.error(f"回调执行失败: {str(e)}")
                
                return False
            
            logger.info(f"🔄 正在自动重连... (第{self.reconnect_count + 1}次)")
            
            if self.cap:
                try:
                    self.cap.release()
                except:
                    pass
                self.cap = None
            
            self.is_opened = False
            
            base_delay = self.retry_interval
            max_delay = 30
            delay = min(base_delay * (2 ** min(self.reconnect_count, 5)), max_delay)
            jitter = delay * 0.1
            actual_delay = delay + (jitter * (1 - 2 * float.fromhex(hex(hash(self.source))[-2:]) / 255))
            
            logger.info(f"⏳ 等待 {actual_delay:.1f} 秒后重试...")
            time.sleep(actual_delay)
            
            if self.source:
                camera_id = self.active_camera_id or "default"
                camera_info = self.cameras.get(camera_id, {})
                width = camera_info.get("width", 640)
                height = camera_info.get("height", 480)
                fps = camera_info.get("fps", 30)
                
                reconnect_source = camera_info.get("processed_source", self.source)
                
                for attempt in range(3):
                    try:
                        success = self.open(reconnect_source, width, height, fps, camera_id)
                        if success:
                            self.reconnect_count += 1
                            logger.info(f"✅ 自动重连成功 (累计{self.reconnect_count}次)")
                            
                            if self.on_reconnect:
                                try:
                                    self.on_reconnect(self.reconnect_count)
                                except Exception as e:
                                    logger.error(f"回调执行失败: {str(e)}")
                            
                            return True
                    except Exception as e:
                        logger.warning(f"⚠️ 重连尝试 {attempt + 1} 失败: {str(e)}")
                        time.sleep(1)
                
                logger.error("❌ 自动重连失败")
                return False
            else:
                logger.error("❌ 无法重连: 视频源未知")
                return False
    
    def close(self):
        """关闭摄像头"""
        with self._lock:
            # 停止心跳
            self._stop_event.set()
            if self._heartbeat_thread:
                self._heartbeat_thread.join(timeout=2)
                self._heartbeat_thread = None
            
            # 释放资源
            if self.cap:
                try:
                    self.cap.release()
                    logger.info(f"📷 视频源已关闭: {self.source}")
                except Exception as e:
                    logger.error(f"关闭视频源异常: {str(e)}")
                finally:
                    self.cap = None
            
            # 更新状态
            self.is_opened = False
            if self.active_camera_id and self.active_camera_id in self.cameras:
                self.cameras[self.active_camera_id]["is_opened"] = False
            
            self.source = None
            self.processed_source = None
            self.source_type = None
            self.active_camera_id = None
    
    def get_stats(self) -> dict:
        """获取摄像头统计信息"""
        uptime = 0
        if self.start_time:
            uptime = time.time() - self.start_time
        
        failure_rate = 0
        if self.total_reads > 0:
            failure_rate = (self.failed_reads / self.total_reads) * 100
        
        return {
            "is_opened": self.is_opened,
            "uptime_seconds": round(uptime, 2),
            "total_reads": self.total_reads,
            "failed_reads": self.failed_reads,
            "failure_rate_percent": round(failure_rate, 2),
            "reconnect_count": self.reconnect_count,
            "last_success_time": self.last_success_time,
            "health_status": self._get_health_status(),
            "source": self.source,
            "processed_source": getattr(self, "processed_source", None),
            "source_type": self.source_type,
            "active_camera_id": self.active_camera_id,
            "total_cameras": len(self.cameras)
        }
    
    def get_camera_list(self) -> list:
        """获取摄像头列表"""
        camera_list = []
        for camera_id, info in self.cameras.items():
            camera_list.append({
                "camera_id": camera_id,
                "source": info["source"],
                "processed_source": info.get("processed_source", info["source"]),
                "source_type": info["source_type"],
                "is_opened": info["is_opened"],
                "width": info["width"],
                "height": info["height"],
                "fps": info["fps"],
                "is_active": camera_id == self.active_camera_id,
                "last_activity": info.get("last_activity", None),
                "uptime_seconds": round(time.time() - info.get("start_time", time.time()), 2) if info.get("start_time") else 0
            })
        return camera_list
    
    def remove_camera(self, camera_id: str) -> bool:
        """移除摄像头"""
        with self._lock:
            if camera_id not in self.cameras:
                logger.error(f"❌ 摄像头 {camera_id} 不存在")
                return False
            
            # 如果是当前活跃摄像头,先关闭
            if camera_id == self.active_camera_id:
                self.close()
            
            del self.cameras[camera_id]
            logger.info(f"🗑️ 摄像头 {camera_id} 已移除")
            return True
    
    def _get_health_status(self) -> str:
        """获取健康状态"""
        if not self.is_opened:
            return "disconnected"
        
        if self.failed_reads > self.total_reads * 0.5 and self.total_reads > 100:
            return "degraded"
        
        if self.reconnect_count >= self.max_retries:
            return "critical"
        
        return "healthy"
    
    def _find_rdk_x5_camera(self) -> int:
        """
        自动检测RDK X5 Edge USB摄像头设备
        
        RDK X5通过USB数据线连接到电脑后，会被识别为USB摄像头设备。
        此方法会扫描系统中的摄像头设备，尝试找到RDK X5。
        
        Returns:
            int: RDK X5 Edge摄像头的索引，如果未找到则返回None
        """
        logger.info("🔍 正在扫描USB摄像头设备...")
        
        # 扫描前10个摄像头设备
        for index in range(0, 10):
            try:
                cap = cv2.VideoCapture(index)
                if cap.isOpened():
                    # 获取摄像头属性
                    width = cap.get(cv2.CAP_PROP_FRAME_WIDTH)
                    height = cap.get(cv2.CAP_PROP_FRAME_HEIGHT)
                    fps = cap.get(cv2.CAP_PROP_FPS)
                    
                    # 尝试读取一帧来验证
                    ret, frame = cap.read()
                    if ret and frame is not None:
                        logger.info(f"   ✅ 找到摄像头 {index}: {int(width)}x{int(height)} @ {fps:.1f}fps")
                        
                        # RDK X5通常支持的分辨率是1280x720或640x480
                        # 通过分辨率和设备特性来识别RDK X5 Edge
                        if (width == 1280 and height == 720) or (width == 640 and height == 480):
                            cap.release()
                            logger.info(f"   🎯 识别为RDK X5 Edge摄像头，索引: {index}")
                            return index
                    
                    cap.release()
                else:
                    logger.debug(f"   ❌ 摄像头 {index}: 无法打开")
            except Exception as e:
                logger.debug(f"   ⚠️ 摄像头 {index}: 异常 - {str(e)}")
        
        logger.warning("⚠️ 未检测到RDK X5 Edge USB摄像头")
        return None
    
    def __enter__(self):
        """上下文管理器入口"""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """上下文管理器出口"""
        self.close()
        return False


# 全局单例
camera_connection = CameraConnectionManager()
