"""告警管理模块

提供告警的存储、管理、触发和通知功能
支持智能告警去重、分级告警、告警升级等功能
"""

import threading
import time
import asyncio
from datetime import datetime, timedelta
from typing import Dict, List, Optional
from components.redis_pool import get_redis_connection
from logging_config import get_logger
from settings import CONF_THRESHOLD, HIGH_CONFIDENCE_THRESHOLD

logger = get_logger('alert')


class AlertManager:
    """告警管理器
    
    负责告警的存储、管理、触发和通知
    支持智能告警去重、分级告警、告警升级等功能
    """
    
    def __init__(self):
        """初始化告警管理器"""
        self.alert_history = []
        self.alert_cooldowns = {}
        self.alert_lock = threading.Lock()
        self.COOLDOWN_SECONDS = 120
        self.MAX_ALERTS_HISTORY = 2000
        self.SAME_AREA_COOLDOWN = 120
        self.SAME_CAMERA_COOLDOWN = 120
        self.RISK_LEVEL_THRESHOLD = {
            "high": HIGH_CONFIDENCE_THRESHOLD,
            "medium": CONF_THRESHOLD,
            "low": CONF_THRESHOLD * 0.7
        }
        self.active_alerts = {}
        self.alert_upgrade_timers = {}
    
    def trigger_alert(self, camera_id: int, area: str, level: str, reason: str, confidence: float = 0.0) -> Dict:
        """触发告警（智能版本）
        
        Args:
            camera_id: 摄像头ID
            area: 区域名称
            level: 告警级别（high, medium, low）
            reason: 告警原因
            confidence: 置信度（用于智能判断）
            
        Returns:
            告警信息
        """
        current_time = time.time()
        
        with self.alert_lock:
            if not self._check_cooldown(camera_id, area, level, current_time):
                return {
                    "success": False,
                    "message": "告警冷却中",
                    "data": None
                }
            
            if not self._check_smart_threshold(camera_id, area, level, confidence, current_time):
                return {
                    "success": False,
                    "message": "未达到告警阈值",
                    "data": None
                }
        
        alert = {
            "id": int(time.time() * 1000),
            "cameraId": camera_id,
            "area": area,
            "level": level,
            "reason": reason,
            "confidence": confidence,
            "time": datetime.now().isoformat(),
            "drowningStartTime": datetime.now().isoformat(),
            "acknowledged": False,
            "resolved": False,
            "upgraded": False,
            "upgrade_count": 0
        }
        
        with self.alert_lock:
            self._update_cooldowns(camera_id, area, level, current_time)
            self.alert_history.append(alert)
            
            if len(self.alert_history) > self.MAX_ALERTS_HISTORY:
                self.alert_history = self.alert_history[-self.MAX_ALERTS_HISTORY:]
            
            alert_key = f"{camera_id}:{area}"
            self.active_alerts[alert_key] = alert
            
            self._schedule_alert_upgrade(alert_key, alert)
        
        self._store_alert_to_redis(alert)
        logger.info(f"告警已存储到Redis: camera_id={camera_id}, area={area}, level={level}")
        
        self._send_notification(alert)
        logger.info(f"告警通知已发送: {alert['id']}")
        
        self._push_alert_to_clients(alert)
        logger.info(f"告警已推送到客户端: {alert['id']}")
        
        return {
            "success": True,
            "message": "告警触发成功",
            "data": alert
        }
    
    def _check_cooldown(self, camera_id: int, area: str, level: str, current_time: float) -> bool:
        """检查告警冷却时间
        
        Args:
            camera_id: 摄像头ID
            area: 区域名称
            level: 告警级别
            current_time: 当前时间
            
        Returns:
            是否允许触发告警
        """
        alert_key = f"{camera_id}:{area}:{level}"
        if alert_key in self.alert_cooldowns:
            if current_time - self.alert_cooldowns[alert_key] < self.COOLDOWN_SECONDS:
                logger.debug(f"特定告警冷却中: {alert_key}")
                return False
        
        area_key = f"{camera_id}:{area}"
        if area_key in self.alert_cooldowns:
            if current_time - self.alert_cooldowns[area_key] < self.SAME_AREA_COOLDOWN:
                logger.debug(f"同一区域告警冷却中: {area_key}")
                return False
        
        camera_key = f"camera:{camera_id}"
        if camera_key in self.alert_cooldowns:
            if current_time - self.alert_cooldowns[camera_key] < self.SAME_CAMERA_COOLDOWN:
                logger.debug(f"同一摄像头告警冷却中: camera_id={camera_id}")
                return False
        
        return True
    
    def _check_smart_threshold(self, camera_id: int, area: str, level: str, confidence: float, current_time: float) -> bool:
        """智能阈值检查
        
        根据置信度和历史告警情况决定是否触发告警
        
        Args:
            camera_id: 摄像头ID
            area: 区域名称
            level: 告警级别
            confidence: 置信度
            current_time: 当前时间
            
        Returns:
            是否允许触发告警
        """
        threshold = self.RISK_LEVEL_THRESHOLD.get(level, 0.35)
        
        if confidence > 0 and confidence < threshold:
            logger.debug(f"置信度未达到阈值: {confidence} < {threshold}")
            return False
        
        area_key = f"{camera_id}:{area}"
        if area_key in self.active_alerts:
            existing_alert = self.active_alerts[area_key]
            if existing_alert["level"] == level and existing_alert["resolved"] is False:
                alert_time = datetime.fromisoformat(existing_alert["time"])
                if (datetime.now() - alert_time).seconds < 120:
                    logger.debug(f"同一区域已有相同级别活动告警，2分钟内不再触发")
                    return False
        
        return True
    
    def _update_cooldowns(self, camera_id: int, area: str, level: str, current_time: float):
        """更新冷却时间
        
        Args:
            camera_id: 摄像头ID
            area: 区域名称
            level: 告警级别
            current_time: 当前时间
        """
        alert_key = f"{camera_id}:{area}:{level}"
        self.alert_cooldowns[alert_key] = current_time
        
        area_key = f"{camera_id}:{area}"
        self.alert_cooldowns[area_key] = current_time
        
        camera_key = f"camera:{camera_id}"
        self.alert_cooldowns[camera_key] = current_time
    
    def _schedule_alert_upgrade(self, alert_key: str, alert: Dict):
        """调度告警升级
        
        如果告警在一定时间内未被确认，自动升级告警级别
        
        Args:
            alert_key: 告警键
            alert: 告警信息
        """
        if alert["level"] == "high":
            return
        
        def upgrade_alert():
            with self.alert_lock:
                if alert_key in self.active_alerts:
                    active_alert = self.active_alerts[alert_key]
                    if not active_alert["acknowledged"] and not active_alert["resolved"]:
                        if active_alert["level"] == "low":
                            active_alert["level"] = "medium"
                            active_alert["upgraded"] = True
                            active_alert["upgrade_count"] += 1
                            logger.warning(f"告警已升级为medium: {active_alert['id']}")
                            self._push_alert_update_to_clients(active_alert)
                        elif active_alert["level"] == "medium":
                            active_alert["level"] = "high"
                            active_alert["upgraded"] = True
                            active_alert["upgrade_count"] += 1
                            logger.warning(f"告警已升级为high: {active_alert['id']}")
                            self._push_alert_update_to_clients(active_alert)
        
        timer = threading.Timer(120, upgrade_alert)
        timer.daemon = True
        timer.start()
        self.alert_upgrade_timers[alert_key] = timer
    
    def acknowledge_alert(self, alert_id: int) -> bool:
        """标记告警为已处理
        
        Args:
            alert_id: 告警ID
            
        Returns:
            是否成功
        """
        with self.alert_lock:
            for alert in self.alert_history:
                if alert['id'] == alert_id:
                    alert['acknowledged'] = True
                    alert['acknowledged_time'] = datetime.now().isoformat()
                    
                    alert_key = f"{alert['cameraId']}:{alert['area']}"
                    if alert_key in self.alert_upgrade_timers:
                        self.alert_upgrade_timers[alert_key].cancel()
                        del self.alert_upgrade_timers[alert_key]
                    
                    self._update_alert_in_redis(alert)
                    logger.info(f"告警 {alert_id} 已确认")
                    self._push_alert_update_to_clients(alert)
                    return True
        return False
    
    def resolve_alert(self, alert_id: int) -> bool:
        """标记告警为已解决
        
        Args:
            alert_id: 告警ID
            
        Returns:
            是否成功
        """
        with self.alert_lock:
            for alert in self.alert_history:
                if alert['id'] == alert_id:
                    alert['resolved'] = True
                    alert['resolved_time'] = datetime.now().isoformat()
                    
                    alert_key = f"{alert['cameraId']}:{alert['area']}"
                    if alert_key in self.active_alerts:
                        del self.active_alerts[alert_key]
                    if alert_key in self.alert_upgrade_timers:
                        self.alert_upgrade_timers[alert_key].cancel()
                        del self.alert_upgrade_timers[alert_key]
                    
                    self._update_alert_in_redis(alert)
                    logger.info(f"告警 {alert_id} 已解决")
                    return True
        return False
    
    def _store_alert_to_redis(self, alert: Dict):
        """存储告警到Redis
        
        Args:
            alert: 告警信息
        """
        try:
            redis_client = get_redis_connection()
            if redis_client:
                alert_data = {}
                for key, value in alert.items():
                    if isinstance(value, bool):
                        alert_data[key] = str(value)
                    else:
                        alert_data[key] = value
                
                alert_key = f"alert:{alert['id']}"
                redis_client.hset(alert_key, mapping=alert_data)
                redis_client.expire(alert_key, 86400)
                
                redis_client.lpush("alerts:recent", alert['id'])
                redis_client.ltrim("alerts:recent", 0, 99)
                
                redis_client.incr("alerts:count:total")
                redis_client.incr(f"alerts:count:{alert['level']}")
        except Exception as e:
            logger.error(f"存储告警到Redis失败: {e}")
    
    def _send_notification(self, alert: Dict):
        """发送告警通知
        
        Args:
            alert: 告警信息
        """
        logger.info(f"[语音调试] 开始发送告警通知: {alert}")
        try:
            import sys
            import os
            backend_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            if backend_dir not in sys.path:
                sys.path.insert(0, backend_dir)
                logger.info(f"[语音调试] 添加路径到sys.path: {backend_dir}")
            
            logger.info("[语音调试] 尝试导入语音播报模块...")
            from alert import voice_alert, get_voice_status
            logger.info(f"[语音调试] 语音播报模块导入成功，当前状态: {get_voice_status()}")
            
            level_text = {
                "high": "高",
                "medium": "中",
                "low": "低"
            }.get(alert['level'], alert['level'])
            
            message = f"{alert['area']} {alert['reason']}，告警级别：{level_text}"
            logger.info(f"[语音调试] 准备调用语音播报: {message}")
            voice_alert(message, alert['area'])
            logger.info(f"[语音调试] 语音播报调用完成，更新状态: {get_voice_status()}")
            
        except ImportError as e:
            logger.error(f"[语音调试] 语音播报模块导入失败: {e}")
            logger.error(f"[语音调试] 当前sys.path: {sys.path}")
        except Exception as e:
            logger.error(f"[语音调试] 发送告警通知失败: {e}", exc_info=True)
    
    def _push_alert_to_clients(self, alert: Dict):
        """通过WebSocket推送告警到所有客户端
        
        Args:
            alert: 告警信息
        """
        try:
            from api.unified_monitor import monitor_server
            
            def _broadcast():
                try:
                    import asyncio
                    loop = asyncio.new_event_loop()
                    asyncio.set_event_loop(loop)
                    loop.run_until_complete(monitor_server.broadcast_alert(alert))
                    loop.close()
                except RuntimeError as e:
                    logger.error(f"异步推送告警失败(运行时错误): {e}")
                except Exception as e:
                    logger.error(f"异步推送告警失败: {e}")
            
            thread = threading.Thread(target=_broadcast, daemon=True)
            thread.start()
        except Exception as e:
            logger.error(f"推送告警到WebSocket失败: {e}")
    
    def _push_alert_update_to_clients(self, alert: Dict):
        """通过WebSocket推送告警更新到所有客户端
        
        Args:
            alert: 告警信息
        """
        try:
            from api.unified_monitor import monitor_server
            
            def _broadcast_update():
                try:
                    import asyncio
                    loop = asyncio.new_event_loop()
                    asyncio.set_event_loop(loop)
                    loop.run_until_complete(monitor_server.broadcast_alert_update(alert))
                    loop.close()
                except Exception as e:
                    logger.error(f"异步推送告警更新失败: {e}")
            
            thread = threading.Thread(target=_broadcast_update, daemon=True)
            thread.start()
        except Exception as e:
            logger.error(f"推送告警更新到WebSocket失败: {e}")
    
    def get_alerts(self, limit: int = 50, offset: int = 0, page: int = 1, size: int = 20) -> List[Dict]:
        """获取告警列表
        
        Args:
            limit: 限制数量（兼容旧接口）
            offset: 偏移量（兼容旧接口）
            page: 页码（从1开始）
            size: 每页大小
            
        Returns:
            告警列表
        """
        with self.alert_lock:
            if page > 0 and size > 0:
                offset = (page - 1) * size
                limit = size
            
            start = offset
            end = offset + limit
            alerts = self.alert_history[start:end][::-1]
            
            for alert in alerts:
                if 'drowningStartTime' not in alert:
                    alert['drowningStartTime'] = alert.get('time', datetime.now().isoformat())
            
            return alerts
    
    def get_unacknowledged_alerts(self) -> List[Dict]:
        """获取未处理的告警
        
        Returns:
            未处理的告警列表
        """
        with self.alert_lock:
            alerts = [alert for alert in self.alert_history if not alert['acknowledged']][::-1]
            
            for alert in alerts:
                if 'drowningStartTime' not in alert:
                    alert['drowningStartTime'] = alert.get('time', datetime.now().isoformat())
            
            return alerts
    
    def _update_alert_in_redis(self, alert: Dict):
        """更新Redis中的告警信息
        
        Args:
            alert: 告警信息
        """
        try:
            redis_client = get_redis_connection()
            if redis_client:
                alert_key = f"alert:{alert['id']}"
                redis_client.hset(alert_key, mapping=alert)
        except Exception as e:
            logger.error(f"更新Redis中的告警失败: {e}")
    
    def delete_alert(self, alert_id: int) -> bool:
        """删除单个告警
        
        Args:
            alert_id: 告警ID
            
        Returns:
            是否成功
        """
        with self.alert_lock:
            for i, alert in enumerate(self.alert_history):
                if alert['id'] == alert_id:
                    self.alert_history.pop(i)
                    self._delete_alert_from_redis(alert_id)
                    self._push_alert_delete_to_clients(alert_id)
                    return True
        return False
    
    def delete_all_alerts(self) -> int:
        """删除所有告警
        
        Returns:
            删除的告警数量
        """
        with self.alert_lock:
            count = len(self.alert_history)
            self.alert_history.clear()
            self.active_alerts.clear()
            for timer in self.alert_upgrade_timers.values():
                timer.cancel()
            self.alert_upgrade_timers.clear()
            
            self._delete_all_alerts_from_redis()
            self._push_alert_clear_to_clients()
            return count
    
    def _delete_alert_from_redis(self, alert_id: int):
        """从Redis中删除单个告警
        
        Args:
            alert_id: 告警ID
        """
        try:
            redis_client = get_redis_connection()
            if redis_client:
                alert_key = f"alert:{alert_id}"
                redis_client.delete(alert_key)
                redis_client.lrem("alerts:recent", 0, str(alert_id))
        except Exception as e:
            logger.error(f"从Redis删除告警失败: {e}")
    
    def _delete_all_alerts_from_redis(self):
        """从Redis中删除所有告警"""
        try:
            redis_client = get_redis_connection()
            if redis_client:
                keys = redis_client.keys("alert:*")
                if keys:
                    redis_client.delete(*keys)
                redis_client.delete("alerts:recent")
        except Exception as e:
            logger.error(f"从Redis删除所有告警失败: {e}")
    
    def _push_alert_delete_to_clients(self, alert_id: int):
        """通过WebSocket推送告警删除通知到所有客户端
        
        Args:
            alert_id: 告警ID
        """
        try:
            from api.unified_monitor import monitor_server
            
            def _broadcast_delete():
                try:
                    import asyncio
                    loop = asyncio.new_event_loop()
                    asyncio.set_event_loop(loop)
                    loop.run_until_complete(monitor_server.broadcast_alert_delete(alert_id))
                    loop.close()
                except Exception as e:
                    logger.error(f"异步推送告警删除失败: {e}")
            
            thread = threading.Thread(target=_broadcast_delete, daemon=True)
            thread.start()
        except Exception as e:
            logger.error(f"推送告警删除到WebSocket失败: {e}")
    
    def _push_alert_clear_to_clients(self):
        """通过WebSocket推送清空告警通知到所有客户端"""
        try:
            from api.unified_monitor import monitor_server
            
            def _broadcast_clear():
                try:
                    import asyncio
                    loop = asyncio.new_event_loop()
                    asyncio.set_event_loop(loop)
                    loop.run_until_complete(monitor_server.broadcast_alert_clear())
                    loop.close()
                except Exception as e:
                    logger.error(f"异步推送清空告警失败: {e}")
            
            thread = threading.Thread(target=_broadcast_clear, daemon=True)
            thread.start()
        except Exception as e:
            logger.error(f"推送清空告警到WebSocket失败: {e}")
    
    def get_alert_statistics(self) -> Dict:
        """获取告警统计信息
        
        Returns:
            告警统计信息
        """
        now = datetime.now()
        today = now.date()
        
        hourly_counts = {f"{i:02d}:00": 0 for i in range(24)}
        daily_counts = {}
        for i in range(7):
            date = now - timedelta(days=i)
            date_str = f"{date.month}/{date.day}"
            daily_counts[date_str] = 0
        
        monthly_counts = {}
        for i in range(12):
            date = now - timedelta(days=i * 30)
            month_str = f"{date.month}月"
            monthly_counts[month_str] = 0
        
        with self.alert_lock:
            total_alerts = len(self.alert_history)
            unacknowledged_alerts = 0
            total_resolved = 0
            total_acknowledged = 0
            
            by_level = {}
            by_area = {}
            
            for alert in self.alert_history:
                if not alert.get('acknowledged', False):
                    unacknowledged_alerts += 1
                if alert.get('resolved', False):
                    total_resolved += 1
                if alert.get('acknowledged', False) and not alert.get('resolved', False):
                    total_acknowledged += 1
                
                level = alert.get('level', 'unknown')
                by_level[level] = by_level.get(level, 0) + 1
                
                area = alert.get('area', 'unknown')
                by_area[area] = by_area.get(area, 0) + 1
                
                try:
                    alert_time = datetime.fromisoformat(alert['time'])
                    
                    if alert_time.date() == today:
                        hour_key = f"{alert_time.hour:02d}:00"
                        if hour_key in hourly_counts:
                            hourly_counts[hour_key] += 1
                    
                    date_str = f"{alert_time.month}/{alert_time.day}"
                    if date_str in daily_counts:
                        daily_counts[date_str] += 1
                    
                    month_str = f"{alert_time.month}月"
                    if month_str in monthly_counts:
                        monthly_counts[month_str] += 1
                except:
                    pass
        
        hourly_result = [{"time": f"{i:02d}:00", "count": hourly_counts[f"{i:02d}:00"]} for i in range(24)]
        
        daily_result = []
        for i in range(6, -1, -1):
            date = now - timedelta(days=i)
            date_str = f"{date.month}/{date.day}"
            daily_result.append({"time": date_str, "count": daily_counts[date_str]})
        
        monthly_result = []
        for i in range(11, -1, -1):
            date = now - timedelta(days=i * 30)
            month_str = f"{date.month}月"
            monthly_result.append({"time": month_str, "count": monthly_counts[month_str]})
        
        return {
            "total_alerts": total_alerts,
            "unacknowledged_alerts": unacknowledged_alerts,
            "total_resolved": total_resolved,
            "total_acknowledged": total_acknowledged,
            "by_level": by_level,
            "by_area": by_area,
            "hourly": hourly_result,
            "daily": daily_result,
            "monthly": monthly_result,
            "active_alerts": len(self.active_alerts)
        }
    
    def _get_hourly_stats(self) -> List[Dict]:
        """获取每小时告警统计
        
        Returns:
            每小时告警统计列表
        """
        now = datetime.now()
        hourly_counts = {}
        
        for i in range(24):
            hour_key = f"{i:02d}:00"
            hourly_counts[hour_key] = 0
        
        with self.alert_lock:
            today = now.date()
            for alert in self.alert_history:
                try:
                    alert_time = datetime.fromisoformat(alert['time'])
                    if alert_time.date() == today:
                        hour_key = f"{alert_time.hour:02d}:00"
                        if hour_key in hourly_counts:
                            hourly_counts[hour_key] += 1
                except:
                    pass
        
        result = []
        for i in range(24):
            hour_key = f"{i:02d}:00"
            result.append({"time": hour_key, "count": hourly_counts[hour_key]})
        
        return result
    
    def _get_daily_stats(self) -> List[Dict]:
        """获取每日告警统计（最近7天）
        
        Returns:
            每日告警统计列表
        """
        now = datetime.now()
        daily_counts = {}
        
        for i in range(7):
            date = now - timedelta(days=i)
            date_str = f"{date.month}/{date.day}"
            daily_counts[date_str] = 0
        
        with self.alert_lock:
            for alert in self.alert_history:
                try:
                    alert_time = datetime.fromisoformat(alert['time'])
                    date_str = f"{alert_time.month}/{alert_time.day}"
                    if date_str in daily_counts:
                        daily_counts[date_str] += 1
                except:
                    pass
        
        result = []
        for i in range(6, -1, -1):
            date = now - timedelta(days=i)
            date_str = f"{date.month}/{date.day}"
            result.append({"time": date_str, "count": daily_counts[date_str]})
        
        return result
    
    def _get_monthly_stats(self) -> List[Dict]:
        """获取每月告警统计（最近12个月）
        
        Returns:
            每月告警统计列表
        """
        now = datetime.now()
        monthly_counts = {}
        
        for i in range(12):
            date = now - timedelta(days=i * 30)
            month_str = f"{date.month}月"
            monthly_counts[month_str] = 0
        
        with self.alert_lock:
            for alert in self.alert_history:
                try:
                    alert_time = datetime.fromisoformat(alert['time'])
                    month_str = f"{alert_time.month}月"
                    if month_str in monthly_counts:
                        monthly_counts[month_str] += 1
                except:
                    pass
        
        result = []
        for i in range(11, -1, -1):
            date = now - timedelta(days=i * 30)
            month_str = f"{date.month}月"
            result.append({"time": month_str, "count": monthly_counts[month_str]})
        
        return result
    
    def get_today_stats(self) -> Dict:
        """获取今日告警统计
        
        Returns:
            今日告警统计信息
        """
        today = datetime.now().date()
        
        with self.alert_lock:
            today_alerts = [
                alert for alert in self.alert_history 
                if datetime.fromisoformat(alert['time']).date() == today
            ]
            
            total_today = len(today_alerts)
            unacknowledged_today = len([alert for alert in today_alerts if not alert['acknowledged']])
            resolved_today = len([alert for alert in today_alerts if alert['resolved']])
            
            by_level = {}
            for alert in today_alerts:
                level = alert['level']
                if level not in by_level:
                    by_level[level] = 0
                by_level[level] += 1
            
            by_area = {}
            for alert in today_alerts:
                area = alert['area']
                if area not in by_area:
                    by_area[area] = 0
                by_area[area] += 1
            
            return {
                "total_alerts": total_today,
                "unacknowledged_alerts": unacknowledged_today,
                "resolved_alerts": resolved_today,
                "by_level": by_level,
                "by_area": by_area,
                "date": today.isoformat()
            }
    
    def get_stats(self) -> Dict:
        """获取告警统计（兼容旧接口）
        
        Returns:
            告警统计信息
        """
        return self.get_alert_statistics()
    
    def get_drowning_timeline(self, camera_id: int = None) -> List[Dict]:
        """获取溺水事件时间线
        
        Args:
            camera_id: 摄像头ID（可选）
            
        Returns:
            溺水事件时间线
        """
        with self.alert_lock:
            alerts = self.alert_history[::-1]
            
            if camera_id:
                alerts = [alert for alert in alerts if alert['cameraId'] == camera_id]
            
            timeline = []
            for alert in alerts:
                timeline.append({
                    "id": alert['id'],
                    "cameraId": alert['cameraId'],
                    "area": alert['area'],
                    "level": alert['level'],
                    "time": alert['time'],
                    "drowningStartTime": alert.get('drowningStartTime', alert['time']),
                    "acknowledged": alert['acknowledged'],
                    "resolved": alert['resolved'],
                    "upgraded": alert.get('upgraded', False),
                    "upgrade_count": alert.get('upgrade_count', 0)
                })
            
            return timeline
    
    def get_active_alerts(self) -> List[Dict]:
        """获取当前活动告警
        
        Returns:
            活动告警列表
        """
        with self.alert_lock:
            return list(self.active_alerts.values())


alert_manager = AlertManager()

def get_alert_manager() -> AlertManager:
    """获取告警管理器实例
    
    Returns:
        告警管理器实例
    """
    return alert_manager