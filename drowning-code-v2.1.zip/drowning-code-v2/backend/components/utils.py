# backend/utils.py
"""
通用工具函数模块
提取重复代码，提供统一的工具方法
"""
import os
import cv2
import numpy as np
import redis
import mysql.connector
import threading
import time
from datetime import datetime
from settings import *


# ========== 数据库连接工具 ==========
import mysql.connector.pooling

_db_pool = None
_db_pool_lock = threading.Lock()

def _init_db_pool():
    """初始化数据库连接池"""
    global _db_pool
    if _db_pool is not None:
        return
    
    with _db_pool_lock:
        if _db_pool is not None:
            return
        
        try:
            _db_pool = mysql.connector.pooling.MySQLConnectionPool(
                pool_name="drowning_pool",
                pool_size=10,
                pool_reset_session=True,
                **MYSQL_CONFIG
            )
            print(f"[{datetime.now()}] ✅ MySQL连接池初始化成功")
        except Exception as e:
            print(f"[{datetime.now()}] ❌ MySQL连接池初始化失败: {str(e)}")
            raise


def get_db_connection(max_retries: int = 3, retry_delay: float = 1.0):
    """
    获取数据库连接（使用连接池）
    
    重要：此函数返回的连接不是线程安全的！
    每个线程应该调用此函数获取自己的连接，而不是共享全局连接。

    正确用法:
        conn = get_db_connection()
        try:
            # 使用连接...
        finally:
            close_db_connection(conn)

    错误用法:
        # 多个线程共享同一个全局连接
        global_conn = get_db_connection()  # 危险！

    Args:
        max_retries: 最大重试次数，默认3次
        retry_delay: 重试间隔（秒），默认1秒

    Returns:
        MySQL连接对象

    Raises:
        Exception: 当所有重试都失败时抛出异常
    """
    last_error = None
    
    for attempt in range(max_retries):
        try:
            if _db_pool is None:
                _init_db_pool()
            
            conn = _db_pool.get_connection()
            conn.ping(reconnect=True)
            print(f"[{datetime.now()}] 数据库连接成功（第 {attempt + 1} 次尝试）")
            return conn
        except Exception as e:
            last_error = e
            wait_time = retry_delay * (2 ** attempt)  # 指数退避
            print(f"[{datetime.now()}] 数据库连接失败（第 {attempt + 1} 次尝试）：{str(e)}")
            
            if attempt < max_retries - 1:
                print(f"[{datetime.now()}] 将在 {wait_time:.2f} 秒后重试...")
                time.sleep(wait_time)
    
    error_msg = f"[{datetime.now()}] 数据库连接失败，已尝试 {max_retries} 次：{str(last_error)}"
    print(error_msg)
    raise Exception(error_msg)


def close_db_connection(db_conn):
    """关闭数据库连接（返回连接池）"""
    if db_conn:
        try:
            db_conn.close()
            print(f"[{datetime.now()}] 数据库连接已归还连接池")
        except Exception as e:
            print(f"[{datetime.now()}] 关闭数据库连接失败: {str(e)}")


def close_db_pool():
    """关闭数据库连接池"""
    global _db_pool
    if _db_pool:
        try:
            _db_pool._cnx_pool.clear()
            _db_pool = None
            print(f"[{datetime.now()}] ✅ MySQL连接池已关闭")
        except Exception as e:
            print(f"[{datetime.now()}] ❌ 关闭MySQL连接池失败: {str(e)}")


# ========== Redis 连接工具 ==========
from .redis_pool import get_redis_connection


def get_redis_client(decode_responses: bool = True):
    """获取 Redis 客户端连接（使用统一的连接池管理器）

    Args:
        decode_responses: 是否解码响应为字符串，默认True（返回字符串）
                         False用于需要二进制数据的场景（如图片、帧数据）

    Returns:
        Redis连接对象
    """
    try:
        client = get_redis_connection(decode_responses=decode_responses)
        if client:
            client.ping()
            return client
        else:
            raise Exception("无法获取Redis连接")
    except Exception as e:
        print(f"[{datetime.now()}] Redis 连接失败：{str(e)}")
        raise


# ========== YOLO 模型工具 ==========
import sys
import os
# 将 backend 目录添加到 Python 路径
backend_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, backend_dir)
from models import get_yolo_model, reload_yolo_model


# ========== 视频处理工具 ==========
def letterbox(frame: np.ndarray, target_width: int, target_height: int) -> np.ndarray:
    """
    使用letterbox策略将帧适配到目标尺寸，避免画面拉伸
    
    Args:
        frame: 原始帧
        target_width: 目标宽度
        target_height: 目标高度
    
    Returns:
        适配后的帧，保持原始宽高比，空白区域填充黑色
    """
    h, w = frame.shape[:2]
    target_ratio = target_width / target_height
    source_ratio = w / h
    
    if source_ratio > target_ratio:
        scale = target_width / w
        new_w = target_width
        new_h = int(h * scale)
        pad_left = 0
        pad_right = 0
        pad_top = (target_height - new_h) // 2
        pad_bottom = target_height - new_h - pad_top
    else:
        scale = target_height / h
        new_w = int(w * scale)
        new_h = target_height
        pad_left = (target_width - new_w) // 2
        pad_right = target_width - new_w - pad_left
        pad_top = 0
        pad_bottom = 0
    
    resized = cv2.resize(frame, (new_w, new_h), interpolation=cv2.INTER_LINEAR)
    
    result = np.zeros((target_height, target_width, 3), dtype=np.uint8)
    result[pad_top:pad_top+new_h, pad_left:pad_left+new_w] = resized
    
    return result


def is_valid_video_file(file_path):
    """
    基础校验：排除空文件、过小文件
    :param file_path: 视频文件路径
    :return: True 表示文件有效，False 表示文件无效
    """
    if not os.path.exists(file_path):
        print(f"[{datetime.now()}] [ERROR] 视频文件不存在：{file_path}")
        return False

    file_size = os.path.getsize(file_path)

    if file_size < 1024:
        print(f"[{datetime.now()}] [ERROR] 视频文件过小（{file_size} 字节），可能已损坏：{file_path}")
        return False

    valid_extensions = ['.mp4', '.avi', '.mov', '.mkv', '.flv', '.wmv', '.m4v']
    ext = os.path.splitext(file_path)[1].lower()
    if ext not in valid_extensions:
        print(f"[{datetime.now()}] [WARNING] 非标准视频格式：{ext}，但仍会尝试打开")

    print(f"[{datetime.now()}] [INFO] 视频文件基础校验通过：{file_path} (大小：{file_size/1024:.2f} KB)")
    return True


def safe_open_video(video_path, timeout=5):
    """
    安全打开视频，超时自动放弃，不卡死主线程
    :param video_path: 视频文件路径
    :param timeout: 超时时间（秒）
    :return: cv2.VideoCapture 对象
    :raises: Exception 当打开失败或超时时抛出异常
    """
    cap = None
    success = False
    error_msg = ""

    def open_thread():
        nonlocal cap, success, error_msg
        try:
            cap = cv2.VideoCapture(video_path)

            if not cap.isOpened():
                error_msg = "VideoCapture 无法打开"
                return

            ret, frame = cap.read()
            if not ret or frame is None:
                error_msg = "无法读取第一帧"
                success = False
                return

            success = True
            print(f"[{datetime.now()}] [INFO] 视频成功打开并验证：{video_path}")
        except Exception as e:
            error_msg = str(e)
            success = False

    thread = threading.Thread(target=open_thread)
    thread.daemon = True
    thread.start()

    thread.join(timeout=timeout)

    if not success or thread.is_alive():
        if cap:
            cap.release()
        raise Exception(f"视频打开超时/失败：{video_path}（{error_msg or '未知错误'}，超时：{timeout}秒）")

    return cap


def init_video_capture(source=VIDEO_SOURCE, timeout=10):
    """
    初始化视频捕获（自动重连，带超时机制）
    :param source: 视频源（摄像头 ID、RTSP 地址或文件路径）
    :param timeout: 超时时间（秒）

    支持以下格式：
    - 整数索引：0, 1, 2... (推荐)
    - RTSP 地址：rtsp://username:password@ip:port/stream
    - 文件路径：/path/to/video.mp4

    注意：Windows 设备实例路径（USB\VID_xxx...）不被 OpenCV 直接支持
    """
    print(f"[{datetime.now()}] 正在打开视频源：{source}")
    start_time = time.time()

    if isinstance(source, str) and os.path.isfile(source):
        print(f"[{datetime.now()}] 步骤 1/2: 正在校验视频文件有效性...")
        if not is_valid_video_file(source):
            raise Exception(f"视频文件校验失败：{source}")

        print(f"[{datetime.now()}] 步骤 2/2: 使用超时保护打开视频...")
        cap = safe_open_video(source, timeout=min(timeout, 5))
    else:
        cap = cv2.VideoCapture(source)

    elapsed = time.time() - start_time
    if elapsed > timeout:
        if cap:
            cap.release()
        raise Exception(f"打开视频源超时 ({timeout}秒): {source}")

    if not cap.isOpened():
        raise Exception(f"无法打开视频源：{source} (耗时：{elapsed:.2f}秒)")

    print(f"[{datetime.now()}] 视频捕获已初始化：{source} (耗时：{elapsed:.2f}秒)")
    return cap


def release_video_capture(cap):
    """释放视频捕获资源"""
    if cap and cap.isOpened():
        cap.release()
        print(f"[{datetime.now()}] 视频捕获已释放")


def release_video_writer(writer):
    """释放视频写入资源"""
    if writer:
        writer.release()
        print(f"[{datetime.now()}] 视频写入已释放")


def get_jpeg_encoding_params(quality: int = 85, optimize: bool = True):
    """
    获取统一的JPEG编码参数（性能优化版）
    
    Args:
        quality: JPEG压缩质量 (1-100)
        optimize: 是否启用Huffman优化（提高压缩率，略微增加编码时间）
    
    Returns:
        cv2编码参数列表
    """
    return [
        int(cv2.IMWRITE_JPEG_QUALITY), quality,
        int(cv2.IMWRITE_JPEG_OPTIMIZE), 1 if optimize else 0,
        int(cv2.IMWRITE_JPEG_PROGRESSIVE), 0,
        int(cv2.IMWRITE_JPEG_CHROMA_QUALITY), 90,
    ]


def save_frame_to_redis(redis_client, frame, key="current_frame", quality=85):
    """
    将帧缓存到 Redis（高性能版）
    :param redis_client: Redis 客户端
    :param frame: OpenCV 图像帧
    :param key: Redis 键名
    :param quality: JPEG压缩质量 (1-100)
                    - 85-90: 高清晰度（推荐，平衡速度与质量）
                    - 70-80: 平衡模式
                    - 50-65: 低带宽模式
    """
    try:
        encode_param = get_jpeg_encoding_params(quality, optimize=True)

        _, buffer = cv2.imencode('.jpg', frame, encode_param)
        frame_data = buffer.tobytes()

        pipe = redis_client.pipeline(transaction=False)
        pipe.setex(key, REDIS_FRAME_EXPIRE, frame_data)
        pipe.setex(f"{key}_timestamp", REDIS_FRAME_EXPIRE, str(time.time()))
        pipe.execute()

        return True
    except Exception as e:
        import logging
        logging.getLogger(__name__).error(f"保存帧到Redis失败: {str(e)}")
        return False


# ========== 告警日志工具 ==========
def save_alert_log(db_conn, video_path, alert_time=None):
    """
    保存告警日志到数据库
    :param db_conn: 数据库连接
    :param video_path: 告警视频路径
    :param alert_time: 告警时间，默认当前时间
    """
    if alert_time is None:
        alert_time = datetime.now()

    try:
        cursor = db_conn.cursor()
        cursor.execute(
            "INSERT INTO alert_log (alert_time, video_path) VALUES (%s, %s)",
            (alert_time, video_path)
        )
        db_conn.commit()
        cursor.close()
        print(f"[{datetime.now()}] 告警日志已写入数据库")
        return True
    except Exception as e:
        print(f"[{datetime.now()}] 告警日志写入失败：{str(e)}")
        if db_conn:
            db_conn.rollback()
        return False


def get_alert_logs(db_conn, page=1, size=10):
    """
    获取告警日志列表
    :param db_conn: 数据库连接
    :param page: 页码
    :param size: 每页数量
    :return: 告警日志列表
    """
    try:
        cursor = db_conn.cursor(dictionary=True)
        offset = (page - 1) * size
        cursor.execute("""
        SELECT * FROM alert_log ORDER BY alert_time DESC LIMIT %s OFFSET %s
        """, (size, offset))
        logs = cursor.fetchall()
        cursor.close()
        return logs
    except Exception as e:
        print(f"[{datetime.now()}] 获取告警日志失败：{str(e)}")
        return []


# ========== LRU缓存工具 ==========
class LRUCache:
    """
    LRU (Least Recently Used) 缓存实现
    
    用于优化视频流和帧数据的缓存管理，限制内存使用
    """
    
    def __init__(self, max_size: int = 100, max_memory_mb: int = 100):
        """
        初始化LRU缓存
        
        Args:
            max_size: 最大缓存条目数，默认100
            max_memory_mb: 最大内存使用量（MB），默认100MB
        """
        from collections import OrderedDict
        self.cache = OrderedDict()
        self.max_size = max_size
        self.max_memory = max_memory_mb * 1024 * 1024  # 转换为字节
        self.current_memory = 0
    
    def get(self, key):
        """获取缓存项
        
        Args:
            key: 缓存键
        
        Returns:
            缓存值，如果不存在返回None
        """
        if key not in self.cache:
            return None
        
        # 将访问的项移到末尾（最近使用）
        self.cache.move_to_end(key)
        return self.cache[key]["data"]
    
    def set(self, key, value):
        """设置缓存项
        
        Args:
            key: 缓存键
            value: 缓存值（二进制数据）
        
        Returns:
            True表示设置成功，False表示被拒绝（过大）
        """
        value_size = len(value) if isinstance(value, bytes) else len(str(value).encode('utf-8'))
        
        # 如果单个值超过最大内存限制的一半，拒绝缓存
        if value_size > self.max_memory / 2:
            print(f"[{datetime.now()}] [WARNING] 缓存项过大，拒绝缓存: {key} ({value_size / 1024 / 1024:.2f} MB)")
            return False
        
        # 如果已存在，先删除旧值
        if key in self.cache:
            self.current_memory -= self.cache[key]["size"]
            del self.cache[key]
        
        # 添加新值
        self.cache[key] = {
            "data": value,
            "size": value_size,
            "timestamp": time.time()
        }
        self.current_memory += value_size
        
        # 清理超出限制的项
        self._evict()
        
        return True
    
    def _evict(self):
        """清理超出限制的缓存项"""
        # 先按条目数清理
        while len(self.cache) > self.max_size:
            oldest_key = next(iter(self.cache))
            self.current_memory -= self.cache[oldest_key]["size"]
            del self.cache[oldest_key]
        
        # 再按内存限制清理
        while self.current_memory > self.max_memory:
            oldest_key = next(iter(self.cache))
            self.current_memory -= self.cache[oldest_key]["size"]
            del self.cache[oldest_key]
    
    def delete(self, key):
        """删除缓存项
        
        Args:
            key: 缓存键
        
        Returns:
            True表示删除成功，False表示键不存在
        """
        if key in self.cache:
            self.current_memory -= self.cache[key]["size"]
            del self.cache[key]
            return True
        return False
    
    def clear(self):
        """清空所有缓存"""
        self.cache.clear()
        self.current_memory = 0
    
    def get_stats(self):
        """获取缓存统计信息"""
        return {
            "size": len(self.cache),
            "memory_used_mb": self.current_memory / 1024 / 1024,
            "max_size": self.max_size,
            "max_memory_mb": self.max_memory / 1024 / 1024
        }

# 全局LRU缓存实例（用于帧数据缓存）
frame_cache = LRUCache(max_size=50, max_memory_mb=50)


# ========== 时间格式化工具 ==========
def format_timestamp(dt=None):
    """
    格式化时间为字符串
    :param dt: datetime 对象，默认当前时间
    :return: 格式化的时间字符串
    """
    if dt is None:
        dt = datetime.now()
    return dt.strftime('%Y-%m-%d %H:%M:%S')


def generate_video_filename(prefix=""):
    """
    生成视频文件名（带时间戳）
    :param prefix: 文件名前缀
    :return: 视频文件名
    """
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    return f"{prefix}{timestamp}.mp4" if prefix else f"{timestamp}.mp4"