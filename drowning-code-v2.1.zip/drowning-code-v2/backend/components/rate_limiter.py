import time
import threading
from collections import defaultdict
from typing import Dict, Callable


class TokenBucket:
    def __init__(self, rate: float, capacity: int):
        self.rate = rate
        self.capacity = capacity
        self.tokens = capacity
        self.last_refill_time = time.time()
        self.lock = threading.Lock()

    def try_acquire(self) -> bool:
        with self.lock:
            now = time.time()
            elapsed = now - self.last_refill_time
            self.tokens = min(self.capacity, self.tokens + elapsed * self.rate)
            self.last_refill_time = now

            if self.tokens >= 1:
                self.tokens -= 1
                return True
            return False


class RateLimiter:
    def __init__(self):
        self.buckets: Dict[str, TokenBucket] = {}
        self.global_bucket = TokenBucket(rate=100, capacity=200)
        self.path_rules: Dict[str, TokenBucket] = {}
        self.ip_buckets: Dict[str, TokenBucket] = {}
        self.lock = threading.Lock()
        self._init_path_rules()

    def _init_path_rules(self):
        self.path_rules = {
            "/api/video_feed": TokenBucket(rate=10, capacity=30),
            "/api/video_feed/snapshot": TokenBucket(rate=5, capacity=10),
            "/api/video_feed/stats": TokenBucket(rate=2, capacity=5),
            "/api/video_feed/fps": TokenBucket(rate=5, capacity=10),
            
            "/api/alerts/trigger": TokenBucket(rate=1, capacity=5),
            "/api/alerts/list": TokenBucket(rate=5, capacity=10),
            "/api/alerts/recent": TokenBucket(rate=10, capacity=20),
            "/api/alerts/today": TokenBucket(rate=2, capacity=5),
            "/api/alerts/statistics": TokenBucket(rate=2, capacity=5),
            
            "/api/camera/status": TokenBucket(rate=5, capacity=10),
            "/api/camera/health": TokenBucket(rate=5, capacity=10),
            "/api/camera/list": TokenBucket(rate=2, capacity=5),
            "/api/camera/stats": TokenBucket(rate=5, capacity=10),
            "/api/camera/reconnect": TokenBucket(rate=1, capacity=3),
            
            "/api/monitoring/stats": TokenBucket(rate=10, capacity=20),
            "/api/monitoring/metrics": TokenBucket(rate=5, capacity=10),
            
            "/api/llm/analyze": TokenBucket(rate=1, capacity=3),
            "/api/llm/ask": TokenBucket(rate=2, capacity=5),
            "/api/llm/generate-alert": TokenBucket(rate=1, capacity=3),
            
            "/api/config/system": TokenBucket(rate=1, capacity=3),
            "/api/config/model": TokenBucket(rate=1, capacity=3),
            "/api/config/camera": TokenBucket(rate=1, capacity=3),
            
            "/api/video/timestamp": TokenBucket(rate=10, capacity=20),
            "/api/video/people-count": TokenBucket(rate=10, capacity=20),
            "/api/video/status": TokenBucket(rate=2, capacity=5),
            
            "/api/video/cleanup": TokenBucket(rate=1, capacity=2),
            "/api/video/folders": TokenBucket(rate=2, capacity=5),
            
            "/api/detection/upload": TokenBucket(rate=2, capacity=5),
            "/api/detection/result": TokenBucket(rate=5, capacity=10),
            "/api/detection/tasks": TokenBucket(rate=2, capacity=5),
            "/api/detection/live-frame": TokenBucket(rate=10, capacity=20),
            
            "/api/device/stream": TokenBucket(rate=2, capacity=5),
            "/api/device/history": TokenBucket(rate=5, capacity=10),
            
            "/api/login": TokenBucket(rate=3, capacity=10),
            "/api/register": TokenBucket(rate=2, capacity=5),
            
            "/system/health": TokenBucket(rate=5, capacity=10),
            "/performance": TokenBucket(rate=5, capacity=10),
        }

    def check(self, path: str, client_ip: str) -> tuple[bool, dict]:
        if not self.global_bucket.try_acquire():
            return False, {"reason": "global", "message": "系统繁忙，请稍后重试"}

        ip_bucket = self.ip_buckets.get(client_ip)
        if ip_bucket is None:
            ip_bucket = TokenBucket(rate=30, capacity=50)
            self.ip_buckets[client_ip] = ip_bucket
        if not ip_bucket.try_acquire():
            return False, {"reason": "ip", "message": "请求过于频繁，请稍后重试"}

        matched_rule = None
        for rule_path, bucket in self.path_rules.items():
            if path.startswith(rule_path) or path == rule_path:
                matched_rule = bucket
                break

        if matched_rule and not matched_rule.try_acquire():
            return False, {"reason": "path", "message": "此接口请求过于频繁，请稍后重试"}

        return True, {"reason": "allowed", "message": "ok"}

    def get_stats(self) -> dict:
        stats = {
            "global": {
                "rate": self.global_bucket.rate,
                "capacity": self.global_bucket.capacity,
                "tokens": round(self.global_bucket.tokens, 2)
            },
            "ip_count": len(self.ip_buckets),
            "path_rules": {k: {"rate": v.rate, "capacity": v.capacity} for k, v in self.path_rules.items()}
        }
        return stats


rate_limiter = RateLimiter()