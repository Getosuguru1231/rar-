import time
import psutil
import redis
from datetime import datetime
from collections import deque

class SystemMonitor:
    def __init__(self):
        self.metrics = {
            'api_response_times': deque(maxlen=100),
            'video_stream_fps': deque(maxlen=100),
            'model_inference_times': deque(maxlen=100),
            'error_counts': {
                'api': 0,
                'video_stream': 0,
                'model': 0
            },
            'connections': {
                'current': 0,
                'total': 0
            },
            'network_io': deque(maxlen=100),
            'disk_io': deque(maxlen=100),
            'alert_stats': {
                'total': 0,
                'unacknowledged': 0,
                'resolved': 0
            },
            'camera_status': {
                'total': 0,
                'online': 0,
                'offline': 0
            }
        }
        self.start_time = time.time()
        # 记录初始网络和磁盘IO
        self.last_network_io = psutil.net_io_counters()
        self.last_disk_io = psutil.disk_io_counters()
        self.last_io_time = time.time()
    
    def record_api_response_time(self, endpoint: str, response_time: float):
        """记录API响应时间"""
        self.metrics['api_response_times'].append({
            'endpoint': endpoint,
            'time': response_time,
            'timestamp': time.time()
        })
    
    def record_video_stream_fps(self, camera_id: str, fps: float):
        """记录视频流FPS"""
        self.metrics['video_stream_fps'].append({
            'camera_id': camera_id,
            'fps': fps,
            'timestamp': time.time()
        })
    
    def record_model_inference_time(self, model_name: str, inference_time: float):
        """记录模型推理时间"""
        self.metrics['model_inference_times'].append({
            'model_name': model_name,
            'time': inference_time,
            'timestamp': time.time()
        })
    
    def increment_error_count(self, error_type: str):
        """增加错误计数"""
        if error_type in self.metrics['error_counts']:
            self.metrics['error_counts'][error_type] += 1
    
    def update_connections(self, current: int, total: int):
        """更新连接数"""
        self.metrics['connections']['current'] = current
        self.metrics['connections']['total'] = total
    
    def record_network_io(self):
        """记录网络IO"""
        current_time = time.time()
        current_network_io = psutil.net_io_counters()
        
        # 计算网络IO速率
        time_diff = current_time - self.last_io_time
        if time_diff > 0:
            bytes_sent_rate = (current_network_io.bytes_sent - self.last_network_io.bytes_sent) / time_diff
            bytes_recv_rate = (current_network_io.bytes_recv - self.last_network_io.bytes_recv) / time_diff
            
            self.metrics['network_io'].append({
                'bytes_sent_rate': bytes_sent_rate,
                'bytes_recv_rate': bytes_recv_rate,
                'timestamp': current_time
            })
            
            self.last_network_io = current_network_io
            self.last_io_time = current_time
    
    def record_disk_io(self):
        """记录磁盘IO"""
        current_time = time.time()
        current_disk_io = psutil.disk_io_counters()
        
        # 计算磁盘IO速率
        time_diff = current_time - self.last_io_time
        if time_diff > 0:
            read_bytes_rate = (current_disk_io.read_bytes - self.last_disk_io.read_bytes) / time_diff
            write_bytes_rate = (current_disk_io.write_bytes - self.last_disk_io.write_bytes) / time_diff
            
            self.metrics['disk_io'].append({
                'read_bytes_rate': read_bytes_rate,
                'write_bytes_rate': write_bytes_rate,
                'timestamp': current_time
            })
            
            self.last_disk_io = current_disk_io
            self.last_io_time = current_time
    
    def update_alert_stats(self, total: int, unacknowledged: int, resolved: int):
        """更新告警统计"""
        self.metrics['alert_stats']['total'] = total
        self.metrics['alert_stats']['unacknowledged'] = unacknowledged
        self.metrics['alert_stats']['resolved'] = resolved
    
    def update_camera_status(self, total: int, online: int, offline: int):
        """更新摄像头状态"""
        self.metrics['camera_status']['total'] = total
        self.metrics['camera_status']['online'] = online
        self.metrics['camera_status']['offline'] = offline
    
    def get_system_metrics(self):
        """获取系统指标"""
        # 获取系统资源使用情况
        cpu_percent = psutil.cpu_percent(interval=0.1)
        memory = psutil.virtual_memory()
        disk = psutil.disk_usage('.')
        
        # 计算平均响应时间
        avg_api_response_time = 0
        if self.metrics['api_response_times']:
            total_time = sum(item['time'] for item in self.metrics['api_response_times'])
            avg_api_response_time = total_time / len(self.metrics['api_response_times'])
        
        # 计算平均FPS
        avg_fps = 0
        if self.metrics['video_stream_fps']:
            total_fps = sum(item['fps'] for item in self.metrics['video_stream_fps'])
            avg_fps = total_fps / len(self.metrics['video_stream_fps'])
        
        # 计算平均推理时间
        avg_inference_time = 0
        if self.metrics['model_inference_times']:
            total_time = sum(item['time'] for item in self.metrics['model_inference_times'])
            avg_inference_time = total_time / len(self.metrics['model_inference_times'])
        
        # 计算网络IO
        avg_network_io = {
            'bytes_sent_rate': 0,
            'bytes_recv_rate': 0
        }
        if self.metrics['network_io']:
            total_sent = sum(item['bytes_sent_rate'] for item in self.metrics['network_io'])
            total_recv = sum(item['bytes_recv_rate'] for item in self.metrics['network_io'])
            avg_network_io['bytes_sent_rate'] = total_sent / len(self.metrics['network_io'])
            avg_network_io['bytes_recv_rate'] = total_recv / len(self.metrics['network_io'])
        
        # 计算磁盘IO
        avg_disk_io = {
            'read_bytes_rate': 0,
            'write_bytes_rate': 0
        }
        if self.metrics['disk_io']:
            total_read = sum(item['read_bytes_rate'] for item in self.metrics['disk_io'])
            total_write = sum(item['write_bytes_rate'] for item in self.metrics['disk_io'])
            avg_disk_io['read_bytes_rate'] = total_read / len(self.metrics['disk_io'])
            avg_disk_io['write_bytes_rate'] = total_write / len(self.metrics['disk_io'])
        
        # 计算运行时间
        uptime = time.time() - self.start_time
        
        # 记录当前网络和磁盘IO
        self.record_network_io()
        self.record_disk_io()
        
        return {
            'system': {
                'cpu_percent': cpu_percent,
                'memory_percent': memory.percent,
                'disk_percent': disk.percent,
                'uptime': uptime,
                'cpu_count': psutil.cpu_count(),
                'memory_total': memory.total,
                'memory_available': memory.available,
                'disk_total': disk.total,
                'disk_free': disk.free
            },
            'api': {
                'avg_response_time': avg_api_response_time,
                'response_time_count': len(self.metrics['api_response_times'])
            },
            'video_stream': {
                'avg_fps': avg_fps,
                'fps_count': len(self.metrics['video_stream_fps'])
            },
            'model': {
                'avg_inference_time': avg_inference_time,
                'inference_count': len(self.metrics['model_inference_times'])
            },
            'network': {
                'avg_bytes_sent_rate': avg_network_io['bytes_sent_rate'],
                'avg_bytes_recv_rate': avg_network_io['bytes_recv_rate'],
                'io_count': len(self.metrics['network_io'])
            },
            'disk': {
                'avg_read_bytes_rate': avg_disk_io['read_bytes_rate'],
                'avg_write_bytes_rate': avg_disk_io['write_bytes_rate'],
                'io_count': len(self.metrics['disk_io'])
            },
            'alerts': self.metrics['alert_stats'],
            'cameras': self.metrics['camera_status'],
            'errors': self.metrics['error_counts'],
            'connections': self.metrics['connections'],
            'timestamp': time.time()
        }

# 创建全局监控实例
system_monitor = SystemMonitor()

def get_system_monitor():
    """获取系统监控实例"""
    return system_monitor