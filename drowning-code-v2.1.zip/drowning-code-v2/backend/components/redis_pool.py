"""Redis连接池管理模块

提供高性能Redis连接池管理功能，减少连接创建和关闭的开销
"""

import redis
import time
from settings import REDIS_CONFIG
from typing import Optional, Dict, Any

class RedisPoolManager:
    """Redis连接池管理器

    负责创建和管理Redis连接池，提供获取和释放连接的方法
    支持自动重连、连接验证和连接复用
    """

    def __init__(self, decode_responses: bool = False):
        """初始化Redis连接池

        Args:
            decode_responses: 是否解码响应为字符串，默认False（返回bytes）
                             True用于需要字符串的场景，False用于需要二进制数据的场景（如图片）
        """
        self.decode_responses = decode_responses
        self.pool = None
        self._last_connection_time = 0
        self._connection_attempts = 0
        self._max_retry_attempts = 5
        self._retry_delay = 1  # 秒
        self._connection_stats = {
            'connections_made': 0,
            'connections_failed': 0,
            'connections_reused': 0,
            'last_success_time': None,
            'last_failure_time': None,
            'last_failure_reason': None
        }
        self._create_pool()

    def _create_pool(self):
        """创建Redis连接池"""
        try:
            self.pool = redis.ConnectionPool(
                host=REDIS_CONFIG["host"],
                port=REDIS_CONFIG["port"],
                db=REDIS_CONFIG["db"],
                password=REDIS_CONFIG.get("password", ""),
                decode_responses=self.decode_responses,
                socket_connect_timeout=2,
                socket_timeout=2,
                socket_keepalive=True,
                max_connections=50,
                health_check_interval=30
            )
            self._connection_stats['connections_made'] += 1
            self._connection_stats['last_success_time'] = time.time()
            self._connection_attempts = 0
            print(f"[OK] Redis连接池创建成功 (decode_responses={self.decode_responses})")
        except Exception as e:
            self._connection_stats['connections_failed'] += 1
            self._connection_stats['last_failure_time'] = time.time()
            self._connection_stats['last_failure_reason'] = str(e)
            print(f"[ERROR] Redis连接池创建失败: {e}")
            self.pool = None

    def _validate_connection(self, conn: redis.Redis) -> bool:
        """验证Redis连接是否有效

        Args:
            conn: Redis连接对象

        Returns:
            True如果连接有效，False否则
        """
        try:
            conn.ping()
            return True
        except Exception as e:
            print(f"[WARNING] Redis连接验证失败: {e}")
            return False

    def get_connection(self) -> Optional[redis.Redis]:
        """获取Redis连接

        使用连接池获取连接，支持自动重连和连接验证

        Returns:
            Redis连接对象，如果连接池未创建或验证失败则返回None
        """
        now = time.time()
        
        # 如果连接池不存在或上次连接失败，尝试重新创建
        if not self.pool:
            if now - self._last_connection_time > self._retry_delay * (2 ** min(self._connection_attempts, 5)):
                self._last_connection_time = now
                self._connection_attempts += 1
                self._create_pool()
            else:
                return None

        if self.pool:
            try:
                conn = redis.Redis(connection_pool=self.pool)
                
                # 仅在连接池创建后首次验证，后续不再验证以提高性能
                if self._last_connection_time + 30 > now:
                    if not self._validate_connection(conn):
                        self.pool.disconnect()
                        self.pool = None
                        self._create_pool()
                        if self.pool:
                            conn = redis.Redis(connection_pool=self.pool)
                        else:
                            return None
                
                self._connection_stats['connections_reused'] += 1
                return conn
                
            except Exception as e:
                self._connection_stats['connections_failed'] += 1
                self._connection_stats['last_failure_time'] = time.time()
                self._connection_stats['last_failure_reason'] = str(e)
                print(f"[ERROR] 获取Redis连接失败: {e}")
                
                self.pool = None
                self._create_pool()
                
                if self.pool:
                    try:
                        return redis.Redis(connection_pool=self.pool)
                    except Exception as e2:
                        print(f"[ERROR] 重试获取Redis连接失败: {e2}")
                        return None
                
                return None
        return None

    def close(self):
        """关闭Redis连接池"""
        if self.pool:
            try:
                self.pool.disconnect()
                print(f"[OK] Redis连接池已关闭 (decode_responses={self.decode_responses})")
            except Exception as e:
                print(f"[ERROR] 关闭Redis连接池失败: {e}")

    def get_stats(self) -> Dict[str, Any]:
        """获取连接池统计信息"""
        return {
            'decode_responses': self.decode_responses,
            'pool_exists': self.pool is not None,
            'connection_attempts': self._connection_attempts,
            **self._connection_stats
        }


# 创建两个全局Redis连接池管理器实例
# decode_responses=False: 用于需要二进制数据的场景（如图片、帧数据）
_redis_pool_binary = RedisPoolManager(decode_responses=False)

# decode_responses=True: 用于需要字符串的场景（如配置、统计数据）
_redis_pool_string = RedisPoolManager(decode_responses=True)

def get_redis_connection(decode_responses: bool = False) -> Optional[redis.Redis]:
    """获取Redis连接

    Args:
        decode_responses: 是否解码响应为字符串，默认False（返回bytes）
                         True用于需要字符串的场景，False用于需要二进制数据的场景

    Returns:
        Redis连接对象
    """
    if decode_responses:
        return _redis_pool_string.get_connection()
    return _redis_pool_binary.get_connection()

def close_redis_pool():
    """关闭所有Redis连接池"""
    _redis_pool_binary.close()
    _redis_pool_string.close()

def get_redis_pool_stats() -> Dict[str, Any]:
    """获取所有Redis连接池的统计信息"""
    return {
        'binary_pool': _redis_pool_binary.get_stats(),
        'string_pool': _redis_pool_string.get_stats()
    }