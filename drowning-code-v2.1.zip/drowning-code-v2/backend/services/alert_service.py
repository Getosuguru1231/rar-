"""告警服务 - 提供告警管理功能"""
import json
import asyncio
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional
from collections import deque

from components.utils import get_redis_client

class AlertService:
    def __init__(self):
        self.redis_client = get_redis_client(decode_responses=True)
        self.alert_history = deque(maxlen=100)
        self.alert_status = {
            "active_alerts": 0,
            "total_alerts_today": 0,
            "last_alert_time": None
        }
    
    def create_alert(self, alert_type: str, details: Dict[str, Any]) -> Dict[str, Any]:
        """创建新告警"""
        alert_id = f"alert_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{id(details)}"
        
        alert = {
            "id": alert_id,
            "type": alert_type,
            "details": details,
            "status": "pending",
            "created_at": datetime.now().isoformat(),
            "updated_at": datetime.now().isoformat()
        }
        
        # 保存到Redis
        try:
            self.redis_client.set(f"alert:{alert_id}", json.dumps(alert))
            self.redis_client.expire(f"alert:{alert_id}", 86400)  # 24小时过期
            
            # 添加到历史记录
            self.alert_history.appendleft(alert)
            
            # 更新统计
            self.alert_status["active_alerts"] += 1
            self.alert_status["total_alerts_today"] += 1
            self.alert_status["last_alert_time"] = datetime.now().isoformat()
            
            # 更新Redis中的统计
            self.redis_client.set("alert:status:active", self.alert_status["active_alerts"])
            self.redis_client.set("alert:status:total_today", self.alert_status["total_alerts_today"])
            self.redis_client.set("alert:status:last_time", self.alert_status["last_alert_time"])
            
            print(f"[{datetime.now()}] 🚨 新告警: {alert_type}")
            
            # 通过WebSocket广播告警
            self._broadcast_alert(alert)
        except Exception as e:
            print(f"[{datetime.now()}] ❌ 创建告警失败: {str(e)}")
        
        return alert
    
    def _broadcast_alert(self, alert: Dict[str, Any]):
        """通过WebSocket广播告警"""
        try:
            from api.unified_monitor import monitor_server
            
            frontend_alert = {
                "id": alert.get("id"),
                "time": alert.get("created_at"),
                "cameraId": alert.get("details", {}).get("camera_id", 1),
                "area": alert.get("details", {}).get("camera_id", "未知区域"),
                "level": alert.get("details", {}).get("risk_level", "high"),
                "reason": alert.get("details", {}).get("risk_details", ["检测到溺水行为"])[0] if alert.get("details", {}).get("risk_details") else "检测到溺水行为",
                "acknowledged": False,
                "resolved": False
            }
            
            loop = asyncio.get_event_loop()
            if loop.is_running():
                asyncio.create_task(monitor_server.broadcast_alert(frontend_alert))
            else:
                loop.run_until_complete(monitor_server.broadcast_alert(frontend_alert))
            
            print(f"[{datetime.now()}] 📡 告警已广播")
        except Exception as e:
            print(f"[{datetime.now()}] ❌ 广播告警失败: {str(e)}")
    
    def get_alert(self, alert_id: str) -> Optional[Dict[str, Any]]:
        """获取单个告警"""
        try:
            alert_data = self.redis_client.get(f"alert:{alert_id}")
            if alert_data:
                return json.loads(alert_data)
            return None
        except Exception as e:
            print(f"[{datetime.now()}] ❌ 获取告警失败: {str(e)}")
            return None
    
    def update_alert_status(self, alert_id: str, status: str) -> bool:
        """更新告警状态"""
        try:
            alert_data = self.redis_client.get(f"alert:{alert_id}")
            if alert_data:
                alert = json.loads(alert_data)
                alert["status"] = status
                alert["updated_at"] = datetime.now().isoformat()
                self.redis_client.set(f"alert:{alert_id}", json.dumps(alert))
                
                # 更新活跃告警数
                if status == "resolved":
                    self.alert_status["active_alerts"] = max(0, self.alert_status["active_alerts"] - 1)
                    self.redis_client.set("alert:status:active", self.alert_status["active_alerts"])
                
                return True
            return False
        except Exception as e:
            print(f"[{datetime.now()}] ❌ 更新告警状态失败: {str(e)}")
            return False
    
    def get_recent_alerts(self, limit: int = 20) -> List[Dict[str, Any]]:
        """获取最近的告警"""
        return list(self.alert_history)[:limit]
    
    def get_alert_statistics(self) -> Dict[str, Any]:
        """获取告警统计信息"""
        today_start = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
        
        # 从Redis获取统计
        try:
            active_alerts = int(self.redis_client.get("alert:status:active") or 0)
            total_today = int(self.redis_client.get("alert:status:total_today") or 0)
            last_time = self.redis_client.get("alert:status:last_time")
        except Exception:
            active_alerts = self.alert_status["active_alerts"]
            total_today = self.alert_status["total_alerts_today"]
            last_time = self.alert_status["last_alert_time"]
        
        return {
            "active_alerts": active_alerts,
            "total_alerts_today": total_today,
            "last_alert_time": last_time,
            "alert_types": ["drowning", "fall", "abnormal_behavior"]
        }
    
    def clear_all_alerts(self) -> bool:
        """清除所有告警"""
        try:
            # 删除Redis中的所有告警
            keys = self.redis_client.keys("alert:*")
            if keys:
                self.redis_client.delete(*keys)
            
            # 重置状态
            self.alert_history.clear()
            self.alert_status = {
                "active_alerts": 0,
                "total_alerts_today": 0,
                "last_alert_time": None
            }
            
            return True
        except Exception as e:
            print(f"[{datetime.now()}] ❌ 清除告警失败: {str(e)}")
            return False

# 创建全局实例
_alert_service = None

def get_alert_service() -> AlertService:
    """获取告警服务实例"""
    global _alert_service
    if _alert_service is None:
        _alert_service = AlertService()
    return _alert_service