"""LLM服务 - 提供AI分析功能"""
import os
import json
import requests
from datetime import datetime
from typing import Dict, Any, Optional

class LLMService:
    def __init__(self, api_key: Optional[str] = None, base_url: Optional[str] = None, model: Optional[str] = None):
        self.api_key = api_key or os.environ.get("LLM_API_KEY") or os.environ.get("TRAE_API_KEY")
        self.base_url = base_url or os.environ.get("LLM_BASE_URL") or "https://dashscope.aliyuncs.com/api/v1"
        self.model = model or os.environ.get("LLM_MODEL") or "qwen-turbo"
        self.provider = os.environ.get("LLM_PROVIDER") or "qwen"
    
    def _build_request(self, messages: list, temperature: float = 0.7) -> Dict[str, Any]:
        if self.provider == "qwen":
            return {
                "model": self.model,
                "input": {
                    "messages": messages
                },
                "parameters": {
                    "temperature": temperature
                }
            }
        else:
            return {
                "model": self.model,
                "messages": messages,
                "temperature": temperature
            }
    
    def _build_url(self) -> str:
        if self.provider == "qwen":
            return f"{self.base_url}/services/aigc/text-generation/generation"
        else:
            return f"{self.base_url}/chat/completions"
    
    def _build_headers(self) -> Dict[str, str]:
        if self.provider == "qwen":
            return {
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json"
            }
        else:
            return {
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json"
            }
    
    def _parse_response(self, response: requests.Response) -> str:
        if response.status_code != 200:
            raise Exception(f"API request failed: HTTP {response.status_code}")
        
        result = response.json()
        
        if self.provider == "qwen":
            if "output" in result:
                return result.get("output", {}).get("text", "")
            elif "error" in result:
                raise Exception(f"API error: {result.get('error', {}).get('message', 'Unknown error')}")
            else:
                raise Exception(f"API error: Unexpected response format")
        else:
            return result.get("choices", [{}])[0].get("message", {}).get("content", "")
    
    def analyze_video_event(self, event_data: Dict[str, Any]) -> Dict[str, Any]:
        if not self.api_key:
            return {"success": False, "error": "API key not configured"}
        
        try:
            prompt = f"""分析以下视频检测事件：
- 检测时间: {event_data.get('timestamp', '未知')}
- 检测到的目标: {event_data.get('detections', [])}
- 人数统计: {event_data.get('people_count', 0)}
- 告警类型: {event_data.get('alert_type', '未知')}

请分析：
1. 当前场景描述
2. 潜在风险评估
3. 建议处理措施"""
            
            messages = [
                {"role": "system", "content": "你是一个溺水检测系统的AI助手，负责分析视频检测事件并提供专业建议。"},
                {"role": "user", "content": prompt}
            ]
            
            response = requests.post(
                self._build_url(),
                headers=self._build_headers(),
                json=self._build_request(messages, 0.7),
                timeout=30
            )
            
            analysis = self._parse_response(response)
            
            return {"success": True, "analysis": analysis}
            
        except Exception as e:
            print(f"[{datetime.now()}] ❌ LLM分析失败: {str(e)}")
            return {"success": False, "error": str(e)}
    
    def generate_report(self, alert_history: list) -> Dict[str, Any]:
        if not self.api_key:
            return {"success": False, "error": "API key not configured"}
        
        try:
            report_data = {
                "total_alerts": len(alert_history),
                "alert_summary": [
                    {
                        "time": alert.get("created_at"),
                        "type": alert.get("type"),
                        "details": alert.get("details")
                    }
                    for alert in alert_history[:10]
                ]
            }
            
            prompt = f"""基于以下告警历史生成报告：
{json.dumps(report_data, ensure_ascii=False, indent=2)}

请生成一份详细的告警报告，包括：
1. 告警概览
2. 常见问题分析
3. 改进建议"""
            
            messages = [
                {"role": "system", "content": "你是一个安全监控系统的报告生成助手，负责生成专业的告警分析报告。"},
                {"role": "user", "content": prompt}
            ]
            
            response = requests.post(
                self._build_url(),
                headers=self._build_headers(),
                json=self._build_request(messages, 0.5),
                timeout=30
            )
            
            report = self._parse_response(response)
            
            return {"success": True, "report": report}
            
        except Exception as e:
            print(f"[{datetime.now()}] ❌ 生成报告失败: {str(e)}")
            return {"success": False, "error": str(e)}
    
    def test_connection(self) -> str:
        try:
            if not self.api_key:
                return "LLM服务未配置API密钥"
            
            messages = [{"role": "user", "content": "测试连接，返回'OK'即可"}]
            
            response = requests.post(
                self._build_url(),
                headers=self._build_headers(),
                json=self._build_request(messages, 0),
                timeout=30
            )
            
            result = self._parse_response(response)
            if "OK" in result or result.strip():
                return "LLM服务连接成功"
            else:
                return f"连接失败: {result}"
                
        except Exception as e:
            return f"连接异常: {str(e)}"
    
    def generate_alert(self, event_data: Dict[str, Any]) -> Dict[str, Any]:
        if not self.api_key:
            return {"success": False, "error": "API key not configured"}
        
        try:
            prompt = f"""分析以下事件并生成告警信息：
- 时间: {event_data.get('timestamp', '未知')}
- 摄像头: {event_data.get('camera_id', '未知')}
- 区域: {event_data.get('area', '未知')}
- 检测目标: {event_data.get('detections', [])}
- 人数: {event_data.get('people_count', 0)}

请生成：
1. 告警标题
2. 告警级别（high/medium/low）
3. 告警描述
4. 处理建议"""
            
            messages = [
                {"role": "system", "content": "你是一个溺水检测系统的AI告警助手，负责分析事件并生成准确的告警信息。"},
                {"role": "user", "content": prompt}
            ]
            
            response = requests.post(
                self._build_url(),
                headers=self._build_headers(),
                json=self._build_request(messages, 0.5),
                timeout=30
            )
            
            alert = self._parse_response(response)
            
            return {"success": True, "alert": alert}
            
        except Exception as e:
            print(f"[{datetime.now()}] ❌ 生成告警失败: {str(e)}")
            return {"success": False, "error": str(e)}
    
    def ask(self, question: str, context: Dict[str, Any] = {}) -> Dict[str, Any]:
        if not self.api_key:
            return {"success": False, "error": "API key not configured"}
        
        try:
            context_str = ""
            if context:
                context_str = f"\n上下文信息：\n{json.dumps(context, ensure_ascii=False, indent=2)}"
            
            prompt = f"{question}{context_str}"
            
            messages = [
                {"role": "system", "content": "你是一个智能监控系统的AI助手，负责回答用户关于监控系统的问题。"},
                {"role": "user", "content": prompt}
            ]
            
            response = requests.post(
                self._build_url(),
                headers=self._build_headers(),
                json=self._build_request(messages, 0.7),
                timeout=30
            )
            
            answer = self._parse_response(response)
            
            return {"success": True, "answer": answer}
            
        except Exception as e:
            print(f"[{datetime.now()}] ❌ LLM提问失败: {str(e)}")
            return {"success": False, "error": str(e)}

_llm_service = None

def get_llm_service() -> LLMService:
    global _llm_service
    if _llm_service is None:
        _llm_service = LLMService()
    return _llm_service