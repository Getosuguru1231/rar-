"""视频清理服务 - 提供视频文件清理功能"""
import os
import json
import shutil
from datetime import datetime, timedelta
from typing import Dict, Any
from .video_storage_service import get_video_storage_service
from settings import UPLOAD_DIR, RESULTS_DIR

class VideoCleanerService:
    def __init__(self):
        self.video_storage_service = get_video_storage_service()
    
    def cleanup_videos(self, days_to_keep: int = 7) -> Dict[str, Any]:
        """清理旧视频"""
        result = self.video_storage_service.cleanup_old_videos(days_to_keep)
        
        total_deleted = result["videos_deleted"] + result["saved_screenshots_deleted"] + result["task_records_deleted"]
        
        return {
            "success": True,
            "message": f"已删除 {result['videos_deleted']} 个视频、{result['saved_screenshots_deleted']} 个截图、{result['task_records_deleted']} 条任务记录",
            "total_files_deleted": total_deleted,
            "cutoff_days": days_to_keep,
            **result
        }
    
    def cleanup_specific_date(self, date_str: str) -> Dict[str, Any]:
        """清理指定日期的视频"""
        alert_dir = self.video_storage_service.alert_dir
        date_path = os.path.join(alert_dir, date_str)
        
        deleted_count = 0
        
        try:
            if os.path.exists(date_path) and os.path.isdir(date_path):
                files = os.listdir(date_path)
                deleted_count = len(files)
                shutil.rmtree(date_path)
                
                # 清理对应的元数据
                metadata_dir = self.video_storage_service.metadata_dir
                for filename in os.listdir(metadata_dir):
                    if date_str in filename:
                        os.remove(os.path.join(metadata_dir, filename))
                        deleted_count += 1
                
                return {
                    "success": True,
                    "message": f"已清理 {date_str} 的 {deleted_count} 个文件",
                    "date": date_str,
                    "deleted_count": deleted_count
                }
            else:
                return {
                    "success": False,
                    "message": f"目录不存在: {date_path}",
                    "date": date_str
                }
        except Exception as e:
            return {
                "success": False,
                "message": f"清理失败: {str(e)}",
                "date": date_str
            }
    
    def delete_uploaded_video(self, filename: str) -> Dict[str, Any]:
        """删除上传的视频文件"""
        try:
            filepath = os.path.join(UPLOAD_DIR, filename)
            if os.path.exists(filepath):
                os.remove(filepath)
                
                # 检查是否有对应的检测结果目录
                task_dirs = []
                if os.path.exists(RESULTS_DIR):
                    for task_id in os.listdir(RESULTS_DIR):
                        task_path = os.path.join(RESULTS_DIR, task_id)
                        if os.path.isdir(task_path):
                            task_dirs.append(task_path)
                
                deleted_count = 1 + len(task_dirs)
                
                return {
                    "success": True,
                    "message": f"已删除上传视频: {filename}",
                    "deleted_files": deleted_count
                }
            else:
                return {
                    "success": False,
                    "message": f"文件不存在: {filename}",
                    "deleted_files": 0
                }
        except Exception as e:
            return {
                "success": False,
                "message": f"删除失败: {str(e)}",
                "deleted_files": 0
            }
    
    def delete_all_uploaded_videos(self) -> Dict[str, Any]:
        """删除所有上传的视频文件"""
        try:
            deleted_count = 0
            
            # 删除上传目录下的所有文件
            if os.path.exists(UPLOAD_DIR):
                for filename in os.listdir(UPLOAD_DIR):
                    filepath = os.path.join(UPLOAD_DIR, filename)
                    if os.path.isfile(filepath):
                        os.remove(filepath)
                        deleted_count += 1
            
            # 删除检测结果目录下的所有任务目录
            if os.path.exists(RESULTS_DIR):
                for task_id in os.listdir(RESULTS_DIR):
                    task_path = os.path.join(RESULTS_DIR, task_id)
                    if os.path.isdir(task_path):
                        shutil.rmtree(task_path)
                        deleted_count += 1
            
            return {
                "success": True,
                "message": f"已删除 {deleted_count} 个文件/目录",
                "deleted_files": deleted_count
            }
        except Exception as e:
            return {
                "success": False,
                "message": f"删除失败: {str(e)}",
                "deleted_files": 0
            }
    
    def delete_by_folder(self, folder_name: str) -> Dict[str, Any]:
        """按文件夹名称删除视频"""
        result = self.video_storage_service.delete_by_folder(folder_name)
        
        if result["success"]:
            return {
                "success": True,
                "message": f"已删除文件夹: {folder_name}",
                **result
            }
        else:
            return {
                "success": False,
                "message": result.get("error", "删除失败"),
                **result
            }
    
    def list_video_folders(self) -> Dict[str, Any]:
        """列出所有视频文件夹"""
        folders = self.video_storage_service.list_video_folders()
        return {
            "success": True,
            "folders": folders,
            "total_folders": len(folders)
        }

# 创建全局实例
_video_cleaner_service = None

def get_video_cleaner_service() -> VideoCleanerService:
    """获取视频清理服务实例"""
    global _video_cleaner_service
    if _video_cleaner_service is None:
        _video_cleaner_service = VideoCleanerService()
    return _video_cleaner_service