"""服务模块 - 提供核心业务逻辑"""
from .alert_service import AlertService, get_alert_service
from .drowning_alert_service import DrowningAlertService, get_drowning_alert_service
from .llm_service import LLMService, get_llm_service
from .video_storage_service import VideoStorageService, get_video_storage_service
from .video_cleaner_service import VideoCleanerService, get_video_cleaner_service
from .detection_service import DetectionService, get_detection_service
