"""溺水告警服务 - 提供溺水检测和告警功能"""
from datetime import datetime, timedelta
from typing import List, Dict, Any
from .alert_service import get_alert_service
from .video_storage_service import get_video_storage_service

class DrowningAlertService:
    def __init__(self):
        self.alert_service = get_alert_service()
        self.video_storage_service = get_video_storage_service()
        self.alert_cooldown = timedelta(seconds=30)  # 告警冷却时间
        self.last_alert_time = None
        self.alert_count = 0
    
    def check_drowning(self, detections: List[Dict[str, Any]], people_count: int) -> Dict[str, Any]:
        """检查是否存在溺水风险"""
        risk_level = "low"
        risk_details = []
        
        # 分析检测结果
        for det in detections:
            cls_name = det.get("class_name")
            confidence = det.get("confidence", 0)
            
            if cls_name in ['in_water', 'in_water2']:
                if confidence > 0.5:
                    risk_level = "high"
                    risk_details.append(f"检测到水中人员 (置信度: {confidence:.2f})")
                elif confidence > 0.35:
                    risk_level = "medium"
                    risk_details.append(f"检测到水中人员 (置信度: {confidence:.2f})")
            
            if people_count > 3:
                if risk_level == "low":
                    risk_level = "medium"
                    risk_details.append(f"多人聚集: {people_count}人")
        
        return {
            "risk_level": risk_level,
            "details": risk_details,
            "people_count": people_count,
            "detection_count": len(detections)
        }
    
    def trigger_alert(self, risk_level: str, details: Dict[str, Any]) -> Dict[str, Any]:
        """触发溺水告警"""
        # 检查冷却时间
        if self.last_alert_time and (datetime.now() - self.last_alert_time) < self.alert_cooldown:
            return {
                "success": False,
                "message": "告警冷却中",
                "cooldown_remaining": (self.alert_cooldown - (datetime.now() - self.last_alert_time)).seconds
            }
        
        # 创建告警
        alert = self.alert_service.create_alert(
            alert_type="drowning",
            details={
                "risk_level": risk_level,
                "people_count": details.get("people_count", 0),
                "detection_count": details.get("detection_count", 0),
                "risk_details": details.get("details", []),
                "camera_id": details.get("camera_id", "unknown")
            }
        )
        
        self.last_alert_time = datetime.now()
        self.alert_count += 1
        
        return {
            "success": True,
            "alert_id": alert.get("id"),
            "message": "告警已触发"
        }
    
    def get_status(self) -> Dict[str, Any]:
        """获取告警状态"""
        stats = self.alert_service.get_alert_statistics()
        
        return {
            "active_alerts": stats.get("active_alerts", 0),
            "total_alerts_today": stats.get("total_alerts_today", 0),
            "last_alert_time": stats.get("last_alert_time"),
            "alert_count": self.alert_count,
            "cooldown_remaining": 0 if not self.last_alert_time else max(
                0, (self.alert_cooldown - (datetime.now() - self.last_alert_time)).seconds
            )
        }

# 创建全局实例
_drowning_alert_service = None

def get_drowning_alert_service() -> DrowningAlertService:
    """获取溺水告警服务实例"""
    global _drowning_alert_service
    if _drowning_alert_service is None:
        _drowning_alert_service = DrowningAlertService()
    return _drowning_alert_service