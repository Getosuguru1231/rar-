"""检测服务 - 提供YOLO模型推理功能"""
import cv2
import numpy as np
from ultralytics import YOLO
from typing import List, Dict, Any, Tuple
from datetime import datetime
import torch

class DetectionService:
    def __init__(self, model_path: str = "best.pt", imgsz: int = 640, conf_threshold: float = 0.5):
        self.model = None
        self.model_path = model_path
        self.imgsz = imgsz
        self.conf_threshold = conf_threshold
        self.class_names = {0: 'in_water', 1: 'in_water2', 2: 'out_of_water'}
        
    def load_model(self) -> bool:
        """加载YOLO模型"""
        try:
            self.model = YOLO(self.model_path)
            # 更新类别名称为模型自带的名称
            if hasattr(self.model, 'names') and self.model.names:
                self.class_names = self.model.names
            print(f"[{datetime.now()}] ✅ YOLO模型加载成功")
            return True
        except Exception as e:
            print(f"[{datetime.now()}] ❌ YOLO模型加载失败: {str(e)}")
            return False
    
    def detect(self, frame: np.ndarray) -> Tuple[List[Dict[str, Any]], int]:
        """
        执行目标检测
        返回: (检测结果列表, 人数)
        """
        if self.model is None:
            return [], 0
        
        try:
            results = self.model(
                frame,
                conf=self.conf_threshold,
                imgsz=self.imgsz,
                iou=0.5,
                max_det=100,
                verbose=False,
                stream=False
            )
            
            detections = []
            people_count = 0
            
            for result in results:
                for box in result.boxes:
                    cls = int(box.cls[0])
                    conf = float(box.conf[0])
                    xyxy = box.xyxy[0].cpu().numpy()
                    
                    x1, y1, x2, y2 = int(xyxy[0]), int(xyxy[1]), int(xyxy[2]), int(xyxy[3])
                    cls_name = self.class_names.get(cls, f"unknown_{cls}")
                    
                    detections.append({
                        "x1": x1,
                        "y1": y1,
                        "x2": x2,
                        "y2": y2,
                        "confidence": conf,
                        "class": cls,
                        "class_name": cls_name
                    })
                    
                    # 统计人数（只统计水中的人）
                    if cls_name in ['in_water', 'in_water2']:
                        people_count += 1
            
            return detections, people_count
        except Exception as e:
            print(f"[{datetime.now()}] ⚠️ 检测过程出错: {str(e)}")
            return [], 0
    
    def draw_detections(self, frame: np.ndarray, detections: List[Dict[str, Any]]) -> np.ndarray:
        """在帧上绘制检测框"""
        result_frame = frame.copy()
        
        for det in detections:
            x1, y1, x2, y2 = det['x1'], det['y1'], det['x2'], det['y2']
            cls_name = det['class_name']
            confidence = det['confidence']
            
            # 根据类别设置颜色
            if cls_name == 'in_water':
                color = (0, 0, 255)  # 红色 - 水中
            elif cls_name == 'in_water2':
                color = (0, 165, 255)  # 橙色 - 疑似水中
            else:
                color = (0, 255, 0)  # 绿色 - 岸边
            
            # 绘制检测框
            cv2.rectangle(result_frame, (x1, y1), (x2, y2), color, 2)
            
            # 添加标签
            label_text = f"{cls_name}: {confidence:.2f}"
            (text_w, text_h), baseline = cv2.getTextSize(label_text, cv2.FONT_HERSHEY_SIMPLEX, 0.9, 2)
            label_y = y1 if y1 > text_h + 20 else y2 + text_h + 20
            cv2.rectangle(result_frame, (x1-2, label_y-text_h-15), (x1+text_w+18, label_y+baseline+5), (0, 0, 0), -1)
            cv2.putText(result_frame, label_text, (x1+8, label_y), 
                        cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 0), 2)
        
        return result_frame

# 创建全局实例
_detection_service = None

def get_detection_service() -> DetectionService:
    """获取检测服务实例"""
    global _detection_service
    if _detection_service is None:
        _detection_service = DetectionService()
    return _detection_service