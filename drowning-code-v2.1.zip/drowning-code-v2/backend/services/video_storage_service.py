"""视频存储服务 - 提供视频文件管理功能"""
import os
import json
import shutil
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional
from pathlib import Path

class VideoStorageService:
    def __init__(self, video_dir: str = "data/video", alert_dir: str = "data/recorded_videos/alerts"):
        self.video_dir = video_dir
        self.alert_dir = alert_dir
        self.metadata_dir = os.path.join(os.path.dirname(alert_dir), "metadata")
        
        # 确保目录存在
        os.makedirs(video_dir, exist_ok=True)
        os.makedirs(alert_dir, exist_ok=True)
        os.makedirs(self.metadata_dir, exist_ok=True)
    
    def save_video(self, frame: bytes, filename: Optional[str] = None) -> str:
        """保存视频帧到文件"""
        if filename is None:
            filename = f"{datetime.now().strftime('%Y%m%d_%H%M%S')}.mp4"
        
        filepath = os.path.join(self.video_dir, filename)
        
        try:
            with open(filepath, 'wb') as f:
                f.write(frame)
            return filepath
        except Exception as e:
            print(f"[{datetime.now()}] ❌ 保存视频失败: {str(e)}")
            return ""
    
    def save_alert_video(self, video_data: bytes, metadata: Dict[str, Any]) -> str:
        """保存告警视频和元数据"""
        timestamp = datetime.now()
        date_dir = os.path.join(self.alert_dir, timestamp.strftime('%Y%m%d'))
        os.makedirs(date_dir, exist_ok=True)
        
        filename = f"alert_{timestamp.strftime('%Y%m%d_%H%M%S')}.mp4"
        filepath = os.path.join(date_dir, filename)
        
        try:
            # 保存视频
            with open(filepath, 'wb') as f:
                f.write(video_data)
            
            # 保存元数据
            metadata_file = os.path.join(self.metadata_dir, f"{filename}.json")
            metadata['saved_at'] = timestamp.isoformat()
            metadata['file_path'] = filepath
            
            with open(metadata_file, 'w', encoding='utf-8') as f:
                json.dump(metadata, f, ensure_ascii=False, indent=2)
            
            return filepath
        except Exception as e:
            print(f"[{datetime.now()}] ❌ 保存告警视频失败: {str(e)}")
            return ""
    
    def list_videos(self, directory: str = None) -> List[Dict[str, Any]]:
        """列出视频文件"""
        target_dir = directory if directory else self.video_dir
        
        if not os.path.exists(target_dir):
            return []
        
        videos = []
        total_size = 0
        
        for filename in os.listdir(target_dir):
            if filename.lower().endswith(('.mp4', '.avi', '.mov', '.mkv')):
                filepath = os.path.join(target_dir, filename)
                file_size = os.path.getsize(filepath)
                total_size += file_size
                
                try:
                    created_at = datetime.fromtimestamp(os.path.getctime(filepath))
                except:
                    created_at = datetime.now()
                
                videos.append({
                    "filename": filename,
                    "path": filepath,
                    "size": file_size,
                    "created_at": created_at.isoformat()
                })
        
        videos.sort(key=lambda x: x["created_at"], reverse=True)
        
        return {
            "videos": videos,
            "total_count": len(videos),
            "total_size": round(total_size / 1024 / 1024, 2)
        }
    
    def delete_video(self, filename: str) -> bool:
        """删除视频文件"""
        filepath = os.path.join(self.video_dir, filename)
        
        try:
            if os.path.exists(filepath):
                os.remove(filepath)
                # 尝试删除对应的元数据文件
                metadata_file = os.path.join(self.metadata_dir, f"{filename}.json")
                if os.path.exists(metadata_file):
                    os.remove(metadata_file)
                return True
            return False
        except Exception as e:
            print(f"[{datetime.now()}] ❌ 删除视频失败: {str(e)}")
            return False
    
    def cleanup_old_videos(self, days_to_keep: int = 7) -> Dict[str, int]:
        """清理指定天数之前的视频"""
        cutoff_date = datetime.now() - timedelta(days=days_to_keep)
        
        result = {
            "videos_deleted": 0,
            "saved_screenshots_deleted": 0,
            "task_records_deleted": 0
        }
        
        # 清理视频目录
        for filename in os.listdir(self.video_dir):
            if filename.lower().endswith('.mp4'):
                filepath = os.path.join(self.video_dir, filename)
                try:
                    file_time = datetime.fromtimestamp(os.path.getctime(filepath))
                    if file_time < cutoff_date:
                        os.remove(filepath)
                        result["videos_deleted"] += 1
                except Exception:
                    pass
        
        # 清理告警视频目录
        for date_dir in os.listdir(self.alert_dir):
            date_path = os.path.join(self.alert_dir, date_dir)
            if os.path.isdir(date_path):
                try:
                    dir_date = datetime.strptime(date_dir, '%Y%m%d')
                    if dir_date < cutoff_date:
                        shutil.rmtree(date_path)
                        result["saved_screenshots_deleted"] += 1
                except Exception:
                    pass
        
        # 清理元数据目录
        for filename in os.listdir(self.metadata_dir):
            if filename.lower().endswith('.json'):
                filepath = os.path.join(self.metadata_dir, filename)
                try:
                    file_time = datetime.fromtimestamp(os.path.getctime(filepath))
                    if file_time < cutoff_date:
                        os.remove(filepath)
                        result["task_records_deleted"] += 1
                except Exception:
                    pass
        
        return result
    
    def delete_by_folder(self, folder_name: str) -> Dict[str, int]:
        """按文件夹名称删除视频"""
        result = {
            "videos_deleted": 0,
            "directories_deleted": 0,
            "files_deleted": 0,
            "success": False
        }
        
        try:
            # 检查视频目录
            video_folder = os.path.join(self.video_dir, folder_name)
            if os.path.exists(video_folder) and os.path.isdir(video_folder):
                for filename in os.listdir(video_folder):
                    filepath = os.path.join(video_folder, filename)
                    if os.path.isfile(filepath):
                        os.remove(filepath)
                        result["files_deleted"] += 1
                shutil.rmtree(video_folder)
                result["directories_deleted"] += 1
                result["success"] = True
            
            # 检查告警视频目录
            alert_folder = os.path.join(self.alert_dir, folder_name)
            if os.path.exists(alert_folder) and os.path.isdir(alert_folder):
                for filename in os.listdir(alert_folder):
                    filepath = os.path.join(alert_folder, filename)
                    if os.path.isfile(filepath):
                        os.remove(filepath)
                        result["files_deleted"] += 1
                shutil.rmtree(alert_folder)
                result["directories_deleted"] += 1
                result["success"] = True
            
            # 清理对应的元数据
            for filename in os.listdir(self.metadata_dir):
                if folder_name in filename:
                    os.remove(os.path.join(self.metadata_dir, filename))
                    result["files_deleted"] += 1
            
            return result
        except Exception as e:
            print(f"[{datetime.now()}] ❌ 按文件夹删除失败: {str(e)}")
            return {"success": False, "error": str(e), **result}
    
    def list_video_folders(self) -> List[Dict[str, Any]]:
        """列出所有视频文件夹"""
        folders = []
        
        # 列出视频目录下的文件夹
        if os.path.exists(self.video_dir):
            for name in os.listdir(self.video_dir):
                path = os.path.join(self.video_dir, name)
                if os.path.isdir(path):
                    try:
                        files = [f for f in os.listdir(path) if f.lower().endswith('.mp4')]
                        size = sum(os.path.getsize(os.path.join(path, f)) for f in files)
                        folders.append({
                            "name": name,
                            "path": path,
                            "file_count": len(files),
                            "size": size,
                            "type": "video"
                        })
                    except Exception:
                        pass
        
        # 列出告警视频目录下的文件夹
        if os.path.exists(self.alert_dir):
            for name in os.listdir(self.alert_dir):
                path = os.path.join(self.alert_dir, name)
                if os.path.isdir(path):
                    try:
                        files = [f for f in os.listdir(path) if f.lower().endswith('.mp4')]
                        size = sum(os.path.getsize(os.path.join(path, f)) for f in files)
                        folders.append({
                            "name": name,
                            "path": path,
                            "file_count": len(files),
                            "size": size,
                            "type": "alert"
                        })
                    except Exception:
                        pass
        
        folders.sort(key=lambda x: x["name"])
        return folders

# 创建全局实例
_video_storage_service = None

def get_video_storage_service() -> VideoStorageService:
    """获取视频存储服务实例"""
    global _video_storage_service
    if _video_storage_service is None:
        _video_storage_service = VideoStorageService()
    return _video_storage_service