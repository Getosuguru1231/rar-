import cv2
import time
import hashlib

cap = cv2.VideoCapture('dshow://', cv2.CAP_DSHOW)
if not cap.isOpened():
    print('Failed to open with dshow://')
    cap = cv2.VideoCapture(0, cv2.CAP_FFMPEG)

if not cap.isOpened():
    print('Failed to open with FFMPEG')
    exit()

cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)

print('Reading frames...')
hashes = []
for i in range(20):
    ret, frame = cap.read()
    if ret and frame is not None:
        frame_hash = hashlib.md5(frame.tobytes()).hexdigest()
        hashes.append(frame_hash)
        if i % 5 == 0:
            print(f'Frame {i}: shape={frame.shape}, hash={frame_hash[:8]}')
    else:
        print(f'Frame {i}: read failed')
    time.sleep(0.05)

cap.release()

print(f'\nUnique hashes: {len(set(hashes))}/{len(hashes)}')
if len(set(hashes)) == 1:
    print('WARNING: Still getting duplicate frames')
else:
    print('SUCCESS: Frames are updating')