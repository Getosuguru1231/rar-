import cv2

print('OpenCV version:', cv2.__version__)

backends = [
    ('CAP_DSHOW', cv2.CAP_DSHOW),
    ('CAP_MSMF', cv2.CAP_MSMF),
    ('CAP_ANY', cv2.CAP_ANY),
]

for i in range(5):
    print(f'\n=== Testing Camera Index {i} ===')
    for name, backend in backends:
        cap = cv2.VideoCapture(i, backend)
        opened = cap.isOpened()
        print(f'  Backend {name}: opened={opened}')
        
        if opened:
            width = cap.get(cv2.CAP_PROP_FRAME_WIDTH)
            height = cap.get(cv2.CAP_PROP_FRAME_HEIGHT)
            fps = cap.get(cv2.CAP_PROP_FPS)
            print(f'  Resolution: {width}x{height}, FPS: {fps}')
            
            ret, frame = cap.read()
            if ret and frame is not None:
                print(f'  Frame read successful: {frame.shape[1]}x{frame.shape[0]}')
            else:
                print(f'  Frame read failed')
            
            cap.release()
            break
        else:
            cap.release()