import argparse
import uvicorn
import redis
import threading
import cv2
import time
import os
import logging
from datetime import datetime
from contextlib import asynccontextmanager
from dotenv import load_dotenv
load_dotenv()
load_dotenv('.env.llm')
from fastapi import FastAPI, Response, HTTPException, Body
from fastapi.middleware.cors import CORSMiddleware
from detection.detect import start_detection, get_camera_status, get_performance_stats
from components.utils import get_redis_client
from settings import *
from api import api_router
from logging_config import setup_logging, get_logger
from middleware import setup_middleware
from components.camera_health import camera_monitor
from core.exception_handler import register_exception_handlers
from core.async_db import async_db_manager
from core.task_queue import task_queue_manager, TaskPriority

logger = get_logger('main')


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("启动溺水检测系统...")
    
    setup_logging('logs', logging.INFO)
    logger.info("日志系统初始化完成")
    
    await task_queue_manager.start()
    logger.info("任务队列管理器已启动")
    
    camera_monitor.start()
    logger.info("摄像头健康监控已启动")
    
    logger.info("启动检测线程...")
    detection_thread = threading.Thread(target=start_detection, daemon=True)
    detection_thread.start()
    logger.info("检测线程已启动")
    
    await async_db_manager.init_pool()
    logger.info("异步数据库连接池已初始化")
    
    from api.webrtc_signaling import startup as webrtc_startup
    await webrtc_startup()
    
    yield
    
    logger.info("正在关闭系统...")
    await task_queue_manager.stop()
    logger.info("任务队列管理器已停止")
    
    await async_db_manager.close()
    logger.info("异步数据库连接池已关闭")
    
    camera_monitor.stop()
    logger.info("摄像头健康监控已停止")
    
    logger.info("系统关闭完成")


app = FastAPI(title="溺水检测系统API", lifespan=lifespan)

app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

setup_middleware(app)

register_exception_handlers(app)


@app.get("/alert_logs")
async def get_alert_logs(page: int = 1, size: int = 10):
    """获取告警日志列表"""
    try:
        offset = (page - 1) * size
        logs = await async_db_manager.execute(
            "SELECT * FROM alert_log ORDER BY alert_time DESC LIMIT %s OFFSET %s",
            (size, offset)
        )
        return {"code": 200, "data": logs}
    except Exception as e:
        logger.error(f"获取告警日志失败: {str(e)}")
        return {"code": 200, "data": []}


@app.get("/dataset_stats")
async def get_dataset_stats():
    """获取数据集数量统计"""
    try:
        drowning_result = await async_db_manager.execute_one(
            "SELECT COUNT(*) as count FROM dataset WHERE category='drowning'"
        )
        normal_result = await async_db_manager.execute_one(
            "SELECT COUNT(*) as count FROM dataset WHERE category='normal'"
        )
        
        return {
            "code": 200,
            "data": {
                "drowning": drowning_result.get("count", 0) if drowning_result else 0,
                "normal": normal_result.get("count", 0) if normal_result else 0
            }
        }
    except Exception as e:
        logger.error(f"获取数据集统计失败: {str(e)}")
        return {"code": 500, "message": "获取数据集统计失败"}


@app.post("/retrain_model")
async def retrain_model():
    """触发模型重训练（使用队列管理）"""
    def _retrain():
        from ultralytics import YOLO
        
        yaml_path = os.path.join(DATASET_DIR, "dataset.yaml")
        with open(yaml_path, "w") as f:
            f.write(f"""
path: {DATASET_DIR}
train: images/drowning
val: images/drowning
test: images/normal
names:
  0: normal
  1: drowning
nc: 2
            """)
        
        model = YOLO(MODEL_PATH)
        model.train(
            data=yaml_path,
            epochs=50,
            batch=16,
            imgsz=IMGSZ,
            device=0,
            save=True,
            project=os.path.join(BASE_DIR, "backend/models/retrain"),
            name="new_model"
        )
        
        new_model_path = os.path.join(BASE_DIR, "backend/models/retrain/new_model/best.pt")
        if os.path.exists(new_model_path):
            os.replace(new_model_path, MODEL_PATH)
            logger.info("模型重训练完成并更新")
        else:
            logger.error("模型重训练失败，未生成新模型")
    
    try:
        task_id = task_queue_manager.submit(_retrain, priority=TaskPriority.HIGH)
        return {"code": 200, "msg": "模型重训练已加入队列", "task_id": task_id}
    except RuntimeError as e:
        return {"code": 500, "msg": str(e)}


@app.post("/stop_system")
async def stop_system():
    """停止检测系统"""
    try:
        redis_client = get_redis_client(decode_responses=True)
        redis_client.set("stop_detection", "1")
        return {"code": 200, "msg": "系统将停止"}
    except Exception as e:
        logger.error(f"停止系统失败: {str(e)}")
        return {"code": 500, "msg": "停止系统失败"}


@app.get("/system/health")
async def system_health():
    """系统健康检查"""
    try:
        redis_ok = False
        try:
            redis_client = get_redis_client(decode_responses=True)
            redis_client.ping()
            redis_ok = True
        except:
            pass
        
        camera_status = get_camera_status()
        performance_stats = get_performance_stats()
        health_report = camera_monitor.get_status_report()
        queue_stats = await task_queue_manager.get_queue_stats()
        
        return {
            "code": 200,
            "data": {
                "redis": "connected" if redis_ok else "disconnected",
                "camera_status": camera_status,
                "performance": performance_stats,
                "health_report": health_report,
                "queue_stats": queue_stats,
                "timestamp": datetime.now().isoformat()
            }
        }
    except Exception as e:
        logger.error(f"系统健康检查失败: {str(e)}")
        return {"code": 500, "message": "系统健康检查失败"}


@app.get("/camera/{camera_id}/status")
async def camera_status(camera_id: int):
    """获取单个摄像头状态"""
    try:
        status = get_camera_status(camera_id)
        health_report = camera_monitor.get_status_report(camera_id)
        performance = get_performance_stats(camera_id)
        
        return {
            "code": 200,
            "data": {
                "camera_id": camera_id,
                "status": status,
                "health": health_report,
                "performance": performance
            }
        }
    except Exception as e:
        logger.error(f"获取摄像头{camera_id}状态失败: {str(e)}")
        return {"code": 500, "message": f"获取摄像头{camera_id}状态失败"}


@app.get("/performance")
async def get_performance():
    """获取系统性能统计"""
    try:
        performance_stats = get_performance_stats()
        return {"code": 200, "data": performance_stats}
    except Exception as e:
        logger.error(f"获取性能统计失败: {str(e)}")
        return {"code": 500, "message": "获取性能统计失败"}


@app.get("/rate-limit/stats")
async def get_rate_limit_stats():
    """获取限流统计信息"""
    try:
        from components.rate_limiter import rate_limiter
        stats = rate_limiter.get_stats()
        return {"code": 200, "data": stats}
    except Exception as e:
        logger.error(f"获取限流统计失败: {str(e)}")
        return {"code": 500, "message": "获取限流统计失败"}


@app.get("/rate-limit/config")
async def get_rate_limit_config():
    """获取限流配置"""
    try:
        from components.rate_limiter import rate_limiter
        config = {
            "global_rate": rate_limiter.global_bucket.rate,
            "global_capacity": rate_limiter.global_bucket.capacity,
            "ip_rate": 30,
            "ip_capacity": 50,
            "path_rules": {k: {"rate": v.rate, "capacity": v.capacity} for k, v in rate_limiter.path_rules.items()}
        }
        return {"code": 200, "data": config}
    except Exception as e:
        logger.error(f"获取限流配置失败: {str(e)}")
        return {"code": 500, "message": "获取限流配置失败"}


@app.get("/queue/stats")
async def get_queue_stats():
    """获取任务队列统计信息"""
    try:
        stats = await task_queue_manager.get_queue_stats()
        return {"code": 200, "data": stats}
    except Exception as e:
        logger.error(f"获取队列统计失败: {str(e)}")
        return {"code": 500, "message": "获取队列统计失败"}


@app.get("/queue/task/{task_id}")
async def get_task_status(task_id: str):
    """获取单个任务状态"""
    try:
        task = await task_queue_manager.get_task_status(task_id)
        if not task:
            return {"code": 404, "message": "任务不存在"}
        
        return {
            "code": 200,
            "data": {
                "task_id": task.task_id,
                "status": task.status.value,
                "priority": task.priority,
                "created_at": task.created_at,
                "started_at": task.started_at,
                "completed_at": task.completed_at,
                "result": task.result,
                "error": task.error
            }
        }
    except Exception as e:
        logger.error(f"获取任务状态失败: {str(e)}")
        return {"code": 500, "message": "获取任务状态失败"}


@app.post("/queue/task/{task_id}/cancel")
async def cancel_task(task_id: str):
    """取消任务"""
    try:
        success = await task_queue_manager.cancel_task(task_id)
        if success:
            return {"code": 200, "message": "任务已取消"}
        else:
            return {"code": 400, "message": "任务无法取消（可能已在运行或不存在）"}
    except Exception as e:
        logger.error(f"取消任务失败: {str(e)}")
        return {"code": 500, "message": "取消任务失败"}


@app.post("/queue/clear")
async def clear_queue():
    """清空任务队列"""
    try:
        await task_queue_manager.clear_queue()
        return {"code": 200, "message": "队列已清空"}
    except Exception as e:
        logger.error(f"清空队列失败: {str(e)}")
        return {"code": 500, "message": "清空队列失败"}


@app.post("/queue/resize")
async def resize_queue(max_concurrent_tasks: int = Body(..., embed=True)):
    """动态调整队列最大并发数"""
    try:
        if max_concurrent_tasks < 1 or max_concurrent_tasks > 50:
            return {"code": 400, "message": "并发数必须在1-50之间"}
        
        task_queue_manager.resize(max_concurrent_tasks)
        return {"code": 200, "message": f"队列并发数已调整为 {max_concurrent_tasks}"}
    except Exception as e:
        logger.error(f"调整队列并发数失败: {str(e)}")
        return {"code": 500, "message": "调整队列并发数失败"}


@app.post("/queue/group-limit")
async def set_group_limit(group_id: str = Body(..., embed=True), max_concurrent: int = Body(..., embed=True)):
    """设置任务组并发限制"""
    try:
        if max_concurrent < 1:
            return {"code": 400, "message": "并发限制必须大于0"}
        
        task_queue_manager.set_group_limit(group_id, max_concurrent)
        return {"code": 200, "message": f"任务组 {group_id} 并发限制已设置为 {max_concurrent}"}
    except Exception as e:
        logger.error(f"设置任务组限制失败: {str(e)}")
        return {"code": 500, "message": "设置任务组限制失败"}


@app.post("/queue/stats/reset")
async def reset_queue_stats():
    """重置队列统计信息"""
    try:
        await task_queue_manager.reset_stats()
        return {"code": 200, "message": "队列统计已重置"}
    except Exception as e:
        logger.error(f"重置队列统计失败: {str(e)}")
        return {"code": 500, "message": "重置队列统计失败"}


def pre_start_check():
    print("=" * 60)
    print("          智能溺水检测系统 - 后端服务启动")
    print("=" * 60)
    
    print("\n[INFO] 启动前检查...")
    
    try:
        redis_client = get_redis_client(decode_responses=True)
        redis_client.ping()
        print("[OK] Redis连接池创建成功")
    except Exception as e:
        print(f"[WARN] Redis连接失败: {e}")
    
    if os.path.exists(MODEL_PATH):
        print(f"[OK] 检测模型文件存在: {MODEL_PATH}")
    else:
        print(f"[WARN] 检测模型文件不存在: {MODEL_PATH}")
    
    print("\n" + "=" * 60)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="智能溺水检测系统后端服务")
    parser.add_argument("--host", default="0.0.0.0", help="绑定地址")
    parser.add_argument("--port", type=int, default=int(os.getenv("PORT", 8000)), help="服务端口")
    parser.add_argument("--reload", action="store_true", help="开发模式自动重载")
    parser.add_argument("--log-level", default="info", choices=["debug", "info", "warning", "error"], help="日志级别")
    args = parser.parse_args()
    
    pre_start_check()
    
    print(f"\n服务启动信息:")
    print(f"  - 地址: http://{args.host}:{args.port}")
    print(f"  - 文档: http://localhost:{args.port}/docs")
    print(f"  - 重新加载: {'开启' if args.reload else '关闭'}")
    print(f"  - 日志级别: {args.log_level}")
    print("\n" + "=" * 60 + "\n")
    
    uvicorn.run(
        "main:app",
        host=args.host,
        port=args.port,
        reload=args.reload,
        log_level=args.log_level
    )