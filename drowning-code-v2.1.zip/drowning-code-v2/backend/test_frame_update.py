import redis
import time
import hashlib

r = redis.Redis(host='localhost', port=6379, db=0)

print('Checking frame updates over 3 seconds...')
hashes = []
for i in range(30):
    frame_data = r.get('current_frame_1')
    if frame_data:
        frame_hash = hashlib.md5(frame_data).hexdigest()
        hashes.append(frame_hash)
    time.sleep(0.1)

print(f'Total frames checked: {len(hashes)}')
print(f'Unique hashes: {len(set(hashes))}')
if len(set(hashes)) == 1:
    print('WARNING: All frames are identical!')
else:
    print('Frames are updating normally')