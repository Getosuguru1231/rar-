import os

# 基础配置 - BASE_DIR 指向 backend 目录
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
# 向上一级到达项目根目录
PROJECT_DIR = os.path.dirname(BASE_DIR)

DATA_DIR = os.path.join(BASE_DIR, "data")
VIDEO_DIR = os.path.join(DATA_DIR, "video")
DATASET_DIR = os.path.join(DATA_DIR, "dataset")
RESULTS_DIR = os.path.join(DATA_DIR, "results")
SCREENSHOTS_DIR = os.path.join(BASE_DIR, "screenshots")
TEMP_SCREENSHOTS_DIR = os.path.join(SCREENSHOTS_DIR, "temp")
UPLOAD_DIR = os.path.join(BASE_DIR, "uploads")

# 确保目录存在
os.makedirs(VIDEO_DIR, exist_ok=True)
os.makedirs(DATASET_DIR, exist_ok=True)
os.makedirs(SCREENSHOTS_DIR, exist_ok=True)
os.makedirs(TEMP_SCREENSHOTS_DIR, exist_ok=True)
os.makedirs(UPLOAD_DIR, exist_ok=True)

# YOLO模型配置 - 使用项目根目录下的模型文件
MODEL_PATH = os.path.join(PROJECT_DIR, "best.pt")
# 类别名称映射 - 必须与模型输出的类别一致
CLASS_NAMES = {0: 'in_water', 1: 'in_water2', 2: 'out_of_water'}
CONF_THRESHOLD = 0.35  # 统一置信度阈值（降低至0.35，提高检测灵敏度）
ALERT_DELAY = 1
IMGSZ = 640  # 推理尺寸640，YOLO标准尺寸，推理效率最高
VIDEO_QUALITY = 95  # JPEG编码质量(95接近无损，配合OPTIMIZE=0兼顾性能)

# 语音播报配置
VOICE_ENABLED = True  # 是否启用语音播报
VOICE_RATE = -2  # 语音速率 (-10到10，负数变慢，正数变快)
VOICE_VOLUME = 100  # 音量 (0到100)
VOICE_WAIT_INTERVAL = 3  # 语音播报间隔（秒），避免频繁播报

# 帧跳过率配置
FRAME_SKIP_RATE = 2  # 每2帧检测一次，平衡实时性与性能，降低GPU负载

# Redis帧过期时间(秒)
REDIS_FRAME_EXPIRE = 30  # 增加过期时间，确保前端能获取到数据

# 检测参数配置 - 优化稳定性和性能
MIN_CONSECUTIVE_FRAMES = 1  # 降低连续检测要求
MAX_MISS_FRAMES = 3  # 减少最大丢失帧数，更快响应
IOU_THRESHOLD = 0.4  # IOU阈值
MIN_DETECTION_AREA = 50  # 降低最小检测面积，确保小检测框也能显示
MAX_DETECTION_AREA = 307200  # 增大最大检测面积，允许整个画面大小的检测框（640x480=307200）
HIGH_CONFIDENCE_THRESHOLD = 0.75  # 高置信度阈值
TEMPORAL_WINDOW = 10  # 时间窗口大小

# 摄像头配置
VIDEO_SOURCE = 0  # 本地摄像头/RTSP地址

# 摄像头ID映射（前端摄像头ID -> 后端视频源配置）
# 支持多种视频源类型：
# - 整数: 本地摄像头索引
# - "usb:N": USB摄像头，N为设备索引
# - "rtsp://...": RTSP流媒体地址
# - "rdk_x5": RDK X5摄像头
CAMERA_CONFIG = {
    1: {
        "source": "usb:0",
        "name": "主游泳池",
        "area": "主游泳池",
        "width": 640,
        "height": 480,
        "fps": 30,
        "type": "usb",
        "enabled": True
    },
    2: {
        "source": None,
        "name": "内置摄像头",
        "area": "泳池2号区域",
        "width": 640,
        "height": 480,
        "fps": 30,
        "type": "usb",
        "enabled": False
    },
    3: {
        "source": None,
        "name": "RDK X5 Edge摄像头",
        "area": "泳池3号区域",
        "width": 1920,
        "height": 1080,
        "fps": 30,
        "type": "rdk_x5",
        "enabled": False
    },
    4: {
        "source": None,
        "name": "摄像头4",
        "area": "泳池4号区域",
        "width": 1920,
        "height": 1080,
        "fps": 30,
        "type": "local",
        "enabled": False
    }
}

def get_camera_config(camera_id: int) -> dict:
    """
    获取摄像头配置
    
    Args:
        camera_id: 前端摄像头ID (1开始)
    
    Returns:
        dict: 摄像头配置信息
    """
    return CAMERA_CONFIG.get(camera_id, CAMERA_CONFIG[1])

def _find_rdk_x5_camera() -> int:
    """
    自动检测RDK X5 Edge USB摄像头设备
    
    Returns:
        int: RDK X5 Edge摄像头的索引，如果未找到则返回0
    """
    import cv2
    for index in range(0, 10):
        try:
            cap = cv2.VideoCapture(index)
            if cap.isOpened():
                width = cap.get(cv2.CAP_PROP_FRAME_WIDTH)
                height = cap.get(cv2.CAP_PROP_FRAME_HEIGHT)
                ret, frame = cap.read()
                if ret and frame is not None:
                    if (width == 1280 and height == 720) or (width == 640 and height == 480):
                        cap.release()
                        return index
                cap.release()
        except Exception:
            continue
    return 0


def get_local_camera_id(frontend_camera_id: int):
    """
    获取后端摄像头源
    
    Args:
        frontend_camera_id: 前端摄像头ID (1开始)
    
    Returns:
        int or str: 摄像头索引或视频源地址/文件路径
    """
    config = CAMERA_CONFIG.get(frontend_camera_id, CAMERA_CONFIG[1])
    source = config["source"]
    if isinstance(source, int):
        return source
    elif isinstance(source, str):
        if source.startswith("usb:"):
            try:
                return int(source.split(":")[1])
            except (ValueError, IndexError):
                return 0
        elif source.lower() == "rdk_x5":
            return _find_rdk_x5_camera()
        elif source.startswith("http://") or source.startswith("https://") or source.startswith("rtsp://"):
            return source
        else:
            return source
    return 0


def get_camera_source(frontend_camera_id: int) -> str:
    """
    获取摄像头原始source配置（保留前缀）
    
    Args:
        frontend_camera_id: 前端摄像头ID (1开始)
    
    Returns:
        str: 原始source字符串（如 "usb:0", "rtsp://..."）
    """
    config = CAMERA_CONFIG.get(frontend_camera_id, CAMERA_CONFIG[1])
    return config.get("source", None)

# 视频流配置
VIDEO_STREAM_HEARTBEAT_INTERVAL = 30  # 心跳间隔(秒)
VIDEO_STREAM_MAX_SAME_FRAMES = 3  # 最大相同帧数
VIDEO_STREAM_RECOVERY_WAIT = 5  # 恢复等待时间(秒)

# 视频保存配置
VIDEO_SAVE_FPS = 15  # 保存视频的帧率（提高到15fps，更流畅）

# 水域名称
WATER_AREA_NAME = "泳池"

# 语音播报文本
VOICE_TEXT = "有人溺水，请立即处理"

# Redis配置
REDIS_CONFIG = {
    "host": os.getenv("REDIS_HOST", "localhost"),
    "port": int(os.getenv("REDIS_PORT", 6379)),
    "db": int(os.getenv("REDIS_DB", 0)),
    "decode_responses": False
}

# 数据库配置
DB_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "root",
    "database": "drowning_db",
    "port": 3306
}

# MySQL配置 (兼容initdb.py)
MYSQL_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "root",
    "database": "drowning_db",
    "port": 3306
}

# 告警配置
ALERT_CONFIG = {
    "enabled": True,
    "sound_enabled": True,
    "call_enabled": False
}

# Twilio配置（短信告警）
TWILIO_CONFIG = {
    "account_sid": "",
    "auth_token": "",
    "twilio_number": "",
    "to_number": ""
}

# 兼容旧的Twilio变量名
TWILIO_ACCOUNT_SID = TWILIO_CONFIG["account_sid"]
TWILIO_AUTH_TOKEN = TWILIO_CONFIG["auth_token"]
