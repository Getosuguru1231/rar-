import cv2
import numpy as np
import os

video_path = r"D:\图片\溺水监测系统\新2\backend\uploads\test.mp4"

print(f'Testing video file: {video_path}')
print(f'File exists: {os.path.exists(video_path)}')

cap = cv2.VideoCapture(video_path)
if not cap.isOpened():
    print('Failed to open video file')
    exit()

print(f'Frames: {cap.get(cv2.CAP_PROP_FRAME_COUNT)}')
print(f'Width: {cap.get(cv2.CAP_PROP_FRAME_WIDTH)}')
print(f'Height: {cap.get(cv2.CAP_PROP_FRAME_HEIGHT)}')
print(f'FPS: {cap.get(cv2.CAP_PROP_FPS)}')

print('\nReading frames...')
for i in range(10):
    ret, frame = cap.read()
    if ret and frame is not None:
        mean_val = np.mean(frame)
        std_val = np.std(frame)
        print(f'Frame {i}: shape={frame.shape}, mean={mean_val:.2f}, std={std_val:.2f}')
    else:
        print(f'Frame {i}: read failed')

cap.release()
print('Done')