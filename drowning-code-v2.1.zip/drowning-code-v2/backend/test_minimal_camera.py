import cv2
import numpy as np

backends = [
    ('CAP_DSHOW', cv2.CAP_DSHOW),
    ('CAP_MSMF', cv2.CAP_MSMF),
    ('CAP_ANY', cv2.CAP_ANY),
]

for name, backend in backends:
    cap = cv2.VideoCapture(0, backend)
    if not cap.isOpened():
        print(f'{name}: Failed to open')
        continue
    
    print(f'\n{name}: Camera opened')
    
    for i in range(10):
        ret, frame = cap.read()
        if ret and frame is not None:
            mean_val = np.mean(frame)
            std_val = np.std(frame)
            print(f'  Frame {i}: mean={mean_val:.2f}, std={std_val:.2f}')
            if std_val > 10:
                print(f'  SUCCESS: Camera is working with {name}!')
                break
        else:
            print(f'  Frame {i}: read failed')
    
    cap.release()

print('\nDone')