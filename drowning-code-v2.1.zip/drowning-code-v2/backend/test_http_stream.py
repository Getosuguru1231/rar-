import requests
import cv2
import numpy as np
import time

stream_url = 'http://10.64.90.195:8899'

print(f'Trying to access stream: {stream_url}')

try:
    response = requests.get(stream_url, stream=True, timeout=10)
    print(f'Status code: {response.status_code}')
    print(f'Content-Type: {response.headers.get("Content-Type", "N/A")}')
    print(f'Content-Length: {response.headers.get("Content-Length", "N/A")}')
    
    if response.status_code == 200:
        print('Stream is accessible')
        
        bytes_buffer = b''
        frame_count = 0
        for chunk in response.iter_content(chunk_size=1024):
            if chunk:
                bytes_buffer += chunk
                
                if b'\xff\xd8' in bytes_buffer and b'\xff\xd9' in bytes_buffer:
                    jpeg_start = bytes_buffer.find(b'\xff\xd8')
                    jpeg_end = bytes_buffer.find(b'\xff\xd9') + 2
                    
                    jpeg_data = bytes_buffer[jpeg_start:jpeg_end]
                    bytes_buffer = bytes_buffer[jpeg_end:]
                    
                    try:
                        frame = cv2.imdecode(np.frombuffer(jpeg_data, dtype=np.uint8), cv2.IMREAD_COLOR)
                        if frame is not None:
                            frame_count += 1
                            print(f'Frame {frame_count}: shape={frame.shape}, mean={np.mean(frame):.2f}')
                        else:
                            print(f'Frame {frame_count}: decode failed')
                    except Exception as e:
                        print(f'Frame decode error: {e}')
                
                if frame_count >= 5:
                    break
            time.sleep(0.01)
    
except requests.exceptions.Timeout:
    print('Connection timed out - stream is not accessible from this machine')
except requests.exceptions.ConnectionError:
    print('Connection error - could not reach the stream server')
except Exception as e:
    print(f'Error: {e}')