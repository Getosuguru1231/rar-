# backend/db_init.py
import mysql.connector
from settings import MYSQL_CONFIG  # 从配置文件导入数据库连接信息

def init_db():
    try:
        # 1. 连接MySQL（注意：需先手动创建drowning_db数据库，或取消下面注释自动创建）
        # 先连接MySQL服务端（不指定数据库）
        conn = mysql.connector.connect(
            host=MYSQL_CONFIG["host"],
            user=MYSQL_CONFIG["user"],
            password=MYSQL_CONFIG["password"],
            charset=MYSQL_CONFIG["charset"]
        )
        cursor = conn.cursor()
        
        # 自动创建drowning_db数据库（如果不存在）
        cursor.execute("CREATE DATABASE IF NOT EXISTS drowning_db")
        print("数据库drowning_db创建/存在")
        
        # 切换到drowning_db数据库
        conn.database = "drowning_db"

        # 2. 创建告警记录表（alert_log）
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS alert_log (
            id INT AUTO_INCREMENT PRIMARY KEY,
            alert_time DATETIME NOT NULL,
            video_path VARCHAR(255) NOT NULL,
            status VARCHAR(20) DEFAULT 'pending',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        """)
        print("告警记录表alert_log创建/存在")

        # 3. 创建数据集表（dataset）
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS dataset (
            id INT AUTO_INCREMENT PRIMARY KEY,
            img_path VARCHAR(255) NOT NULL,
            label_path VARCHAR(255) NOT NULL,
            category VARCHAR(20) NOT NULL,  # drowning/normal
            create_time DATETIME DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        """)
        print("数据集表dataset创建/存在")

        # 提交并关闭连接
        conn.commit()
        cursor.close()
        conn.close()
        print("✅ 数据库初始化完成！")
    
    except mysql.connector.Error as e:
        print(f"❌ 数据库初始化失败：{e}")
        raise

if __name__ == "__main__":
    # 执行初始化函数
    init_db()