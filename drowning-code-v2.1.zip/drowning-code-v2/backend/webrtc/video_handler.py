import asyncio
import cv2
import numpy as np
from aiortc import VideoStreamTrack
import av
import time
import fractions
from typing import Optional, Tuple
import sys
import os

# 添加项目根目录到路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from settings import get_local_camera_id, CAMERA_CONFIG
from components.utils import letterbox, get_redis_client
from components.frame_buffer import shared_frame_buffer

class VideoFrameHandler:
    def __init__(self, camera_id: int = 0, width: int = 1920, height: int = 1080):
        self.camera_id = camera_id
        self.width = width
        self.height = height
        self.frame = None
        self.lock = asyncio.Lock()
        self._running = False
        self._cap = None
        self._last_frame_time = 0
        self._frame_cache = None
        self._cache_timestamp = 0
        
        self._frames_processed = 0
        self._frames_dropped = 0
        self._last_stats_time = time.time()
        
        self._fps_stats = {
            'frame_count': 0,
            'last_fps_time': time.time(),
            'current_fps': 0
        }
        
        self._redis_client = None
        self._use_redis = True
        self._redis_last_connected = 0
        self._redis_reconnect_attempts = 0
        self._last_redis_reconnect = 0
        
        self._fallback_frame = None
        self._fallback_frame_created = False
        
        self._previous_frame = None
        self._max_mean_diff = 30
        self._consecutive_bad_frames = 0
        self._max_bad_frames = 5
        
        self._init_redis()
    
    def _is_frame_stable(self, frame: np.ndarray) -> bool:
        """检查帧是否稳定"""
        if self._previous_frame is None:
            return True
        
        # 检查尺寸是否一致
        if frame.shape != self._previous_frame.shape:
            return False
        
        # 计算与上一帧的差异（使用加权差异，更稳定）
        diff = cv2.absdiff(frame, self._previous_frame)
        mean_diff = np.mean(diff)
        
        # 使用配置的阈值，减少误判
        if mean_diff > self._max_mean_diff:
            self._consecutive_bad_frames += 1
            # 只在连续多帧不稳定时才标记为不稳定（增加到8帧）
            if self._consecutive_bad_frames >= self._max_bad_frames + 3:
                return False
            # 连续帧数不够，仍认为是稳定的
            return True
        
        self._consecutive_bad_frames = 0
        return True
    
    def _should_use_frame(self, frame: np.ndarray) -> bool:
        """判断是否应该使用当前帧（非常宽松的判断）"""
        if frame is None or frame.size == 0:
            return False
        
        # 只检查基本尺寸
        if frame.shape[0] < 10 or frame.shape[1] < 10:
            return False
        
        # 其他情况都允许通过，避免过度过滤导致闪屏
        return True
    
    def _init_redis(self):
        """初始化Redis连接（使用统一的连接池管理）"""
        try:
            print(f"[WebRTC Video] 尝试连接Redis...")
            
            try:
                self._redis_client = get_redis_client(decode_responses=False)
                self._use_redis = True
                self._redis_last_connected = time.time()
                print(f"[WebRTC Video] Redis连接成功！摄像头{self.camera_id}将从Redis获取视频帧")
                return
            except Exception as redis_err:
                print(f"[WebRTC Video] Redis连接失败: {redis_err}")
                self._redis_client = None
                self._use_redis = False
        except ImportError:
            print(f"[WebRTC Video] redis模块未安装，将使用备用方案")
        
        print(f"[WebRTC Video] 回退到本地摄像头方案...")
        self._init_camera()
    
    def _reconnect_redis(self):
        """尝试重新连接Redis（使用统一的连接池管理）"""
        if self._redis_client is not None:
            try:
                self._redis_client.close()
            except:
                pass
        
        try:
            self._redis_client = get_redis_client(decode_responses=False)
            self._use_redis = True
            self._redis_last_connected = time.time()
            print(f"[WebRTC Video] ✅ Redis重连成功！摄像头{self.camera_id}")
            return True
        except Exception as redis_err:
            print(f"[WebRTC Video] ❌ Redis重连失败: {redis_err}")
            self._redis_client = None
            self._use_redis = False
            return False
    
    def _init_camera(self):
        """初始化本地摄像头作为备用方案 - 已禁用，避免与检测线程冲突"""
        print(f"[WebRTC Video] 摄像头{self.camera_id} 备用摄像头初始化已禁用，使用共享帧缓冲区")
        return False
    
    async def get_frame(self) -> Optional[np.ndarray]:
        async with self.lock:
            try:
                if not self._fallback_frame_created:
                    self._fallback_frame = np.zeros((self.height, self.width, 3), dtype=np.uint8)
                    cv2.putText(self._fallback_frame, f"Camera {self.camera_id} - Video Stream Ready", 
                               (self.width//4, self.height//2), cv2.FONT_HERSHEY_SIMPLEX, 2.0, (100, 200, 255), 4)
                    self._fallback_frame_created = True
                    print(f"[WebRTC Video] 后备帧已创建，尺寸: {self.width}x{self.height}")
                
                current_time = time.time()
                
                frame = shared_frame_buffer.get_frame(self.camera_id)
                if frame is not None and frame.size > 0:
                    self._frames_processed += 1
                    self._last_frame_time = current_time
                    self.frame = frame
                    
                    self._fps_stats['frame_count'] += 1
                    elapsed = current_time - self._fps_stats['last_fps_time']
                    if elapsed >= 30.0:
                        self._fps_stats['current_fps'] = round(self._fps_stats['frame_count'] / elapsed, 2)
                        self._fps_stats['frame_count'] = 0
                        self._fps_stats['last_fps_time'] = current_time
                    
                    return frame
                else:
                    print(f"[WebRTC Video] ⚠️ 摄像头{self.camera_id} 共享缓冲区为空，尝试其他数据源")
                
                if self._use_redis:
                    if self._redis_client:
                        try:
                            redis_key = f"current_frame_{self.camera_id}"
                            frame_data = self._redis_client.get(redis_key)
                            
                            if not frame_data:
                                frame_data = self._redis_client.get("current_frame")
                            
                            if frame_data:
                                frame = np.frombuffer(frame_data, dtype=np.uint8)
                                frame = cv2.imdecode(frame, cv2.IMREAD_COLOR)
                                
                                if frame is not None and frame.size > 0:
                                    self._frames_processed += 1
                                    self._last_frame_time = current_time
                                    self.frame = frame
                                    self._redis_last_connected = current_time
                                    self._redis_reconnect_attempts = 0
                                    
                                    self._fps_stats['frame_count'] += 1
                                    elapsed = current_time - self._fps_stats['last_fps_time']
                                    if elapsed >= 30.0:
                                        self._fps_stats['current_fps'] = round(self._fps_stats['frame_count'] / elapsed, 2)
                                        self._fps_stats['frame_count'] = 0
                                        self._fps_stats['last_fps_time'] = current_time
                                    
                                    return frame
                            else:
                                print(f"[WebRTC Video] ⚠️ 摄像头{self.camera_id} Redis无数据")
                                if current_time - self._last_frame_time > 5:
                                    if current_time - self._last_redis_reconnect > 3:
                                        print(f"[WebRTC Video] 🔄 摄像头{self.camera_id} Redis无数据，尝试重连...")
                                        self._last_redis_reconnect = current_time
                                        self._reconnect_redis()
                        except Exception as e:
                            print(f"[WebRTC Video] Redis读取异常: {type(e).__name__}: {e}")
                            if current_time - self._last_redis_reconnect > 3:
                                self._last_redis_reconnect = current_time
                                self._redis_reconnect_attempts += 1
                                print(f"[WebRTC Video] 🔄 摄像头{self.camera_id} 尝试Redis重连 ({self._redis_reconnect_attempts})...")
                                self._reconnect_redis()
                    else:
                        print(f"[WebRTC Video] ⚠️ 摄像头{self.camera_id} Redis客户端未初始化")
                
                if self._cap and self._cap.isOpened():
                    ret, frame = self._cap.read()
                    if ret and frame is not None:
                        self.frame = frame
                        self._frames_processed += 1
                        print(f"[WebRTC Video] 摄像头{self.camera_id} 从本地摄像头读取帧 | 尺寸: {frame.shape[1]}x{frame.shape[0]}")
                        return frame
                    else:
                        print(f"[WebRTC Video] ⚠️ 摄像头{self.camera_id} 本地摄像头读取失败")
                else:
                    print(f"[WebRTC Video] ⚠️ 摄像头{self.camera_id} 本地摄像头未打开")
                
            except Exception as e:
                print(f"[WebRTC Video] 获取帧异常: {type(e).__name__}: {e}")
        
        print(f"[WebRTC Video] ⚠️ 摄像头{self.camera_id} 所有数据源都失败，返回后备帧")
        return self.frame if self.frame is not None else self._fallback_frame
    
    def get_last_frame_time(self) -> float:
        """获取最后一帧的时间戳"""
        return self._last_frame_time
    
    
    
    async def update_frame(self, frame_data: bytes):
        async with self.lock:
            nparr = np.frombuffer(frame_data, np.uint8)
            self.frame = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
            self._last_frame_time = time.time()
    
    def is_running(self) -> bool:
        return self._running
        
    def set_running(self, running: bool):
        self._running = running
    
    def get_stats(self) -> dict:
        now = time.time()
        elapsed = now - self._last_stats_time
        
        stats = {
            'frames_processed': self._frames_processed,
            'frames_dropped': self._frames_dropped,
            'last_frame_time': self._last_frame_time,
            'frame_rate': self._frames_processed / elapsed if elapsed > 0 else 0
        }
        
        return stats


class WebRTCVideoTrack(VideoStreamTrack):
    def __init__(self, camera_id: int = 1, width: int = 1920, height: int = 1080, fps: int = 30):
        super().__init__()
        self.camera_id = camera_id
        self.width = width
        self.height = height
        self.fps = fps
        self.frame_handler = VideoFrameHandler(camera_id)
        self._last_valid_frame = None
        self._has_valid_frame = False
        
        # 时间戳管理 - 使用单调递增计数器（避免time.time()累积误差）
        self._start_time = time.time()
        self._frame_counter = 0
        self._time_base = fractions.Fraction(1, 90000)
        self._last_pts = 0
        
        # 简单统计
        self._total_frames = 0
        self._skipped_frames = 0
        self._last_stats_time = time.time()
        self._stats_frame_count = 0
        
        # 帧率控制（关键优化）
        self._last_send_time = time.time()
        self._frame_interval = 1.0 / self.fps
        self._target_pts_interval = 90000 // self.fps  # 每帧的PTS增量
        
        # 移除帧队列，直接从共享缓冲区获取最新帧（消除队列延迟）
        
        # 最近帧时间戳
        self._last_frame_timestamp = 0
        
        # 连接稳定性监控
        self._consecutive_empty_frames = 0
        self._max_consecutive_empty = 10
    
    async def recv(self) -> av.VideoFrame:
        self._total_frames += 1
        self._stats_frame_count += 1
        
        current_time = time.time()
        
        if current_time - self._last_stats_time >= 30.0:
            elapsed = current_time - self._last_stats_time
            actual_fps = self._stats_frame_count / elapsed if elapsed > 0 else 0
            self._last_stats_time = current_time
            self._stats_frame_count = 0
        
        frame_data = await self.frame_handler.get_frame()
        
        frame_timestamp = self.frame_handler.get_last_frame_time()
        if frame_timestamp > 0:
            ideal_send_time = frame_timestamp + (self._total_frames - 1) * self._frame_interval
            sleep_time = ideal_send_time - current_time
            if sleep_time > 0 and sleep_time < self._frame_interval * 3:
                await asyncio.sleep(sleep_time)
        
        # 优先使用最后有效帧，确保不出现空白
        use_frame = None
        if frame_data is not None and frame_data.size > 0:
            use_frame = frame_data
            self._consecutive_empty_frames = 0
        else:
            self._consecutive_empty_frames += 1
            
            if self._has_valid_frame and self._last_valid_frame is not None:
                use_frame = self._last_valid_frame
            else:
                return self._get_fallback_frame()
        
        # 更新帧时间戳
        if frame_timestamp > 0:
            self._last_frame_timestamp = frame_timestamp
        
        try:
            # 完善的帧数据验证
            if use_frame is None:
                return self._get_fallback_frame()
            
            if len(use_frame.shape) != 3:
                return self._get_fallback_frame()
            
            height, width, channels = use_frame.shape
            
            if height < 20 or width < 20:
                return self._get_fallback_frame()
            
            if channels != 3:
                if channels == 1:
                    use_frame = cv2.cvtColor(use_frame, cv2.COLOR_GRAY2BGR)
                elif channels == 4:
                    use_frame = cv2.cvtColor(use_frame, cv2.COLOR_BGRA2BGR)
                else:
                    return self._get_fallback_frame()
            
            if use_frame.dtype != np.uint8:
                use_frame = use_frame.astype(np.uint8)
            
            # 必要时进行缩放（使用letterbox策略保持宽高比）
            if height != self.height or width != self.width:
                use_frame = letterbox(use_frame, self.width, self.height)
            
            # 保存有效帧
            if frame_data is not None and frame_data.size > 0:
                self._last_valid_frame = use_frame.copy()
                self._has_valid_frame = True
            
            # 使用单调递增的PTS（避免time.time()累积误差）
            self._frame_counter += 1
            new_pts = self._frame_counter * self._target_pts_interval
            
            if new_pts <= self._last_pts:
                new_pts = self._last_pts + 1
            
            self._last_pts = new_pts
            
            # 创建视频帧（直接从numpy创建，使用bgr24格式）
            video_frame = av.VideoFrame.from_ndarray(use_frame, format="bgr24")
            video_frame.pts = new_pts
            video_frame.time_base = self._time_base
            video_frame.dts = new_pts
            
            return video_frame
            
        except Exception as e:
            print(f"[WebRTC Video] 创建视频帧异常: {type(e).__name__}: {e}")
            return self._get_fallback_frame()
    
    def _get_fallback_frame(self) -> av.VideoFrame:
        """获取后备帧，确保不会返回空帧"""
        # 使用最后一个有效帧
        if self._has_valid_frame and self._last_valid_frame is not None:
            try:
                video_frame = av.VideoFrame.from_ndarray(self._last_valid_frame, format="bgr24")
                video_frame.pts = self._last_pts
                video_frame.time_base = self._time_base
                video_frame.dts = self._last_pts
                return video_frame
            except Exception:
                pass
        
        # 最后保障：创建静态帧
        img = np.full((self.height, self.width, 3), 40, dtype=np.uint8)
        video_frame = av.VideoFrame.from_ndarray(img, format="bgr24")
        video_frame.pts = self._last_pts
        video_frame.time_base = self._time_base
        video_frame.dts = self._last_pts
        return video_frame