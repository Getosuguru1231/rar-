import asyncio
import json
import uuid
import logging
from typing import Dict, Optional
from aiortc import RTCPeerConnection, RTCSessionDescription, VideoStreamTrack, RTCConfiguration, RTCIceServer
from aiortc.contrib.media import MediaBlackhole
from .video_handler import WebRTCVideoTrack
from .config import webrtc_config, get_video_config

logger = logging.getLogger(__name__)


class WebRTCPeer:
    def __init__(self, peer_id: str, camera_id: int, pc: RTCPeerConnection):
        self.peer_id = peer_id
        self.camera_id = camera_id
        self.pc = pc
        self.video_track: Optional[WebRTCVideoTrack] = None
        self.media = MediaBlackhole()
        self._connected = False
        
    async def add_video_track(self):
        logger.info("[WebRTC] 添加视频轨道...")
        video_config = get_video_config()
        self.video_track = WebRTCVideoTrack(
            camera_id=self.camera_id,
            width=video_config['width'],
            height=video_config['height'],
            fps=video_config['fps']
        )
        self.video_track.direction = "sendonly"
        self.pc.addTrack(self.video_track)
        logger.info("[WebRTC] 视频轨道添加成功")
        
    async def start(self):
        self._connected = True
        if self.video_track:
            self.video_track.frame_handler.set_running(True)
            print("[WebRTC] 视频轨道已启动")
            
    async def stop(self):
        self._connected = False
        if self.video_track:
            self.video_track.frame_handler.set_running(False)
        await self.media.stop()
        
    def is_connected(self):
        return self._connected


class PeerManager:
    def __init__(self):
        self.peers: Dict[str, WebRTCPeer] = {}
        self.camera_peers: Dict[int, list] = {}
        self._lock = asyncio.Lock()
        
    async def create_peer(self, camera_id: int, websocket) -> WebRTCPeer:
        peer_id = str(uuid.uuid4())
        
        # 将IceServer配置转换为aiortc所需的格式
        ice_servers = [
            RTCIceServer(
                urls=server.urls,
                username=server.username,
                credential=server.credential
            ) for server in webrtc_config.ice_servers
        ]
        
        config = RTCConfiguration(
            iceServers=ice_servers
        )
        pc = RTCPeerConnection(config)
        
        peer = WebRTCPeer(peer_id, camera_id, pc)
        
        async with self._lock:
            self.peers[peer_id] = peer
            if camera_id not in self.camera_peers:
                self.camera_peers[camera_id] = []
            self.camera_peers[camera_id].append(peer_id)
        
        # ICE连接状态监控
        ice_retry_count = {'count': 0}
        is_reconnecting = {'value': False}
        
        @pc.on("iceconnectionstatechange")
        async def on_ice_connection_state_change():
            state = pc.iceConnectionState
            print(f"[WebRTC] ICE连接状态变化: {state}")
            
            if state in ["connected", "completed"]:
                print("[WebRTC] ✅ ICE连接成功")
                ice_retry_count['count'] = 0
                is_reconnecting['value'] = False
                peer._connected = True
            elif state == "failed":
                ice_retry_count['count'] += 1
                max_retries = 5
                if ice_retry_count['count'] < max_retries:
                    delay = min(2 ** ice_retry_count['count'], 10)
                    print(f"[WebRTC] ❌ ICE连接失败，{delay}秒后尝试重连 ({ice_retry_count['count']}/{max_retries})")
                    await asyncio.sleep(delay)
                    if pc.iceConnectionState == "failed":
                        asyncio.create_task(self._retry_ice_connection(peer))
                else:
                    print("[WebRTC] ❌ ICE连接重试次数已达上限，删除peer")
                    asyncio.create_task(self.remove_peer(peer_id))
            elif state == "disconnected":
                if is_reconnecting['value']:
                    return
                    
                confirm_delay = 5
                print(f"[WebRTC] ⚠️ ICE连接断开，{confirm_delay}秒后确认是否需要重连")
                await asyncio.sleep(confirm_delay)
                if pc.iceConnectionState == "disconnected":
                    print("[WebRTC] ❌ ICE连接确认断开，尝试重连")
                    is_reconnecting['value'] = True
                    asyncio.create_task(self._retry_ice_connection(peer))
            elif state == "closed":
                print("[WebRTC] ICE连接已关闭")
                peer._connected = False
                asyncio.create_task(self.remove_peer(peer_id))
                
        @pc.on("connectionstatechange")
        async def on_connection_state_change():
            print("[WebRTC] 连接状态: " + pc.connectionState)
            
        @pc.on("track")
        async def on_track(track):
            print("[WebRTC] 收到远程轨道: " + track.kind)
            
        return peer
    
    async def _retry_ice_connection(self, peer: 'WebRTCPeer'):
        """重试ICE连接"""
        try:
            print("[WebRTC] 尝试重新创建ICE连接...")
            if peer.pc and peer.pc.connectionState != 'closed':
                try:
                    ice_gathering_state = peer.pc.iceGatheringState
                    print(f"[WebRTC] 当前ICE收集状态: {ice_gathering_state}")
                    
                    if ice_gathering_state != 'gathering':
                        offer = await peer.pc.createOffer({
                            'offerToReceiveVideo': True,
                            'offerToReceiveAudio': False
                        })
                        await peer.pc.setLocalDescription(offer)
                        print("[WebRTC] ✅ 已重新创建ICE连接")
                    else:
                        print("[WebRTC] ⚠️ 正在收集ICE候选，等待完成后重试")
                except Exception as ice_err:
                    print(f"[WebRTC] ❌ 重新创建ICE失败: {ice_err}")
                    import traceback
                    traceback.print_exc()
            else:
                print("[WebRTC] ⚠️ PeerConnection已关闭，无法重试")
        except Exception as e:
            print(f"[WebRTC] ❌ 重试ICE连接失败: {e}")
            import traceback
            traceback.print_exc()
        
    async def handle_offer(self, peer_id: str, sdp: str, sdp_semantics: str = "unified-plan") -> Optional[str]:
        peer = self.peers.get(peer_id)
        if not peer:
            print("[WebRTC] 错误: 未找到peer " + peer_id)
            return None
            
        try:
            print("[WebRTC] === 处理Offer开始 ===")
            print("[WebRTC] SDP长度: " + str(len(sdp)))
            print("[WebRTC] SDP语义: " + sdp_semantics)
            
            # 1. 先添加视频轨道
            print("[WebRTC] 添加视频轨道...")
            await peer.add_video_track()
            print("[WebRTC] 视频轨道添加成功")
            
            # 2. 设置远程描述
            print("[WebRTC] 设置远程描述...")
            await peer.pc.setRemoteDescription(RTCSessionDescription(sdp=sdp, type="offer"))
            print("[WebRTC] 远程描述设置成功")
            
            # 3. 创建Answer，优化视频编码参数
            print("[WebRTC] 创建Answer...")
            answer = await peer.pc.createAnswer()
            print("[WebRTC] Answer创建成功")
            
            # 4. 优化SDP - 提高视频质量和带宽
            modified_sdp = self._optimize_sdp(answer.sdp)
            answer.sdp = modified_sdp
            
            # 5. 设置本地描述
            print("[WebRTC] 设置本地描述...")
            await peer.pc.setLocalDescription(answer)
            print("[WebRTC] 本地描述设置成功")
            
            # 6. 启动视频轨道
            await peer.start()
            
            answer_sdp = peer.pc.localDescription.sdp
            print("[WebRTC] === 处理Offer完成，Answer长度: " + str(len(answer_sdp)) + " ===")
            return answer_sdp
            
        except Exception as e:
            print("[WebRTC] 创建answer失败: " + type(e).__name__ + ": " + str(e))
            import traceback
            traceback.print_exc()
            # 打印详细的错误信息
            print("[WebRTC] 错误详情:")
            print(f"  - peer_id: {peer_id}")
            print(f"  - peer对象: {peer}")
            print(f"  - peer.pc: {peer.pc if peer else 'None'}")
            if peer and peer.pc:
                print(f"  - pc.signalingState: {peer.pc.signalingState}")
                print(f"  - pc.connectionState: {peer.pc.connectionState}")
            return None
    
    def _optimize_sdp(self, sdp: str) -> str:
        """优化SDP以提高帧率、清晰度和降低延迟（关键优化）"""
        lines = sdp.split('\r\n')
        result = []
        
        # 使用配置的帧率
        video_config = get_video_config()
        target_fps = video_config.get('fps', 30)
        max_bitrate = video_config.get('max_bitrate', 4000000)
        min_bitrate = video_config.get('min_bitrate', 800000)
        
        # 优先使用H264（如果支持），禁用VP9以降低复杂度
        use_h264 = False
        use_vp8 = False
        h264_payload_type = None
        vp8_payload_type = None
        
        for line in lines:
            if line.startswith('a=rtpmap:'):
                # 检测可用的编解码器并记录payload type
                if 'H264/' in line:
                    use_h264 = True
                    h264_payload_type = line.split(':')[1].split(' ')[0]
                elif 'VP8/' in line:
                    use_vp8 = True
                    vp8_payload_type = line.split(':')[1].split(' ')[0]
                # 跳过VP9以降低编码复杂度
                elif 'VP9/' in line:
                    continue
            result.append(line)
        
        # 在m=video行后添加优化参数
        video_line_index = -1
        for i, line in enumerate(result):
            if line.startswith('m=video'):
                video_line_index = i
                break
        
        if video_line_index >= 0:
            # 删除可能存在的旧带宽设置
            result = [line for line in result if not line.startswith('b=AS:')]
            result = [line for line in result if not line.startswith('b=TIAS:')]
            result = [line for line in result if not line.startswith('b=RR:')]
            
            # 在m=video行后插入带宽和编码优化参数
            max_bitrate_kbps = max_bitrate // 1000
            min_bitrate_kbps = min_bitrate // 1000
            
            # 设置带宽限制
            result.insert(video_line_index + 1, f'b=AS:{max_bitrate_kbps}')
            result.insert(video_line_index + 2, f'b=TIAS:{max_bitrate}')
            
            # 添加RTCP反馈参数（低延迟关键）
            result.insert(video_line_index + 3, 'a=rtcp-fb:* nack')
            result.insert(video_line_index + 4, 'a=rtcp-fb:* nack pli')
            result.insert(video_line_index + 5, 'a=rtcp-fb:* transport-cc')
            
            # 添加低延迟参数
            result.insert(video_line_index + 6, 'a=framerate:' + str(target_fps))
            result.insert(video_line_index + 7, 'a=sendonly')
            
            # 添加视频优化参数 - 更新所有fmtp行
            for i, line in enumerate(result):
                if 'fmtp:' in line and ('H264' in line or 'VP8' in line):
                    old_line = line
                    
                    if 'H264' in old_line:
                        # 优化H264参数 - 低延迟编码（关键优化）
                        if 'profile-level-id' not in old_line:
                            old_line += ';profile-level-id=42e01f'
                        if 'max-fps' not in old_line:
                            old_line += f';max-fps={target_fps}'
                        if 'packetization-mode' not in old_line:
                            old_line += ';packetization-mode=1'
                        if 'min-fps' not in old_line:
                            old_line += ';min-fps=5'
                        if 'level-asymmetry-allowed' not in old_line:
                            old_line += ';level-asymmetry-allowed=1'
                        if 'x-google-start-bitrate' not in old_line:
                            old_line += f';x-google-start-bitrate={max_bitrate_kbps}'
                        if 'x-google-max-bitrate' not in old_line:
                            old_line += f';x-google-max-bitrate={max_bitrate_kbps}'
                        if 'x-google-min-bitrate' not in old_line:
                            old_line += f';x-google-min-bitrate={min_bitrate_kbps}'
                        if 'max-reorder-delay' not in old_line:
                            old_line += ';max-reorder-delay=0'
                        if 'use-level-asymmetry' not in old_line:
                            old_line += ';use-level-asymmetry=1'
                        if 'temporal-layers' not in old_line:
                            old_line += ';temporal-layers=1'
                        if 'temporal-layer-id' not in old_line:
                            old_line += ';temporal-layer-id=0'
                        if 'stereo' not in old_line:
                            old_line += ';stereo=0'
                        # 低延迟关键参数
                        if 'x-google-flag' not in old_line:
                            old_line += ';x-google-flag=conference'
                        if 'x-google-min-qp' not in old_line:
                            old_line += ';x-google-min-qp=0'
                            
                    elif 'VP8' in old_line:
                        # 优化VP8参数
                        if 'max-fps' not in old_line:
                            old_line += f';max-fps={target_fps}'
                        if 'min-fps' not in old_line:
                            old_line += ';min-fps=5'
                            
                    result[i] = old_line
        
        return '\r\n'.join(result)
            
    async def add_ice_candidate(self, peer_id: str, candidate: dict):
        peer = self.peers.get(peer_id)
        if not peer:
            return
            
        try:
            from aiortc.rtcicetransport import candidate_from_aioice
            from aioice import Candidate
            if candidate.get("candidate"):
                aioice_candidate = Candidate.from_sdp(candidate.get("candidate", ""))
                ice_candidate = candidate_from_aioice(aioice_candidate)
                ice_candidate.sdpMid = candidate.get("sdpMid", "")
                ice_candidate.sdpMLineIndex = candidate.get("sdpMLineIndex", 0)
                await peer.pc.addIceCandidate(ice_candidate)
                print(f"[WebRTC] ICE候选添加成功: {candidate.get('candidate', '')[:50]}...")
        except Exception as e:
            print(f"[WebRTC] 添加ICE候选失败: {type(e).__name__}: {e}")
            
    async def remove_peer(self, peer_id: str):
        async with self._lock:
            peer = self.peers.pop(peer_id, None)
            if peer:
                camera_id = peer.camera_id
                if camera_id in self.camera_peers:
                    try:
                        self.camera_peers[camera_id].remove(peer_id)
                    except ValueError:
                        pass
                await peer.stop()
                try:
                    await peer.pc.close()
                except Exception:
                    pass
                    
    async def remove_peer_by_camera(self, camera_id: int):
        async with self._lock:
            peer_ids = self.camera_peers.get(camera_id, []).copy()
            for peer_id in peer_ids:
                await self.remove_peer(peer_id)
                
    def get_peer_count(self) -> int:
        return len(self.peers)
        
    def get_camera_peer_count(self, camera_id: int) -> int:
        return len(self.camera_peers.get(camera_id, []))


peer_manager = PeerManager()