"""WebRTC模块

提供WebRTC视频流服务所需的核心组件：
- PeerManager: 管理WebRTC对等连接
- VideoFrameHandler: 视频帧处理
- WebRTCVideoTrack: 视频轨道
- SignalingHandler: 信令处理
- WebRTC配置管理
"""

from .peer_manager import PeerManager, peer_manager
from .video_handler import VideoFrameHandler, WebRTCVideoTrack
from .config import webrtc_config, get_ice_servers, get_video_config, get_connection_timeout, get_reconnect_config

# 注意：SignalingHandler 和 signaling_handler 在 routes/webrtc_signaling.py 中定义并使用

__all__ = [
    'PeerManager',
    'peer_manager',
    'VideoFrameHandler',
    'WebRTCVideoTrack',
    'webrtc_config',
    'get_ice_servers',
    'get_video_config',
    'get_connection_timeout',
    'get_reconnect_config',
]