"""WebRTC配置模块

包含WebRTC连接所需的所有配置参数，包括STUN/TURN服务器、编解码器设置、带宽限制等。
"""

import os
from typing import List, Dict, Optional
from dataclasses import dataclass, field


@dataclass
class IceServer:
    """ICE服务器配置"""
    urls: str
    username: Optional[str] = None
    credential: Optional[str] = None
    credential_type: str = 'password'
    
    def to_dict(self) -> Dict[str, str]:
        result = {'urls': self.urls}
        if self.username:
            result['username'] = self.username
        if self.credential:
            result['credential'] = self.credential
        if self.credential_type:
            result['credentialType'] = self.credential_type
        return result


@dataclass
class WebRTCConfig:
    """WebRTC全局配置"""
    
    # ICE服务器配置
    ice_servers: List[IceServer] = field(default_factory=list)
    
    # 连接配置
    ice_candidate_pool_size: int = 10
    ice_transport_policy: str = 'all'  # 'all', 'relay', 'host'
    
    # 媒体配置 - 低延迟优化
    video_codec: str = 'H264'  # 使用H264替代VP8，更好的硬件支持和更低延迟
    audio_codec: str = 'opus'
    max_video_bitrate: int = 5000000  # 5 Mbps - 适合1280x720分辨率
    min_video_bitrate: int = 800000   # 800 kbps
    max_audio_bitrate: int = 96000    # 96 kbps - 稍低音频码率
    
    # 视频分辨率配置 - 与摄像头配置保持一致（主摄像头1280x720）
    default_width: int = 1280
    default_height: int = 720
    default_fps: int = 30
    min_fps: int = 5
    max_fps: int = 30
    
    # 低延迟编码配置
    encoding_preset: str = 'ultrafast'  # 最快编码速度
    encoding_tune: str = 'zerolatency'  # 零延迟编码
    
    # 连接超时配置（毫秒）
    connection_timeout: int = 30000
    ice_gathering_timeout: int = 15000
    
    # 重连配置
    max_reconnect_attempts: int = 5
    reconnect_delay_base: int = 1000  # 基础重连延迟（毫秒）
    reconnect_delay_max: int = 30000   # 最大重连延迟（毫秒）
    
    # 性能配置
    enable_nack: bool = True
    enable_pli: bool = True
    enable_remb: bool = True
    
    @classmethod
    def from_env(cls) -> 'WebRTCConfig':
        """从环境变量加载配置"""
        config = cls()
        
        # 从环境变量读取STUN服务器
        stun_servers = os.environ.get('WEBRTC_STUN_SERVERS', '')
        if stun_servers:
            for url in stun_servers.split(','):
                url = url.strip()
                if url:
                    config.ice_servers.append(IceServer(urls=url))
        else:
            config.ice_servers.extend([
                IceServer(urls='stun:stun.l.google.com:19302'),
                IceServer(urls='stun:stun1.l.google.com:19302'),
                IceServer(urls='stun:stun2.l.google.com:19302'),
                IceServer(urls='stun:stun3.l.google.com:19302'),
                IceServer(urls='stun:stun4.l.google.com:19302'),
            ])
            
            config.ice_servers.extend([
                IceServer(urls='turn:turn.openrelay.metered.ca:80', username='openrelayproject', credential='openrelayproject'),
                IceServer(urls='turn:turn.openrelay.metered.ca:443', username='openrelayproject', credential='openrelayproject'),
            ])
        
        # 从环境变量读取TURN服务器
        turn_url = os.environ.get('WEBRTC_TURN_URL')
        if turn_url:
            turn_username = os.environ.get('WEBRTC_TURN_USERNAME')
            turn_credential = os.environ.get('WEBRTC_TURN_CREDENTIAL')
            config.ice_servers.append(IceServer(
                urls=turn_url,
                username=turn_username,
                credential=turn_credential
            ))
        
        # 视频配置
        if os.environ.get('WEBRTC_VIDEO_WIDTH'):
            config.default_width = int(os.environ['WEBRTC_VIDEO_WIDTH'])
        if os.environ.get('WEBRTC_VIDEO_HEIGHT'):
            config.default_height = int(os.environ['WEBRTC_VIDEO_HEIGHT'])
        if os.environ.get('WEBRTC_VIDEO_FPS'):
            config.default_fps = int(os.environ['WEBRTC_VIDEO_FPS'])
        
        # 比特率配置
        if os.environ.get('WEBRTC_MAX_VIDEO_BITRATE'):
            config.max_video_bitrate = int(os.environ['WEBRTC_MAX_VIDEO_BITRATE'])
        if os.environ.get('WEBRTC_MIN_VIDEO_BITRATE'):
            config.min_video_bitrate = int(os.environ['WEBRTC_MIN_VIDEO_BITRATE'])
        
        # 超时配置
        if os.environ.get('WEBRTC_CONNECTION_TIMEOUT'):
            config.connection_timeout = int(os.environ['WEBRTC_CONNECTION_TIMEOUT'])
        
        return config


# 创建全局配置实例
webrtc_config = WebRTCConfig.from_env()


def get_ice_servers() -> List[IceServer]:
    """获取ICE服务器列表"""
    return webrtc_config.ice_servers


def get_connection_timeout() -> int:
    """获取连接超时时间（毫秒）"""
    return webrtc_config.connection_timeout


def get_video_config() -> Dict[str, int]:
    """获取视频配置"""
    return {
        'width': webrtc_config.default_width,
        'height': webrtc_config.default_height,
        'fps': webrtc_config.default_fps,
        'min_fps': webrtc_config.min_fps,
        'max_fps': webrtc_config.max_fps,
        'max_bitrate': webrtc_config.max_video_bitrate,
        'min_bitrate': webrtc_config.min_video_bitrate,
    }


def get_reconnect_config() -> Dict[str, int]:
    """获取重连配置"""
    return {
        'max_attempts': webrtc_config.max_reconnect_attempts,
        'delay_base': webrtc_config.reconnect_delay_base,
        'delay_max': webrtc_config.reconnect_delay_max,
    }