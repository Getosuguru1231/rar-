import zipfile, os, fnmatch

src = 'D:/download/新2/新2'
dst = 'D:/繁文缛节/繁文缛节/yulin-drowning-code-v2.zip'

if os.path.exists(dst):
    os.remove(dst)

skip_dir_names = {
    'node_modules', 'venv', 'yolo_env', '__pycache__', '.git', 'logs',
    'screenshots', 'uploads', 'detection_results', 'recorded_videos',
    'models_dir', 'dist', 'edge', 'static', 'extra_modules', 'temp', 'tmp'
}
skip_file_patterns = [
    '*.pyc', '*.bin', '*.pth', 'ffmpeg.zip', 'best.pt',
    'yolov8n.pt', 'test_frame.jpg', 'pack.sh', '*~', '*.bak',
    'package-lock.json', 'Pipfile*'
]

def should_skip(rel):
    sep = os.sep
    parts = rel.split(sep)
    for p in parts:
        if p in skip_dir_names:
            return True
    fn = os.path.basename(rel)
    for pat in skip_file_patterns:
        if fnmatch.fnmatch(fn, pat):
            return True
    if sep.join(['data', 'results']) in rel:
        return True
    if sep.join(['data', 'video']) in rel:
        return True
    if sep.join(['data', 'screenshots']) in rel:
        return True
    return False

count = 0
with zipfile.ZipFile(dst, 'w', zipfile.ZIP_DEFLATED) as zf:
    for root, dirs, files in os.walk(src):
        dirs[:] = [d for d in dirs if d not in skip_dir_names]
        for fn in files:
            fp = os.path.join(root, fn)
            rel = os.path.relpath(fp, src)
            if should_skip(rel):
                continue
            zf.write(fp, rel)
            count += 1
            if count % 500 == 0:
                print(f'  {count} files...', flush=True)

mb = os.path.getsize(dst) / (1024 * 1024)
print(f'Files: {count}  Size: {mb:.1f}MB')
if mb <= 100:
    print('OK: Ready for GitHub / Nodehub')
else:
    print(f'WARN: {mb:.0f}MB > 100MB limit')
