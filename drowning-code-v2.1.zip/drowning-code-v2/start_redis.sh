#!/bin/bash
set -e

echo "================================================"
echo "           智能溺水检测系统 - Redis启动脚本"
echo "================================================"
echo ""

REDIS_PORT="6379"

echo "[检查Redis安装]"
if ! command -v redis-server &> /dev/null; then
    echo "[WARNING] 未找到redis-server"
    echo "请确保Redis已安装: sudo apt install redis-server (Debian/Ubuntu)"
    echo "或使用Docker启动Redis: docker-compose up -d redis"
    exit 1
fi

echo ""
echo "[启动Redis服务]"
echo "Redis端口: $REDIS_PORT"
echo ""
redis-server --port $REDIS_PORT