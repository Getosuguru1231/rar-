import subprocess
import os
import sys

frontend_dir = os.path.join(os.path.dirname(__file__), 'frontend')
os.chdir(frontend_dir)

vite_path = os.path.join(frontend_dir, 'node_modules', '.bin', 'vite')

with open('vite_start.log', 'w', encoding='utf-8') as log_file:
    log_file.write(f"=== 启动前端服务 ===\n")
    log_file.write(f"工作目录: {os.getcwd()}\n")
    log_file.write(f"vite路径: {vite_path}\n")
    log_file.write(f"vite存在: {os.path.exists(vite_path)}\n")
    log_file.flush()
    
    try:
        process = subprocess.Popen(
            [vite_path, '--host', '0.0.0.0', '--port', '3000'],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding='utf-8',
            errors='replace'
        )
        
        log_file.write("进程已启动\n")
        log_file.flush()
        
        for line in iter(process.stdout.readline, ''):
            log_file.write(line)
            log_file.flush()
            
    except Exception as e:
        log_file.write(f"启动失败: {str(e)}\n")
        log_file.flush()
        raise
