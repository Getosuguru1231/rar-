import os
import sys

# 直接写入环境信息
with open('env_result.txt', 'w', encoding='utf-8') as f:
    f.write("=== 环境信息 ===\n")
    f.write(f"Python版本: {sys.version}\n")
    f.write(f"当前目录: {os.getcwd()}\n")
    f.write(f"操作系统: {sys.platform}\n")
    
    # 检查前端目录
    frontend_dir = os.path.join(os.getcwd(), 'frontend')
    f.write(f"\n=== 前端项目 ===\n")
    f.write(f"前端目录: {frontend_dir}\n")
    f.write(f"目录存在: {os.path.exists(frontend_dir)}\n")
    
    if os.path.exists(frontend_dir):
        package_json = os.path.join(frontend_dir, 'package.json')
        f.write(f"package.json存在: {os.path.exists(package_json)}\n")
        
        node_modules = os.path.join(frontend_dir, 'node_modules')
        f.write(f"node_modules存在: {os.path.exists(node_modules)}\n")
        
        vite_bin = os.path.join(frontend_dir, 'node_modules', '.bin', 'vite')
        f.write(f"vite二进制存在: {os.path.exists(vite_bin)}\n")
        
        dist_dir = os.path.join(frontend_dir, 'dist')
        f.write(f"dist目录存在: {os.path.exists(dist_dir)}\n")

f.close()
print("Done")
