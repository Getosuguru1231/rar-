import torch
import torch.nn as nn
import torch.nn.functional as F

from ultralytics.nn.modules.conv import Conv, RepConv
from ultralytics.nn.modules.block import Bottleneck, C2f, C3k2 as C3K2, SPPF
from ultralytics.nn.modules.transformer import AIFI

def autopad(k, p=None, d=1):
    if d > 1:
        k = d * (k - 1) + 1 if isinstance(k, int) else [d * (x - 1) + 1 for x in k]
    if p is None:
        p = k // 2 if isinstance(k, int) else [x // 2 for x in k]
    return p


class DynamicConv(nn.Module):
    def __init__(self, c1, c2, k=3, s=1, p=None, g=1, act=True):
        super().__init__()
        self.c1 = c1
        self.c2 = c2
        self.conv = nn.Conv2d(c1, c2, k, s, autopad(k, p), groups=g, bias=False)
        self.bn = nn.BatchNorm2d(c2)
        self.act = nn.SiLU() if act is True else (act if isinstance(act, nn.Module) else nn.Identity())

    def forward(self, x):
        return self.act(self.bn(self.conv(x)))


class TripletAtt(nn.Module):
    def __init__(self, c1, c2=None, *args, **kwargs):
        super().__init__()
        self.c1 = c1
        self.c2 = c2 if c2 is not None else c1
        self.conv = nn.Conv2d(3, 1, 7, 1, 3, bias=False)

    def forward(self, x):
        mean = torch.mean(x, dim=1, keepdim=True)
        max_val = torch.max(x, dim=1, keepdim=True)[0]

        if x.shape[1] > 1:
            std = torch.std(x, dim=1, keepdim=True, correction=0)
        else:
            std = torch.zeros_like(mean)

        att = torch.cat([mean, max_val, std], 1)
        att = self.conv(att)
        return x * torch.sigmoid(att)


class ChannelAttention(nn.Module):
    def __init__(self, c1, c2=None, reduction=8):
        super().__init__()
        self.c1 = c1
        self.c2 = c2 if c2 is not None else c1
        self.reduction = reduction
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.max_pool = nn.AdaptiveMaxPool2d(1)
        mid_channels = max(c1 // reduction, 1)
        self.fc = nn.Sequential(
            nn.Conv2d(c1, mid_channels, 1, bias=False),
            nn.SiLU(),
            nn.Conv2d(mid_channels, c1, 1, bias=False)
        )

    def forward(self, x):
        avg_out = self.fc(self.avg_pool(x))
        max_out = self.fc(self.max_pool(x))
        return x * torch.sigmoid(avg_out + max_out)


class SE(nn.Module):
    def __init__(self, c1, c2=None, reduction=8):
        super().__init__()
        self.c1 = c1
        self.c2 = c2 if c2 is not None else c1
        self.reduction = reduction
        self.squeeze = nn.AdaptiveAvgPool2d(1)
        mid_channels = max(c1 // reduction, 1)
        self.excitation = nn.Sequential(
            nn.Conv2d(c1, mid_channels, 1, bias=False),
            nn.SiLU(),
            nn.Conv2d(mid_channels, c1, 1, bias=False),
            nn.Sigmoid()
        )

    def forward(self, x):
        return x * self.excitation(self.squeeze(x))


class SpatialAttention(nn.Module):
    def __init__(self, c1, c2=None, kernel_size=7):
        super().__init__()
        self.c1 = c1
        self.c2 = c2 if c2 is not None else c1
        self.kernel_size = kernel_size
        padding = kernel_size // 2
        self.conv = nn.Conv2d(2, 1, kernel_size, padding=padding, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avg_out = torch.mean(x, dim=1, keepdim=True)
        max_out, _ = torch.max(x, dim=1, keepdim=True)
        att = torch.cat([avg_out, max_out], dim=1)
        att = self.conv(att)
        return x * self.sigmoid(att)


class CBAM(nn.Module):
    def __init__(self, c1, c2=None, reduction=8, kernel_size=7):
        super().__init__()
        self.c1 = c1
        self.c2 = c2 if c2 is not None else c1
        self.channel_attn = ChannelAttention(c1, c1, reduction)
        self.spatial_attn = SpatialAttention(c1, c1, kernel_size)

    def forward(self, x):
        x = self.channel_attn(x)
        x = self.spatial_attn(x)
        return x


class SimAM(nn.Module):
    def __init__(self, c1, c2=None, lambda_=1e-4):
        super().__init__()
        self.c1 = c1
        self.c2 = c2 if c2 is not None else c1
        self.lambda_ = lambda_

    def forward(self, x):
        b, c, h, w = x.shape
        n = h * w - 1
        x_minus_mu_squared = (x - x.mean(dim=[2, 3], keepdim=True)) ** 2
        y = x_minus_mu_squared / (4 * (x_minus_mu_squared.sum(dim=[2, 3], keepdim=True) / n + self.lambda_)) + 0.5
        return x * y


class EMA(nn.Module):
    def __init__(self, c1, c2=None, num_levels=4):
        super().__init__()
        self.c1 = c1
        self.c2 = c2 if c2 is not None else c1
        self.num_levels = num_levels
        self.convs = nn.ModuleList()
        for _ in range(num_levels):
            self.convs.append(nn.Sequential(
                nn.Conv2d(c1, c1, 3, padding=1, groups=c1, bias=False),
                nn.Conv2d(c1, c1, 1, bias=False),
                nn.Sigmoid()
            ))

    def forward(self, x):
        out = x
        for conv in self.convs:
            out = out * conv(out) + out
        return out


class ReflectionReduction(nn.Module):
    def __init__(self, c1, c2=None, reduction_ratio=0.5):
        super().__init__()
        self.c1 = c1
        self.c2 = c2 if c2 is not None else c1
        reduced_dim = int(c1 * reduction_ratio)
        self.conv_down = Conv(c1, reduced_dim, 1, 1)
        self.conv_up = Conv(reduced_dim, self.c2, 1, 1)
        self.attention = SpatialAttention(reduced_dim, reduced_dim)

    def forward(self, x):
        residual = x
        x = self.conv_down(x)
        x = self.attention(x)
        x = self.conv_up(x)
        return x + residual


class ShadowReduction(nn.Module):
    def __init__(self, c1, c2=None, kernel_size=3):
        super().__init__()
        self.c1 = c1
        self.c2 = c2 if c2 is not None else c1
        padding = kernel_size // 2
        self.conv = Conv(c1, self.c2, kernel_size, 1, p=padding, g=c1)
        self.norm = nn.BatchNorm2d(self.c2)

    def forward(self, x):
        residual = x
        x = self.conv(x)
        x = self.norm(x)
        return x + residual


class EdgeAwareAttention(nn.Module):
    def __init__(self, c1, c2=None):
        super().__init__()
        self.c1 = c1
        self.c2 = c2 if c2 is not None else c1
        self.conv1 = Conv(c1, c1, 3, 1, p=1)
        self.conv2 = Conv(c1, c1, 3, 1, p=1, g=c1)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        edge = self.conv1(x)
        att = self.sigmoid(self.conv2(edge))
        return x * att + x


class DepthwiseConv(nn.Module):
    def __init__(self, c1, c2=None, k=3, s=1, p=None, g=None, act=True):
        super().__init__()
        self.c1 = c1
        self.c2 = c2 if c2 is not None else c1
        g = g or c1
        self.conv = nn.Conv2d(c1, self.c2, k, s, autopad(k, p), groups=g, bias=False)
        self.bn = nn.BatchNorm2d(self.c2)
        self.act = Conv.default_act if act is True else (act if isinstance(act, nn.Module) else nn.Identity())

    def forward(self, x):
        return self.act(self.bn(self.conv(x)))


class CoordConv(nn.Module):
    def __init__(self, c1, c2=None, k=1, s=1, p=None):
        super().__init__()
        self.c1 = c1
        self.c2 = c2 if c2 is not None else c1
        self.conv = Conv(c1 + 2, self.c2, k, s, autopad(k, p))

    def forward(self, x):
        b, _, h, w = x.shape
        x_coord = torch.linspace(-1, 1, w, device=x.device, dtype=x.dtype).view(1, 1, 1, w).expand(b, 1, h, w)
        y_coord = torch.linspace(-1, 1, h, device=x.device, dtype=x.dtype).view(1, 1, h, 1).expand(b, 1, h, w)
        x_with_coord = torch.cat([x, x_coord, y_coord], dim=1)
        return self.conv(x_with_coord)


class HybridC2fC3K2(nn.Module):
    def __init__(self, c1, c2, n=1, shortcut=False, g=1, e=0.5):
        super().__init__()
        self.c1 = c1
        self.c2 = c2
        self.n = n
        self.shortcut = shortcut
        self.g = g
        self.e = e

        self.c = int(c2 * e)
        self.cv1 = Conv(c1, 2 * self.c, 1, 1)

        self.m = nn.ModuleList()
        for _ in range(n):
            self.m.append(nn.Sequential(
                Bottleneck(self.c, self.c, shortcut, g, k=((3, 3), (3, 3))),
                TripletAtt(self.c, self.c)
            ))

        self.cv2 = Conv(2 * self.c, c2, 1)

    def forward(self, x):
        x = self.cv1(x)
        if len(self.m) == 1:
            x = self.m[0](x[:, :self.c])
            x = torch.cat([x, x], dim=1)
        else:
            x = torch.cat([m(x[:, :self.c]) if i == 0 else m(x[:, self.c:]) for i, m in enumerate(self.m)], dim=1)
        return self.cv2(x)


class EnhancedC2f(nn.Module):
    def __init__(self, c1, c2, n=1, shortcut=False, g=1, e=0.5):
        super().__init__()
        self.c1 = c1
        self.c2 = c2
        self.n = n
        self.shortcut = shortcut
        self.g = g
        self.e = e

        self.c = int(c2 * e)
        self.cv1 = Conv(c1, 2 * self.c, 1, 1)
        self.cv2 = Conv(2 * self.c, c2, 1)

        self.m = nn.ModuleList(Bottleneck(self.c, self.c, shortcut, g) for _ in range(n))
        self.att = SE(2 * self.c, 2 * self.c)

    def forward(self, x):
        x = self.cv1(x)
        x = torch.cat([x[:, :self.c], *[m(x[:, self.c:]) for m in self.m]], dim=1)
        x = self.att(x)
        return self.cv2(x)


class HighPrecisionC2f(nn.Module):
    def __init__(self, c1, c2, n=1, shortcut=False, g=1, e=0.5):
        super().__init__()
        self.c1 = c1
        self.c2 = c2
        self.n = n
        self.shortcut = shortcut
        self.g = g
        self.e = e

        self.c = int(c2 * e)
        self.cv1 = Conv(c1, 2 * self.c, 1, 1)
        self.cv2 = Conv(2 * self.c, c2, 1)

        self.m = nn.ModuleList(Bottleneck(self.c, self.c, shortcut, g) for _ in range(n))
        self.cbam = CBAM(2 * self.c, 2 * self.c)

    def forward(self, x):
        x = self.cv1(x)
        x = torch.cat([x[:, :self.c], *[m(x[:, self.c:]) for m in self.m]], dim=1)
        x = self.cbam(x)
        return self.cv2(x)


class MANet(nn.Module):
    def __init__(self, c1, c2, n=1, e=0.5):
        super().__init__()
        self.c1 = c1
        self.c2 = c2
        self.n = n
        self.e = e

        self.c = int(c2 * e)
        self.cv1 = Conv(c1, self.c, 1, 1)
        self.cv2 = Conv(self.c, c2, 1, 1)

        self.m = nn.ModuleList()
        for _ in range(n):
            self.m.append(nn.Sequential(
                Conv(self.c, self.c, 3, 1, p=1),
                SE(self.c, self.c)
            ))

    def forward(self, x):
        x = self.cv1(x)
        for m in self.m:
            x = x + m(x)
        return self.cv2(x)


class ASPP(nn.Module):
    def __init__(self, c1, c2=None, dilations=(1, 6, 12, 18)):
        super().__init__()
        self.c1 = c1
        self.c2 = c2 if c2 is not None else c1
        self.dilations = dilations

        num_dilations = len(dilations)
        out_channels = self.c2 // num_dilations

        self.aspp = nn.ModuleList()
        for d in dilations:
            self.aspp.append(Conv(c1, out_channels, 3, 1, p=d, d=d))

        self.conv = Conv(self.c2, self.c2, 1, 1)

    def forward(self, x):
        return self.conv(torch.cat([m(x) for m in self.aspp], dim=1))


class DySample(nn.Module):
    def __init__(self, c1, c2=None, scale=2):
        super().__init__()
        self.c1 = c1
        self.c2 = c2 if c2 is not None else c1
        self.scale = scale
        self.conv = Conv(c1, self.c2, 3, 1, p=1)

    def forward(self, x):
        b, c, h, w = x.shape
        x = F.interpolate(x, scale_factor=self.scale, mode='bilinear', align_corners=False)
        x = self.conv(x)
        return F.interpolate(x, size=(h, w), mode='bilinear', align_corners=False)


class CARAFE(nn.Module):
    def __init__(self, c1, c2=None, kernel_size=3, up_factor=2):
        super().__init__()
        self.c1 = c1
        self.c2 = c2 if c2 is not None else c1
        self.up_factor = up_factor
        self.conv = Conv(c1, self.c2, 3, 1, p=1)

    def forward(self, x):
        b, c, h, w = x.shape
        x = F.interpolate(x, scale_factor=self.up_factor, mode='bilinear', align_corners=False)
        x = self.conv(x)
        return F.interpolate(x, size=(h, w), mode='bilinear', align_corners=False)


class CustomConcat(nn.Module):
    def __init__(self, c1, c2=None, dimension=1):
        super().__init__()
        self.c1 = c1
        self.c2 = c2 if c2 is not None else c1
        self.d = dimension

    def forward(self, x):
        x_shapes = [xi.shape for xi in x]
        if len(x) > 1:
            target_h, target_w = x[0].shape[2], x[0].shape[3]
            for i in range(1, len(x)):
                if x[i].shape[2] != target_h or x[i].shape[3] != target_w:
                    x[i] = F.interpolate(x[i], size=(target_h, target_w), mode='bilinear', align_corners=False)
        return torch.cat(x, self.d)