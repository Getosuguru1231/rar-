"""
YOLO模型运行状态诊断脚本
用于检查模型加载、推理性能、硬件加速等状态
"""
import sys
import os
import time
import torch
import cv2
import numpy as np
from pathlib import Path

# 添加backend目录到Python路径
script_dir = Path(__file__).parent
backend_dir = script_dir.parent / "backend"
sys.path.insert(0, str(backend_dir))

def print_section(title):
    """打印分节标题"""
    print(f"\n{'='*60}")
    print(f"  {title}")
    print(f"{'='*60}")

def check_pytorch():
    """检查PyTorch环境"""
    print_section("1. PyTorch 环境检查")
    
    print(f"✓ PyTorch版本: {torch.__version__}")
    print(f"✓ CUDA可用: {torch.cuda.is_available()}")
    
    if torch.cuda.is_available():
        print(f"✓ CUDA版本: {torch.version.cuda}")
        print(f"✓ GPU设备: {torch.cuda.get_device_name(0)}")
        print(f"✓ GPU内存: {torch.cuda.get_device_properties(0).total_memory / 1024**3:.2f} GB")
    else:
        print("⚠ 未检测到GPU,使用CPU进行推理")
    
    # 检查可用的线程数
    print(f"✓ CPU线程数: {torch.get_num_threads()}")
    print(f"✓ MKL-DNN可用: {torch.backends.mkldnn.is_available()}")

def check_opencv():
    """检查OpenCV环境"""
    print_section("2. OpenCV 环境检查")
    
    print(f"✓ OpenCV版本: {cv2.__version__}")
    
    # 检查视频编解码器支持
    codecs = ['H264', 'MJPG', 'XVID', 'MP4V']
    print("✓ 支持的编解码器:")
    for codec in codecs:
        fourcc = cv2.VideoWriter_fourcc(*codec)
        print(f"  - {codec}: {'✓' if fourcc != 0 else '✗'}")

def load_yolo_model():
    """加载并测试YOLO模型"""
    print_section("3. YOLO模型加载测试")
    
    try:
        from ultralytics import YOLO
        
        # 使用backend目录下的模型路径
        model_path = backend_dir / "models_dir" / "best.pt"
        imgs_size = 320  # 默认值
        
        print(f"✓ 模型路径: {model_path}")
        print(f"✓ 图像尺寸: {imgs_size}")
        
        # 检查模型文件是否存在
        if not model_path.exists():
            print(f"✗ 模型文件不存在: {model_path}")
            return None
        
        print(f"✓ 模型文件大小: {model_path.stat().st_size / 1024**2:.2f} MB")
        
        # 加载模型
        print("\n🔄 正在加载模型...")
        start_time = time.time()
        model = YOLO(str(model_path))
        load_time = time.time() - start_time
        
        print(f"✓ 模型加载成功! 耗时: {load_time:.2f}秒")
        print(f"✓ 模型类别: {model.names}")
        print(f"✓ 类别数量: {len(model.names)}")
        
        return model
        
    except Exception as e:
        print(f"✗ 模型加载失败: {e}")
        import traceback
        traceback.print_exc()
        return None

def test_inference(model):
    """测试模型推理性能"""
    print_section("4. 模型推理性能测试")
    
    if model is None:
        print("✗ 模型未加载,跳过推理测试")
        return
    
    try:
        # 使用默认图像尺寸
        IMGSZ = 320
        
        # 创建测试图像 (模拟摄像头帧)
        test_image = np.zeros((480, 640, 3), dtype=np.uint8)
        # 添加一些随机噪声模拟真实场景
        noise = np.random.randint(0, 50, test_image.shape, dtype=np.uint8)
        test_image = cv2.add(test_image, noise)
        
        print(f"✓ 测试图像尺寸: {test_image.shape}")
        print(f"✓ 推理图像尺寸: {IMGSZ}")
        
        # 预热推理 (第一次推理通常较慢)
        print("\n🔄 预热推理...")
        _ = model(test_image, verbose=False, imgsz=IMGSZ)
        
        # 正式测试推理速度
        print("\n🔄 执行10次推理测试...")
        inference_times = []
        
        for i in range(10):
            start_time = time.time()
            results = model(test_image, verbose=False, imgsz=IMGSZ)
            elapsed = time.time() - start_time
            inference_times.append(elapsed)
            
            if i == 0:
                print(f"  第1次: {elapsed*1000:.2f}ms (包含初始化)")
        
        # 计算统计信息 (排除第一次)
        avg_time = np.mean(inference_times[1:]) * 1000
        min_time = np.min(inference_times[1:]) * 1000
        max_time = np.max(inference_times[1:]) * 1000
        fps = 1000 / avg_time
        
        print(f"\n📊 推理性能统计 (9次平均):")
        print(f"  平均耗时: {avg_time:.2f}ms")
        print(f"  最快耗时: {min_time:.2f}ms")
        print(f"  最慢耗时: {max_time:.2f}ms")
        print(f"  预估FPS: {fps:.2f}")
        
        # 性能评估
        if fps >= 30:
            print(f"\n✅ 性能优秀! 满足实时检测要求 (>30 FPS)")
        elif fps >= 15:
            print(f"\n⚠️  性能良好,可以满足基本实时检测 (15-30 FPS)")
        else:
            print(f"\n❌ 性能不足,建议优化或升级硬件 (<15 FPS)")
        
    except Exception as e:
        print(f"✗ 推理测试失败: {e}")
        import traceback
        traceback.print_exc()

def check_backend_api():
    """检查后端API服务状态"""
    print_section("5. 后端API服务检查")
    
    try:
        import requests
        
        # 检查健康端点
        response = requests.get("http://localhost:8000/docs", timeout=5)
        if response.status_code == 200:
            print("✓ API文档可访问: http://localhost:8000/docs")
        else:
            print(f"✗ API文档访问失败: HTTP {response.status_code}")
        
        # 检查视频任务API
        response = requests.get("http://localhost:8000/api/video/tasks", timeout=5)
        if response.status_code == 200:
            tasks = response.json()
            print(f"✓ 视频任务API正常,当前任务数: {len(tasks)}")
        else:
            print(f"✗ 视频任务API异常: HTTP {response.status_code}")
        
    except requests.exceptions.ConnectionError:
        print("✗ 无法连接到后端服务 (http://localhost:8000)")
        print("  提示: 请确保后端服务已启动")
    except Exception as e:
        print(f"✗ API检查失败: {e}")

def main():
    """主函数"""
    print("\n" + "="*60)
    print("  🎯 YOLO模型运行状态诊断工具")
    print("="*60)
    print(f"  诊断时间: {time.strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"  Python版本: {sys.version}")
    print(f"  工作目录: {os.getcwd()}")
    
    # 执行各项检查
    check_pytorch()
    check_opencv()
    model = load_yolo_model()
    test_inference(model)
    check_backend_api()
    
    print_section("诊断完成")
    print("✅ 所有检查已完成!")
    print("\n💡 建议:")
    print("  1. 如果FPS较低,考虑降低图像分辨率或启用GPU加速")
    print("  2. 定期检查模型文件完整性")
    print("  3. 监控服务器资源使用情况(CPU/内存/GPU)")

if __name__ == "__main__":
    main()
