# 测试脚本目录

## 📋 说明

此目录包含项目开发过程中使用的各种测试脚本。

---

## 🧪 测试脚本列表

### 摄像头相关测试
- `test_camera.py` - 基础摄像头功能测试
- `test_camera_alert.py` - 摄像头告警系统测试
- `test_camera_connection.py` - 摄像头连接稳定性测试
- `test_camera_devices.py` - 摄像头设备枚举测试

### 视频相关测试
- `test_video_diagnosis.py` - 视频诊断工具
- `test_video_storage.py` - 视频存储功能测试
- `test_video_validation.py` - 视频文件验证测试
- `check_video_results.py` - 视频检测结果检查

### RDK X5 Edge相关测试
- `test_rdk_x5_websocket.py` - RDK X5 Edge WebSocket连接测试

### 性能测试
- `test_latency.py` - 系统延迟测试

### LLM相关测试
- `test_llm.py` - 大语言模型API测试

---

## 🚀 运行测试

### 单个测试
```bash
cd tests
python test_camera.py
```

### 所有测试
```bash
cd tests
for file in test_*.py; do
    echo "Running $file..."
    python "$file"
done
```

---

## 📝 编写新测试

### 命名规范
- 文件名: `test_<功能模块>.py`
- 类名: `Test<功能模块>`
- 方法名: `test_<具体功能>`

### 示例
```python
"""
摄像头连接测试
"""
import pytest

class TestCameraConnection:
    def test_basic_connection(self):
        """测试基础连接"""
        pass
    
    def test_reconnection(self):
        """测试重连机制"""
        pass
```

---

## ⚠️ 注意事项

1. **临时脚本**: 这些是开发阶段的测试脚本,不应作为正式测试套件
2. **迁移计划**: 未来应迁移到pytest/unittest框架
3. **依赖检查**: 运行前确保所有依赖已安装
4. **环境影响**: 部分测试可能需要硬件设备(摄像头)

---

## 🔄 维护建议

### 定期清理
- 删除已过时的测试
- 更新失败的测试用例
- 整合重复的测试逻辑

### 文档化
- 为每个测试添加docstring
- 记录测试前提条件
- 说明预期结果

---

**最后更新**: 2026-04-10  
**维护者**: 开发团队
