"""
环境依赖验证与修复脚本
用于快速检查虚拟环境中所有关键依赖是否正确安装,并自动修复常见问题
"""

import sys
import os
import subprocess
import importlib
from pathlib import Path

# 定义需要检查的关键依赖及其最低版本要求
REQUIRED_PACKAGES = {
    'torch': '2.0.0',
    'torchvision': '0.15.0',
    'cv2': '4.8.0',  # opencv-python 的模块名是 cv2
    'numpy': '1.24.0',
    'ultralytics': '8.0.0',
    'fastapi': '0.100.0',
    'uvicorn': '0.20.0',
    'mysql.connector': '8.0.0',  # mysql-connector-python 的模块名
    'redis': '5.0.0',
    'pyttsx3': '2.90',
    'multipart': '0.0.6',  # python-multipart 的模块名
    'dotenv': '1.0.0',  # python-dotenv
    'psutil': '5.9.0',
}

# Python 3.13兼容性配置
PYTHON_313_COMPAT = {
    'pydantic': '2.12.5',
    'pydantic_core': '2.41.5',
}

def check_python_version():
    """检查Python版本"""
    print(f"Python 版本: {sys.version}")
    print(f"Python 路径: {sys.executable}")
    
    major, minor = sys.version_info[:2]
    if major == 3 and minor >= 13:
        print("⚠️  检测到 Python 3.13+,已启用兼容性模式")
        # 设置Pydantic v1兼容性环境变量
        os.environ['PYDANTIC_V1_COMPATIBILITY_WARNING'] = 'ignore'
        return True
    return False

def check_package(package_name, min_version=None):
    """检查单个包是否安装且版本符合要求"""
    try:
        module = importlib.import_module(package_name.replace('-', '_'))
        version = getattr(module, '__version__', 'unknown')
        
        if min_version and version != 'unknown':
            print(f"✓ {package_name:30s} {version:15s} (最低: {min_version})")
        else:
            print(f"✓ {package_name:30s} {version}")
        return True, version
    except ImportError as e:
        print(f"✗ {package_name:30s} 未安装 - {str(e)}")
        return False, None
    except Exception as e:
        print(f"? {package_name:30s} 检查失败 - {str(e)}")
        return False, None

def check_redis_connection():
    """检查Redis连接"""
    try:
        import redis
        r = redis.Redis(host='localhost', port=6379, db=0, socket_timeout=2)
        r.ping()
        print("✓ Redis 连接成功")
        return True
    except Exception as e:
        print(f"✗ Redis 连接失败: {str(e)}")
        print("  提示: 请确保Redis服务正在运行 (redis-server)")
        return False

def check_mysql_connection():
    """检查MySQL连接"""
    try:
        import mysql.connector
        conn = mysql.connector.connect(
            host='localhost',
            port=3306,
            user='root',
            password='root',  # MySQL root密码
            database='drowning_db',
            connection_timeout=3
        )
        conn.close()
        print("✓ MySQL 连接成功")
        return True
    except Exception as e:
        print(f"✗ MySQL 连接失败: {str(e)}")
        print("  提示: 请确保MySQL服务正在运行,并已执行 init_database.bat")
        print("  当前配置: 用户=root, 密码=root, 数据库=drowning_db")
        return False

def check_model_files():
    """检查YOLO模型文件"""
    model_path = Path(__file__).parent / 'models_dir' / 'best.pt'
    if model_path.exists():
        size_mb = model_path.stat().st_size / (1024 * 1024)
        print(f"✓ YOLO模型文件存在: {model_path.name} ({size_mb:.1f} MB)")
        return True
    else:
        print(f"✗ YOLO模型文件不存在: {model_path}")
        print("  提示: 系统将自动回退到yolov8n.pt预训练模型")
        return False

def check_camera_access():
    """检查摄像头访问权限"""
    try:
        import cv2
        cap = cv2.VideoCapture(0)
        if cap.isOpened():
            ret, frame = cap.read()
            cap.release()
            if ret:
                print("✓ 摄像头访问正常")
                return True
        print("⚠️  摄像头不可用或未连接")
        return False
    except Exception as e:
        print(f"✗ 摄像头检查失败: {str(e)}")
        return False

def fix_pydantic_compatibility():
    """修复Pydantic v1兼容性问题"""
    print("\n" + "="*70)
    print("检查 Pydantic 兼容性...")
    print("="*70)
    
    major, minor = sys.version_info[:2]
    if major == 3 and minor >= 13:
        print("检测到 Python 3.13+,需要特殊配置")
        
        # 检查当前版本
        try:
            import pydantic
            import pydantic_core
            current_pydantic = pydantic.__version__
            current_core = pydantic_core.__version__
            
            print(f"当前 pydantic: {current_pydantic}")
            print(f"当前 pydantic-core: {current_core}")
            
            if current_pydantic == PYTHON_313_COMPAT['pydantic'] and \
               current_core == PYTHON_313_COMPAT['pydantic_core']:
                print("✓ Pydantic 版本兼容")
                return True
            else:
                print("⚠️  Pydantic 版本不匹配,建议升级")
                return False
        except ImportError:
            print("✗ Pydantic 未安装")
            return False
    return True

def install_dependencies():
    """安装或更新依赖"""
    print("\n" + "="*70)
    print("安装/更新依赖...")
    print("="*70)
    
    requirements_file = Path(__file__).parent / 'requirements.txt'
    if requirements_file.exists():
        print(f"使用 requirements.txt 安装依赖...")
        result = subprocess.run(
            [sys.executable, '-m', 'pip', 'install', '-r', str(requirements_file)],
            capture_output=True,
            text=True
        )
        if result.returncode == 0:
            print("✓ 依赖安装成功")
            return True
        else:
            print("✗ 依赖安装失败:")
            print(result.stderr)
            return False
    else:
        print("✗ requirements.txt 不存在")
        return False

def main():
    print("=" * 70)
    print("智能溺水检测系统 - 环境依赖验证与修复工具")
    print("=" * 70)
    print()
    
    # 检查Python版本并设置兼容性
    is_python_313 = check_python_version()
    print()
    
    # 检查依赖包
    print("-" * 70)
    print("依赖包检查:")
    print("-" * 70)
    
    results = []
    for package, min_ver in REQUIRED_PACKAGES.items():
        result, version = check_package(package, min_ver)
        results.append((package, result))
    
    print()
    
    # 检查外部服务
    print("-" * 70)
    print("外部服务检查:")
    print("-" * 70)
    check_redis_connection()
    check_mysql_connection()
    print()
    
    # 检查资源文件
    print("-" * 70)
    print("资源文件检查:")
    print("-" * 70)
    check_model_files()
    check_camera_access()
    print()
    
    # 检查兼容性
    if is_python_313:
        fix_pydantic_compatibility()
        print()
    
    # 汇总结果
    print("=" * 70)
    print("检查结果汇总:")
    print("=" * 70)
    
    passed = sum(1 for _, r in results if r)
    total = len(results)
    
    print(f"依赖包通过: {passed}/{total}")
    
    if passed == total:
        print("\n✓ 所有依赖检查通过!环境配置正确。")
        print("\n启动命令:")
        print("  前端: cd frontend && npm run dev")
        print("  后端: cd backend && .\\yolo_env\\Scripts\\python.exe main.py")
        return 0
    else:
        print("\n✗ 部分依赖缺失或版本不符")
        print("\n修复选项:")
        print("  1. 自动安装依赖: 运行此脚本时添加 --fix 参数")
        print("  2. 手动安装: pip install -r requirements.txt")
        
        if '--fix' in sys.argv:
            print("\n开始自动修复...")
            if install_dependencies():
                print("\n✓ 修复完成,请重新运行此脚本验证")
            else:
                print("\n✗ 修复失败,请检查网络连接或手动安装")
        
        return 1

if __name__ == "__main__":
    sys.exit(main())
