import cv2
import sys

print("检测可用的摄像头设备...")
print("="*50)

available_cameras = []
for index in range(5):  # 检查索引0-4
    try:
        cap = cv2.VideoCapture(index)
        if cap.isOpened():
            ret, frame = cap.read()
            if ret:
                height, width = frame.shape[:2]
                backend = cap.getBackendName()
                print(f"✅ 摄像头 {index}:")
                print(f"   后端: {backend}")
                print(f"   分辨率: {width}x{height}")
                available_cameras.append(index)
            else:
                print(f"⚠️  摄像头 {index}: 可以打开但无法读取帧")
            cap.release()
        else:
            print(f"❌ 摄像头 {index}: 无法打开")
    except Exception as e:
        print(f"❌ 摄像头 {index}: 错误 - {str(e)}")

print("="*50)
if available_cameras:
    print(f"\n找到 {len(available_cameras)} 个可用摄像头: {available_cameras}")
    print(f"\n建议在 settings.py 中设置 VIDEO_SOURCE = {available_cameras[0]}")
else:
    print("\n未找到可用的摄像头!")
    print("建议:")
    print("1. 检查USB摄像头是否正确连接")
    print("2. 使用视频文件作为测试源")
    print("3. 在 settings.py 中设置 VIDEO_SOURCE 为视频文件路径")
