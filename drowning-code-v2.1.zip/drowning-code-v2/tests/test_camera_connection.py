# backend/test_camera_connection.py
"""
摄像头连接管理器测试脚本
"""
import sys
from pathlib import Path
import time

# 添加项目根目录到路径
sys.path.insert(0, str(Path(__file__).parent))

from components.camera_connection import CameraConnectionManager
from logging_config import setup_logging

# 初始化日志
setup_logging()


def test_camera_connection():
    """测试摄像头连接管理器"""
    print("="*70)
    print("🧪 摄像头连接管理器测试")
    print("="*70)
    
    # 1. 初始化管理器
    print("\n1️⃣ 初始化摄像头管理器...")
    manager = CameraConnectionManager(
        max_retries=5,
        retry_interval=2,
        heartbeat_interval=3
    )
    print("✅ 管理器初始化成功")
    
    # 2. 打开摄像头
    print("\n2️⃣ 打开摄像头 (设备0)...")
    success = manager.open(source=0, width=640, height=480, fps=30)
    
    if not success:
        print("❌ 摄像头打开失败,测试终止")
        return
    
    print("✅ 摄像头打开成功")
    
    # 3. 读取帧测试
    print("\n3️⃣ 测试读取帧...")
    for i in range(10):
        ret, frame = manager.read(timeout=2)
        
        if ret and frame is not None:
            print(f"   ✅ 帧 {i+1}: 成功读取 ({frame.shape[1]}x{frame.shape[0]})")
        else:
            print(f"   ❌ 帧 {i+1}: 读取失败")
        
        time.sleep(0.1)
    
    # 4. 获取统计信息
    print("\n4️⃣ 获取统计信息...")
    stats = manager.get_stats()
    print(f"   连接状态: {'已连接' if stats['is_opened'] else '未连接'}")
    print(f"   运行时长: {stats['uptime_seconds']}秒")
    print(f"   总读取数: {stats['total_reads']}")
    print(f"   失败次数: {stats['failed_reads']}")
    print(f"   失败率: {stats['failure_rate_percent']}%")
    print(f"   重连次数: {stats['reconnect_count']}")
    print(f"   健康状态: {stats['health_status']}")
    
    # 5. 等待心跳检测
    print("\n5️⃣ 等待心跳检测 (6秒)...")
    time.sleep(6)
    
    stats = manager.get_stats()
    print(f"   健康状态: {stats['health_status']}")
    
    # 6. 测试手动关闭和重新打开
    print("\n6️⃣ 测试关闭和重新打开...")
    manager.close()
    print("   ✅ 摄像头已关闭")
    
    time.sleep(1)
    
    success = manager.open(source=0, width=640, height=480, fps=30)
    if success:
        print("   ✅ 摄像头重新打开成功")
        
        # 读取一帧验证
        ret, frame = manager.read(timeout=2)
        if ret:
            print(f"   ✅ 验证读取成功: {frame.shape[1]}x{frame.shape[0]}")
    else:
        print("   ❌ 摄像头重新打开失败")
    
    # 7. 最终统计
    print("\n7️⃣ 最终统计...")
    stats = manager.get_stats()
    print(f"   总读取数: {stats['total_reads']}")
    print(f"   失败次数: {stats['failed_reads']}")
    print(f"   重连次数: {stats['reconnect_count']}")
    print(f"   健康状态: {stats['health_status']}")
    
    # 8. 清理资源
    print("\n8️⃣ 清理资源...")
    manager.close()
    print("   ✅ 资源已释放")
    
    print("\n" + "="*70)
    print("✨ 测试完成!")
    print("="*70)


if __name__ == "__main__":
    try:
        test_camera_connection()
    except KeyboardInterrupt:
        print("\n\n⌨️ 用户中断测试")
    except Exception as e:
        print(f"\n\n❌ 测试异常: {str(e)}")
        import traceback
        traceback.print_exc()
