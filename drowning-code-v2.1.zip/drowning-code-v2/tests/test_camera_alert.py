# 摄像头和告警功能测试脚本
# 用于快速测试所有新增接口

import requests
import time

BASE_URL = "http://localhost:8000"

def print_section(title):
    """打印分隔线"""
    print("\n" + "="*60)
    print(f"  {title}")
    print("="*60)

def test_camera_status():
    """测试获取摄像头状态"""
    print_section("测试 1: 获取摄像头状态")
    try:
        response = requests.get(f"{BASE_URL}/camera/status")
        if response.status_code == 200:
            data = response.json()
            print(f"✅ 摄像头状态获取成功")
            print(f"   当前源：{data['data']['source']}")
            print(f"   运行状态：{'运行中' if data['data']['is_running'] else '已停止'}")
        else:
            print(f"❌ 请求失败：{response.status_code}")
    except Exception as e:
        print(f"❌ 测试失败：{str(e)}")

def test_voice_alert():
    """测试语音播报"""
    print_section("测试 2: 本地语音播报")
    try:
        response = requests.post(
            f"{BASE_URL}/voice-alert",
            params={"message": "测试语音播报，危险水域请勿靠近"}
        )
        if response.status_code == 200:
            print(f"✅ 语音播报已触发")
            print(f"   响应：{response.json()['message']}")
        else:
            print(f"❌ 请求失败：{response.status_code}")
    except Exception as e:
        print(f"❌ 测试失败：{str(e)}")

def test_camera_start():
    """测试启动摄像头"""
    print_section("测试 3: 启动摄像头（使用默认源）")
    try:
        response = requests.post(f"{BASE_URL}/camera/start")
        if response.status_code == 200:
            data = response.json()
            print(f"✅ 摄像头已启动")
            print(f"   源：{data['data']['source']}")
        else:
            print(f"❌ 请求失败：{response.status_code}")
    except Exception as e:
        print(f"❌ 测试失败：{str(e)}")

def test_camera_switch():
    """测试切换摄像头"""
    print_section("测试 4: 切换摄像头（可选测试）")
    print("提示：输入摄像头源地址（留空跳过）")
    source = input("例如：1 (摄像头 1) 或 rtsp://... : ").strip()
    
    if source:
        try:
            response = requests.post(
                f"{BASE_URL}/camera/switch",
                params={"source": source}
            )
            if response.status_code == 200:
                data = response.json()
                print(f"✅ 摄像头已切换到：{data['data']['source']}")
            else:
                print(f"❌ 请求失败：{response.status_code}")
        except Exception as e:
            print(f"❌ 测试失败：{str(e)}")
    else:
        print("⏭️  跳过此测试")

def test_camera_stop():
    """测试停止摄像头"""
    print_section("测试 5: 停止摄像头")
    try:
        response = requests.post(f"{BASE_URL}/camera/stop")
        if response.status_code == 200:
            print(f"✅ 摄像头已停止")
        else:
            print(f"❌ 请求失败：{response.status_code}")
    except Exception as e:
        print(f"❌ 测试失败：{str(e)}")

def main():
    """主测试流程"""
    print_section("🚀 溺水系统 - 摄像头与告警功能测试")
    print("本测试将验证以下功能：")
    print("  1. 摄像头状态查询")
    print("  2. 本地语音播报")
    print("  3. 摄像头启动")
    print("  4. 摄像头切换（可选）")
    print("  5. 摄像头停止")
    print("\n请确保后端服务已启动：python main.py")
    input("\n按 Enter 键开始测试...")
    
    # 执行测试
    test_camera_status()
    time.sleep(1)
    
    test_voice_alert()
    time.sleep(2)  # 等待语音播报完成
    
    test_camera_start()
    time.sleep(1)
    
    test_camera_switch()
    time.sleep(1)
    
    test_camera_stop()
    
    # 最终状态
    print_section("测试完成")
    test_camera_status()
    print("\n✅ 所有测试已完成！")
    print("\n提示：")
    print("  - 如果听到语音播报，说明本地语音功能正常")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n⚠️  用户中断测试")
    except Exception as e:
        print(f"\n❌ 测试过程出错：{str(e)}")
