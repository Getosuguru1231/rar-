"""
视频流延迟测试脚本
用于验证优化效果并监控性能指标
"""
import time
import requests
from datetime import datetime

def test_video_stream_latency():
    """测试视频流延迟和帧率"""
    print("="*70)
    print("🧪 视频流延迟测试")
    print("="*70)
    
    url = "http://localhost:8000/api/video_feed"
    
    try:
        # 发送请求并测量响应时间
        start_time = time.time()
        response = requests.get(url, stream=True, timeout=10)
        
        if response.status_code == 200:
            print(f"✅ 连接成功 (耗时: {(time.time() - start_time)*1000:.0f}ms)")
            
            frame_count = 0
            test_duration = 5  # 测试5秒
            
            print(f"\n📊 开始测试，持续 {test_duration} 秒...")
            test_start = time.time()
            
            for chunk in response.iter_content(chunk_size=1024):
                if b'Content-Type: image/jpeg' in chunk:
                    frame_count += 1
                
                elapsed = time.time() - test_start
                if elapsed >= test_duration:
                    break
            
            # 计算结果
            fps = frame_count / test_duration
            avg_latency_ms = (test_duration / frame_count * 1000) if frame_count > 0 else 0
            
            print("\n" + "="*70)
            print("📈 测试结果:")
            print("="*70)
            print(f"  • 总帧数: {frame_count}")
            print(f"  • 测试时长: {test_duration}s")
            print(f"  • 平均帧率: {fps:.1f} FPS")
            print(f"  • 平均延迟: {avg_latency_ms:.0f}ms")
            print("="*70)
            
            # 评估结果
            if fps >= 25:
                print("✅ 帧率优秀 (>25 FPS)")
            elif fps >= 15:
                print("⚠️  帧率一般 (15-25 FPS)")
            else:
                print("❌ 帧率较低 (<15 FPS)，建议进一步优化")
            
            if avg_latency_ms <= 1000:
                print("✅ 延迟优秀 (<1s)")
            elif avg_latency_ms <= 2000:
                print("⚠️  延迟可接受 (1-2s)")
            else:
                print("❌ 延迟过高 (>2s)，需要优化")
                
        else:
            print(f"❌ 连接失败，状态码: {response.status_code}")
            
    except requests.exceptions.ConnectionError:
        print("❌ 无法连接到后端服务，请确保服务已启动")
        print("   启动命令: cd backend && .\\yolo_env\\Scripts\\python.exe main.py")
    except Exception as e:
        print(f"❌ 测试失败: {str(e)}")

def check_camera_health():
    """检查摄像头健康状态"""
    print("\n" + "="*70)
    print("📷 摄像头健康状态检查")
    print("="*70)
    
    try:
        response = requests.get("http://localhost:8000/api/camera/health", timeout=5)
        
        if response.status_code == 200:
            data = response.json()
            if data.get("success"):
                health = data["data"]
                print(f"  • 健康状态: {health.get('health_status', 'unknown')}")
                print(f"  • 总读取帧数: {health.get('total_frames_read', 0)}")
                print(f"  • 当前FPS: {health.get('fps', 0):.1f}")
                print(f"  • 失败率: {health.get('failure_rate', 0)*100:.1f}%")
                print(f"  • 重连次数: {health.get('reconnect_count', 0)}")
            else:
                print("❌ 获取健康状态失败")
        else:
            print(f"❌ 请求失败，状态码: {response.status_code}")
            
    except Exception as e:
        print(f"❌ 检查失败: {str(e)}")

if __name__ == "__main__":
    print(f"测试时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
    
    # 测试视频流延迟
    test_video_stream_latency()
    
    # 检查摄像头健康状态
    check_camera_health()
    
    print("\n💡 提示: 如果延迟仍然较高，请参考 OPTIMIZE_VIDEO_LATENCY.md")
