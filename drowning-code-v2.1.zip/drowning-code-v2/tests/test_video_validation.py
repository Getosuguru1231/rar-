# backend/test_video_validation.py
"""
视频文件校验测试脚本
用于测试视频文件的快速校验和超时保护机制
"""
import os
import sys
from datetime import datetime

# 添加项目根目录到路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from components.utils import is_valid_video_file, safe_open_video


def test_video_file(filepath):
    """测试单个视频文件"""
    print(f"\n{'='*60}")
    print(f"测试文件：{filepath}")
    print(f"{'='*60}\n")
    
    # 步骤 1：基础文件校验
    print(f"[{datetime.now()}] 📋 执行基础文件校验...")
    is_valid = is_valid_video_file(filepath)
    
    if not is_valid:
        print(f"\n❌ 基础校验失败，跳过后续测试")
        return False
    
    print(f"\n✅ 基础校验通过\n")
    
    # 步骤 2：安全打开测试（带超时）
    print(f"[{datetime.now()}] 🎬 执行安全打开测试（超时：5 秒）...")
    try:
        cap = safe_open_video(filepath, timeout=5)
        print(f"\n✅ 视频成功打开！")
        
        # 获取视频信息
        fps = cap.get(cv2.CAP_PROP_FPS)
        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        duration = total_frames / fps if fps > 0 else 0
        
        print(f"\n📊 视频信息:")
        print(f"   - 分辨率：{width} x {height}")
        print(f"   - FPS: {fps:.2f}")
        print(f"   - 总帧数：{total_frames}")
        print(f"   - 时长：{duration:.2f} 秒")
        
        # 释放资源
        cap.release()
        print(f"\n✅ 资源已释放")
        return True
        
    except Exception as e:
        print(f"\n❌ 打开失败：{str(e)}")
        return False


if __name__ == "__main__":
    import cv2
    
    print("="*60)
    print("视频文件快速校验与超时保护测试")
    print("="*60)
    
    # 测试用例 1：用户提供的视频文件
    test_file = r"C:\Users\whz42\Desktop\临时暂放\图片等\屏幕录制 2026-01-24 150944.mp4"
    result1 = test_video_file(test_file)
    
    # 测试用例 2：不存在的文件
    print(f"\n{'='*60}")
    print(f"测试：不存在的文件")
    print(f"{'='*60}")
    fake_file = r"C:\nonexistent\fake_video.mp4"
    result2 = not is_valid_video_file(fake_file)  # 应该返回 False
    print(f"预期结果：False (文件不存在)")
    print(f"实际结果：{is_valid_video_file(fake_file)}")
    print(f"测试{'通过' if result2 else '失败'} ✓")
    
    # 测试用例 3：空文件（创建临时文件）
    print(f"\n{'='*60}")
    print(f"测试：空文件/过小文件")
    print(f"{'='*60}")
    temp_empty = os.path.join(os.getcwd(), "temp_empty_test.mp4")
    try:
        with open(temp_empty, 'wb') as f:
            pass  # 创建空文件
        result3 = not is_valid_video_file(temp_empty)  # 应该返回 False
        print(f"预期结果：False (文件过小)")
        print(f"实际结果：{is_valid_video_file(temp_empty)}")
        print(f"测试{'通过' if result3 else '失败'} ✓")
    except Exception as e:
        print(f"⚠️ 创建临时文件失败：{e}")
        result3 = True  # 不影响整体结果
    finally:
        if os.path.exists(temp_empty):
            try:
                os.remove(temp_empty)
            except:
                pass

    # 总结
    print(f"\n{'='*60}")
    print(f"测试总结")
    print(f"{'='*60}")
    all_passed = result1 and result2 and result3
    if all_passed:
        print(f"✅ 所有测试通过！")
    else:
        print(f"⚠️ 部分测试失败，请检查输出日志")
    
    print(f"\n完成时间：{datetime.now()}")
