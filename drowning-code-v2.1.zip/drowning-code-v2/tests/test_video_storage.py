# backend/test_video_storage.py
"""
视频存储系统测试脚本
"""
import os
import sys
from datetime import datetime
from pathlib import Path

# 添加项目根目录到路径
sys.path.insert(0, str(Path(__file__).parent))

from video_storage import VideoStorageManager
from logging_config import setup_logging

# 初始化日志
setup_logging()


def test_video_storage():
    """测试视频存储功能"""
    print("="*70)
    print("🧪 视频存储系统测试")
    print("="*70)
    
    # 1. 初始化管理器
    print("\n1️⃣ 初始化视频存储管理器...")
    storage = VideoStorageManager(retention_days=30)
    print("✅ 初始化成功")
    
    # 2. 创建测试视频文件
    print("\n2️⃣ 创建测试视频文件...")
    test_video_path = Path(__file__).parent / "test_video.mp4"
    
    # 创建一个空的测试文件
    with open(test_video_path, 'wb') as f:
        f.write(b'\x00' * 1024)  # 1KB 空文件
    
    print(f"✅ 测试文件已创建: {test_video_path}")
    
    # 3. 测试保存告警视频
    print("\n3️⃣ 测试保存告警视频...")
    try:
        metadata = {
            "water_area": "测试泳池",
            "alert_time": datetime.now().isoformat(),
            "confidence": 0.85,
            "camera_source": 0,
            "test": True
        }
        
        stored_path = storage.save_alert_video(str(test_video_path), metadata)
        print(f"✅ 告警视频已保存: {stored_path}")
        
        # 验证文件存在
        if Path(stored_path).exists():
            print("✅ 文件验证通过")
        else:
            print("❌ 文件不存在!")
    
    except Exception as e:
        print(f"❌ 保存失败: {str(e)}")
        import traceback
        traceback.print_exc()
    
    # 4. 测试保存正常视频
    print("\n4️⃣ 测试保存正常视频...")
    try:
        normal_metadata = {
            "duration_seconds": 60,
            "test": True
        }
        
        normal_path = storage.save_normal_video(str(test_video_path), 60, normal_metadata)
        print(f"✅ 正常视频已保存: {normal_path}")
    
    except Exception as e:
        print(f"❌ 保存失败: {str(e)}")
    
    # 5. 测试搜索功能
    print("\n5️⃣ 测试搜索功能...")
    try:
        videos = storage.search_videos(video_type="alert", limit=10)
        print(f"✅ 搜索到 {len(videos)} 个告警视频")
        
        for i, video in enumerate(videos[:3], 1):
            print(f"   {i}. {video.get('filename')} - {video.get('timestamp')}")
    
    except Exception as e:
        print(f"❌ 搜索失败: {str(e)}")
    
    # 6. 测试统计功能
    print("\n6️⃣ 测试统计功能...")
    try:
        stats = storage.get_statistics()
        print(f"✅ 统计信息:")
        print(f"   总视频数: {stats.get('total_videos', 0)}")
        print(f"   告警视频: {stats.get('alert_videos', 0)}")
        print(f"   正常视频: {stats.get('normal_videos', 0)}")
        print(f"   总大小: {stats.get('total_size_mb', 0)} MB")
    
    except Exception as e:
        print(f"❌ 统计失败: {str(e)}")
    
    # 7. 测试元数据加载
    print("\n7️⃣ 测试元数据加载...")
    try:
        if videos:
            filename = videos[0]['filename']
            metadata = storage.load_metadata(filename)
            
            if metadata:
                print(f"✅ 元数据加载成功:")
                print(f"   类型: {metadata.get('type')}")
                print(f"   时间: {metadata.get('timestamp')}")
                print(f"   状态: {metadata.get('status')}")
            else:
                print("❌ 元数据为空")
    
    except Exception as e:
        print(f"❌ 加载失败: {str(e)}")
    
    # 8. 测试清理功能
    print("\n8️⃣ 测试清理功能...")
    try:
        # 清理1天前的视频(应该清理测试视频)
        deleted = storage.cleanup_old_videos(days=1)
        print(f"✅ 清理完成: 删除 {deleted} 个视频")
    
    except Exception as e:
        print(f"❌ 清理失败: {str(e)}")
    
    # 9. 清理测试文件
    print("\n9️⃣ 清理测试文件...")
    try:
        if test_video_path.exists():
            test_video_path.unlink()
            print("✅ 测试文件已删除")
    except Exception as e:
        print(f"⚠️ 删除测试文件失败: {str(e)}")
    
    print("\n" + "="*70)
    print("✨ 测试完成!")
    print("="*70)


if __name__ == "__main__":
    try:
        test_video_storage()
    except KeyboardInterrupt:
        print("\n\n⌨️ 用户中断测试")
    except Exception as e:
        print(f"\n\n❌ 测试异常: {str(e)}")
        import traceback
        traceback.print_exc()
