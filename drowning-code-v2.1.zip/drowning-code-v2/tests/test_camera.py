# backend/test_camera.py
"""
摄像头测试脚本
用于验证 Windows 设备路径格式是否正确
"""
import cv2
from datetime import datetime

# 笔记本摄像头设备路径
CAMERA_PATH = "USB\\VID_04F2&PID_B7E8&MI_00\\6&37C306D&1&0000"

def test_camera():
    """测试摄像头是否可用"""
    print("=" * 60)
    print("摄像头测试工具")
    print("=" * 60)
    
    # 方法 1: 尝试直接使用 OpenCV 打开
    print(f"\n[{datetime.now()}] 方法 1: 直接打开设备路径")
    print(f"设备路径：{CAMERA_PATH}")
    
    cap1 = cv2.VideoCapture(CAMERA_PATH)
    if cap1.isOpened():
        print("✅ 直接打开成功！")
        ret, frame = cap1.read()
        if ret:
            print(f"✅ 成功读取帧：{frame.shape}")
        cap1.release()
    else:
        print("❌ 直接打开失败")
    cap1.release()
    
    # 方法 2: 使用 DirectShow 后端
    print(f"\n[{datetime.now()}] 方法 2: 使用 DirectShow 后端")
    
    try:
        # 转换为 DirectShow 格式
        device_path = CAMERA_PATH.replace("\\", "#").lower()
        directshow_path = f"\\\\?\\usb#{device_path}#{{e5323777-f976-4f5b-9b55-b94699c46e44}}"
        
        print(f"DirectShow 路径：{directshow_path}")
        
        cap2 = cv2.VideoCapture(directshow_path, cv2.CAP_DSHOW)
        
        if cap2.isOpened():
            print("✅ DirectShow 打开成功！")
            
            # 测试读取帧
            for i in range(5):
                ret, frame = cap2.read()
                if ret:
                    print(f"✅ 帧 {i+1}: {frame.shape[0]}x{frame.shape[1]}")
                else:
                    print(f"❌ 帧 {i+1}: 读取失败")
                    break
            
            cap2.release()
            print("\n✅ 摄像头测试通过！")
        else:
            print("❌ DirectShow 打开失败")
            cap2.release()
    
    except Exception as e:
        print(f"❌ DirectShow 测试失败：{str(e)}")
    
    # 方法 3: 尝试使用索引 0（默认摄像头）
    print(f"\n[{datetime.now()}] 方法 3: 使用摄像头索引 0")
    cap3 = cv2.VideoCapture(0)
    
    if cap3.isOpened():
        print("✅ 索引 0 打开成功！")
        ret, frame = cap3.read()
        if ret:
            print(f"✅ 成功读取帧：{frame.shape}")
        cap3.release()
    else:
        print("❌ 索引 0 打开失败")
    cap3.release()
    
    print("\n" + "=" * 60)
    print("测试完成")
    print("=" * 60)

if __name__ == "__main__":
    test_camera()
