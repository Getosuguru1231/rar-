"""
语言大模型功能测试脚本
用于验证LLM集成是否正常工作
"""

import requests
import json
from datetime import datetime

BASE_URL = "http://localhost:8000"


def test_llm_connection():
    """测试LLM连接"""
    print("=" * 60)
    print("测试1: LLM连接测试")
    print("=" * 60)
    
    try:
        response = requests.get(f"{BASE_URL}/api/llm/test", timeout=10)
        result = response.json()
        
        print(f"状态码: {result['code']}")
        print(f"消息: {result['message']}")
        
        if result['code'] == 200:
            print(f"✅ 连接成功!")
            print(f"提供商: {result['data']['config']['provider']}")
            print(f"模型: {result['data']['config']['model']}")
            print(f"API响应: {result['data'].get('response', 'N/A')}")
        else:
            print(f"❌ 连接失败: {result['message']}")
            print(f"配置信息: {json.dumps(result['data']['config'], indent=2, ensure_ascii=False)}")
            
    except Exception as e:
        print(f"❌ 测试异常: {str(e)}")
    
    print()


def get_llm_config():
    """获取LLM配置"""
    print("=" * 60)
    print("测试2: 获取LLM配置")
    print("=" * 60)
    
    try:
        response = requests.get(f"{BASE_URL}/api/llm/config", timeout=10)
        result = response.json()
        
        print(f"状态码: {result['code']}")
        print(f"配置信息:")
        print(json.dumps(result['data'], indent=2, ensure_ascii=False))
        
    except Exception as e:
        print(f"❌ 测试异常: {str(e)}")
    
    print()


def test_drowning_analysis():
    """测试溺水事件分析"""
    print("=" * 60)
    print("测试3: 溺水事件智能分析")
    print("=" * 60)
    
    event_data = {
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "location": "游泳池A区",
        "confidence": 0.85,
        "person_count": 1,
        "duration": 15.5,
        "behavior_description": "检测到人员在水中挣扎，头部多次没入水中，手臂挥舞"
    }
    
    try:
        response = requests.post(
            f"{BASE_URL}/api/llm/analyze",
            json=event_data,
            timeout=30
        )
        result = response.json()
        
        print(f"状态码: {result['code']}")
        print(f"消息: {result['message']}")
        
        if result['code'] == 200:
            print(f"\n✅ 分析成功!")
            print(f"使用模型: {result['data']['model']}")
            print(f"\n分析结果:\n{result['data']['analysis']}")
        else:
            print(f"❌ 分析失败")
            
    except Exception as e:
        print(f"❌ 测试异常: {str(e)}")
    
    print()


def test_alert_generation():
    """测试预警消息生成"""
    print("=" * 60)
    print("测试4: 预警消息生成（短信推送）")
    print("=" * 60)
    
    event_data = {
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "location": "游泳池B区",
        "confidence": 0.92,
        "person_count": 2,
        "duration": 20.0,
        "behavior_description": "两名人员同时出现异常行为"
    }
    
    try:
        response = requests.post(
            f"{BASE_URL}/api/llm/generate-alert",
            json=event_data,
            timeout=30
        )
        result = response.json()
        
        print(f"状态码: {result['code']}")
        print(f"消息: {result['message']}")
        
        if result['code'] == 200:
            print(f"\n✅ 预警消息生成成功!")
            print(f"消息长度: {result['data']['length']} 字符")
            print(f"\n预警消息:\n{result['data']['alert_message']}")
        else:
            print(f"❌ 生成失败")
            
    except Exception as e:
        print(f"❌ 测试异常: {str(e)}")
    
    print()


def test_report_generation():
    """测试检测报告生成"""
    print("=" * 60)
    print("测试5: 检测报告生成")
    print("=" * 60)
    
    detection_results = [
        {
            "timestamp": "2026-04-08 19:30:00",
            "location": "游泳池A区",
            "confidence": 0.85,
            "status": "detected",
            "person_count": 1
        },
        {
            "timestamp": "2026-04-08 19:35:00",
            "location": "游泳池B区",
            "confidence": 0.72,
            "status": "detected",
            "person_count": 1
        },
        {
            "timestamp": "2026-04-08 19:40:00",
            "location": "游泳池A区",
            "confidence": 0.65,
            "status": "warning",
            "person_count": 2
        }
    ]
    
    try:
        response = requests.post(
            f"{BASE_URL}/api/llm/generate-report",
            json={"detection_results": detection_results},
            timeout=30
        )
        result = response.json()
        
        print(f"状态码: {result['code']}")
        print(f"消息: {result['message']}")
        
        if result['code'] == 200:
            print(f"\n✅ 报告生成成功!")
            print(f"检测结果数量: {result['data']['result_count']}")
            print(f"\n检测报告:\n{result['data']['report']}")
        else:
            print(f"❌ 报告生成失败")
            
    except Exception as e:
        print(f"❌ 测试异常: {str(e)}")
    
    print()


def test_qa():
    """测试智能问答"""
    print("=" * 60)
    print("测试6: 智能问答")
    print("=" * 60)
    
    questions = [
        {
            "question": "检测到溺水后应该采取什么应急措施？",
            "context": ""
        },
        {
            "question": "如何提高溺水检测系统的准确率？",
            "context": "当前系统使用YOLOv8模型，置信度阈值为0.6"
        }
    ]
    
    for i, qa in enumerate(questions, 1):
        print(f"\n问题 {i}: {qa['question']}")
        print("-" * 60)
        
        try:
            response = requests.post(
                f"{BASE_URL}/api/llm/ask",
                json=qa,
                timeout=30
            )
            result = response.json()
            
            if result['code'] == 200:
                print(f"回答:\n{result['data']['answer']}")
            else:
                print(f"❌ 回答失败")
                
        except Exception as e:
            print(f"❌ 测试异常: {str(e)}")
    
    print()


def main():
    """运行所有测试"""
    print("\n")
    print("╔" + "=" * 58 + "╗")
    print("║" + " " * 15 + "语言大模型功能测试" + " " * 21 + "║")
    print("╚" + "=" * 58 + "╝")
    print()
    
    # 检查后端服务是否运行
    try:
        response = requests.get(f"{BASE_URL}/", timeout=5)
        print("✅ 后端服务正在运行\n")
    except:
        print("❌ 后端服务未运行，请先启动后端服务！")
        print(f"   运行命令: cd backend && .\\yolo_env\\Scripts\\python.exe main.py")
        return
    
    # 运行测试
    test_llm_connection()
    get_llm_config()
    test_drowning_analysis()
    test_alert_generation()
    test_report_generation()
    test_qa()
    
    print("\n" + "=" * 60)
    print("测试完成！")
    print("=" * 60)
    print("\n提示:")
    print("1. 如果看到'降级模板'说明API未配置或调用失败")
    print("2. 请检查 .env.llm 文件中的API密钥配置")
    print("3. 详细文档请参考: LLM_INTEGRATION_GUIDE.md")
    print()


if __name__ == "__main__":
    main()
