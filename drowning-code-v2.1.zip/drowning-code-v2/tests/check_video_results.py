"""
查询视频监测结果脚本
"""
import mysql.connector
from pathlib import Path
from datetime import datetime

print("="*70)
print("📊 视频监测结果查询")
print("="*70)

# 1. 查询数据库中的告警记录
print("\n1️⃣ 数据库告警记录:")
print("-" * 70)

try:
    conn = mysql.connector.connect(
        host='localhost',
        user='root',
        password='root',
        database='drowning_db'
    )
    cursor = conn.cursor(dictionary=True)
    
    cursor.execute("""
        SELECT id, alert_time, video_path 
        FROM alert_log 
        ORDER BY alert_time DESC 
        LIMIT 10
    """)
    
    rows = cursor.fetchall()
    
    if rows:
        for i, row in enumerate(rows, 1):
            print(f"{i}. ID: {row['id']}")
            print(f"   时间: {row['alert_time']}")
            print(f"   路径: {row['video_path']}")
            print(f"   文件存在: {'✅' if Path(row['video_path']).exists() else '❌'}")
            print()
    else:
        print("暂无告警记录")
    
    cursor.close()
    conn.close()
    
except Exception as e:
    print(f"❌ 查询失败: {e}")

# 2. 查看用户上传的视频
print("\n2️⃣ 用户上传视频:")
print("-" * 70)

upload_dir = Path(__file__).parent / "uploads"
if upload_dir.exists():
    videos = list(upload_dir.glob("*.mp4"))
    if videos:
        for i, video in enumerate(videos, 1):
            size_mb = video.stat().st_size / (1024 * 1024)
            print(f"{i}. {video.name}")
            print(f"   大小: {size_mb:.2f} MB")
            print(f"   修改时间: {datetime.fromtimestamp(video.stat().st_mtime)}")
            print()
    else:
        print("暂无上传视频")
else:
    print("uploads目录不存在")

# 3. 查看告警视频
print("\n3️⃣ 实时检测告警视频:")
print("-" * 70)

alerts_dir = Path(__file__).parent.parent / "data" / "recorded_videos" / "alerts"
if alerts_dir.exists():
    videos = list(alerts_dir.rglob("*.mp4"))
    if videos:
        for i, video in enumerate(videos, 1):
            size_kb = video.stat().st_size / 1024
            print(f"{i}. {video.relative_to(alerts_dir.parent)}")
            print(f"   大小: {size_kb:.2f} KB")
            print(f"   修改时间: {datetime.fromtimestamp(video.stat().st_mtime)}")
            print()
    else:
        print("暂无告警视频")
else:
    print("告警视频目录不存在")

print("\n" + "="*70)
print("✅ 查询完成")
print("="*70)
