"""
🔍 视频文件诊断脚本
用于详细分析视频文件的各项参数和可读性
"""
import cv2
import os

video_path = r"C:\Users\whz42\Desktop\临时暂放\图片等\游泳池小孩误入深水区溺水，还好救生员及时发现.mp4"

print("="*60)
print(f"📹 视频文件诊断：{os.path.basename(video_path)}")
print("="*60)

# 基础信息
print(f"\n📁 文件信息:")
print(f"  路径：{video_path}")
print(f"  存在：{'✅ 是' if os.path.exists(video_path) else '❌ 否'}")
print(f"  大小：{os.path.getsize(video_path) / 1024 / 1024:.2f} MB")

# 尝试用不同方式打开
print(f"\n🎬 OpenCV 版本：{cv2.__version__}")

print(f"\n📊 测试 1: 基本打开")
cap = cv2.VideoCapture(video_path)
print(f"  cap.isOpened(): {cap.isOpened()}")

if cap.isOpened():
    print(f"\n📊 测试 2: 获取视频属性")
    fps = cap.get(cv2.CAP_PROP_FPS)
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    fourcc = cap.get(cv2.CAP_PROP_FOURCC)
    
    print(f"  帧率 (FPS): {fps}")
    print(f"  分辨率：{width} x {height}")
    print(f"  总帧数：{total}")
    print(f"  时长：{total/fps:.2f}秒 (如果 fps>0)")
    print(f"  编码器：{fourcc}")
    
    print(f"\n📊 测试 3: 读取第一帧")
    ret, frame = cap.read()
    print(f"  读取结果 ret: {ret}")
    if ret and frame is not None:
        print(f"  ✅ 成功！帧尺寸：{frame.shape}")
        print(f"  数据类型：{frame.dtype}")
        print(f"  像素总数：{frame.size}")
    else:
        print(f"  ❌ 失败：frame={frame}")
        
    print(f"\n📊 测试 4: 连续读取 10 帧")
    success_count = 0
    for i in range(10):
        ret, frame = cap.read()
        if ret and frame is not None:
            success_count += 1
        else:
            print(f"  第{i+1}帧失败")
            break
    
    print(f"  成功读取：{success_count}/10 帧")
    
    cap.release()
else:
    print(f"  ❌ 无法打开视频")

print(f"\n📊 测试 5: 使用不同的后端 API")
backends = [
    (cv2.CAP_ANY, "自动检测"),
    (cv2.CAP_DSHOW, "DirectShow"),
    (cv2.CAP_MSMF, "Media Foundation"),
]

for backend_id, backend_name in backends:
    print(f"\n  尝试 {backend_name}:")
    cap = cv2.VideoCapture(video_path, backend_id)
    if cap.isOpened():
        ret, frame = cap.read()
        print(f"    isOpened: ✅, 读取：{'✅' if ret else '❌'}, 尺寸：{frame.shape if ret else 'N/A'}")
        cap.release()
    else:
        print(f"    isOpened: ❌")

print("\n" + "="*60)
print("诊断完成")
print("="*60)
