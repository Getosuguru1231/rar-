"""
check_dataset.py

Quality checks on the built GRU dataset (X.npy / y.npy / meta.csv).

Usage:
    python src/check_dataset.py \
        --x data/processed/X.npy \
        --y data/processed/y.npy \
        --meta data/processed/meta.csv \
        --schema data/processed/feature_schema.json
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import sys

import numpy as np
import pandas as pd

_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
_PROJ_ROOT = os.path.dirname(_THIS_DIR)
if _PROJ_ROOT not in sys.path:
    sys.path.insert(0, _PROJ_ROOT)

from src.config import FEATURE_DIM, NUM_CLASSES

logger = logging.getLogger(__name__)


def check_counts(X, y, meta):
    """X, y, meta must have same number of samples."""
    n_x, n_y, n_m = X.shape[0], y.shape[0], len(meta)
    ok = (n_x == n_y == n_m)
    logger.info("Sample counts: X=%d  y=%d  meta=%d  %s",
                n_x, n_y, n_m, "OK" if ok else "MISMATCH!")
    return ok


def check_nan_inf(X):
    """Check for NaN / Inf in feature matrix."""
    nan_count = int(np.sum(np.isnan(X)))
    inf_count = int(np.sum(np.isinf(X)))
    ok = (nan_count == 0 and inf_count == 0)
    logger.info("NaN: %d  Inf: %d  %s", nan_count, inf_count, "OK" if ok else "FAIL")
    return ok


def check_feature_dim(X, expected_dim=FEATURE_DIM):
    """Check feature dimension matches config."""
    actual = X.shape[2] if X.ndim == 3 else X.shape[1]
    ok = (actual == expected_dim)
    logger.info("Feature dim: expected=%d  actual=%d  %s",
                expected_dim, actual, "OK" if ok else "MISMATCH!")
    return ok


def check_label_range(y, num_classes=NUM_CLASSES):
    """Check labels are in valid range."""
    min_y, max_y = int(y.min()), int(y.max())
    ok = (min_y >= 0 and max_y < num_classes)
    logger.info("Label range: [%d, %d]  expected [0, %d]  %s",
                min_y, max_y, num_classes - 1, "OK" if ok else "OUT OF RANGE!")
    return ok


def check_label_distribution(y, meta):
    """Report label distribution by class and by split."""
    id_to_label = meta["label"].drop_duplicates()
    logger.info("Label distribution (by window count):")
    unique, counts = np.unique(y, return_counts=True)
    total = len(y)
    for u, c in zip(unique, counts):
        label_name = meta[meta["class_id"] == u]["label"].iloc[0] if len(meta[meta["class_id"] == u]) > 0 else "?"
        logger.info("  %s (class %d): %d (%.1f%%)", label_name, u, c, 100 * c / total)

    # By event count (not window count)
    if "event_id" in meta.columns:
        event_counts = meta.groupby("event_id")["label"].first().value_counts()
        logger.info("Label distribution (by unique event count):")
        for label, c in event_counts.items():
            logger.info("  %s: %d events", label, c)

    # Split distribution
    if "split" in meta.columns and meta["split"].notna().any():
        split_counts = meta["split"].value_counts()
        logger.info("Split distribution:")
        for s, c in split_counts.items():
            logger.info("  %s: %d samples", s, c)


def check_video_isolation(meta):
    """Ensure same video_id does not appear in multiple splits."""
    if "split" not in meta.columns or meta["split"].isna().all():
        logger.warning("No split column in meta; skipping video isolation check")
        return True

    video_splits = meta.groupby("video_id")["split"].unique()
    leaks = []
    for vid, splits in video_splits.items():
        if len(splits) > 1:
            leaks.append((vid, list(splits)))
    if leaks:
        logger.error("DATA LEAK: same video appears in multiple splits!")
        for vid, splits in leaks:
            logger.error("  video_id=%s splits=%s", vid, splits)
        return False
    logger.info("Video isolation check: OK (no cross-split leakage)")
    return True


def check_missing_frame_ratios(meta, threshold=0.20):
    """Report windows with high missing frame ratios."""
    if "missing_frame_ratio" not in meta.columns:
        return True
    high_missing = meta[meta["missing_frame_ratio"] > threshold]
    if len(high_missing) > 0:
        logger.warning("%d windows have missing_frame_ratio > %.2f",
                       len(high_missing), threshold)
    else:
        logger.info("Missing frame ratio check: all windows <= %.2f", threshold)
    return True


def main():
    parser = argparse.ArgumentParser(description="Dataset quality checks")
    parser.add_argument("--x", default="data/processed/X.npy")
    parser.add_argument("--y", default="data/processed/y.npy")
    parser.add_argument("--meta", default="data/processed/meta.csv")
    parser.add_argument("--schema", default=None)
    args = parser.parse_args()

    logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")

    x_path = os.path.join(_PROJ_ROOT, args.x)
    y_path = os.path.join(_PROJ_ROOT, args.y)
    meta_path = os.path.join(_PROJ_ROOT, args.meta)

    for p, name in [(x_path, "X"), (y_path, "y"), (meta_path, "meta")]:
        if not os.path.exists(p):
            logger.error("%s not found: %s", name, p)
            sys.exit(1)

    X = np.load(x_path)
    y = np.load(y_path)
    meta = pd.read_csv(meta_path)

    print("\n" + "=" * 60)
    print("Dataset Quality Report")
    print("=" * 60)

    results = {}
    results["counts"] = check_counts(X, y, meta)
    results["nan_inf"] = check_nan_inf(X)
    results["feature_dim"] = check_feature_dim(X)
    results["label_range"] = check_label_range(y)
    results["video_isolation"] = check_video_isolation(meta)
    results["missing_frames"] = check_missing_frame_ratios(meta)

    check_label_distribution(y, meta)

    # Schema check
    if args.schema:
        schema_path = os.path.join(_PROJ_ROOT, args.schema)
        if os.path.exists(schema_path):
            with open(schema_path) as f:
                schema = json.load(f)
            if schema.get("feature_dim") == FEATURE_DIM:
                logger.info("Feature schema consistency: OK (dim=%d)", FEATURE_DIM)
            else:
                logger.error("Feature schema dimension mismatch!")

    print("=" * 60)
    all_ok = all(results.values())
    print(f"Overall: {'ALL CHECKS PASSED' if all_ok else 'SOME CHECKS FAILED'}")
    print("=" * 60 + "\n")


if __name__ == "__main__":
    main()
