"""
train_gru.py

Train the DrowningGRUClassifier on pre-extracted sequences.

Usage:
    python src/train_gru.py \
        --x data/processed/X.npy \
        --y data/processed/y.npy \
        --epochs 50 \
        --batch-size 32 \
        --lr 0.001 \
        --save outputs/models/best_gru.pth
"""

from __future__ import annotations

import argparse
import logging
import os
import sys

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, Dataset
from sklearn.model_selection import train_test_split
from sklearn.metrics import f1_score

_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
_PROJ_ROOT = os.path.dirname(_THIS_DIR)
if _PROJ_ROOT not in sys.path:
    sys.path.insert(0, _PROJ_ROOT)

from src.config import (
    FEATURE_DIM,
    NUM_CLASSES,
    SEQ_LEN,
    GRU_HIDDEN_SIZE,
    GRU_NUM_LAYERS,
    GRU_DROPOUT,
    BATCH_SIZE,
    LEARNING_RATE,
    EPOCHS,
    TRAIN_VAL_SPLIT,
    USE_CLASS_WEIGHT,
    DEFAULT_X_PATH,
    DEFAULT_Y_PATH,
    DEFAULT_MODEL_SAVE,
    DEFAULT_TRAIN_LOG,
)
from src.models.gru_classifier import DrowningGRUClassifier

logger = logging.getLogger(__name__)


class SequenceDataset(Dataset):
    """Thin wrapper around X.npy / y.npy for DataLoader."""

    def __init__(self, X, y):
        self.X = torch.from_numpy(X).float()
        self.y = torch.from_numpy(y).long()

    def __len__(self):
        return len(self.X)

    def __getitem__(self, idx):
        return self.X[idx], self.y[idx]


def _compute_accuracy(logits, labels):
    preds = logits.argmax(dim=1)
    return (preds == labels).float().mean().item()


def _train_one_epoch(model, loader, criterion, optimizer, device):
    model.train()
    total_loss = 0.0
    total_acc = 0.0
    for X_batch, y_batch in loader:
        X_batch, y_batch = X_batch.to(device), y_batch.to(device)
        optimizer.zero_grad()
        logits = model(X_batch)
        loss = criterion(logits, y_batch)
        loss.backward()
        optimizer.step()
        total_loss += loss.item() * X_batch.size(0)
        total_acc += _compute_accuracy(logits, y_batch) * X_batch.size(0)
    n = len(loader.dataset)
    return total_loss / n, total_acc / n


@torch.no_grad()
def _eval_one_epoch(model, loader, criterion, device):
    model.eval()
    total_loss = 0.0
    total_acc = 0.0
    all_preds = []
    all_labels = []
    for X_batch, y_batch in loader:
        X_batch, y_batch = X_batch.to(device), y_batch.to(device)
        logits = model(X_batch)
        loss = criterion(logits, y_batch)
        total_loss += loss.item() * X_batch.size(0)
        total_acc += _compute_accuracy(logits, y_batch) * X_batch.size(0)
        all_preds.append(logits.argmax(dim=1).cpu())
        all_labels.append(y_batch.cpu())
    n = len(loader.dataset)
    all_preds = torch.cat(all_preds).numpy()
    all_labels = torch.cat(all_labels).numpy()
    val_f1 = f1_score(all_labels, all_preds, average="macro", zero_division=0)
    return total_loss / n, total_acc / n, val_f1


def main():
    parser = argparse.ArgumentParser(description="Train GRU drowning classifier")
    parser.add_argument("--x", default=DEFAULT_X_PATH)
    parser.add_argument("--y", default=DEFAULT_Y_PATH)
    parser.add_argument("--epochs", type=int, default=EPOCHS)
    parser.add_argument("--batch-size", type=int, default=BATCH_SIZE)
    parser.add_argument("--lr", type=float, default=LEARNING_RATE)
    parser.add_argument("--save", default=DEFAULT_MODEL_SAVE)
    parser.add_argument("--device", default=None)
    args = parser.parse_args()

    logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")

    if args.device is None:
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    else:
        device = torch.device(args.device)
    logger.info("Using device: %s", device)

    if not os.path.exists(args.x) or not os.path.exists(args.y):
        logger.error("X.npy or y.npy not found. Run extract_sequences.py first.")
        sys.exit(1)

    X = np.load(args.x)
    y = np.load(args.y)

    if X.shape[0] != y.shape[0]:
        logger.error("Mismatch: X=%d y=%d", X.shape[0], y.shape[0])
        sys.exit(1)

    logger.info("Loaded X: %s  y: %s", X.shape, y.shape)

    if X.shape[0] == 0:
        logger.error("Zero samples in X.npy. Extract sequences first.")
        sys.exit(1)

    unique, counts = np.unique(y, return_counts=True)
    min_count = counts.min()
    if min_count < 2:
        logger.error("Need >=2 samples per class for stratified split. Min is %d.", min_count)
        sys.exit(1)

    X_train, X_val, y_train, y_val = train_test_split(
        X, y, train_size=TRAIN_VAL_SPLIT, stratify=y, random_state=42
    )
    logger.info("Train: %d  Val: %d", len(X_train), len(X_val))

    train_ds = SequenceDataset(X_train, y_train)
    val_ds = SequenceDataset(X_val, y_val)
    train_loader = DataLoader(train_ds, batch_size=args.batch_size, shuffle=True)
    val_loader = DataLoader(val_ds, batch_size=args.batch_size, shuffle=False)

    model = DrowningGRUClassifier(
        input_size=FEATURE_DIM,
        hidden_size=GRU_HIDDEN_SIZE,
        num_layers=GRU_NUM_LAYERS,
        dropout=GRU_DROPOUT,
        num_classes=NUM_CLASSES,
    ).to(device)

    if USE_CLASS_WEIGHT:
        class_counts = np.bincount(y_train, minlength=NUM_CLASSES)
        class_weights = 1.0 / (class_counts + 1e-6)
        class_weights = class_weights / class_weights.sum() * NUM_CLASSES
        class_weights_t = torch.tensor(class_weights, dtype=torch.float32).to(device)
        logger.info("Class weights: %s", class_weights)
    else:
        class_weights_t = None

    criterion = nn.CrossEntropyLoss(weight=class_weights_t)
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)

    best_val_f1 = -1.0
    log_rows = []

    for epoch in range(1, args.epochs + 1):
        train_loss, train_acc = _train_one_epoch(model, train_loader, criterion, optimizer, device)
        val_loss, val_acc, val_f1 = _eval_one_epoch(model, val_loader, criterion, device)
        log_rows.append({
            "epoch": epoch, "train_loss": train_loss, "train_acc": train_acc,
            "val_loss": val_loss, "val_acc": val_acc, "val_f1": val_f1,
        })
        logger.info("Epoch %3d | tr_loss:%.4f tr_acc:%.4f | vl_loss:%.4f vl_acc:%.4f vl_f1:%.4f",
                     epoch, train_loss, train_acc, val_loss, val_acc, val_f1)

        if val_f1 > best_val_f1:
            best_val_f1 = val_f1
            os.makedirs(os.path.dirname(args.save), exist_ok=True)
            torch.save(model.state_dict(), args.save)
            logger.info("  -> saved best model (val_f1=%.4f)", val_f1)

    logger.info("Training complete. Best val_f1: %.4f", best_val_f1)

    os.makedirs(os.path.dirname(DEFAULT_TRAIN_LOG), exist_ok=True)
    pd.DataFrame(log_rows).to_csv(DEFAULT_TRAIN_LOG, index=False)
    logger.info("Log saved to %s", DEFAULT_TRAIN_LOG)


if __name__ == "__main__":
    main()
