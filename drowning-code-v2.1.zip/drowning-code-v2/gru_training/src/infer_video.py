"""
infer_video.py

End-to-end inference on a full video:
  YOLO-Pose + ByteTrack → per-track feature buffer → GRU → annotated output.

Usage:
    python src/infer_video.py \
        --video data/test.mp4 \
        --gru outputs/models/best_gru.pth \
        --pose-model yolo11n-pose.pt \
        --save outputs/videos/result.mp4
"""

from __future__ import annotations

import argparse
import logging
import os
import sys
from collections import defaultdict, deque

import cv2
import numpy as np
import torch

_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
_PROJ_ROOT = os.path.dirname(_THIS_DIR)
if _PROJ_ROOT not in sys.path:
    sys.path.insert(0, _PROJ_ROOT)

from src.config import (
    FEATURE_DIM,
    NUM_CLASSES,
    SEQ_LEN,
    GRU_HIDDEN_SIZE,
    GRU_NUM_LAYERS,
    GRU_DROPOUT,
    ID_TO_LABEL,
    LABEL_MAP,
    DROWNING_THRESHOLD,
    ALARM_CONSECUTIVE_COUNT,
    DEFAULT_POSE_MODEL,
    TRACKER_CONFIG,
    VIDEOS_DIR,
    load_pose_model,
)
from src.models.gru_classifier import DrowningGRUClassifier
from src.utils.features import extract_frame_feature, build_sequence
from src.utils.video import open_video, get_video_properties
from src.utils.visualization import draw_bbox, draw_label, draw_alert

logger = logging.getLogger(__name__)

# Colours for each class (BGR)
CLASS_COLORS = {
    0: (0, 255, 0),    # Swimming → green
    1: (255, 255, 0),  # Idle in water → cyan
    2: (0, 0, 255),    # Drowning → red
    3: (255, 165, 0),  # Person out of water → orange
}


def _get_all_person_dets(result):
    """
    Extract all person (class 0) detections with track_ids and keypoints.

    Returns list of dicts with keys: xyxy, xywh, keypoints, track_id.
    """
    dets = []
    if result.boxes is None:
        return dets

    try:
        cls_ids = result.boxes.cls
        if cls_ids is None or len(cls_ids) == 0:
            return dets
        cls_ids = cls_ids.cpu().numpy()
    except Exception:
        return dets

    ids = None
    if result.boxes.id is not None:
        try:
            ids = result.boxes.id.cpu().numpy().astype(int)
        except Exception:
            pass

    for i, c in enumerate(cls_ids):
        if int(c) != 0:
            continue
        try:
            xyxy = result.boxes.xyxy[i].cpu().numpy()
            xywh = result.boxes.xywh[i].cpu().numpy() if result.boxes.xywh is not None else None
        except Exception:
            continue

        det = {
            "xyxy": xyxy,
            "xywh": xywh,
            "keypoints": None,
            "track_id": int(ids[i]) if ids is not None and i < len(ids) else i,
        }
        if result.keypoints is not None and result.keypoints.data is not None:
            try:
                det["keypoints"] = result.keypoints.data[i].cpu().numpy()
            except Exception:
                pass
        dets.append(det)

    return dets


def main():
    parser = argparse.ArgumentParser(description="Drowning detection video inference")
    parser.add_argument("--video", default="D:/Videos/Drowning/41.mp4", help="Path to input video (prompts if omitted)")
    parser.add_argument("--gru", default="outputs/models/best_gru_best.pth", help="Path to GRU weights")
    parser.add_argument("--pose-model", default=DEFAULT_POSE_MODEL)
    parser.add_argument("--save", default=None, help="Output video path (auto-generated if omitted)")
    parser.add_argument("--device", default=None)
    parser.add_argument("--no-display", action="store_true",
                        help="Don't show preview window (default: hidden on server)")
    args = parser.parse_args()

    logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")

    # ── Prompt for video if not provided ──────────────────────────────────
    if args.video is None:
        args.video = input("Enter video path: ").strip()
        if not args.video:
            logger.error("No video path provided.")
            sys.exit(1)

    # ── Device ───────────────────────────────────────────────────────────
    if args.device is None:
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    else:
        device = torch.device(args.device)
    logger.info("Using device: %s", device)

    # ── Load GRU model ───────────────────────────────────────────────────
    if not os.path.exists(args.gru):
        logger.error("GRU weights not found: %s", args.gru)
        sys.exit(1)

    gru_model = DrowningGRUClassifier(
        input_size=FEATURE_DIM,
        hidden_size=GRU_HIDDEN_SIZE,
        num_layers=GRU_NUM_LAYERS,
        dropout=GRU_DROPOUT,
        num_classes=NUM_CLASSES,
    )
    gru_model.load_state_dict(torch.load(args.gru, map_location=device))
    gru_model.to(device)
    gru_model.eval()
    logger.info("Loaded GRU model: %s", args.gru)

    # ── Load YOLO-Pose ───────────────────────────────────────────────────
    try:
        pose_model, actual_model = load_pose_model(args.pose_model)
        logger.info("Loaded pose model: %s", actual_model)
    except Exception as e:
        logger.error("Failed to load any pose model: %s", e)
        sys.exit(1)

    # ── Open video (properties only; tracking reads the file itself) ─────
    cap = open_video(args.video)
    if cap is None:
        sys.exit(1)

    props = get_video_properties(cap)
    cap.release()  # we only needed properties; track() opens its own reader

    logger.info("Video: %dx%d @ %.1f fps, %d frames",
                 props["width"], props["height"], props["fps"], props["frame_count"])

    # ── Output video ─────────────────────────────────────────────────────
    if args.save is None:
        base_name = os.path.splitext(os.path.basename(args.video))[0]
        args.save = os.path.join(VIDEOS_DIR, f"{base_name}_result.mp4")

    os.makedirs(os.path.dirname(args.save), exist_ok=True)
    fourcc = cv2.VideoWriter_fourcc(*"mp4v")
    out_writer = cv2.VideoWriter(
        args.save, fourcc, props["fps"], (props["width"], props["height"])
    )
    if not out_writer.isOpened():
        logger.error("Cannot open VideoWriter for %s", args.save)
        sys.exit(1)

    # ── State ────────────────────────────────────────────────────────────
    # Per-track_id: deque of frame features
    track_buffers: dict[int, deque] = defaultdict(lambda: deque(maxlen=SEQ_LEN))
    # Per-track_id: last prediction info
    track_predictions: dict[int, dict] = {}
    # Per-track_id: consecutive drowning frame counter
    track_alarm_counters: dict[int, int] = defaultdict(int)
    # Total frame counter
    frame_idx = 0

    logger.info("Starting inference...")

    try:
        results_gen = pose_model.track(
            source=args.video,
            tracker=TRACKER_CONFIG,
            stream=True,
            persist=True,
            verbose=False,
        )
    except Exception as e:
        logger.error("track() failed: %s", e)
        out_writer.release()
        sys.exit(1)

    w, h = props["width"], props["height"]

    for result in results_gen:
        # result.orig_img is the raw frame (BGR) that YOLO processed
        frame = result.orig_img
        if frame is None:
            continue

        dets = _get_all_person_dets(result)

        for det in dets:
            tid = det["track_id"]
            xyxy = det["xyxy"]
            xywh = det["xywh"]
            kpts = det["keypoints"]

            # Build & store feature
            feat = extract_frame_feature(xywh, kpts, w, h)
            track_buffers[tid].append(feat)

            # ── Draw bounding box ────────────────────────────────────────
            color = CLASS_COLORS.get(
                track_predictions.get(tid, {}).get("class", 0), (0, 255, 0)
            )
            draw_bbox(frame, xyxy, tid, color=color)

            # ── Predict when buffer is full ──────────────────────────────
            if len(track_buffers[tid]) >= SEQ_LEN:
                seq = build_sequence(track_buffers[tid])  # [seq_len, 55]
                seq_t = torch.from_numpy(seq).float().unsqueeze(0).to(device)  # [1, seq_len, 55]

                with torch.no_grad():
                    logits = gru_model(seq_t)
                    probs = torch.softmax(logits, dim=1).cpu().numpy()[0]

                pred_class = int(np.argmax(probs))
                pred_conf = float(probs[pred_class])
                drowning_conf = float(probs[LABEL_MAP["Drowning"]])

                track_predictions[tid] = {
                    "class": pred_class,
                    "confidence": pred_conf,
                    "probabilities": probs,
                }

                # ── Alarm logic ──────────────────────────────────────────
                if drowning_conf >= DROWNING_THRESHOLD:
                    track_alarm_counters[tid] += 1
                else:
                    track_alarm_counters[tid] = 0

            # ── Draw prediction label ────────────────────────────────────
            if tid in track_predictions:
                pred = track_predictions[tid]
                label_text = f"{ID_TO_LABEL[pred['class']]} {pred['confidence']:.2f}"
                draw_label(
                    frame, label_text,
                    position=(int(xyxy[0]), int(xyxy[1]) - 8),
                    color=(255, 255, 255),
                    bg_color=CLASS_COLORS.get(pred["class"], (0, 255, 0)),
                )

            # ── Draw alert if alarm active ───────────────────────────────
            if track_alarm_counters.get(tid, 0) >= ALARM_CONSECUTIVE_COUNT:
                draw_alert(frame)
                # Also log to console
                logger.warning(
                    "ALERT: suspected drowning | track_id=%d | frame=%d | prob=%.3f",
                    tid, frame_idx,
                    track_predictions.get(tid, {}).get("probabilities", [0]*NUM_CLASSES)[LABEL_MAP["Drowning"]],
                )

        # Status bar at bottom
        status = f"Frame: {frame_idx} | Tracks: {len(dets)}"
        cv2.putText(frame, status, (10, h - 12),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (200, 200, 200), 1)

        out_writer.write(frame)

        if not args.no_display:
            cv2.imshow("Drowning Detection", frame)
            if cv2.waitKey(1) & 0xFF == ord("q"):
                break

        frame_idx += 1

    # ── Cleanup ──────────────────────────────────────────────────────────
    out_writer.release()
    cv2.destroyAllWindows()

    logger.info("Done. %d frames processed. Output saved to: %s", frame_idx, args.save)


if __name__ == "__main__":
    main()
