"""
build_gru_dataset.py

Align events.csv (human annotations) with keypoints.csv (pre-tracked features)
to produce training-ready X.npy / y.npy / meta.csv.

Usage:
    python src/build_gru_dataset.py \
        --events data/annotations/events.csv \
        --keypoints data/pretrack \
        --output data/processed \
        --seq-len 32 \
        --stride 8
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import sys
from collections import defaultdict

import numpy as np
import pandas as pd
from tqdm import tqdm

_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
_PROJ_ROOT = os.path.dirname(_THIS_DIR)
if _PROJ_ROOT not in sys.path:
    sys.path.insert(0, _PROJ_ROOT)

from src.config import (
    LABEL_MAP,
    SEQ_LEN,
    STRIDE,
    FEATURE_DIM,
    NUM_KEYPOINTS,
    KPT_DIM,
)

logger = logging.getLogger(__name__)

# KPT column names consistent with pretrack_videos.py
KPT_NAMES = [
    "nose", "left_eye", "right_eye", "left_ear", "right_ear",
    "left_shoulder", "right_shoulder", "left_elbow", "right_elbow",
    "left_wrist", "right_wrist", "left_hip", "right_hip",
    "left_knee", "right_knee", "left_ankle", "right_ankle",
]

BBOX_COLS = ["bbox_x_center", "bbox_y_center", "bbox_width", "bbox_height"]


def _build_kpt_cols():
    """Return ordered list of keypoint column names matching FEATURE_DIM layout."""
    cols = []
    for i in range(NUM_KEYPOINTS):
        cols.append(f"kp{i}_x")
        cols.append(f"kp{i}_y")
        cols.append(f"kp{i}_conf")
    return cols


def _load_keypoints_table(keypoints_dir, video_id):
    """Load the keypoints CSV for a given video_id."""
    csv_path = os.path.join(keypoints_dir, f"{video_id}_keypoints.csv")
    if not os.path.exists(csv_path):
        return None
    return pd.read_csv(csv_path)


def _extract_sequence(kpt_df, track_id, start_frame, end_frame):
    """
    Extract a temporal sequence for one track, one frame range.

    Returns np.ndarray shape [T, 55] or None if no valid data.
    """
    mask = (
        (kpt_df["track_id"] == track_id)
        & (kpt_df["frame_id"] >= start_frame)
        & (kpt_df["frame_id"] <= end_frame)
    )
    sub = kpt_df[mask].sort_values("frame_id")

    if len(sub) == 0:
        return None

    # Build feature matrix
    kpt_cols = _build_kpt_cols()
    features = np.zeros((len(sub), FEATURE_DIM), dtype=np.float32)

    for idx, (_, row) in enumerate(sub.iterrows()):
        # Keypoints (first 51 dims)
        for j, col in enumerate(kpt_cols):
            val = row.get(col, np.nan)
            if pd.isna(val):
                val = 0.0
            features[idx, j] = float(val)

        # Bbox (last 4 dims)
        for j, col in enumerate(BBOX_COLS):
            val = row.get(col, np.nan)
            if pd.isna(val):
                val = 0.0
            features[idx, 51 + j] = float(val)

    return features


def _check_window_quality(seq, missing_frame_ratio=0.20, min_keypoint_conf=0.30):
    """
    Check if a window meets quality thresholds.

    Returns (ok, missing_ratio, mean_kpt_conf).
    """
    if seq is None or seq.shape[0] == 0:
        return False, 1.0, 0.0

    # Count frames with all-zero features as "missing"
    missing_count = int(np.sum(np.all(seq == 0, axis=1)))
    missing_ratio = missing_count / seq.shape[0]

    # Mean confidence across all keypoints (every 3rd element starting at index 2)
    confs = []
    for i in range(NUM_KEYPOINTS):
        conf_idx = i * 3 + 2
        if conf_idx < FEATURE_DIM:
            confs.extend(seq[:, conf_idx].tolist())
    mean_conf = float(np.mean(confs)) if confs else 0.0

    ok = (missing_ratio <= missing_frame_ratio) and (mean_conf >= min_keypoint_conf)
    return ok, missing_ratio, mean_conf


def _sliding_windows(features, seq_len, stride):
    """Generate (start, end, window) tuples."""
    t = features.shape[0]
    windows = []
    for start in range(0, t - seq_len + 1, stride):
        end = start + seq_len
        windows.append((start, end, features[start:end].copy()))
    return windows


def main():
    parser = argparse.ArgumentParser(description="Build GRU dataset from events + keypoints")
    parser.add_argument("--events", default="data/annotations/events.csv")
    parser.add_argument("--keypoints", default="data/pretrack")
    parser.add_argument("--output", default="data/processed")
    parser.add_argument("--seq-len", type=int, default=SEQ_LEN)
    parser.add_argument("--stride", type=int, default=STRIDE)
    parser.add_argument("--missing-frame-ratio", type=float, default=0.20)
    parser.add_argument("--min-keypoint-conf", type=float, default=0.30)
    args = parser.parse_args()

    logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")

    events_path = os.path.join(_PROJ_ROOT, args.events)
    keypoints_dir = os.path.join(_PROJ_ROOT, args.keypoints)
    output_dir = os.path.join(_PROJ_ROOT, args.output)
    os.makedirs(output_dir, exist_ok=True)

    # ── Load events ────────────────────────────────────────────────────
    if not os.path.exists(events_path):
        logger.error("events.csv not found: %s", events_path)
        sys.exit(1)

    events = pd.read_csv(events_path)
    required_cols = {"video_id", "track_id", "start_frame", "end_frame", "label",
                     "split", "usable"}
    missing_cols = required_cols - set(events.columns)
    if missing_cols:
        logger.error("events.csv is missing columns: %s", missing_cols)
        sys.exit(1)

    # Filter usable events
    events = events[(events["usable"] == 1) & (events["label"] != "uncertain")].copy()
    if len(events) == 0:
        logger.error("No usable events after filtering (usable=1, label!=uncertain)")
        sys.exit(1)

    logger.info("Loaded %d usable events from %s", len(events), events_path)

    # ── Build dataset ──────────────────────────────────────────────────
    all_X = []
    all_y = []
    meta_rows = []
    rejected_count = 0

    for _, event in tqdm(events.iterrows(), desc="Processing events", total=len(events)):
        video_id = event["video_id"]
        track_id = int(event["track_id"])
        start_frame = int(event["start_frame"])
        end_frame = int(event["end_frame"])
        label_str = str(event["label"]).strip()
        split = str(event["split"]).strip()

        # Validate label
        label_lower = label_str.lower()
        class_id = None
        for key, val in LABEL_MAP.items():
            if key.lower() == label_lower:
                class_id = val
                break
        if class_id is None:
            logger.warning("Unknown label '%s' for event, skipping", label_str)
            continue

        # Load keypoints
        kpt_df = _load_keypoints_table(keypoints_dir, video_id)
        if kpt_df is None:
            logger.warning("No keypoints CSV for video_id=%s, skipping event", video_id)
            continue

        # Extract sequence
        features = _extract_sequence(kpt_df, track_id, start_frame, end_frame)
        if features is None or features.shape[0] < args.seq_len:
            logger.debug(
                "Event video=%s track=%d has only %d frames (< %d), skipping",
                video_id, track_id,
                features.shape[0] if features is not None else 0, args.seq_len,
            )
            continue

        # Sliding windows
        windows = _sliding_windows(features, args.seq_len, args.stride)
        for w_start, w_end, window in windows:
            ok, miss_ratio, mean_conf = _check_window_quality(
                window, args.missing_frame_ratio, args.min_keypoint_conf
            )
            if not ok:
                rejected_count += 1
                continue

            all_X.append(window)
            all_y.append(class_id)
            meta_rows.append({
                "sample_id": len(all_X) - 1,
                "event_id": event.get("event_id", ""),
                "video_id": video_id,
                "track_id": track_id,
                "start_frame": start_frame + w_start,
                "end_frame": start_frame + w_end,
                "label": label_str,
                "class_id": class_id,
                "split": split,
                "missing_frame_ratio": round(miss_ratio, 4),
                "mean_keypoint_conf": round(mean_conf, 4),
            })

    # ── Check results ──────────────────────────────────────────────────
    if not all_X:
        logger.error("No sequences built. Check that events match keypoints data.")
        sys.exit(1)

    X = np.stack(all_X, axis=0).astype(np.float32)
    y = np.array(all_y, dtype=np.int64)

    logger.info("Built %d sequences (rejected %d bad windows)", len(all_X), rejected_count)
    logger.info("X shape: %s, y shape: %s", X.shape, y.shape)

    # ── Save ───────────────────────────────────────────────────────────
    np.save(os.path.join(output_dir, "X.npy"), X)
    np.save(os.path.join(output_dir, "y.npy"), y)

    meta_df = pd.DataFrame(meta_rows)
    meta_df.to_csv(os.path.join(output_dir, "meta.csv"), index=False)

    # label_map.json
    with open(os.path.join(output_dir, "label_map.json"), "w") as f:
        json.dump(LABEL_MAP, f, indent=2)

    # feature_schema.json
    kpt_cols = _build_kpt_cols()
    schema = {
        "feature_dim": FEATURE_DIM,
        "layout": {
            "keypoints": {f"dim_{i}": name for i, name in enumerate(kpt_cols)},
            "bbox": {
                "dim_51": "bbox_x_center",
                "dim_52": "bbox_y_center",
                "dim_53": "bbox_width",
                "dim_54": "bbox_height",
            },
        },
        "keypoint_names": KPT_NAMES,
        "normalisation": "all coordinates normalised to [0, 1]",
    }
    with open(os.path.join(output_dir, "feature_schema.json"), "w") as f:
        json.dump(schema, f, indent=2)

    # Distribution summary
    unique, counts = np.unique(y, return_counts=True)
    logger.info("Label distribution:")
    for u, c in zip(unique, counts):
        id_to_label = {v: k for k, v in LABEL_MAP.items()}
        logger.info("  %s (class %d): %d samples", id_to_label.get(u, "?"), u, c)

    split_dist = meta_df["split"].value_counts().to_dict()
    logger.info("Split distribution: %s", split_dist)

    logger.info("Saved to: %s", output_dir)


if __name__ == "__main__":
    main()
