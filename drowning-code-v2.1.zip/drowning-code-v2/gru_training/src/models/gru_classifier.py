"""
GRU-based temporal classifier for drowning behaviour recognition.

Input:  [batch_size, seq_len, feature_dim]  e.g. [B, 32, 55]
Output: [batch_size, num_classes]           logits
"""

import torch
import torch.nn as nn


class DrowningGRUClassifier(nn.Module):
    """
    Two-layer GRU with dropout, followed by a Linear classification head.

    Parameters
    ----------
    input_size : int   – feature dimension per frame (default 55)
    hidden_size : int  – GRU hidden state size (default 128)
    num_layers : int   – stacked GRU layers (default 2)
    dropout : float    – inter-layer dropout (default 0.3)
    num_classes : int  – output classes (default 3)
    """

    def __init__(
        self,
        input_size=55,
        hidden_size=128,
        num_layers=2,
        dropout=0.3,
        num_classes=3,
    ):
        super().__init__()
        self.hidden_size = hidden_size
        self.num_layers = num_layers

        self.gru = nn.GRU(
            input_size=input_size,
            hidden_size=hidden_size,
            num_layers=num_layers,
            batch_first=True,
            dropout=dropout if num_layers > 1 else 0.0,
        )
        self.classifier = nn.Linear(hidden_size, num_classes)

    def forward(self, x):
        """
        Parameters
        ----------
        x : torch.Tensor, shape [batch_size, seq_len, input_size]

        Returns
        -------
        logits : torch.Tensor, shape [batch_size, num_classes]
        """
        # GRU outputs: out [B, seq_len, hidden], h_n [num_layers, B, hidden]
        out, _ = self.gru(x)
        # Use the last time-step's output for classification
        last_out = out[:, -1, :]            # [B, hidden_size]
        logits = self.classifier(last_out)  # [B, num_classes]
        return logits
