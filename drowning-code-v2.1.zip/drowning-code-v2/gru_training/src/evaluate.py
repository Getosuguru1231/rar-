"""
evaluate.py

Evaluate a trained GRU classifier on held-out sequences.

Usage:
    python src/evaluate.py \
        --x data/processed/X.npy \
        --y data/processed/y.npy \
        --model outputs/models/best_gru.pth
"""

from __future__ import annotations

import argparse
import logging
import os
import sys

import numpy as np
import torch
from torch.utils.data import DataLoader

_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
_PROJ_ROOT = os.path.dirname(_THIS_DIR)
if _PROJ_ROOT not in sys.path:
    sys.path.insert(0, _PROJ_ROOT)

from src.config import (
    FEATURE_DIM,
    NUM_CLASSES,
    GRU_HIDDEN_SIZE,
    GRU_NUM_LAYERS,
    GRU_DROPOUT,
    BATCH_SIZE,
    ID_TO_LABEL,
    DEFAULT_X_PATH,
    DEFAULT_Y_PATH,
    DEFAULT_MODEL_SAVE,
    DEFAULT_CM_PLOT,
)
from src.models.gru_classifier import DrowningGRUClassifier
from src.utils.metrics import compute_metrics, plot_confusion_matrix

logger = logging.getLogger(__name__)


def main():
    parser = argparse.ArgumentParser(description="Evaluate GRU drowning classifier")
    parser.add_argument("--x", default=DEFAULT_X_PATH)
    parser.add_argument("--y", default=DEFAULT_Y_PATH)
    parser.add_argument("--model", default=DEFAULT_MODEL_SAVE)
    parser.add_argument("--batch-size", type=int, default=BATCH_SIZE)
    parser.add_argument("--device", default=None)
    args = parser.parse_args()

    logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")

    # ── Device ───────────────────────────────────────────────────────────
    if args.device is None:
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    else:
        device = torch.device(args.device)
    logger.info("Using device: %s", device)

    # ── Load data ────────────────────────────────────────────────────────
    if not os.path.exists(args.x) or not os.path.exists(args.y):
        logger.error("X.npy / y.npy not found.")
        sys.exit(1)

    X = np.load(args.x)
    y = np.load(args.y)

    if X.shape[0] != y.shape[0]:
        logger.error("X and y sample counts do not match.")
        sys.exit(1)

    logger.info("Loaded X: %s  y: %s", X.shape, y.shape)

    # ── Load model ───────────────────────────────────────────────────────
    if not os.path.exists(args.model):
        logger.error("Model weights not found: %s", args.model)
        sys.exit(1)

    model = DrowningGRUClassifier(
        input_size=FEATURE_DIM,
        hidden_size=GRU_HIDDEN_SIZE,
        num_layers=GRU_NUM_LAYERS,
        dropout=GRU_DROPOUT,
        num_classes=NUM_CLASSES,
    )
    model.load_state_dict(torch.load(args.model, map_location=device))
    model.to(device)
    model.eval()
    logger.info("Loaded model: %s", args.model)

    # ── Inference ────────────────────────────────────────────────────────
    X_t = torch.from_numpy(X).float()
    y_t = torch.from_numpy(y).long()

    all_preds = []
    loader = DataLoader(
        list(zip(X_t, y_t)), batch_size=args.batch_size, shuffle=False
    )

    with torch.no_grad():
        for X_batch, _ in loader:
            X_batch = X_batch.to(device)
            logits = model(X_batch)
            preds = logits.argmax(dim=1).cpu().numpy()
            all_preds.append(preds)

    y_pred = np.concatenate(all_preds)

    # ── Metrics ──────────────────────────────────────────────────────────
    metrics = compute_metrics(y, y_pred, average="macro")
    print("\n" + "=" * 50)
    print("Evaluation Results")
    print("=" * 50)
    print(f"Accuracy : {metrics['accuracy']:.4f}")
    print(f"Precision: {metrics['precision']:.4f}  (macro)")
    print(f"Recall   : {metrics['recall']:.4f}  (macro)")
    print(f"F1-score : {metrics['f1']:.4f}  (macro)")
    print("Confusion Matrix:")
    print(metrics["confusion_matrix"])
    print("=" * 50)

    # ── Confusion matrix plot ────────────────────────────────────────────
    os.makedirs(os.path.dirname(DEFAULT_CM_PLOT), exist_ok=True)
    plot_confusion_matrix(y, y_pred, ID_TO_LABEL, DEFAULT_CM_PLOT)


if __name__ == "__main__":
    main()
