"""
generate_events.py

Generate a pre-filled events.csv from the keypoints.csv files produced by
pretrack_videos.py.  Produces one event per (video, track_id) pair with at
least 32 frames, auto-filling everything except *label* and *split*.

Usage:
    python src/generate_events.py
"""

from __future__ import annotations

import logging
import os
import sys
from pathlib import Path

import pandas as pd

_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
_PROJ_ROOT = os.path.dirname(_THIS_DIR)
if _PROJ_ROOT not in sys.path:
    sys.path.insert(0, _PROJ_ROOT)

from src.config import PRETRACK_DIR, EVENTS_CSV  # ── see below for config additions

logger = logging.getLogger(__name__)


# ────────────────────────────────────────────────────────────────────────
#  helper: human-readable time
# ────────────────────────────────────────────────────────────────────────

def _format_seconds(seconds: float) -> str:
    """seconds → HH:MM:SS.mmm"""
    h = int(seconds // 3600)
    m = int((seconds % 3600) // 60)
    s = int(seconds % 60)
    ms = int(round((seconds - int(seconds)) * 1000))
    if ms >= 1000:
        ms -= 1000
        s += 1
    return f"{h:02d}:{m:02d}:{s:02d}.{ms:03d}"


# ────────────────────────────────────────────────────────────────────────
#  main
# ────────────────────────────────────────────────────────────────────────

def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")

    pretrack_dir = os.path.join(_PROJ_ROOT, PRETRACK_DIR)
    events_path  = os.path.join(_PROJ_ROOT, EVENTS_CSV)

    # ── 1.  collect all keypoints CSVs ──────────────────────────────────
    kpt_files = sorted(Path(pretrack_dir).glob("*_keypoints.csv"))
    if not kpt_files:
        logger.error("No _keypoints.csv files found in %s", pretrack_dir)
        sys.exit(1)

    logger.info("Found %d keypoints files", len(kpt_files))

    # ── 2.  load existing labels (preserve user work) ───────────────────
    existing_labels: dict[tuple[str, int], dict] = {}
    if os.path.exists(events_path):
        old = pd.read_csv(events_path)
        for _, row in old.iterrows():
            key = (str(row["video_id"]), int(row["track_id"]))
            lbl = str(row.get("label", "TODO")).strip()
            if lbl and lbl != "TODO":
                existing_labels[key] = {
                    "label":  lbl,
                    "usable": int(row.get("usable", 1)),
                    "note":   str(row.get("note", "")),
                }
        logger.info("Preserved %d existing labels", len(existing_labels))

    # ── 3.  build events ────────────────────────────────────────────────
    events = []
    event_id = 1

    for fp in kpt_files:
        video_id = fp.stem.replace("_keypoints", "")
        df = pd.read_csv(fp)
        if len(df) == 0:
            continue

        source_video = df["source_video"].iloc[0] if "source_video" in df.columns else ""
        fps = 30.0
        if df["timestamp"].max() > 0:
            fps = round(df["frame_id"].max() / df["timestamp"].max(), 1)

        for tid in sorted(df["track_id"].unique()):
            if tid == 0:                              # ByteTrack fallback — skip
                continue
            tdf = df[df["track_id"] == tid]
            n_frames = len(tdf)
            if n_frames < 32:                          # too short for one GRU window
                continue

            start_f = int(tdf["frame_id"].min())
            end_f   = int(tdf["frame_id"].max())
            start_s = start_f / fps
            end_s   = end_f / fps

            key = (video_id, int(tid))
            if key in existing_labels:
                label  = existing_labels[key]["label"]
                usable = existing_labels[key]["usable"]
                note   = existing_labels[key].get("note", f"{n_frames} frames in track")
            else:
                label  = "TODO"
                usable = 1
                note   = f"{n_frames} frames in track"

            events.append({
                "event_id":      event_id,
                "video_id":      video_id,
                "source_video":  source_video,
                "track_id":      int(tid),
                "start_time":    _format_seconds(start_s),
                "end_time":      _format_seconds(end_s),
                "start_frame":   start_f,
                "end_frame":     end_f,
                "label":         label.strip(),
                "split":         "",                   # ← 待标注完成后人工或脚本自动划分
                "usable":        usable,
                "note":          note,
            })
            event_id += 1

    if not events:
        logger.error("No events generated — check keypoints data.")
        sys.exit(1)

    # ── 4.  write ───────────────────────────────────────────────────────
    cols = ["event_id", "video_id", "source_video", "track_id",
            "start_time", "end_time", "start_frame", "end_frame",
            "label", "split", "usable", "note"]

    os.makedirs(os.path.dirname(events_path), exist_ok=True)
    pd.DataFrame(events, columns=cols).to_csv(events_path, index=False)

    logger.info("Wrote %d events → %s", len(events), events_path)

    # quick summary
    n_todo = sum(1 for e in events if e["label"] == "TODO")
    n_labelled = len(events) - n_todo
    logger.info("Labelled: %d  |  TODO: %d  |  Videos: %d",
                n_labelled, n_todo, len({e["video_id"] for e in events}))


if __name__ == "__main__":
    main()
