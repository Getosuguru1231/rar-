"""
extract_sequences.py

Read labelled video clips, run YOLO-Pose + ByteTrack, extract per-track
feature sequences via sliding window, and save X.npy / y.npy / meta.csv.

Usage:
    python src/extract_sequences.py \
        --labels data/labels.csv \
        --seq-len 32 \
        --stride 8 \
        --model yolo11n-pose.pt \
        --output data/processed
"""

from __future__ import annotations

import argparse
import logging
import os
import sys
from collections import defaultdict, deque

import numpy as np
import pandas as pd
from tqdm import tqdm

# Ensure the project root is on sys.path so "src.*" imports work.
_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
_PROJ_ROOT = os.path.dirname(_THIS_DIR)
if _PROJ_ROOT not in sys.path:
    sys.path.insert(0, _PROJ_ROOT)

from src.config import (
    LABEL_MAP,
    SEQ_LEN,
    STRIDE,
    FEATURE_DIM,
    DEFAULT_POSE_MODEL,
    TRACKER_CONFIG,
    load_pose_model,
)
from src.utils.features import extract_frame_feature, sliding_windows

logger = logging.getLogger(__name__)


# ── helpers ──────────────────────────────────────────────────────────────────

def _validate_label(label_str: str) -> int:
    """Convert a string label to integer class id; raise on unknown."""
    label_str = label_str.strip()
    for key, val in LABEL_MAP.items():
        if key.lower() == label_str.lower():
            return val
    raise ValueError(
        f"Unknown label '{label_str}'. Expected one of {list(LABEL_MAP)}"
    )


def _get_largest_person_box(results):
    """
    From ultralytics Results, pick the person det (class 0) with largest bbox area.

    Returns (box_xyxy, box_xywh, keypoints) or (None, None, None).
    box_xyxy : [x1, y1, x2, y2]  (pixel)
    box_xywh : [cx, cy, w, h]     (pixel)
    keypoints : [17, 3] or None
    """
    if results.boxes is None:
        return None, None, None

    try:
        cls_ids = results.boxes.cls
        if cls_ids is None or len(cls_ids) == 0:
            return None, None, None
        cls_ids = cls_ids.cpu().numpy()
    except Exception:
        return None, None, None

    person_indices = [i for i, c in enumerate(cls_ids) if int(c) == 0]
    if not person_indices:
        return None, None, None

    boxes_xyxy = results.boxes.xyxy
    boxes_xywh = results.boxes.xywh
    keypoints_all = results.keypoints

    # Guard against malformed box tensors
    if boxes_xyxy is None or len(boxes_xyxy) == 0:
        return None, None, None
    if boxes_xywh is None or len(boxes_xywh) == 0:
        return None, None, None

    best_area = -1.0
    best_xyxy = None
    best_xywh = None
    best_kpts = None

    for idx in person_indices:
        if idx >= len(boxes_xyxy) or idx >= len(boxes_xywh):
            continue
        try:
            x1, y1, x2, y2 = boxes_xyxy[idx].cpu().numpy()
        except Exception:
            continue
        area = (x2 - x1) * (y2 - y1)
        if area > best_area:
            best_area = area
            best_xyxy = boxes_xyxy[idx].cpu().numpy()
            try:
                best_xywh = boxes_xywh[idx].cpu().numpy()
            except Exception:
                # Derive xywh from xyxy as fallback
                best_xywh = np.array([
                    (x1 + x2) / 2, (y1 + y2) / 2, x2 - x1, y2 - y1
                ], dtype=np.float32)
            if keypoints_all is not None and keypoints_all.data is not None:
                try:
                    best_kpts = keypoints_all.data[idx].cpu().numpy()
                except Exception:
                    best_kpts = None

    return best_xyxy, best_xywh, best_kpts


# ── main ─────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="Extract pose feature sequences from labelled clips"
    )
    parser.add_argument("--labels", required=True, help="Path to labels.csv")
    parser.add_argument("--seq-len", type=int, default=SEQ_LEN)
    parser.add_argument("--stride", type=int, default=STRIDE)
    parser.add_argument("--model", default=DEFAULT_POSE_MODEL)
    parser.add_argument("--output", default="data/processed")
    args = parser.parse_args()

    logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")

    # ── Load labels ──────────────────────────────────────────────────────
    if not os.path.exists(args.labels):
        logger.error("labels.csv not found: %s", args.labels)
        sys.exit(1)

    df = pd.read_csv(args.labels)
    if "clip_path" not in df.columns or "label" not in df.columns:
        logger.error("labels.csv must contain 'clip_path' and 'label' columns")
        sys.exit(1)

    # Validate labels early
    valid_rows = []
    for _, row in df.iterrows():
        try:
            class_id = _validate_label(row["label"])
            valid_rows.append((row["clip_path"], class_id))
        except ValueError as e:
            logger.warning("Skipping row: %s", e)

    if not valid_rows:
        logger.error("No valid rows in labels.csv")
        sys.exit(1)

    # ── Load YOLO-Pose ───────────────────────────────────────────────────
    try:
        pose_model, actual_model = load_pose_model(args.model)
        logger.info("Loaded pose model: %s", actual_model)
    except Exception as e:
        logger.error("Failed to load any pose model: %s", e)
        sys.exit(1)

    # ── Process clips ────────────────────────────────────────────────────
    all_X = []      # list of np.ndarray [seq_len, 55]
    all_y = []      # list of int
    meta_rows = []  # list of dicts for meta.csv

    for clip_path, class_id in tqdm(valid_rows, desc="Processing clips"):
        if not os.path.exists(clip_path):
            logger.warning("Clip not found, skipping: %s", clip_path)
            continue

        # Track-level feature buffers: track_id → deque of features
        track_features: dict[int, deque] = defaultdict(
            lambda: deque(maxlen=args.seq_len * 10)
        )

        try:
            results_gen = pose_model.track(
                source=clip_path,
                tracker=TRACKER_CONFIG,
                stream=True,
                persist=True,
                verbose=False,
            )
        except Exception as e:
            logger.warning("track() failed for %s: %s", clip_path, e)
            continue

        # Video resolution — obtained from the first frame with a valid image
        w, h = None, None
        frame_idx = 0

        for result in results_gen:
            if result is None:
                frame_idx += 1
                continue

            # Determine video resolution from the first valid frame
            if w is None and result.orig_img is not None:
                h, w = result.orig_img.shape[:2]
                logger.info("Processing: %s (%dx%d)", clip_path, w, h)

            # Safety: if we somehow never got dimensions, skip this frame
            if w is None:
                frame_idx += 1
                continue

            # Get the largest person detection this frame
            xyxy, xywh, kpts = _get_largest_person_box(result)

            if xywh is None:
                frame_idx += 1
                continue

            # Build feature for this frame
            feat = extract_frame_feature(xywh, kpts, w, h)

            # Determine track_id
            track_id = None
            if result.boxes is not None and result.boxes.id is not None:
                try:
                    ids = result.boxes.id.cpu().numpy().astype(int)
                    cls_ids = result.boxes.cls.cpu().numpy()
                    person_indices = [
                        i for i, c in enumerate(cls_ids) if int(c) == 0
                    ]
                    if person_indices:
                        # Find the track_id for the largest bbox person
                        best_idx = max(
                            person_indices,
                            key=lambda i: (
                                (result.boxes.xyxy[i][2] - result.boxes.xyxy[i][0])
                                * (result.boxes.xyxy[i][3] - result.boxes.xyxy[i][1])
                            ),
                        )
                        track_id = int(ids[best_idx])
                except Exception:
                    pass

            if track_id is None:
                track_id = 0  # fallback single-person track

            track_features[track_id].append(feat)
            frame_idx += 1

        # ── Sliding window on each track ─────────────────────────────────
        if w is None:
            logger.warning(
                "No valid frames with detections in: %s", os.path.basename(clip_path)
            )
            continue

        for tid, feat_deque in track_features.items():
            if len(feat_deque) < args.seq_len:
                logger.debug(
                    "Track %d in %s has only %d frames (< %d), skipping",
                    tid, os.path.basename(clip_path), len(feat_deque), args.seq_len,
                )
                continue

            feats = np.stack(list(feat_deque), axis=0)  # [T, 55]
            for start, end, seq in sliding_windows(feats, args.seq_len, args.stride):
                all_X.append(seq)
                all_y.append(class_id)
                meta_rows.append({
                    "clip_path": clip_path,
                    "label": class_id,
                    "track_id": tid,
                    "start_frame": start,
                    "end_frame": end,
                })

    # ── Save ─────────────────────────────────────────────────────────────
    if not all_X:
        logger.error(
            "No sequences extracted. Check that clips exist, contain people, "
            "and have >= %d frames.", args.seq_len
        )
        sys.exit(1)

    os.makedirs(args.output, exist_ok=True)

    X = np.stack(all_X, axis=0).astype(np.float32)  # [N, seq_len, 55]
    y = np.array(all_y, dtype=np.int64)

    x_path = os.path.join(args.output, "X.npy")
    y_path = os.path.join(args.output, "y.npy")
    meta_path = os.path.join(args.output, "meta.csv")

    np.save(x_path, X)
    np.save(y_path, y)
    pd.DataFrame(meta_rows).to_csv(meta_path, index=False)

    logger.info("Saved X: %s  shape=%s", x_path, X.shape)
    logger.info("Saved y: %s  shape=%s", y_path, y.shape)
    logger.info("Saved meta: %s  (%d rows)", meta_path, len(meta_rows))

    # Quick sanity check
    if X.shape[0] != y.shape[0]:
        logger.error(
            "Mismatch! X has %d samples but y has %d. This is a bug.",
            X.shape[0], y.shape[0],
        )
        sys.exit(1)

    logger.info("Done. Extracted %d sequences across %d classes.",
                X.shape[0], len(set(all_y)))


if __name__ == "__main__":
    main()
