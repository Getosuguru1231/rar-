"""
pretrack_videos.py

Run YOLO-Pose + ByteTrack on raw videos to generate:
  - <video_id>_preview.mp4   – annotated preview for manual labelling
  - <video_id>_keypoints.csv  – per-frame, per-track keypoint features

Usage:
    python src/pretrack_videos.py \
        --input D:\Videos\Drowning \
        --output data/pretrack \
        --model yolov8m-pose.pt
"""

from __future__ import annotations

import argparse
import logging
import os
import sys
from pathlib import Path

import cv2
import numpy as np
import pandas as pd
from tqdm import tqdm

_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
_PROJ_ROOT = os.path.dirname(_THIS_DIR)
if _PROJ_ROOT not in sys.path:
    sys.path.insert(0, _PROJ_ROOT)

from src.config import (
    DEFAULT_POSE_MODEL,
    TRACKER_CONFIG,
    load_pose_model,
)

logger = logging.getLogger(__name__)

# COCO keypoint names
KPT_NAMES = [
    "nose", "left_eye", "right_eye", "left_ear", "right_ear",
    "left_shoulder", "right_shoulder", "left_elbow", "right_elbow",
    "left_wrist", "right_wrist", "left_hip", "right_hip",
    "left_knee", "right_knee", "left_ankle", "right_ankle",
]

# Keypoint skeleton pairs for drawing
SKELETON = [
    (5, 6), (5, 7), (7, 9), (6, 8), (8, 10), (5, 11), (6, 12),
    (11, 12), (11, 13), (13, 15), (12, 14), (14, 16),
]

COLORS = {
    "bbox": (0, 255, 0),       # green
    "kpt": (0, 255, 255),      # yellow
    "skeleton": (255, 255, 0),  # cyan
    "text": (255, 255, 255),   # white
}


def _make_columns():
    """Build the CSV column names for keypoints.csv."""
    cols = [
        "video_id", "source_video", "frame_id", "timestamp",
        "track_id", "bbox_x_center", "bbox_y_center",
        "bbox_width", "bbox_height", "det_conf",
    ]
    for i, name in enumerate(KPT_NAMES):
        cols.append(f"kp{i}_x")
        cols.append(f"kp{i}_y")
        cols.append(f"kp{i}_conf")
    return cols


def _draw_skeleton(frame, keypoints, w, h):
    """Draw keypoints and skeleton on frame."""
    if keypoints is None:
        return
    for i, (kx, ky, kc) in enumerate(keypoints):
        if kc < 0.3:
            continue
        px, py = int(kx * w) if kx <= 1 else int(kx), int(ky * h) if ky <= 1 else int(ky)
        # clamp to frame
        px = max(0, min(w - 1, px))
        py = max(0, min(h - 1, py))
        cv2.circle(frame, (px, py), 3, COLORS["kpt"], -1)

    for a, b in SKELETON:
        if a >= len(keypoints) or b >= len(keypoints):
            continue
        x1, y1, c1 = keypoints[a]
        x2, y2, c2 = keypoints[b]
        if c1 < 0.3 or c2 < 0.3:
            continue
        p1 = (int(x1 * w) if x1 <= 1 else int(x1), int(y1 * h) if y1 <= 1 else int(y1))
        p2 = (int(x2 * w) if x2 <= 1 else int(x2), int(y2 * h) if y2 <= 1 else int(y2))
        cv2.line(frame, p1, p2, COLORS["skeleton"], 1)


def _draw_bbox(frame, xyxy, track_id):
    """Draw bounding box with track_id label."""
    x1, y1, x2, y2 = map(int, xyxy)
    cv2.rectangle(frame, (x1, y1), (x2, y2), COLORS["bbox"], 2)
    label = f"ID:{track_id}"
    (tw, th), _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.6, 2)
    cv2.rectangle(frame, (x1, y1 - th - 8), (x1 + tw + 4, y1), COLORS["bbox"], -1)
    cv2.putText(frame, label, (x1 + 2, y1 - 4),
                cv2.FONT_HERSHEY_SIMPLEX, 0.6, COLORS["text"], 2)


def process_video(video_path, pose_model, output_dir, fps_out=30, output_res=None):
    """
    Process one video: run YOLO-Pose + ByteTrack, produce preview & keypoints CSV.

    If output_res is (out_w, out_h), the preview video is resized to that resolution
    (much faster writing for 4K sources).

    Returns (preview_path, keypoints_csv_path).
    """
    video_id = Path(video_path).stem
    source_rel = os.path.relpath(video_path, _PROJ_ROOT).replace("\\", "/")

    preview_path = os.path.join(output_dir, f"{video_id}_preview.mp4")
    kpt_path = os.path.join(output_dir, f"{video_id}_keypoints.csv")

    # Get video properties
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        logger.error("Cannot open video: %s", video_path)
        return None, None
    orig_fps = cap.get(cv2.CAP_PROP_FPS)
    w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    cap.release()

    logger.info("Processing: %s (%dx%d, %.1f fps, %d frames)",
                video_id, w, h, orig_fps, total_frames)

    # Run YOLO-Pose + ByteTrack
    try:
        results_gen = pose_model.track(
            source=video_path,
            tracker=TRACKER_CONFIG,
            stream=True,
            persist=True,
            verbose=False,
        )
    except Exception as e:
        logger.error("track() failed for %s: %s", video_path, e)
        return None, None

    # Prepare output
    out_w, out_h = (w, h) if output_res is None else output_res
    fourcc = cv2.VideoWriter_fourcc(*"mp4v")
    out = cv2.VideoWriter(preview_path, fourcc, fps_out, (out_w, out_h))
    csv_rows = []

    frame_idx = 0
    for result in tqdm(results_gen, desc=f"  {video_id}", total=total_frames):
        if result is None:
            frame_idx += 1
            continue

        frame = result.orig_img
        if frame is None:
            frame_idx += 1
            continue

        if frame.shape[1] != w:
            # resize if needed (first frame may already be the right size)
            pass

        timestamp = frame_idx / orig_fps if orig_fps > 0 else frame_idx / 30.0

        # Extract detections
        if result.boxes is not None and result.boxes.cls is not None:
            try:
                cls_ids = result.boxes.cls.cpu().numpy()
            except Exception:
                cls_ids = np.array([])

            ids_arr = None
            if result.boxes.id is not None:
                try:
                    ids_arr = result.boxes.id.cpu().numpy().astype(int)
                except Exception:
                    pass

            for i, c in enumerate(cls_ids):
                if int(c) != 0:
                    continue

                try:
                    xyxy = result.boxes.xyxy[i].cpu().numpy()
                    xywh = result.boxes.xywh[i].cpu().numpy() if result.boxes.xywh is not None else None
                    conf = float(result.boxes.conf[i]) if result.boxes.conf is not None else 1.0
                except Exception:
                    continue

                track_id = int(ids_arr[i]) if ids_arr is not None and i < len(ids_arr) else i

                # Keypoints (normalised)
                keypoints_flat = [np.nan] * 51
                if result.keypoints is not None and result.keypoints.data is not None:
                    try:
                        kpts = result.keypoints.data[i].cpu().numpy()  # [17, 3] in pixels
                        # Normalise
                        kpts[:, 0] /= float(w)
                        kpts[:, 1] /= float(h)
                        keypoints_flat = kpts.flatten().tolist()
                    except Exception:
                        pass

                # Normalise bbox
                cx_n = float(xywh[0]) / w if xywh is not None else float(xyxy[0] + xyxy[2]) / 2 / w
                cy_n = float(xywh[1]) / h if xywh is not None else float(xyxy[1] + xyxy[3]) / 2 / h
                bw_n = float(xywh[2]) / w if xywh is not None else float(xyxy[2] - xyxy[0]) / w
                bh_n = float(xywh[3]) / h if xywh is not None else float(xyxy[3] - xyxy[1]) / h

                row = [video_id, source_rel, frame_idx, timestamp, track_id,
                       cx_n, cy_n, bw_n, bh_n, conf] + keypoints_flat
                csv_rows.append(row)

                # Draw on preview
                _draw_bbox(frame, xyxy, track_id)
                if result.keypoints is not None and result.keypoints.data is not None:
                    try:
                        kpts_px = result.keypoints.data[i].cpu().numpy()
                        _draw_skeleton(frame, kpts_px, w, h)
                    except Exception:
                        pass

        # Draw frame counter
        cv2.putText(frame, f"Frame: {frame_idx}", (10, h - 12),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (200, 200, 200), 1)

        # Resize output frame if needed
        if output_res is not None:
            frame_out = cv2.resize(frame, output_res, interpolation=cv2.INTER_LINEAR)
        else:
            frame_out = frame
        out.write(frame_out)
        frame_idx += 1

    out.release()

    # Save keypoints CSV
    cols = _make_columns()
    df = pd.DataFrame(csv_rows, columns=cols)
    df.to_csv(kpt_path, index=False, float_format="%.6f")

    logger.info("  -> preview: %s", preview_path)
    logger.info("  -> keypoints: %s (%d rows)", kpt_path, len(df))

    return preview_path, kpt_path


def main():
    parser = argparse.ArgumentParser(description="Pre-track raw videos")
    parser.add_argument("--input", default=None,
                        help="Directory containing raw videos")
    parser.add_argument("--video", default=None,
                        help="Single video file to process")
    parser.add_argument("--output", default="data/pretrack")
    parser.add_argument("--model", default=DEFAULT_POSE_MODEL)
    parser.add_argument("--fps-out", type=int, default=30,
                        help="Preview video output FPS")
    parser.add_argument("--output-resolution", default=None,
                        help="Resize output preview, e.g. '1280x720' or '1920x1080'")
    args = parser.parse_args()

    logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")

    output_dir = os.path.join(_PROJ_ROOT, args.output)
    os.makedirs(output_dir, exist_ok=True)

    # Parse output resolution
    output_res = None
    if args.output_resolution:
        parts = args.output_resolution.lower().split("x")
        if len(parts) == 2:
            output_res = (int(parts[0]), int(parts[1]))
            logger.info("Output preview will be resized to %dx%d", output_res[0], output_res[1])

    # Gather video files
    if args.video:
        video_files = [args.video]
    elif args.input:
        input_dir = os.path.join(_PROJ_ROOT, args.input)
        video_exts = {".mp4", ".mov", ".avi", ".mkv", ".MOV", ".MP4"}
        video_files = sorted([
            os.path.join(input_dir, f) for f in os.listdir(input_dir)
            if os.path.splitext(f)[1] in video_exts
        ])
    else:
        logger.error("Must specify --input or --video")
        sys.exit(1)

    if not video_files:
        logger.error("No videos found")
        sys.exit(1)

    logger.info("Found %d video(s)", len(video_files))

    # Load YOLO-Pose
    try:
        pose_model, actual_model = load_pose_model(args.model)
        logger.info("Loaded pose model: %s", actual_model)
    except Exception as e:
        logger.error("Failed to load pose model: %s", e)
        sys.exit(1)

    # Process each video
    for vp in video_files:
        process_video(vp, pose_model, output_dir, fps_out=args.fps_out,
                      output_res=output_res)

    logger.info("All done. Output in: %s", output_dir)


if __name__ == "__main__":
    main()
