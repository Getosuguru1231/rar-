"""
Drowning Detection System — Global Configuration.

All paths and hyperparameters can be overridden via command-line arguments
in the respective scripts. This file serves as the central default source.
"""

import os

# ── Paths ────────────────────────────────────────────────────────────────────
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, "data")
CLIPS_DIR = os.path.join(DATA_DIR, "clips")
PROCESSED_DIR = os.path.join(DATA_DIR, "processed")
OUTPUTS_DIR = os.path.join(BASE_DIR, "outputs")
MODELS_DIR = os.path.join(OUTPUTS_DIR, "models")
LOGS_DIR = os.path.join(OUTPUTS_DIR, "logs")
VIDEOS_DIR = os.path.join(OUTPUTS_DIR, "videos")
PRETRACK_DIR = os.path.join(DATA_DIR, "pretrack")
ANNOTATIONS_DIR = os.path.join(DATA_DIR, "annotations")
EVENTS_CSV = os.path.join(ANNOTATIONS_DIR, "events.csv")

DEFAULT_LABELS_CSV = os.path.join(DATA_DIR, "labels.csv")
DEFAULT_X_PATH = os.path.join(PROCESSED_DIR, "X.npy")
DEFAULT_Y_PATH = os.path.join(PROCESSED_DIR, "y.npy")
DEFAULT_META_PATH = os.path.join(PROCESSED_DIR, "meta.csv")
DEFAULT_MODEL_SAVE = os.path.join(MODELS_DIR, "best_gru.pth")
DEFAULT_TRAIN_LOG = os.path.join(LOGS_DIR, "train_log.csv")
DEFAULT_CM_PLOT = os.path.join(LOGS_DIR, "confusion_matrix.png")

# ── Pose model ───────────────────────────────────────────────────────────────
# Primary pose model.  Place the downloaded weights file in the project root
# (drowning_gru_project/) or provide an absolute path via --model.
DEFAULT_POSE_MODEL = "yolov8m-pose.pt"
# Fallback if the primary model cannot be loaded (lighter, may auto-download).
FALLBACK_POSE_MODEL = "yolov8n-pose.pt"
TRACKER_CONFIG = "bytetrack.yaml"


def load_pose_model(model_name=None):
    """
    Load a YOLO pose model with automatic fallback.

    If ``model_name`` (e.g. yolov8m-pose.pt) fails to load,
    automatically tries ``FALLBACK_POSE_MODEL`` (yolov8n-pose.pt).

    Parameters
    ----------
    model_name : str or None
        Desired model name.  If None, uses ``DEFAULT_POSE_MODEL``.

    Returns
    -------
    (model, actual_name) : (ultralytics.YOLO, str)
    """
    from ultralytics import YOLO

    if model_name is None:
        model_name = DEFAULT_POSE_MODEL

    try:
        return YOLO(model_name), model_name
    except Exception:
        if model_name == DEFAULT_POSE_MODEL and FALLBACK_POSE_MODEL:
            print(
                f"[WARN] Failed to load '{model_name}'. "
                f"Falling back to '{FALLBACK_POSE_MODEL}'..."
            )
            return YOLO(FALLBACK_POSE_MODEL), FALLBACK_POSE_MODEL
        raise

# ── Sequence ─────────────────────────────────────────────────────────────────
SEQ_LEN = 32          # number of frames per sample
STRIDE = 8            # sliding-window stride (frames)
FEATURE_DIM = 55      # 17 kpts * 3 + 4 bbox

# ── Keypoint config ──────────────────────────────────────────────────────────
NUM_KEYPOINTS = 17
KPT_DIM = 3           # x, y, confidence

# ── Classification ───────────────────────────────────────────────────────────
NUM_CLASSES = 4

LABEL_MAP = {
    "Swimming": 0,
    "Idle in water": 1,
    "Drowning": 2,
    "Person out of water": 3,
}

ID_TO_LABEL = {v: k for k, v in LABEL_MAP.items()}

# ── Alarm ────────────────────────────────────────────────────────────────────
DROWNING_THRESHOLD = 0.7        # probability above which we consider "suspected"
ALARM_CONSECUTIVE_COUNT = 10    # consecutive frames above threshold to fire alarm

# ── GRU architecture ─────────────────────────────────────────────────────────
GRU_HIDDEN_SIZE = 128
GRU_NUM_LAYERS = 2
GRU_DROPOUT = 0.3

# ── Training ─────────────────────────────────────────────────────────────────
BATCH_SIZE = 32
LEARNING_RATE = 0.001
EPOCHS = 50
TRAIN_VAL_SPLIT = 0.8           # fraction for training
USE_CLASS_WEIGHT = True          # auto-compute from y distribution

# ── Inference ────────────────────────────────────────────────────────────────
DEVICE = "cuda"                  # "cuda", "cpu", or None for auto-detect

# ── Visualization ────────────────────────────────────────────────────────────
BBOX_COLOR = (0, 255, 0)         # green
ALERT_COLOR = (0, 0, 255)        # red
TEXT_COLOR = (255, 255, 255)     # white
FONT_SCALE = 0.6
FONT_THICKNESS = 2
LINE_THICKNESS = 2
