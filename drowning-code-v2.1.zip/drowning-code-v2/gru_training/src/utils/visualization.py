"""
OpenCV drawing utilities for video annotation.
"""

import cv2
import numpy as np

from src.config import (
    BBOX_COLOR,
    ALERT_COLOR,
    TEXT_COLOR,
    FONT_SCALE,
    FONT_THICKNESS,
    LINE_THICKNESS,
)


def draw_bbox(frame, box, track_id, color=BBOX_COLOR):
    """
    Draw a bounding box with track ID label.

    Parameters
    ----------
    frame : np.ndarray (H, W, 3)
    box : tuple/list (x1, y1, x2, y2) in pixel coords
    track_id : int
    color : tuple (B, G, R)
    """
    x1, y1, x2, y2 = map(int, box)
    cv2.rectangle(frame, (x1, y1), (x2, y2), color, LINE_THICKNESS)
    label = f"ID:{track_id}"
    (tw, th), _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, FONT_SCALE, FONT_THICKNESS)
    cv2.rectangle(frame, (x1, y1 - th - 6), (x1 + tw + 4, y1), color, -1)
    cv2.putText(frame, label, (x1 + 2, y1 - 4),
                cv2.FONT_HERSHEY_SIMPLEX, FONT_SCALE, TEXT_COLOR, FONT_THICKNESS)


def draw_label(frame, text, position, color=TEXT_COLOR, bg_color=None):
    """
    Draw a text label, optionally with a filled background.

    Parameters
    ----------
    frame : np.ndarray
    text : str
    position : tuple (x, y) — bottom-left corner of text
    color : tuple (B, G, R)
    bg_color : tuple (B, G, R) or None
    """
    (tw, th), _ = cv2.getTextSize(text, cv2.FONT_HERSHEY_SIMPLEX, FONT_SCALE, FONT_THICKNESS)
    x, y = position
    if bg_color is not None:
        cv2.rectangle(frame, (x, y - th - 4), (x + tw + 4, y + 2), bg_color, -1)
    cv2.putText(frame, text, (x + 2, y - 2),
                cv2.FONT_HERSHEY_SIMPLEX, FONT_SCALE, color, FONT_THICKNESS)


def draw_alert(frame, text="ALERT: suspected drowning"):
    """
    Draw a prominent red alert banner at the top of the frame.

    Parameters
    ----------
    frame : np.ndarray
    text : str
    """
    h, w = frame.shape[:2]
    banner_h = 50
    overlay = frame.copy()
    cv2.rectangle(overlay, (0, 0), (w, banner_h), (0, 0, 255), -1)
    cv2.addWeighted(overlay, 0.6, frame, 0.4, 0, frame)

    font_scale = 1.0
    thickness = 2
    (tw, th), _ = cv2.getTextSize(text, cv2.FONT_HERSHEY_SIMPLEX, font_scale, thickness)
    cx = (w - tw) // 2
    cy = (banner_h + th) // 2
    cv2.putText(frame, text, (cx, cy),
                cv2.FONT_HERSHEY_SIMPLEX, font_scale, (255, 255, 255), thickness)


def draw_keypoints(frame, keypoints, color=(0, 255, 255), radius=3):
    """
    Draw pose keypoints as circles.

    Parameters
    ----------
    frame : np.ndarray
    keypoints : np.ndarray, shape [17, 3]  (x, y, conf) in pixel coords
    color : tuple (B, G, R)
    radius : int
    """
    for kp in keypoints:
        x, y, conf = kp
        if conf > 0.3:
            cv2.circle(frame, (int(x), int(y)), radius, color, -1)
