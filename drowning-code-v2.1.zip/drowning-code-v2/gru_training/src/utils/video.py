"""
Safe video I/O helpers.
"""

import logging
import cv2

logger = logging.getLogger(__name__)


def open_video(path):
    """
    Open a video file with error handling.

    Returns
    -------
    cv2.VideoCapture or None
    """
    cap = cv2.VideoCapture(path)
    if not cap.isOpened():
        logger.warning("Cannot open video: %s", path)
        return None
    return cap


def get_video_properties(cap):
    """
    Extract basic properties from an opened VideoCapture.

    Returns
    -------
    dict with keys: fps, width, height, frame_count
    """
    return {
        "fps": cap.get(cv2.CAP_PROP_FPS),
        "width": int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)),
        "height": int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT)),
        "frame_count": int(cap.get(cv2.CAP_PROP_FRAME_COUNT)),
    }
