"""
Feature extraction from YOLO-Pose outputs.

Each frame produces a 55-d feature vector:
  17 keypoints * (x, y, conf) = 51
  + bbox (cx, cy, w, h)      =  4
  ─────────────────────────────────
  TOTAL                       = 55
"""

from collections import deque

import numpy as np

from src.config import FEATURE_DIM, NUM_KEYPOINTS


def extract_frame_feature(box, keypoints, image_width, image_height):
    """
    Normalise and flatten one frame's detection into a fixed-size vector.

    Parameters
    ----------
    box : np.ndarray or None
        [x_center, y_center, width, height] in pixel coordinates.
    keypoints : np.ndarray or None
        Shape [17, 3] with columns (x, y, confidence).
    image_width : int
    image_height : int

    Returns
    -------
    feature : np.ndarray
        Shape [55], dtype float32.  All coordinates normalised to [0, 1].
    """
    feature = np.zeros(FEATURE_DIM, dtype=np.float32)

    # ── Keypoints (first 51 dims) ────────────────────────────────────────
    if keypoints is not None and keypoints.shape == (NUM_KEYPOINTS, 3):
        kpts = keypoints.astype(np.float32).copy()
        # Normalise x, y
        kpts[:, 0] /= float(image_width)
        kpts[:, 1] /= float(image_height)
        # confidence stays as-is (already 0-1 typically)
        feature[:51] = kpts.flatten()
    else:
        # All-zero signifies missing / low-confidence keypoints.
        # Interface reserved for future interpolation from previous frame.
        pass

    # ── Bounding box (last 4 dims) ───────────────────────────────────────
    if box is not None and len(box) == 4:
        bx = np.array(box, dtype=np.float32)
        bx[0] /= float(image_width)   # cx
        bx[1] /= float(image_height)  # cy
        bx[2] /= float(image_width)   # w
        bx[3] /= float(image_height)  # h
        feature[51:55] = bx
    # else: stays zero

    return feature


def build_sequence(feature_deque):
    """
    Convert a deque of per-frame features into a stacked numpy array.

    Parameters
    ----------
    feature_deque : collections.deque
        Contains np.ndarrays of shape [55].

    Returns
    -------
    np.ndarray, shape [len(deque), 55]
    """
    return np.stack(list(feature_deque), axis=0).astype(np.float32)


def sliding_windows(features, seq_len, stride):
    """
    Generate (start_frame, end_frame, sequence) tuples via sliding window.

    Parameters
    ----------
    features : np.ndarray, shape [T, 55]
    seq_len : int
    stride : int

    Yields
    ------
    (start_idx, end_idx, np.ndarray[seq_len, 55])
    """
    t = features.shape[0]
    for start in range(0, t - seq_len + 1, stride):
        end = start + seq_len
        yield start, end, features[start:end].copy()
