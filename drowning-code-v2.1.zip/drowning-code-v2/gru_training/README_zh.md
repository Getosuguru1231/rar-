# 溺水行为检测系统

**YOLO-Pose + ByteTrack + GRU** — 面向游泳安全的时序动作识别系统。

本项目是一个**基于视频的人员时序行为识别**流水线。YOLO-Pose 逐帧提取人体关键点和边界框，ByteTrack 保证跨帧人员 ID 一致，GRU 对每个 `track_id` 的定长姿态序列窗口进行分类，并在推理阶段将窗口级结果映射回视频帧进行告警：

| 类别 ID | 标签 | 说明 |
|----------|------|------|
| 0 | `Swimming` | 正常游泳行为 |
| 1 | `Idle in water` | 水中静止 / 漂浮 |
| 2 | `Drowning` | 溺水 |
| 3 | `Person out of water` | 人员已离开水域 |

## 核心设计原则

**YOLO-Pose 负责"每一帧这个人长什么姿态"，events.csv 负责"这段时间这个人在做什么动作"，GRU 负责"连续多帧姿态变化属于哪类行为"。**

- `events.csv` 是人工标注的**事件索引表**，只说明某个视频、某个 track_id、某段时间对应什么行为——它**不包含**每一帧的人体关键点数值。
- `keypoints.csv` 是 YOLO-Pose + ByteTrack 自动导出的**逐帧特征表**，包含每一帧每个人的 17 个关键点坐标与置信度、人体框——但它**不包含**行为标签。
- **两者必须配合使用**：`events.csv` 提供标签和切片范围，`keypoints.csv` 提供数值特征，`build_gru_dataset.py` 负责对齐切片生成 `X.npy/y.npy`。

**不能只靠 events.csv 直接生成 X.npy，也不能只靠 keypoints.csv 生成可靠的 y.npy。**

### 与 PyTorch GRU 输入格式的约定

本项目所有 GRU 训练与推理代码默认使用：

```python
nn.GRU(
    input_size=55,
    hidden_size=128,
    num_layers=2,
    batch_first=True,
    dropout=0.3,
    bidirectional=False
)
```

因此，`X.npy` 的形状固定为：

```text
[N, SEQ_LEN, FEATURE_DIM]
```

即：

```text
[样本数, 时间步长, 每帧特征数]
```

例如默认配置下：

```text
X.npy = [N, 32, 55]
y.npy = [N]
```

其中 `batch_first=True` 非常重要。PyTorch 的 `nn.GRU` 默认是 `batch_first=False`，如果忘记设置，模型会把输入理解为 `[SEQ_LEN, N, FEATURE_DIM]`，导致 README 中的数据形状和代码不一致。

另外，`nn.GRU` 本身只输出时序隐藏特征，不会直接输出四类行为。因此模型结构应为：

```text
连续姿态序列 X
↓
GRU 提取时序特征
↓
Linear 分类头
↓
Swimming / Idle in water / Drowning / Person out of water
```

## 项目结构

```
drowning_gru_project/
├── data/
│   ├── raw_videos/                  # 原始长视频
│   │   ├── pool_001.mp4
│   │   └── pool_002.mp4
│   ├── pretrack/                    # YOLO-Pose + ByteTrack 预跟踪结果
│   │   ├── pool_001_preview.mp4     # 带框、关键点、track_id、frame_id 的预览视频
│   │   ├── pool_001_keypoints.csv   # 逐帧关键点特征（生成 X.npy 的原材料）
│   │   ├── pool_001_tracks.csv      # 可选：轨迹摘要
│   │   ├── pool_002_preview.mp4
│   │   └── pool_002_keypoints.csv
│   ├── annotations/
│   │   └── events.csv               # 人工事件标注表（标签 + 切片范围）
│   └── processed/                   # 生成 GRU 数据集
│       ├── X.npy                    # GRU 输入：[N, SEQ_LEN, FEATURE_DIM]
│       ├── y.npy                    # GRU 标签：[N]
│       ├── meta.csv                 # 每个样本的来源信息
│       ├── label_map.json           # 类别名与类别 ID 映射
│       ├── feature_schema.json      # X 每一维的字段顺序
│       └── dataset_config.json      # 数据集构建参数快照
├── outputs/
│   ├── models/                      # 训练好的 GRU 权重（best_gru.pth）
│   ├── logs/                        # 训练日志、混淆矩阵图
│   └── videos/                      # 标注后的输出视频
├── src/
│   ├── config.py                    # 所有超参数与路径配置
│   ├── pretrack_videos.py           # 生成 preview.mp4 + keypoints.csv
│   ├── generate_events.py           # 从 keypoints 自动生成 events.csv 模板
│   ├── build_gru_dataset.py         # events.csv + keypoints.csv → X.npy/y.npy
│   ├── check_dataset.py             # 数据集质量检查
│   ├── train_gru.py                 # 训练 GRU
│   ├── evaluate.py                  # 评估
│   ├── infer_video.py               # 视频推理
│   ├── models/
│   │   └── gru_classifier.py
│   └── utils/
│       ├── features.py
│       ├── video.py
│       ├── metrics.py
│       └── visualization.py
├── requirements.txt
└── README.md
```

## 安装

```bash
cd drowning_gru_project
pip install -r requirements.txt
```

首次运行任一脚本时，如果本地未找到 YOLO pose 模型权重，Ultralytics 会自动下载。默认模型为 `yolov8m-pose.pt`；请将下载好的权重文件放置在项目根目录下。

### GPU 加速（推荐）

本项目支持 CUDA 加速。RTX 4060 Laptop GPU（8 GB）约可提速 10–20 倍。

```bash
# 安装 CUDA 版 PyTorch（仅 CPU 版需执行一次）
pip uninstall -y torch torchvision
pip install torch==2.4.1+cu124 torchvision==0.19.1+cu124 \
    --index-url https://download.pytorch.org/whl/cu124

# 验证 GPU 可用
python -c "import torch; print(torch.cuda.is_available())"
# 应输出 True
```

`src/config.py` 中默认 `DEVICE = "cuda"`，所有脚本自动使用 GPU。若需 CPU 运行，加 `--device cpu` 即可。

## 数据准备

### 1. 整理原始视频

将所有原始录制视频放入 `data/raw_videos/`，文件名使用 `pool_001.mp4`、`pool_002.mp4` 这种稳定命名，不建议使用中文、空格或特殊符号。

### 2. 自动预跟踪（生成 keypoints.csv）

运行 YOLO-Pose 检测人体关键点，并用 ByteTrack 给同一个人生成稳定的 track_id，输出预览视频和逐帧关键点特征表：

```bash
python src/pretrack_videos.py \
    --input data/raw_videos \
    --output data/pretrack \
    --model yolov8m-pose.pt \
    --tracker bytetrack \
    --save-keypoints
```

为每个视频生成：
- `data/pretrack/<video_id>_preview.mp4` — 带 bbox、pose、track_id、frame_id 的预览视频，供人工标注使用
- `data/pretrack/<video_id>_keypoints.csv` — 逐帧关键点特征，每行表示某个 frame_id 中某个 track_id 的 bbox 和 17 个关键点

### 3. 人工标注 events.csv

人工观看 `data/pretrack/*_preview.mp4`，按"某个 video_id 的某个 track_id 在某段帧范围是什么行为"进行标注。多人视频必须按人标注，不能把整个视频直接标为溺水。

在 `data/annotations/events.csv` 中按以下格式填写：

```csv
event_id,video_id,source_video,track_id,start_time,end_time,start_frame,end_frame,label,split,usable,note
1,pool_001,data/raw_videos/pool_001.mp4,3,00:00:12.000,00:00:16.000,360,480,Drowning,train,1,中间偏右人员原地挣扎
2,pool_001,data/raw_videos/pool_001.mp4,5,00:00:20.000,00:00:24.000,600,720,Swimming,train,1,左侧人员正常游泳
3,pool_002,data/raw_videos/pool_002.mp4,1,00:01:05.000,00:01:09.000,1950,2070,Person out of water,val,1,岸边人员
4,pool_002,data/raw_videos/pool_002.mp4,2,00:00:30.000,00:00:34.000,900,1020,Idle in water,val,1,池边人员漂浮不动
```

有效标签及标注标准：

| 标签 | 中文含义 | 标注标准 |
|------|----------|----------|
| `Swimming` | 正常游泳 | 有规律划水，能正常前进，身体方向与速度相对稳定 |
| `Idle in water` | 水中静止 | 人在水中但无明显动作，漂浮或站立不动，不前进也不挣扎 |
| `Drowning` | 溺水 | 原地挣扎，无有效前进，手臂无规律乱挥，头部频繁上下浮动，姿态不稳定 |
| `Person out of water` | 离水人员 | 人在岸边、池边、泳池外，或明显不在水中 |
| `uncertain` | 不确定 | 看不清、遮挡严重、无法判断。此类样本不进入训练，只用于复查 |

`usable=0` 的事件同样不进入训练。

### 4. keypoints.csv 字段说明

| 字段 | 类型 | 示例 | 说明 |
|------|------|------|------|
| `video_id` | 字符串 | `pool_001` | 必须与 events.csv 中的 video_id 一致 |
| `source_video` | 字符串 | `data/raw_videos/pool_001.mp4` | 原始视频路径，用于回查 |
| `frame_id` | 整数 | `360` | 从 0 开始，整个项目必须统一 |
| `timestamp` | 浮点数 | `12.000` | 当前帧对应的时间（秒） |
| `track_id` | 整数 | `3` | ByteTrack 分配的跟踪 ID |
| `bbox_x_center` | 浮点数 | `0.512` | 人体框中心 x，归一化到 0–1 |
| `bbox_y_center` | 浮点数 | `0.438` | 人体框中心 y，归一化到 0–1 |
| `bbox_width` | 浮点数 | `0.083` | 人体框宽度，归一化到 0–1 |
| `bbox_height` | 浮点数 | `0.176` | 人体框高度，归一化到 0–1 |
| `det_conf` | 浮点数 | `0.91` | 人体检测置信度 |
| `kp0_x` ~ `kp16_x` | 浮点数 | `0.501` | 17 个关键点 x 坐标，归一化到 0–1 |
| `kp0_y` ~ `kp16_y` | 浮点数 | `0.203` | 17 个关键点 y 坐标，归一化到 0–1 |
| `kp0_conf` ~ `kp16_conf` | 浮点数 | `0.93` | 17 个关键点置信度 |

**坐标归一化原则**：所有 x/y 坐标除以图像宽高后归一化至 [0, 1]，避免模型学到分辨率或摄像头位置的无关差异。

**关于 `det_conf`**：`det_conf` 保存人体检测置信度，建议仅用于数据质量过滤、调试和复查，默认**不进入**最终 `X.npy`。默认 `FEATURE_DIM=55` 只包含 `17×3` 个关键点特征和 `4` 个 bbox 特征。如果后续决定把 `det_conf` 也作为输入特征，则 `FEATURE_DIM` 必须同步改为 `56`，并更新 `feature_schema.json`、训练代码和推理代码。

## 使用方法 — 完整流程（无 AI 辅助操作手册）

以下步骤从原始视频到最终告警推理，均可独立执行，不需要任何 AI 工具辅助。

**所有命令均在 `drowning_gru_project/` 目录下运行。**

---

### 步骤 1：生成预览视频与关键点（必须 GPU 加速）

对 `data/raw_videos/` 下所有视频运行 YOLO-Pose + ByteTrack 预跟踪：

```bash
# 批量处理整个目录
python src/pretrack_videos.py \
    --input data/raw_videos \
    --output data/pretrack \
    --model yolov8m-pose.pt \
    --output-resolution 1280x720

# 或只处理单个视频
python src/pretrack_videos.py \
    --video data/raw_videos/你的视频.mp4 \
    --output data/pretrack \
    --model yolov8m-pose.pt \
    --output-resolution 1280x720
```

| 参数 | 说明 |
|------|------|
| `--input` | 原始视频所在目录 |
| `--video` | 单个视频文件路径（与 `--input` 二选一） |
| `--output` | 结果输出目录，默认 `data/pretrack` |
| `--model` | YOLO Pose 模型权重路径 |
| `--output-resolution` | 输出预览视频分辨率，如 `1280x720`，减小可加速 |
| `--fps-out` | 输出预览帧率，默认 30 |

**每处理一个视频会生成两个文件：**

```
data/pretrack/
├── <video_id>_preview.mp4       # 带 bbox + 关键点 + track_id + frame_id 的预览视频
└── <video_id>_keypoints.csv     # 逐帧、逐人的 17 个关键点坐标与人体框
```

若使用 GPU（RTX 4060，配置见安装章节），一个 4K 60fps 视频约 1–2 分钟；纯 CPU 则可能需要 20–30 分钟。

---

### 步骤 2：自动生成 events.csv 模板

首次使用时，从 `keypoints.csv` 自动提取每个视频中 ≥32 帧的 track，生成一份待标注的事件模板：

```bash
python src/generate_events.py
```

模板自动填入 `event_id`、`video_id`、`source_video`、`track_id`、`start_frame`、`end_frame`、`start_time`、`end_time`、`note`；`label` 填为 `TODO`，`split` **留空**（标注完成后再划分 train/val/test）。

- **排除** `track_id=0`（ByteTrack 未分配 ID 时的回退编号，不代表真实人物）
- **保留**已标注过的 label（按 `video_id` + `track_id` 匹配，不会覆盖你的工作）
- 可在标注过程中随时重跑此命令来更新模板

---

### 步骤 3：人工观看 preview.mp4 并标注 events.csv

1. 打开 `data/pretrack/<video_id>_preview.mp4`
2. 画面中每个人身上都有 `ID:xxx` 的标签，左上角有 `Frame:xxx` 的帧号
3. 找 `data/annotations/events.csv` 中对应 `video_id` 和 `track_id` 的行
4. 将 `label` 列的 `TODO` 替换为以下四个标签之一：
   - `Swimming` — 正常游泳
   - `Idle in water` — 水中静止/漂浮
   - `Drowning` — 溺水挣扎
   - `Person out of water` — 离水/岸边

5. 如果该段行为中间有变化，将该行拆成多条（每段行为一致），分别填不同的帧范围
6. 确认 `usable` 列保持为 `1`；不确定的行为设 `usable=0` 或 label 填 `uncertain`

**events.csv 字段说明：**

| 字段 | 必填 | 说明 |
|------|------|------|
| `event_id` | 自动 | 递增编号 |
| `video_id` | 自动 | 对应 preview 文件名 |
| `source_video` | 自动 | 原始视频路径 |
| `track_id` | 自动 | preview 中显示的人物 ID |
| `start_frame` / `end_frame` | 自动 | 该 track 的实时帧范围（≥32 帧） |
| `start_time` / `end_time` | 自动 | 格式 `HH:MM:SS.mmm`，由帧号 ÷ fps 算出 |
| `label` | **你填** | `Swimming` / `Idle in water` / `Drowning` / `Person out of water` |
| `split` | 标注后划分 | 留空，标注完成后按类别均衡分配 train/val/test |
| `usable` | 可选 | 1=可用，0=跳过 |
| `note` | 自动 | 该 track 在 keypoints 中的总帧数 |

---

### 步骤 4：构建 GRU 训练数据集

标注完 events.csv 后，将 events.csv 与 keypoints.csv 对齐切片生成 `X.npy` / `y.npy`：

```bash
python src/build_gru_dataset.py \
    --events data/annotations/events.csv \
    --keypoints data/pretrack \
    --output data/processed \
    --seq-len 32 \
    --stride 8
```

| 参数 | 说明 |
|------|------|
| `--events` | events.csv 路径 |
| `--keypoints` | keypoints.csv 所在目录 |
| `--output` | 输出目录，默认 `data/processed` |
| `--seq-len` | 每个 GRU 序列的帧数，默认 32 |
| `--stride` | 滑动窗口步长，默认 8 |
| `--missing-frame-ratio` | 窗口缺失比例超过此值则丢弃，默认 0.20 |
| `--min-keypoint-conf` | 窗口平均关键点置信度低于此值则丢弃，默认 0.30 |

**生成以下文件：**

| 文件 | 内容 |
|------|------|
| `data/processed/X.npy` | 训练特征矩阵，形状 `[N, 32, 55]` |
| `data/processed/y.npy` | 训练标签，形状 `[N]`（整数类别 ID） |
| `data/processed/meta.csv` | 样本来源 trace |
| `data/processed/label_map.json` | 类别名 → ID 映射 |
| `data/processed/feature_schema.json` | X 每一维的字段顺序 |

---

### 步骤 5：数据集质量检查

训练前必须检查数据集完整性：

```bash
python src/check_dataset.py \
    --x data/processed/X.npy \
    --y data/processed/y.npy \
    --meta data/processed/meta.csv \
    --schema data/processed/feature_schema.json
```

会检查：数量一致性、NaN/Inf、特征维度、标签范围、类别分布、视频跨 split 泄漏等。所有检查通过后再训练。

---

### 步骤 6：训练 GRU 分类器

```bash
python src/train_gru.py \
    --x data/processed/X.npy \
    --y data/processed/y.npy \
    --epochs 50 \
    --batch-size 32 \
    --lr 0.001 \
    --save outputs/models/best_gru.pth
```

| 参数 | 说明 |
|------|------|
| `--x` / `--y` | 训练数据路径 |
| `--epochs` | 训练轮数 |
| `--batch-size` | 批大小，显存不足可降至 16 或 8 |
| `--lr` | 学习率 |
| `--save` | 最佳模型保存路径 |
| `--device` | `cuda`（默认）/ `cpu` |

训练日志保存在 `outputs/logs/train_log.csv`。每个 epoch 输出 train/val 的 loss、accuracy、F1，并自动保存 val F1 最高的模型。

---

### 步骤 7：评估模型

```bash
python src/evaluate.py \
    --x data/processed/X.npy \
    --y data/processed/y.npy \
    --model outputs/models/best_gru.pth
```

输出 Accuracy、Precision、Recall、F1（macro）、混淆矩阵。混淆矩阵图保存至 `outputs/logs/confusion_matrix.png`。

---

### 步骤 8：对视频进行推理

```bash
python src/infer_video.py \
    --video data/raw_videos/测试视频.mp4 \
    --gru outputs/models/best_gru.pth \
    --pose-model yolov8m-pose.pt \
    --save outputs/videos/result.mp4
```

| 参数 | 说明 |
|------|------|
| `--video` | 待推理的视频路径 |
| `--gru` | 训练好的 GRU 模型权重 |
| `--pose-model` | YOLO Pose 模型权重 |
| `--save` | 输出视频保存路径 |
| `--device` | `cuda`（默认）/ `cpu` |
| `--no-display` | 不弹出实时预览窗口（服务器环境） |

输出视频将显示：边界框 + track_id + 行为类别 + 置信度；当连续多帧判定为 `Drowning` 且概率 ≥ 0.7 时触发红色警报。

---

### 快速速查表

| 步骤 | 脚本 | 输入 | 输出 |
|------|------|------|------|
| 1. 预跟踪 | `pretrack_videos.py` | 原始视频 | preview.mp4 + keypoints.csv |
| 2. 生成模板 | `generate_events.py` | keypoints.csv | events.csv（TODO 模板） |
| 3. 标注 | 人工 | preview.mp4 | events.csv（已填 label） |
| 4. 构建数据集 | `build_gru_dataset.py` | events.csv + keypoints.csv | X.npy / y.npy / meta.csv |
| 5. 质量检查 | `check_dataset.py` | X.npy / y.npy / meta.csv | 终端报告 |
| 6. 训练 | `train_gru.py` | X.npy / y.npy | best_gru.pth |
| 7. 评估 | `evaluate.py` | X.npy / y.npy + best_gru.pth | 指标 + 混淆矩阵 |
| 8. 推理 | `infer_video.py` | 视频 + best_gru.pth | 标注输出视频 |



## 配置参数

所有默认值定义在 `src/config.py` 中。每个脚本均支持命令行参数覆盖：

| 参数 | 默认值 | 说明 |
|-----------|---------|------|
| `SEQ_LEN` | 32 | 每个序列样本的帧数（30 FPS 下约 1.07 秒） |
| `STRIDE` | 8 | 滑动窗口步长（窗口间有重叠以增加样本） |
| `FEATURE_DIM` | 55 | 17 个关键点 × 3 + 4 个 bbox；默认不包含 det_conf |
| `BATCH_FIRST` | True | GRU 输入格式使用 `[batch, seq, feature]`，即 `[N, SEQ_LEN, FEATURE_DIM]` |
| `DROWNING_THRESHOLD` | 0.7 | 判定疑似溺水的概率阈值 |
| `ALARM_CONSECUTIVE_COUNT` | 10 | 触发警报所需的连续推理窗口数；若映射到帧级，可换算为连续帧数 |
| `GRU_HIDDEN_SIZE` | 128 | GRU 隐层单元数 |
| `GRU_NUM_LAYERS` | 2 | 堆叠 GRU 层数 |
| `GRU_DROPOUT` | 0.3 | 层间 dropout 比率 |
| `MISSING_FRAME_RATIO` | 0.20 | 窗口缺失帧比例超过此值则剔除 |
| `MIN_KEYPOINT_CONF` | 0.30 | 窗口平均关键点置信度低于此值则剔除 |

## 特征设计

每帧默认生成 **55 维**特征向量。注意：`det_conf` 默认不进入 `X.npy`，只用于质量过滤和复查。

| 组成部分 | 维度 | 说明 |
|-----------|------|------|
| 关键点 | 0–50 | 17 个关键点 × (x, y, confidence)，已归一化到 [0, 1] |
| 边界框 | 51–54 | (cx, cy, w, h)，已归一化到 [0, 1] |

YOLO-Pose 使用的 17 个 COCO 关键点：

| 编号 | 英文名 | 中文含义 |
|------|--------|----------|
| 0 | nose | 鼻子 |
| 1 | left_eye | 左眼 |
| 2 | right_eye | 右眼 |
| 3 | left_ear | 左耳 |
| 4 | right_ear | 右耳 |
| 5 | left_shoulder | 左肩 |
| 6 | right_shoulder | 右肩 |
| 7 | left_elbow | 左肘 |
| 8 | right_elbow | 右肘 |
| 9 | left_wrist | 左腕 |
| 10 | right_wrist | 右腕 |
| 11 | left_hip | 左髋 |
| 12 | right_hip | 右髋 |
| 13 | left_knee | 左膝 |
| 14 | right_knee | 右膝 |
| 15 | left_ankle | 左踝 |
| 16 | right_ankle | 右踝 |

`feature_schema.json` 记录了 X 每一维对应的字段，训练、评估、推理必须使用同一份 schema，确保输入维度一致。

## 数据质量规范

### 缺失帧处理

水中人体经常被遮挡，导致某些帧检测不到目标或关键点置信度过低：

1. **Reindex**：对窗口内的缺失帧重建索引
2. **插值**：中间少量缺失帧使用线性插值补齐
3. **前后填充**：边界缺失帧用最近有效帧填充
4. **剔除**：缺失比例超过 `MISSING_FRAME_RATIO`（默认 20%）或平均关键点置信度低于 `MIN_KEYPOINT_CONF`（默认 0.30）的窗口直接剔除

### 防数据泄漏

训练集和测试集**按 video_id 划分**，同一视频的不同窗口绝不出现在不同 split 中。`check_dataset.py` 强制检查此项。

### 样本数统计

一个事件用滑动窗口会生成多个样本，但它们高度相似，不能等同于独立事件。报告中应同时统计**事件数**和**窗口数**；评估以事件级或视频级划分为准。

## 常见问题

**问：为什么需要 keypoints.csv？不能直接用 events.csv 生成 X.npy 吗？**

答：不能。events.csv 只包含"哪个视频、哪个 track_id、哪段帧、什么标签"，不包含每一帧的 17 个关键点坐标和人体框数值。而 GRU 的输入 X.npy 需要的是连续的数值特征序列——这些数值只能从 keypoints.csv（YOLO-Pose 逐帧输出）中获取。两者缺一不可。

**问：脚本输出 "No sequences extracted"？**

答：请检查 events.csv 与 keypoints.csv 中的 video_id、track_id 是否一致；事件帧范围是否在 keypoints.csv 覆盖范围内；关键点置信度是否过低导致窗口被剔除；pose 模型是否下载成功。

**问：CUDA 显存不足？**

答：降低 `--batch-size` 或加 `--device cpu` 使用 CPU 运行。

**问：可以使用其他 YOLO pose 模型吗？**

答：可以。在任意脚本中使用 `--model <模型名>.pt` 或 `--pose-model <模型名>.pt` 即可。所有 YOLO pose 变体（yolov8n-pose、yolov8m-pose、yolov8l-pose、yolo11n-pose 等）均输出 17 个 COCO 关键点且格式完全一致，特征维度（55）保持不变。默认模型为 `yolov8m-pose.pt`。

**问：如果视频中有多个人怎么办？**

答：预跟踪阶段 ByteTrack 会为每个人分配独立的 track_id。events.csv 按人标注（每个 track_id 独立标注行为）。构建数据集和推理时，每个人都独立处理。

**问：关键点置信度过低怎么办？**

答：水中下半身经常不可见，泳池场景关键点置信度可能整体偏低。`MIN_KEYPOINT_CONF` 阈值不宜设太高（建议从 0.30 开始），可通过 `meta.csv` 中的 `mean_keypoint_conf` 字段检查实际分布后调整。

**问：ByteTrack 给同一个人重新分配了 ID 怎么办？**

答：如果同一人在视频中途被重新分配了 track_id，应在 events.csv 中拆成两个事件分别标注，不要强行合并。

**问：如何增加更多行为类别？**

答：修改 `src/config.py` 中的 `LABEL_MAP` 和 `NUM_CLASSES`，更新 `events.csv` 中的 label 定义，然后重新构建数据集并重新训练。

**问：为什么 README 里 X.npy 是 `[N, 32, 55]`，而有些 PyTorch GRU 示例是 `[32, N, 55]`？**

答：因为本项目约定 `batch_first=True`，所以输入格式是 `[batch, seq, feature]`。如果使用 PyTorch 默认的 `batch_first=False`，输入才是 `[seq, batch, feature]`。为了减少初学者出错，本项目统一使用 `batch_first=True`。

**问：`det_conf` 要不要作为第 56 维输入？**

答：默认不加入。先使用 55 维更稳定、更清晰。如果后续实验发现 `det_conf` 有帮助，可以加入，但必须同时修改 `FEATURE_DIM=56`、`feature_schema.json`、训练代码、推理代码和已有模型权重的输入维度。

## 一句话总结

```
原始视频 → YOLO-Pose + ByteTrack → preview.mp4 + keypoints.csv
    → 人工标注 events.csv → events.csv + keypoints.csv 对齐切片
    → X.npy / y.npy / meta.csv → 训练 GRU 识别 Swimming / Idle in water / Drowning / Person out of water
```

**最终原则**：YOLO-Pose 负责"每一帧这个人长什么姿态"，events.csv 负责"这段时间这个人在做什么动作"，GRU 负责"连续多帧姿态变化属于哪类行为"。缺少 keypoints.csv，就没有 X.npy 的数值输入；缺少 events.csv，就没有可靠的 y.npy 标签。训练代码必须与数据形状保持一致：本项目统一使用 `batch_first=True`，即 `X=[N, SEQ_LEN, FEATURE_DIM]`。
