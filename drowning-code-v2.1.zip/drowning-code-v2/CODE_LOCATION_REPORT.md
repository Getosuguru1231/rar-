# 🏊 溺水监测系统 - 代码位置报告

> 版本: 1.0  
> 日期: 2026年6月7日  
> 描述: 系统代码按功能模块分类整理，便于查看和修改

---

## 一、系统整体架构

```
新1/
├── frontend/          # 前端(Vue 3)
├── backend/           # 后端(FastAPI)
├── data/              # 数据存储(视频、截图)
└── CODE_LOCATION_REPORT.md  # 本报告
```

---

## 二、前端代码分类

### 2.1 核心状态管理模块

| 功能 | 文件位置 | 说明 |
|------|---------|------|
| 摄像头状态管理 | `frontend/src/composables/useCameraState.js` | 统一管理摄像头配置、人数统计、告警状态 |
| 告警状态存储 | `frontend/src/stores/alertStore.js` | 管理告警列表、统计数据、筛选状态 |

### 2.2 通信模块

| 功能 | 文件位置 | 说明 |
|------|---------|------|
| WebSocket连接管理 | `frontend/src/composables/useWebSocket.js` | 统一处理WebSocket连接、心跳、重连 |
| WebSocket配置 | `frontend/src/config/websocket.js` | WebSocket URL配置和常量定义 |
| WebRTC视频传输 | `frontend/src/composables/useWebRTC.js` | WebRTC信令、PeerConnection管理 |
| WebRTC工具函数 | `frontend/src/utils/webrtc.js` | SDP处理、ICE候选、连接状态日志 |

### 2.3 视频流模块

| 功能 | 文件位置 | 说明 |
|------|---------|------|
| 视频流处理 | `frontend/src/composables/useVideoStream.js` | 视频流加载、错误处理、重试机制 |
| 视频上传检测 | `frontend/src/composables/useVideoDetection.js` | 视频上传、检测结果轮询 |
| MJPEG播放器 | `frontend/src/components/video/MJPEGPlayer.vue` | MJPEG格式视频流播放 |
| WebRTC播放器 | `frontend/src/components/video/WebRTCPlayer.vue` | WebRTC视频播放 |
| RDK X5 Edge播放器 | `frontend/src/components/video/RDK X5 EdgeVideoPlayer.vue` | RDK X5 Edge设备视频流播放 |
| 通用视频播放器 | `frontend/src/components/video/VideoPlayer.vue` | 视频播放器统一入口 |

### 2.4 定时器模块

| 功能 | 文件位置 | 说明 |
|------|---------|------|
| 定时器管理 | `frontend/src/composables/useTimer.js` | 统一管理setInterval/setTimeout |

### 2.5 API接口模块

| 功能 | 文件位置 | 说明 |
|------|---------|------|
| API请求封装 | `frontend/src/utils/api.js` | 统一的HTTP请求、错误处理、缓存 |
| API常量配置 | `frontend/src/utils/index.js` | API地址、常量定义、工具函数 |

### 2.6 页面视图模块

| 功能 | 文件位置 | 说明 |
|------|---------|------|
| 主监控页面 | `frontend/src/views/Monitor.vue` | 视频监控、告警列表、统计面板 |
| 告警管理页面 | `frontend/src/views/AlertManagement.vue` | 告警历史、确认、删除 |
| 检测历史页面 | `frontend/src/views/DetectionHistory.vue` | 检测记录、回放 |
| 管理面板页面 | `frontend/src/views/AdminPanel.vue` | 系统管理配置 |
| 登录页面 | `frontend/src/components/common/Login.vue` | 用户登录 |

### 2.7 组件模块

| 功能 | 文件位置 | 说明 |
|------|---------|------|
| 统计面板 | `frontend/src/components/common/StatsPanel.vue` | 实时统计数据展示 |
| 人数统计 | `frontend/src/components/common/PeopleCount.vue` | 人数统计显示 |
| 告警弹窗 | `frontend/src/components/business/AlertDialog.vue` | 告警详情弹窗 |
| 虚拟告警列表 | `frontend/src/components/business/VirtualAlertList.vue` | 虚拟滚动告警列表 |
| 视频流监控 | `frontend/src/components/monitor/VideoStreamMonitor.vue` | 视频流监控组件 |

### 2.8 路由模块

| 功能 | 文件位置 | 说明 |
|------|---------|------|
| 路由配置 | `frontend/src/router/index.js` | 前端路由定义 |

---

## 三、后端代码分类

### 3.1 路由模块

| 功能 | 文件位置 | 说明 |
|------|---------|------|
| 视频流路由 | `backend/routes/video_feed_routes.py` | MJPEG视频流接口 |
| WebRTC信令路由 | `backend/routes/webrtc_signaling.py` | WebRTC信令服务器 |
| WebSocket路由 | `backend/routes/video_websocket.py` | 视频数据WebSocket推送 |
| 告警路由 | `backend/routes/alert_routes.py` | 告警触发、列表、确认 |
| 摄像头路由 | `backend/routes/camera_routes.py` | 摄像头状态、配置 |
| 视频路由 | `backend/routes/video_routes.py` | 视频文件管理、检测 |
| 视频路由扩展 | `backend/routes/video_routes_ext.py` | 视频检测扩展接口 |
| 统一监控路由 | `backend/routes/unified_monitor.py` | 统一监控数据接口 |
| 健康检查路由 | `backend/routes/health_routes.py` | 系统健康检查 |
| 认证路由 | `backend/routes/auth_routes.py` | 用户登录、认证 |
| LLM路由 | `backend/routes/llm_routes.py` | LLM分析接口 |

### 3.2 核心服务模块

| 功能 | 文件位置 | 说明 |
|------|---------|------|
| 告警服务 | `backend/services/alert_service.py` | 告警逻辑处理 |
| 检测服务 | `backend/services/detection_service.py` | 目标检测处理 |
| 溺水告警服务 | `backend/services/drowning_alert_service.py` | 溺水检测逻辑 |
| LLM服务 | `backend/services/llm_service.py` | LLM分析服务 |
| 视频存储服务 | `backend/services/video_storage_service.py` | 视频文件存储管理 |
| 视频清理服务 | `backend/services/video_cleaner_service.py` | 过期视频清理 |

### 3.3 组件模块

| 功能 | 文件位置 | 说明 |
|------|---------|------|
| 告警管理器 | `backend/components/alert_manager.py` | 告警状态管理 |
| 摄像头连接 | `backend/components/camera_connection.py` | 摄像头连接管理 |
| 摄像头健康 | `backend/components/camera_health.py` | 摄像头健康检查 |
| 统一监控 | `backend/components/monitoring.py` | 系统监控指标 |
| Redis连接池 | `backend/components/redis_pool.py` | Redis连接管理 |
| WebSocket管理器 | `backend/components/websocket_manager.py` | WebSocket连接管理 |

### 3.4 WebRTC模块

| 功能 | 文件位置 | 说明 |
|------|---------|------|
| Peer连接管理 | `backend/webrtc/peer_manager.py` | WebRTC PeerConnection管理 |
| 视频帧处理 | `backend/webrtc/video_handler.py` | 视频帧捕获和处理 |

### 3.5 检测模块

| 功能 | 文件位置 | 说明 |
|------|---------|------|
| 检测核心 | `backend/detection/core.py` | YOLO目标检测核心逻辑 |
| 检测工具 | `backend/detection/utils.py` | 检测辅助工具函数 |

### 3.6 配置模块

| 功能 | 文件位置 | 说明 |
|------|---------|------|
| 配置管理器 | `backend/configs/config_manager.py` | 系统配置管理 |
| 系统配置 | `backend/configs/system.yaml` | 系统参数配置 |

### 3.7 启动入口

| 功能 | 文件位置 | 说明 |
|------|---------|------|
| 主入口 | `backend/main.py` | FastAPI应用入口 |

| 生产启动 | `backend/start_production.py` | 生产环境启动 |

---

## 四、功能模块与文件映射表

| 功能模块 | 前端文件 | 后端文件 |
|---------|---------|---------|
| **视频流播放** | useVideoStream.js, MJPEGPlayer.vue, WebRTCPlayer.vue, RDK X5 EdgeVideoPlayer.vue | video_feed_routes.py, video_handler.py |
| **WebRTC通信** | useWebRTC.js, webrtc.js | webrtc_signaling.py, peer_manager.py |
| **WebSocket通信** | useWebSocket.js, websocket.js | video_websocket.py, websocket_manager.py |
| **告警管理** | alertStore.js, AlertDialog.vue, AlertManagement.vue | alert_routes.py, alert_service.py, alert_manager.py |
| **目标检测** | useVideoDetection.js | detection_service.py, detection/core.py |
| **摄像头管理** | useCameraState.js | camera_routes.py, camera_connection.py |
| **统计数据** | StatsPanel.vue, PeopleCount.vue | unified_monitor.py, monitoring.py |
| **用户认证** | Login.vue | auth_routes.py |
| **定时任务** | useTimer.js | - |

---

## 五、修改指引

| 修改需求 | 推荐文件 | 说明 |
|---------|---------|------|
| 修改视频流参数 | `frontend/src/composables/useVideoStream.js` | 超时时间、重试次数、帧率 |
| 修改WebSocket配置 | `frontend/src/composables/useWebSocket.js` | 重连策略、心跳间隔 |
| 修改摄像头配置 | `frontend/src/composables/useCameraState.js` | 默认配置、初始摄像头列表 |
| 修改告警逻辑 | `frontend/src/stores/alertStore.js` | 告警状态更新、统计计算 |
| 修改检测模型 | `backend/detection/core.py` | YOLO模型加载、推理逻辑 |
| 修改视频存储 | `backend/services/video_storage_service.py` | 存储路径、文件命名 |
| 修改API接口 | `frontend/src/utils/api.js` | 请求封装、错误处理 |

---

## 六、关键常量位置

| 常量 | 文件位置 | 说明 |
|------|---------|------|
| API_BASE_URL | `frontend/src/utils/index.js` | 后端API地址 |
| VIDEO_STREAM_TIMEOUT | `frontend/src/composables/useVideoStream.js` | 视频流超时时间 |
| HEARTBEAT_INTERVAL | `frontend/src/composables/useWebSocket.js` | WebSocket心跳间隔 |
| MAX_RECONNECT_ATTEMPTS | `frontend/src/composables/useWebSocket.js` | 最大重连次数 |

---

## 七、数据流向图

```
摄像头 → OpenCV采集 → Redis缓存 → 后端API → WebSocket推送 → 前端展示
                                            ↓
                                       YOLO检测 → 告警触发 → 前端告警列表
```

---

## 八、Composable封装说明

### 8.1 useWebSocket

**功能**: 封装WebSocket连接管理逻辑

**特性**:
- 自动重连（指数退避策略）
- 心跳检测机制
- 连接超时处理
- 统一的消息处理回调

**使用方式**:
```javascript
const { connected, connect, disconnect, sendMessage } = useWebSocket(
  () => 'ws://localhost:8000/ws',
  {
    onMessage: handleMessage,
    onOpen: () => console.log('连接成功'),
    onClose: () => console.log('连接关闭')
  }
)
```

### 8.2 useTimer

**功能**: 封装定时器管理逻辑

**特性**:
- 支持key标记定时器
- 自动捕获异常
- 组件卸载时自动清理

**使用方式**:
```javascript
const { setInterval, clearInterval } = useTimer()
const timerId = setInterval(refreshStats, 2000, 'stats-refresh')
```

### 8.3 useCameraState

**功能**: 封装摄像头状态管理逻辑

**特性**:
- 统一的摄像头配置
- 计算属性自动更新统计
- 支持多数据源更新

**使用方式**:
```javascript
const { cameras, totalPeopleCount, refreshCameraStats } = useCameraState([
  { id: 1, area: '主游泳池', isConfigured: true }
])
```

---

## 九、API接口列表

### 9.1 视频流接口

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | `/video/feed/{camera_id}` | 获取MJPEG视频流 |
| GET | `/video/people-count` | 获取人数统计 |

### 9.2 WebSocket接口

| 路径 | 说明 |
|------|------|
| `/ws/video` | 视频数据推送 |
| `/ws/monitor` | 监控数据推送 |

### 9.3 告警接口

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | `/alert/list` | 获取告警列表 |
| POST | `/alert/trigger` | 触发告警 |
| POST | `/alert/acknowledge/{id}` | 确认告警 |
| DELETE | `/alert/delete/{id}` | 删除告警 |

### 9.4 认证接口

| 方法 | 路径 | 说明 |
|------|------|------|
| POST | `/auth/login` | 用户登录 |
| POST | `/auth/logout` | 用户登出 |

---

## 十、常用命令

### 前端

```bash
# 安装依赖
cd frontend && npm install

# 开发模式
cd frontend && npm run dev

# 生产构建
cd frontend && npm run build
```

### 后端

```bash
# 安装依赖
cd backend && pip install -r requirements.txt

# 开发模式
cd backend && python main.py
# 开发模式（自动重载）
# cd backend && python main.py --reload

# 生产模式
cd backend && python start_production.py
```

---

## 十一、目录结构汇总

```
frontend/src/
├── assets/           # 静态资源
├── components/       # 组件
│   ├── business/     # 业务组件
│   ├── common/       # 通用组件
│   ├── monitor/      # 监控组件
│   └── video/        # 视频组件
├── composables/      # Composable函数
├── config/           # 配置文件
├── router/           # 路由配置
├── stores/           # 状态存储
├── utils/            # 工具函数
├── views/            # 页面视图
├── App.vue           # 根组件
└── main.js           # 入口文件

backend/
├── api/              # API模块
├── components/       # 核心组件
├── configs/          # 配置文件
├── detection/        # 检测模块
├── routes/           # 路由定义
├── services/         # 服务层
├── webrtc/           # WebRTC模块
├── utils/            # 工具函数
├── main.py           # 主入口
└── start.py          # 启动脚本
```

---

**文档结束**