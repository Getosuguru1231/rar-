import json

with open(r'D:\zhuomian\132456\backend\detection_tasks.json', 'r', encoding='utf-8') as f:
    tasks = json.load(f)

for task_id, task in tasks.items():
    print(f'任务: {task_id[:8]}...')
    print(f'  drowning_events: {len(task.get("drowning_events", []))}个')
    print(f'  saved_images: {len(task.get("saved_images", []))}张')
    print(f'  temp_screenshots: {len(task.get("temp_screenshots", []))}张')

    # 检查事件类型分布
    events = task.get('drowning_events', [])
    types = {}
    for e in events:
        t = e.get('type', 'unknown')
        types[t] = types.get(t, 0) + 1
    print(f'  事件类型分布: {types}')
