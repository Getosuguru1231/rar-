@echo off
chcp 65001 >nul
echo ================================================
echo           智能溺水检测系统 - 一键启动脚本
echo ================================================
echo.

set "BACKEND_DIR=%~dp0backend"
set "FRONTEND_DIR=%~dp0frontend"
set "REACT_DIR=%~dp0react"

echo 请选择要启动的服务:
echo.
echo [1] 启动所有服务 (Redis + 后端 + Vue前端)
echo [2] 仅启动后端服务
echo [3] 仅启动Vue前端
echo [4] 仅启动React前端
echo [5] 仅启动Redis
echo [6] 使用Docker Compose启动全部
echo [0] 退出
echo.
set /p "choice=请输入选择 [0-6]: "

if "%choice%"=="1" (
    echo.
    echo [启动Redis]
    start "Redis" cmd /k "cd /d %~dp0 && start_redis.bat"
    timeout /t 2 /nobreak >nul
    
    echo.
    echo [启动后端服务]
    start "Backend" cmd /k "cd /d %BACKEND_DIR% && start_backend.bat"
    timeout /t 3 /nobreak >nul
    
    echo.
    echo [启动Vue前端]
    start "Vue Frontend" cmd /k "cd /d %FRONTEND_DIR% && start_frontend_vue.bat"
    
    echo.
    echo 所有服务已启动，正在打开浏览器...
    timeout /t 5 /nobreak >nul
    start http://localhost:3001
    
) else if "%choice%"=="2" (
    echo.
    echo [启动后端服务]
    cd /d %BACKEND_DIR%
    call start_backend.bat
    
) else if "%choice%"=="3" (
    echo.
    echo [启动Vue前端]
    cd /d %FRONTEND_DIR%
    call start_frontend_vue.bat
    
) else if "%choice%"=="4" (
    echo.
    echo [启动React前端]
    cd /d %REACT_DIR%
    call start_frontend_react.bat
    
) else if "%choice%"=="5" (
    echo.
    echo [启动Redis]
    call start_redis.bat
    
) else if "%choice%"=="6" (
    echo.
    echo [使用Docker Compose启动全部服务]
    echo 请确保Docker已运行
    timeout /t 2 /nobreak >nul
    docker-compose up -d
    if %errorlevel% equ 0 (
        echo [OK] Docker服务启动成功
        echo 访问地址:
        echo   - Vue前端: http://localhost:3001
        echo   - React前端: http://localhost:5173
        echo   - 后端API: http://localhost:8000
        timeout /t 5 /nobreak >nul
        start http://localhost:3001
    ) else (
        echo [ERROR] Docker启动失败
    )
    
) else if "%choice%"=="0" (
    echo 退出...
    exit /b 0
    
) else (
    echo [ERROR] 无效选择
    pause
    goto :eof
)

echo.
echo ================================================
echo           服务启动完成
echo ================================================
echo.
echo 服务地址:
echo   - Vue前端: http://localhost:3001
echo   - React前端: http://localhost:5173
echo   - 后端API: http://localhost:8000
echo   - API文档: http://localhost:8000/docs
echo   - Redis: localhost:6379
echo.
echo 按任意键退出...
pause >nul