import re

# 读取文件
with open('frontend/src/views/Monitor.vue', 'r', encoding='utf-8') as f:
    content = f.read()

# 添加 WebRTCPlayer 导入
if 'import WebRTCPlayer' not in content:
    content = content.replace(
        'import axios from "axios"',
        'import axios from "axios"\nimport WebRTCPlayer from "../components/video/WebRTCPlayer.vue"'
    )

# 替换视频流部分
old_video = '''            <div class="video-wrapper">
              <!-- 实时视频流 -->
              <img 
                :src="`/api/video_feed?camera=${camera.id}&t=${Date.now()}`" 
                alt="监控画面" 
                class="video-stream"
                @error="handleVideoError(camera.id)"
              >
              <!-- 视频加载错误 -->
              <div class="video-error" v-if="camera.videoError" @click="reloadVideo(camera.id)">
                画面加载失败，点击刷新
              </div>'''

new_video = '''            <div class="video-wrapper">
              <!-- WebRTC 低延迟视频流 -->
              <WebRTCPlayer 
                :camera-id="camera.id" 
                :auto-connect="true"
                :show-stats="false"
                @connected="(data) => handleVideoConnected(camera.id, data)"
                @error="(data) => handleVideoError(camera.id, data)"
              />'''

content = content.replace(old_video, new_video)

# 添加 WebRTC 相关的事件处理函数
if 'const handleVideoConnected' not in content:
    # 找到 handleVideoError 函数并在其后添加新函数
    handle_video_error_pattern = r'(const handleVideoError = \(cameraId[^}]+\})'
    replacement = r'\1\n\nconst handleVideoConnected = (cameraId, data) => {\n  console.log(`[Monitor] 摄像头 ${cameraId} WebRTC连接成功:`, data)\n  const camera = cameras.value.find(c => c.id === cameraId)\n  if (camera) {\n    camera.videoLoaded = true\n    camera.videoError = false\n  }\n}'
    
    content = re.sub(handle_video_error_pattern, replacement, content)

# 保存文件
with open('frontend/src/views/Monitor.vue', 'w', encoding='utf-8') as f:
    f.write(content)

print('修改完成')
