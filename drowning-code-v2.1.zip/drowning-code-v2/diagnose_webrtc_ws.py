#!/usr/bin/env python3
"""WebRTC WebSocket端点诊断脚本"""

import asyncio
import json
import sys
from datetime import datetime

async def test_websocket(url, name):
    """测试WebSocket连接"""
    try:
        import websockets
        print(f"\n{'='*60}")
        print(f"测试: {name}")
        print(f"URL: {url}")
        print(f"{'='*60}")
        
        async with websockets.connect(url, ping_interval=None, close_timeout=5) as ws:
            print("✅ WebSocket连接成功!")
            
            # 接收第一条消息（如果有）
            try:
                msg = await asyncio.wait_for(ws.recv(), timeout=3)
                print(f"📩 收到消息: {msg[:200]}")
            except asyncio.TimeoutError:
                print("⏳ 3秒内无消息")
            
            return True
    except Exception as e:
        print(f"❌ 连接失败: {type(e).__name__}: {e}")
        return False

async def test_webrtc_signaling():
    """测试WebRTC信令"""
    print("\n" + "="*60)
    print("WebRTC 信令测试")
    print("="*60)
    
    url = "ws://localhost:8002/ws/webrtc/1"
    
    try:
        import websockets
        async with websockets.connect(url, ping_interval=None) as ws:
            print("✅ 信令连接成功!")
            
            # 接收任何初始消息
            try:
                msg = await asyncio.wait_for(ws.recv(), timeout=2)
                print(f"📩 初始消息: {msg}")
            except asyncio.TimeoutError:
                print("⏳ 无初始消息")
            
            # 发送ping
            print("\n📤 发送ping...")
            await ws.send(json.dumps({"type": "ping"}))
            
            try:
                resp = await asyncio.wait_for(ws.recv(), timeout=5)
                print(f"📩 ping响应: {resp}")
            except asyncio.TimeoutError:
                print("❌ 5秒内无ping响应")
            
            return True
    except Exception as e:
        print(f"❌ 信令测试失败: {type(e).__name__}: {e}")
        return False

async def main():
    print("="*60)
    print("WebRTC 视频流诊断")
    print(f"时间: {datetime.now()}")
    print("="*60)
    
    # 测试三个关键端点
    endpoints = [
        ("ws://localhost:8002/ws/webrtc/1", "WebRTC信令"),
        ("ws://localhost:8002/ws/video/1", "视频流"),
        ("ws://localhost:8002/ws/alerts", "告警推送"),
    ]
    
    results = {}
    for url, name in endpoints:
        results[name] = await test_websocket(url, name)
    
    # 单独测试WebRTC信令
    await test_webrtc_signaling()
    
    print("\n" + "="*60)
    print("诊断结果汇总")
    print("="*60)
    for name, success in results.items():
        status = "✅ 正常" if success else "❌ 失败"
        print(f"{name}: {status}")
    
    return all(results.values())

if __name__ == "__main__":
    result = asyncio.run(main())
    sys.exit(0 if result else 1)
