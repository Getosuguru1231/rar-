# 智能溺水检测系统 - 问题排查与修复报告

## 报告概述

本报告记录了智能溺水检测系统在开发和运行过程中遇到的问题、根本原因分析以及对应的修复方案。

---

## 目录

1. [失帧和掉帧问题](#1-失帧和掉帧问题)
2. [端口连接问题](#2-端口连接问题)
3. [视频上传检测功能问题](#3-视频上传检测功能问题)
4. [API路径错误](#4-api路径错误)
5. [画面显示效果优化](#5-画面显示效果优化)
6. [标签显示问题](#6-标签显示问题)
7. [人数统计问题](#7-人数统计问题)
8. [总结](#8-总结)

---

## 1. 失帧和掉帧问题

### 问题描述
视频流卡顿严重，实际帧率仅为 0.8-0.9 fps，远低于目标帧率。

### 根本原因
主循环中直接调用 `cap.read()` 读取摄像头帧导致主线程阻塞，无法及时处理视频流。

### 修复方案

**文件**: `backend/detect.py`

```python
# 引入独立线程更新摄像头帧，避免阻塞主循环
import threading
frame_lock = threading.Lock()

def update_camera_frame():
    nonlocal current_frame
    while not redis_client.get("stop_detection"):
        try:
            cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
            ret, temp_frame = cap.read()
            if ret and temp_frame is not None:
                with frame_lock:
                    current_frame = temp_frame.copy()
        except:
            pass
        time.sleep(0.5)

# 启动摄像头更新线程
camera_thread = threading.Thread(target=update_camera_frame, daemon=True)
camera_thread.start()
```

**优化结果**: 帧率从 0.8 fps 提升至约 6.6 fps

---

## 2. 端口连接问题

### 问题描述
前端代理配置指向错误的后端端口，导致前后端无法正常通信。

### 根本原因
- 后端服务运行在端口 8002
- 前端代理配置指向了端口 8003

### 修复方案

**文件**: `frontend/vite.config.js`

```javascript
// 修改前
proxy: {
  '/api': { target: 'http://localhost:8003', ... },
  '/ws': { target: 'http://localhost:8003', ... }
}

// 修改后
proxy: {
  '/api': { target: 'http://localhost:8002', ... },
  '/ws': { target: 'http://localhost:8002', ... }
}
```

**同步更新**: README.md 文档中所有端口引用已同步更新

---

## 3. 视频上传检测功能问题

### 问题描述
视频上传检测功能无法正常使用，API 调用失败。

### 根本原因

#### 3.1 API路径重复问题
axios 的 `baseURL` 已设置为 `/api`，但前端调用时又添加了 `/api` 前缀，导致 URL 变成 `/api/api/detection/...`

#### 3.2 数据结构不匹配
后端 API 返回格式为 `{code, data: {...}}`，但前端直接访问 `data.videos` 而不是 `data.data.videos`

### 修复方案

**文件**: `frontend/src/composables/useVideoDetection.js`

```javascript
// 修复路径重复问题 - 移除重复的 /api 前缀
const response = await apiGet('/detection/videos/list', {}, {}, false)

// 修复数据结构问题 - 正确访问嵌套的 data 字段
const data = response.data || {}
videoList.value = data.videos || []
```

**修改的 API 调用**:
- `/api/detection/upload` → `/detection/upload`
- `/api/detection/result/{task_id}` → `/detection/result/{task_id}`
- `/api/detection/tasks` → `/detection/tasks`
- `/api/detection/videos/list` → `/detection/videos/list`
- `/api/detection/results/images/{task_id}` → `/detection/results/images/{task_id}`

---

## 4. API路径错误

### 问题描述
前端调用 `/api/video/videos/list` 返回 404 错误。

### 根本原因
后端实际路由为 `/api/detection/videos/list`，前端调用了错误的路径 `/api/video/videos/list`

### 修复方案
统一 API 路径前缀为 `/detection/`，更新所有相关的前端 API 调用。

---

## 5. 画面显示效果优化

### 问题描述
视频画面有黑边，没有填满容器；摄像头标题栏和状态徽章样式不够清晰。

### 根本原因
- 视频元素使用 `object-fit: contain`，会保持宽高比但不填满容器
- 标题栏和徽章样式过于简洁，视觉效果不佳

### 修复方案

**文件**: `frontend/src/views/Monitor.vue`

```css
/* 视频容器样式优化 */
.video-container video {
  object-fit: cover;  /* 填满容器，保持比例 */
  background-color: #0a0a0f;
}

/* 摄像头标题栏优化 */
.camera-header {
  padding: 6px 12px;
  background: rgba(0, 0, 0, 0.7);
  backdrop-filter: blur(4px);
}

/* 连接状态徽章优化 */
.connection-badge {
  font-size: 12px;
  padding: 3px 10px;
  border-radius: 10px;
}

.connection-badge.connected {
  background: rgba(34, 197, 94, 0.2);
  color: #22c55e;
}
```

**文件**: `frontend/src/components/video/WebRTCPlayer.vue`

```css
.video-element {
  object-fit: cover;  /* 改为 cover 填满容器 */
  background-color: #0a0a0f;
}
```

---

## 6. 标签显示问题

### 问题描述
检测框标签不显示，中英文标签均不显示。

### 根本原因
代码中检查的标签名称与 YOLO 模型实际输出的标签不匹配：
- 代码检查 `"drowning"` 和 `"Normal"`
- 模型实际输出 `"in_water"`, `"in_water2"`, `"out_of_water"`

### 修复方案

**文件**: `backend/detect.py`

```python
# 修复前
if cls_name == "drowning" and conf >= CONF_THRESHOLD:
    label_text = f"Drowning {conf:.2f}"
else:
    label_text = f"Normal {conf:.2f}"

# 修复后
if cls_name in ['in_water', 'in_water2'] and conf >= CONF_THRESHOLD:
    label_text = f"{cls_name} {conf:.2f}"
else:
    label_text = f"{cls_name} {conf:.2f}"
```

---

## 7. 人数统计问题

### 问题描述
画面上人数统计显示导致画面框跳动，影响观看体验。

### 根本原因
人数统计文字直接绘制在视频画面上，每次人数变化都会导致画面重新绘制，产生跳动效果。

### 修复方案

**文件**: `backend/detection/core.py`

移除画面上绘制人数统计的代码（第 169-174 行）：
- 移除"总人数"显示
- 移除"水中人数"显示
- 移除"风险等级"显示

**保留功能**: 人数统计仍在后端计算并写入 Redis，供监控面板使用。

---

## 8. 总结

### 已修复问题列表

| 问题类型 | 状态 | 影响文件 |
|----------|------|----------|
| 失帧和掉帧 | ✅ 已修复 | `backend/detect.py` |
| 端口配置不一致 | ✅ 已修复 | `frontend/vite.config.js` |
| API路径重复 | ✅ 已修复 | `frontend/src/composables/useVideoDetection.js` |
| API路径错误 | ✅ 已修复 | `frontend/src/composables/useVideoDetection.js` |
| 数据结构不匹配 | ✅ 已修复 | `frontend/src/composables/useVideoDetection.js` |
| 画面显示效果 | ✅ 已优化 | `frontend/src/views/Monitor.vue`, `frontend/src/components/video/WebRTCPlayer.vue` |
| 标签显示问题 | ✅ 已修复 | `backend/detect.py` |
| 人数统计显示 | ✅ 已优化 | `backend/detection/core.py` |

### 当前系统状态

| 项目 | 状态 |
|------|------|
| 后端服务 | ✅ 运行中 (http://localhost:8002) |
| 前端服务 | ✅ 运行中 (http://localhost:3000) |
| WebRTC连接 | ✅ 正常 |
| Redis连接 | ✅ 正常 |
| YOLO模型 | ✅ 已加载 (GPU加速) |
| 视频帧率 | ✅ 约6.6 fps |

### 后续建议

1. **持续性能监控**: 建议添加性能监控指标，定期检查帧率和延迟
2. **日志系统完善**: 增加更详细的错误日志和调试信息
3. **自动故障恢复**: 实现自动重连和故障转移机制
4. **负载均衡**: 考虑引入负载均衡以支持更多并发连接

---

**报告生成时间**: 2026-06-01  
**系统版本**: v2.0