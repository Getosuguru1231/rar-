const http = require('http');

const boundary = '----TestBoundary12345';
const fileContent = 'test content for upload';

const body = Buffer.from(
  '--' + boundary + '\r\n' +
  'Content-Disposition: form-data; name="video"; filename="test.jpg"\r\n' +
  'Content-Type: image/jpeg\r\n' +
  '\r\n' +
  fileContent + '\r\n' +
  '--' + boundary + '--\r\n'
);

const options = {
  hostname: 'localhost',
  port: 8002,
  path: '/api/detection/upload',
  method: 'POST',
  headers: {
    'Content-Type': 'multipart/form-data; boundary=' + boundary,
    'Content-Length': body.length
  }
};

const req = http.request(options, (res) => {
  console.log('Status:', res.statusCode);
  let data = '';
  res.on('data', (chunk) => { data += chunk; });
  res.on('end', () => { console.log('Response:', data); });
});

req.on('error', (e) => { console.error('Error:', e.message); });
req.write(body);
req.end();