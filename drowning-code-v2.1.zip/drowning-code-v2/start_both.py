import subprocess
import time
import os

print("=== 启动前端服务 ===")
os.chdir('frontend')
result = subprocess.run(['npm', 'run', 'dev'], capture_output=True, text=True, timeout=30)
print(f"前端服务启动结果: {result.returncode}")
print(f"STDOUT: {result.stdout}")
print(f"STDERR: {result.stderr}")
