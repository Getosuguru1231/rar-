@echo off
chcp 65001 >nul
echo ================================================
echo           智能溺水检测系统 - 后端启动脚本
echo ================================================
echo.

set "VENV_DIR=venv"
set "PYTHON_EXE=python"
set "UVICORN_PORT=8001"

cd /d "%~dp0backend"

echo [检查虚拟环境]
if not exist "%VENV_DIR%" (
    echo 未找到虚拟环境，正在创建...
    %PYTHON_EXE% -m venv %VENV_DIR%
    if %errorlevel% neq 0 (
        echo [ERROR] 虚拟环境创建失败
        pause
        exit /b 1
    )
    echo [OK] 虚拟环境创建成功
)

echo.
echo [激活虚拟环境]
call %VENV_DIR%\Scripts\activate.bat
if %errorlevel% neq 0 (
    echo [ERROR] 虚拟环境激活失败
    pause
    exit /b 1
)
echo [OK] 虚拟环境已激活

echo.
echo [检查依赖]
pip list | findstr /i "fastapi uvicorn redis" >nul
if %errorlevel% neq 0 (
    echo 缺少依赖，正在安装...
    pip install -r requirements.txt
    if %errorlevel% neq 0 (
        echo [ERROR] 依赖安装失败
        pause
        exit /b 1
    )
    echo [OK] 依赖安装成功
)

echo.
echo [启动后端服务]
echo 服务端口: %UVICORN_PORT%
echo 访问地址: http://localhost:%UVICORN_PORT%
echo Swagger文档: http://localhost:%UVICORN_PORT%/docs
echo.
uvicorn main:app --host 0.0.0.0 --port %UVICORN_PORT% --reload

pause