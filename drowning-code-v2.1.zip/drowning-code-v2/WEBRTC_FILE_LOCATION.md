# WebRTC 视频流文件位置文档

## 概述

本项目基于 WebRTC 技术实现实时视频流传输，包含完整的后端信令服务器、Peer连接管理、视频帧处理以及前端播放组件。文档详细列出所有与 WebRTC 相关的文件位置及其功能说明。

---

## 一、后端 WebRTC 模块 (`backend/webrtc/`)

### 1.1 模块初始化

| 文件 | 路径 | 功能 |
|------|------|------|
| `__init__.py` | [backend/webrtc/__init__.py](file:///d:/图片/三合一/backend/webrtc/__init__.py) | WebRTC模块入口，导出核心类和配置函数 |

**核心导出：**
- `PeerManager` / `peer_manager`: 全局Peer连接管理器
- `VideoFrameHandler` / `WebRTCVideoTrack`: 视频帧处理和轨道类
- `webrtc_config`: WebRTC全局配置实例
- `get_ice_servers` / `get_video_config` / `get_connection_timeout` / `get_reconnect_config`: 配置获取函数

---

### 1.2 配置管理

| 文件 | 路径 | 功能 |
|------|------|------|
| `config.py` | [backend/webrtc/config.py](file:///d:/图片/三合一/backend/webrtc/config.py) | WebRTC连接配置，包括ICE服务器、编解码器、带宽、超时等 |

**主要配置项：**
- **ICE服务器**: STUN/TURN服务器列表（默认使用Google STUN）
- **视频参数**: 分辨率(1920x1080)、帧率(30fps)、码率(800kbps-4Mbps)
- **编解码器**: H264（低延迟优化）、Opus音频
- **连接超时**: 30秒连接超时，15秒ICE收集超时
- **重连配置**: 最大5次重连尝试，指数退避延迟

---

### 1.3 Peer连接管理

| 文件 | 路径 | 功能 |
|------|------|------|
| `peer_manager.py` | [backend/webrtc/peer_manager.py](file:///d:/图片/三合一/backend/webrtc/peer_manager.py) | 管理WebRTC对等连接生命周期，处理Offer/Answer、ICE候选 |

**核心类：**

| 类名 | 职责 |
|------|------|
| `WebRTCPeer` | 单个Peer连接的封装，包含RTCPeerConnection和视频轨道 |
| `PeerManager` | 全局Peer管理器，维护peer_id到Peer对象的映射 |

**关键方法：**
- `create_peer()`: 创建新的Peer连接
- `handle_offer()`: 处理客户端Offer，生成Answer（含SDP优化）
- `add_ice_candidate()`: 添加ICE候选
- `remove_peer()`: 清理Peer连接
- `_optimize_sdp()`: 优化SDP参数（带宽限制、RTCP反馈、H264参数）

---

### 1.4 视频帧处理

| 文件 | 路径 | 功能 |
|------|------|------|
| `video_handler.py` | [backend/webrtc/video_handler.py](file:///d:/图片/三合一/backend/webrtc/video_handler.py) | 视频帧获取、处理和WebRTC视频轨道实现 |

**核心类：**

| 类名 | 职责 |
|------|------|
| `VideoFrameHandler` | 视频帧获取器，从Redis或本地摄像头读取帧 |
| `WebRTCVideoTrack` | aiortc视频轨道实现，按帧率发送帧 |

**帧获取流程：**
1. **优先从Redis获取**: 从`current_frame_{camera_id}`键读取JPEG编码帧
2. **后备方案**: 使用OpenCV读取本地摄像头
3. **帧队列**: 维护小型帧队列，减少延迟

**关键特性：**
- 帧率控制（30fps目标）
- 单调递增PTS时间戳
- 帧尺寸验证和缩放
- 后备帧机制（防止空白画面）

---

### 1.5 信令服务器

| 文件 | 路径 | 功能 |
|------|------|------|
| `webrtc_signaling.py` | [backend/api/webrtc_signaling.py](file:///d:/图片/三合一/backend/api/webrtc_signaling.py) | WebSocket信令端点，处理Offer/Answer/ICE信令交换 |

**WebSocket端点：**
- `ws/webrtc/{camera_id}`: WebRTC信令连接入口

**核心类：**

| 类名 | 职责 |
|------|------|
| `SignalingManager` | 信令管理器，维护WebSocket连接和心跳检测 |

**信令消息类型：**
| 类型 | 方向 | 说明 |
|------|------|------|
| `offer` | 客户端→服务端 | 客户端发送Offer |
| `answer` | 服务端→客户端 | 服务端回复Answer |
| `ice_candidate` | 双向 | ICE候选交换 |
| `ping/pong` | 双向 | 心跳检测 |
| `close` | 客户端→服务端 | 关闭连接 |

**心跳机制：**
- 心跳间隔：30秒
- PONG超时：60秒
- 最大丢失PONG数：5次 → 断开连接

---

## 二、前端 WebRTC 模块 (`frontend/src/`)

### 2.1 WebRTC组合式函数

| 文件 | 路径 | 功能 |
|------|------|------|
| `useWebRTC.js` | [frontend/src/composables/useWebRTC.js](file:///d:/图片/三合一/frontend/src/composables/useWebRTC.js) | Vue组合式函数，封装WebRTC连接逻辑 |

**返回值：**

| 属性/方法 | 类型 | 说明 |
|-----------|------|------|
| `remoteStream` | `ref<MediaStream>` | 远程视频流 |
| `isConnected` | `ref<boolean>` | 连接状态 |
| `isConnecting` | `ref<boolean>` | 连接中状态 |
| `connectionState` | `ref<string>` | 连接状态字符串 |
| `iceConnectionState` | `ref<string>` | ICE连接状态 |
| `stats` | `ref<object>` | 连接统计信息 |
| `error` | `ref<string>` | 错误信息 |
| `connect()` | `function` | 建立连接 |
| `disconnect()` | `function` | 断开连接 |
| `restart()` | `function` | 重启连接 |

**关键特性：**
- 自动重连（最大10次，指数退避）
- 心跳检测（20秒间隔）
- 统计监控（帧率、丢包率）
- SDP低延迟优化
- JitterBuffer配置（50ms目标）

---

### 2.2 WebRTC播放器组件

| 文件 | 路径 | 功能 |
|------|------|------|
| `WebRTCPlayer.vue` | [frontend/src/components/video/WebRTCPlayer.vue](file:///d:/图片/三合一/frontend/src/components/video/WebRTCPlayer.vue) | WebRTC视频播放器组件，自动播放远程流 |

**Props：**

| 属性 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `cameraId` | `Number/String` | - | 摄像头ID（必填） |
| `autoConnect` | `Boolean` | `true` | 是否自动连接 |
| `showStats` | `Boolean` | `false` | 是否显示性能统计 |

**Events：**

| 事件 | 说明 |
|------|------|
| `connected` | 连接成功 |
| `disconnected` | 连接断开 |
| `error` | 连接错误 |
| `stats` | 统计信息更新 |

**模板结构：**
- `<video>`元素：直接播放远程流（无Canvas层）
- 性能统计面板：显示帧率、丢包率、重连次数
- 连接状态覆盖层：连接中、已断开、错误状态

---

### 2.3 WebRTC工具函数

| 文件 | 路径 | 功能 |
|------|------|------|
| `webrtc.js` | [frontend/src/utils/webrtc.js](file:///d:/图片/三合一/frontend/src/utils/webrtc.js) | WebRTC工具函数和常量定义 |

**核心常量：**

| 常量 | 说明 |
|------|------|
| `ICE_SERVERS` | STUN服务器列表（7个公共服务器） |
| `TURN_SERVERS` | TURN服务器配置 |
| `DEFAULT_CONFIG` | RTCPeerConnection默认配置 |
| `SIGNALING_MESSAGE_TYPES` | 信令消息类型枚举 |

**核心函数：**

| 函数 | 说明 |
|------|------|
| `getIceServers()` | 获取ICE服务器（含环境变量配置） |
| `createPeerConnection()` | 创建RTCPeerConnection实例 |
| `setLowLatencySDP()` | 优化SDP以降低延迟 |
| `validateSDP()` | 验证SDP格式 |
| `getReconnectDelay()` | 计算重连延迟（指数退避） |
| `formatStats()` | 格式化连接统计信息 |

---

### 2.4 WebSocket配置

| 文件 | 路径 | 功能 |
|------|------|------|
| `websocket.js` | [frontend/src/config/websocket.js](file:///d:/图片/三合一/frontend/src/config/websocket.js) | WebSocket地址配置，包含WebRTC信令地址生成 |

**关键函数：**
- `getWebRtcWsUrl(cameraId)`: 生成WebRTC信令WebSocket地址

---

## 三、相关页面和组件

### 3.1 测试页面

| 文件 | 路径 | 功能 |
|------|------|------|
| `TestWebRTC.vue` | [frontend/src/views/TestWebRTC.vue](file:///d:/图片/三合一/frontend/src/views/TestWebRTC.vue) | WebRTC功能测试页面 |

### 3.2 监控相关

| 文件 | 路径 | 功能 |
|------|------|------|
| `Monitor.vue` | [frontend/src/views/Monitor.vue](file:///d:/图片/三合一/frontend/src/views/Monitor.vue) | 主监控页面，展示多路视频流 |
| `VideoStreamMonitor.vue` | [frontend/src/components/monitor/VideoStreamMonitor.vue](file:///d:/图片/三合一/frontend/src/components/monitor/VideoStreamMonitor.vue) | 视频流监控组件 |
| `useMonitor.js` | [frontend/src/composables/useMonitor.js](file:///d:/图片/三合一/frontend/src/composables/useMonitor.js) | 监控功能组合式函数 |

---

## 四、视频流数据流向

```
┌──────────────┐    Redis    ┌──────────────┐
│  摄像头/检测  │ ──────────► │ VideoFrame   │
│   线程(detect.py) │          │   Handler    │
└──────────────┘             └───────┬──────┘
                                     │
                                     ▼
                            ┌──────────────┐    WebRTC    ┌──────────────┐
                            │ WebRTCVideo  │ ────────────► │ WebRTCPlayer │
                            │    Track     │   视频流      │    (前端)    │
                            └───────┬──────┘              └──────────────┘
                                    │
                     ┌──────────────┼──────────────┐
                     ▼              ▼              ▼
              ┌─────────┐   ┌──────────────┐  ┌──────────────┐
              │PeerManager│   │ Signaling    │  │   Config     │
              │           │   │  Manager     │  │              │
              └─────────┘   └──────────────┘  └──────────────┘
```

### 数据流转步骤：

1. **帧采集**: `detection/detect.py` 将视频帧写入Redis (`current_frame_{camera_id}`)
2. **帧读取**: `VideoFrameHandler` 从Redis读取JPEG帧并解码
3. **帧传输**: `WebRTCVideoTrack.recv()` 按帧率发送帧到WebRTC
4. **信令交换**: `SignalingManager` 通过WebSocket处理Offer/Answer/ICE
5. **视频播放**: 前端`WebRTCPlayer`接收远程流并播放

---

## 五、WebRTC连接流程

```
客户端                              服务端
   │                                  │
   │─── WebSocket连接 ──────────────►│
   │  ws://host/ws/webrtc/{camera_id}│
   │                                  │
   │─── Offer ──────────────────────►│
   │                                  │
   │◄── Answer ──────────────────────│
   │                                  │
   │─── ICE Candidate ──────────────►│
   │◄── ICE Candidate ──────────────│
   │                                  │
   │◄── WebRTC Video Stream ─────────│
   │                                  │
```

---

## 六、配置环境变量

| 环境变量 | 说明 | 默认值 |
|----------|------|--------|
| `WEBRTC_STUN_SERVERS` | STUN服务器列表（逗号分隔） | Google STUN服务器 |
| `WEBRTC_TURN_URL` | TURN服务器地址 | 无 |
| `WEBRTC_TURN_USERNAME` | TURN服务器用户名 | 无 |
| `WEBRTC_TURN_CREDENTIAL` | TURN服务器密码 | 无 |
| `WEBRTC_VIDEO_WIDTH` | 视频宽度 | 1920 |
| `WEBRTC_VIDEO_HEIGHT` | 视频高度 | 1080 |
| `WEBRTC_VIDEO_FPS` | 视频帧率 | 30 |
| `WEBRTC_MAX_VIDEO_BITRATE` | 最大视频码率 | 4000000 |
| `WEBRTC_MIN_VIDEO_BITRATE` | 最小视频码率 | 800000 |
| `WEBRTC_CONNECTION_TIMEOUT` | 连接超时（毫秒） | 30000 |

---

## 七、关键依赖

### 后端依赖

| 依赖 | 版本 | 用途 |
|------|------|------|
| `aiortc` | - | WebRTC服务器实现 |
| `aioice` | - | ICE候选处理 |
| `av` | - | 视频帧编码 |
| `redis` | - | 帧数据缓存 |
| `opencv-python` | - | 帧解码和处理 |

### 前端依赖

| 依赖 | 用途 |
|------|------|
| Vue 3 | 前端框架 |
| WebRTC API | 浏览器原生WebRTC支持 |
| WebSocket API | 信令传输 |

---

## 八、文件位置汇总表

| 分类 | 文件 | 路径 |
|------|------|------|
| **后端核心** | `__init__.py` | `backend/webrtc/__init__.py` |
| | `config.py` | `backend/webrtc/config.py` |
| | `peer_manager.py` | `backend/webrtc/peer_manager.py` |
| | `video_handler.py` | `backend/webrtc/video_handler.py` |
| **后端API** | `webrtc_signaling.py` | `backend/api/webrtc_signaling.py` |
| **前端组合式** | `useWebRTC.js` | `frontend/src/composables/useWebRTC.js` |
| **前端组件** | `WebRTCPlayer.vue` | `frontend/src/components/video/WebRTCPlayer.vue` |
| **前端工具** | `webrtc.js` | `frontend/src/utils/webrtc.js` |
| **前端配置** | `websocket.js` | `frontend/src/config/websocket.js` |
| **测试页面** | `TestWebRTC.vue` | `frontend/src/views/TestWebRTC.vue` |
| **监控页面** | `Monitor.vue` | `frontend/src/views/Monitor.vue` |
| | `VideoStreamMonitor.vue` | `frontend/src/components/monitor/VideoStreamMonitor.vue` |
| | `useMonitor.js` | `frontend/src/composables/useMonitor.js` |