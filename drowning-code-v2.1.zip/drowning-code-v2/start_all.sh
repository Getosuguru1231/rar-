#!/bin/bash
set -e

echo "================================================"
echo "           智能溺水检测系统 - 一键启动脚本"
echo "================================================"
echo ""

SCRIPT_DIR=$(dirname "$0")
BACKEND_DIR="$SCRIPT_DIR/backend"
FRONTEND_DIR="$SCRIPT_DIR/frontend"
REACT_DIR="$SCRIPT_DIR/react"

echo "请选择要启动的服务:"
echo ""
echo "[1] 启动所有服务 (Redis + 后端 + Vue前端)"
echo "[2] 仅启动后端服务"
echo "[3] 仅启动Vue前端"
echo "[4] 仅启动React前端"
echo "[5] 仅启动Redis"
echo "[6] 使用Docker Compose启动全部"
echo "[0] 退出"
echo ""
read -p "请输入选择 [0-6]: " choice

case $choice in
    1)
        echo ""
        echo "[启动Redis]"
        gnome-terminal --tab --title="Redis" -- bash -c "cd $SCRIPT_DIR && ./start_redis.sh; exec bash" 2>/dev/null || \
        xterm -e "cd $SCRIPT_DIR && ./start_redis.sh" 2>/dev/null || \
        echo "请手动启动Redis: ./start_redis.sh"
        sleep 2
        
        echo ""
        echo "[启动后端服务]"
        gnome-terminal --tab --title="Backend" -- bash -c "cd $BACKEND_DIR && ./start_backend.sh; exec bash" 2>/dev/null || \
        xterm -e "cd $BACKEND_DIR && ./start_backend.sh" 2>/dev/null || \
        echo "请手动启动后端: ./start_backend.sh"
        sleep 3
        
        echo ""
        echo "[启动Vue前端]"
        gnome-terminal --tab --title="Vue Frontend" -- bash -c "cd $FRONTEND_DIR && ./start_frontend_vue.sh; exec bash" 2>/dev/null || \
        xterm -e "cd $FRONTEND_DIR && ./start_frontend_vue.sh" 2>/dev/null || \
        echo "请手动启动前端: ./start_frontend_vue.sh"
        
        echo ""
        echo "所有服务已启动，正在打开浏览器..."
        sleep 5
        xdg-open http://localhost:3001 2>/dev/null || echo "请访问: http://localhost:3001"
        ;;
    2)
        echo ""
        echo "[启动后端服务]"
        cd "$BACKEND_DIR"
        ./start_backend.sh
        ;;
    3)
        echo ""
        echo "[启动Vue前端]"
        cd "$FRONTEND_DIR"
        ./start_frontend_vue.sh
        ;;
    4)
        echo ""
        echo "[启动React前端]"
        cd "$REACT_DIR"
        ./start_frontend_react.sh
        ;;
    5)
        echo ""
        echo "[启动Redis]"
        ./start_redis.sh
        ;;
    6)
        echo ""
        echo "[使用Docker Compose启动全部服务]"
        echo "请确保Docker已运行"
        sleep 2
        docker-compose up -d
        if [ $? -eq 0 ]; then
            echo "[OK] Docker服务启动成功"
            echo "访问地址:"
            echo "  - Vue前端: http://localhost:3001"
            echo "  - React前端: http://localhost:5173"
            echo "  - 后端API: http://localhost:8000"
            sleep 5
            xdg-open http://localhost:3001 2>/dev/null || echo "请访问: http://localhost:3001"
        else
            echo "[ERROR] Docker启动失败"
        fi
        ;;
    0)
        echo "退出..."
        exit 0
        ;;
    *)
        echo "[ERROR] 无效选择"
        exit 1
        ;;
esac

echo ""
echo "================================================"
echo "           服务启动完成"
echo "================================================"
echo ""
echo "服务地址:"
echo "  - Vue前端: http://localhost:3001"
echo "  - React前端: http://localhost:5173"
echo "  - 后端API: http://localhost:8000"
echo "  - API文档: http://localhost:8000/docs"
echo "  - Redis: localhost:6379"
echo ""