# WebRTC视频流无法显示问题排查指南

## 📋 问题描述

Vue前端无法显示WebRTC视频流

## 🔍 常见原因及解决方案

### 1️⃣ **WebSocket信令服务器未启动**

**症状**: 前端控制台显示 `WebSocket连接失败` 或 `信令服务器连接错误`

**排查步骤**:
1. 检查后端是否在运行
   ```bash
   cd backend
   python main.py
   ```

2. 验证WebSocket端点是否可用
   - 访问: `http://127.0.0.1:8002/ws/webrtc/1`
   - 应该能看到WebSocket握手响应

3. 检查Vite代理配置
   - 确保 `/ws` 路径正确代理到后端
   - 检查 `vite.config.js` 中的代理配置

**解决方案**: 重启后端服务

---

### 2️⃣ **ICE连接失败**

**症状**: 前端控制台显示 `ICE连接失败` 或 `ICE连接状态: failed`

**常见原因**:
- STUN/TURN服务器无法访问
- 网络防火墙阻止
- NAT穿透失败

**排查步骤**:
1. 检查网络连接
   ```javascript
   // 在浏览器控制台执行
   console.log('ICE Servers配置:', ICE_SERVERS)
   ```

2. 测试STUN服务器
   - Google STUN: `stun:stun.l.google.com:19302`
   - 可以访问 https://www.websocket.org/echo.html 测试

3. 查看详细ICE日志
   ```javascript
   // 应该在控制台看到类似输出:
   // [WebRTC] ICE候选生成: { candidate: "..." }
   // [WebRTC] ICE连接状态: checking
   // [WebRTC] ICE连接状态: connected 或 failed
   ```

**解决方案**:
- 如果在内网环境，尝试添加TURN服务器
- 或者在本地环境使用内网直连

---

### 3️⃣ **后端视频轨道未启动**

**症状**: ICE连接成功，但视频无法显示

**排查步骤**:
1. 检查后端日志
   ```bash
   # 应该看到:
   # [WebRTC] 新连接 - 摄像头1, peer_id=xxx
   # [WebRTC] 收到offer，创建answer
   # [WebRTC] ICE连接状态 - 摄像头1: connected
   ```

2. 检查Redis连接
   ```bash
   # 确认Redis中有视频帧数据
   redis-cli
   > GET current_frame
   # 应该返回二进制数据
   ```

3. 检查视频帧处理
   ```python
   # 在video_handler.py中添加日志
   async def get_frame(self):
       print(f"[WebRTC] 获取帧, camera_id={self.camera_id}")
       # ...
   ```

**解决方案**:
- 确保Redis中有视频数据
- 检查 `backend/webrtc/video_handler.py` 的帧获取逻辑

---

### 4️⃣ **前端视频元素未正确绑定**

**症状**: `remoteStream` 已有值，但视频不显示

**排查步骤**:
1. 检查video元素
   ```javascript
   // 在Vue devtools中检查:
   - videoRef.value 是否存在
   - videoRef.value.srcObject 是否等于 remoteStream.value
   - videoRef.value.readyState 是否为 4 (HAVE_ENOUGH_DATA)
   ```

2. 检查video元素属性
   ```html
   <!-- 确保video元素包含这些属性 -->
   <video
     ref="videoRef"
     autoplay
     muted
     playsinline
     class="video-stream"
   />
   ```

3. 查看控制台日志
   ```javascript
   // 应该看到:
   // [WebRTC] 收到远程轨道: video
   // [WebRTC] 远程流已设置, stream id: xxx
   // [VideoPlayer] WebRTC视频流已设置到video元素
   ```

**解决方案**:
- 确保 `remoteStream` 正确赋值给 `videoRef.value.srcObject`
- 使用 `nextTick()` 确保DOM更新后再赋值

---

### 5️⃣ **CORS跨域问题**

**症状**: 浏览器控制台显示跨域错误

**排查步骤**:
1. 检查CORS配置
   ```python
   # 在 backend/main.py 中确认
   app.add_middleware(
       CORSMiddleware,
       allow_origins=[
           "http://localhost:3001",  # 前端地址
           "http://127.0.0.1:3001",
       ],
       allow_credentials=True,
       allow_methods=["*"],
       allow_headers=["*"],
   )
   ```

2. 检查WebSocket升级头
   ```javascript
   // 确保代理支持WebSocket
   proxy: {
     '/ws': {
       target: 'http://127.0.0.1:8002',
       ws: true,  // 关键：启用WebSocket支持
       changeOrigin: true
     }
   }
   ```

**解决方案**:
- 更新CORS白名单
- 确保Vite代理正确配置

---

## 🛠️ 调试工具

### 前端调试

1. **启用详细日志**
   ```javascript
   // 在浏览器控制台执行
   localStorage.setItem('debug', 'WebRTC:*')
   ```

2. **WebRTC状态检查**
   ```javascript
   // 创建测试页面
   const pc = new RTCPeerConnection({
     iceServers: [{ urls: 'stun:stun.l.google.com:19302' }]
   })
   console.table({
     'iceConnectionState': pc.iceConnectionState,
     'iceGatheringState': pc.iceGatheringState,
     'connectionState': pc.connectionState,
     'signalingState': pc.signalingState
   })
   ```

3. **Network面板检查**
   - 筛选 `ws://` 或 `wss://` 请求
   - 查看WebSocket握手是否成功
   - 检查是否有数据传输

### 后端调试

1. **启用uvicorn日志**
   ```bash
   python -m uvicorn main:app --host 0.0.0.0 --port 8002 --log-level debug
   ```

2. **测试Redis连接**
   ```python
   import redis
   r = redis.Redis(host='localhost', port=6379, db=0, decode_responses=False)
   frame_data = r.get("current_frame")
   print(f"Redis帧数据: {len(frame_data) if frame_data else 0} bytes")
   ```

3. **直接测试WebRTC信令**
   ```python
   # 使用websockets库测试
   import asyncio
   import websockets
   
   async def test_signaling():
       async with websockets.connect('ws://localhost:8002/ws/webrtc/1') as ws:
           # 接收welcome消息
           msg = await ws.recv()
           print(f"收到: {msg}")
   
   asyncio.run(test_signaling())
   ```

---

## 📝 排查清单

在浏览器控制台中执行以下检查:

```javascript
// 1. 检查WebSocket连接
console.log('WebSocket URL:', getWebRtcWsUrl(1))

// 2. 检查WebRTC连接对象
console.log('peer connection:', pc.value)

// 3. 检查远程流
console.log('remote stream:', remoteStream.value)

// 4. 检查video元素
console.log('video element:', videoRef.value)
console.log('video srcObject:', videoRef.value?.srcObject)

// 5. 检查所有track
if (remoteStream.value) {
  console.log('tracks:', remoteStream.value.getTracks())
}
```

---

## 🔧 快速修复步骤

如果以上都无法解决，尝试以下快速修复:

### 方案1: 重启服务

```bash
# 停止所有服务
# Ctrl+C

# 重启后端
cd backend
python main.py

# 重启前端
cd frontend
npm run dev
```

### 方案2: 清除浏览器缓存

1. 打开开发者工具 (F12)
2. 右键点击刷新按钮
3. 选择 "清空缓存并硬性重新加载"

### 方案3: 检查端口占用

```bash
# Windows
netstat -ano | findstr "8002"
netstat -ano | findstr "3001"

# 杀死占用端口的进程
taskkill /PID <进程ID> /F
```

### 方案4: 使用备用视频源

如果WebRTC无法工作，可以临时使用WebSocket视频流:

```javascript
// 在VideoPlayer.vue中强制使用WebSocket模式
useWebRTCMode.value = false
useWebSocketMode.value = true
```

---

## 📞 获取帮助

如果问题仍然存在，请提供以下信息:

1. **浏览器控制台日志**
   - 搜索 `[WebRTC]` 开头的所有日志
   - 复制完整错误信息

2. **后端日志**
   - 重启后端并观察启动日志
   - 执行WebRTC连接测试并记录日志

3. **Network面板截图**
   - WebSocket连接状态
   - 请求和响应头信息

4. **环境信息**
   - 操作系统
   - 浏览器版本
   - 前端框架版本
   - 后端Python版本

---

## ✅ 修复验证

修复完成后，请验证以下内容:

- [ ] 前端控制台无错误
- [ ] `[WebRTC] ICE连接状态: connected` 出现
- [ ] `[WebRTC] 收到远程轨道: video` 出现
- [ ] `[WebRTC] 远程流已设置` 出现
- [ ] video元素可见且有画面
- [ ] FPS计数器显示正常

如果所有检查项都通过，WebRTC应该正常工作！
