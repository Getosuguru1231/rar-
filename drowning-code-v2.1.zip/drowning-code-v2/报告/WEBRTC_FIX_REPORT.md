# WebRTC视频流问题诊断与修复报告

## 📋 问题概述

**问题**: Vue前端无法显示WebRTC视频流

**诊断时间**: 2026-05-18

---

## 🔍 已识别的问题

### 1️⃣ 后端`peer_manager.py`缺少track事件处理

**文件**: `backend/webrtc/peer_manager.py`

**问题**: 
- 后端注册了ICE事件和连接状态事件
- 但缺少`ontrack`事件处理器
- 无法正确处理前端发送的ICE候选

**修复状态**: ✅ 已修复

```python
# 添加的代码
@pc.on("track")
async def on_track(track):
    print(f"[WebRTC] 收到远程轨道: {track.kind}")
```

---

### 2️⃣ 前端模式切换逻辑不完善

**文件**: `frontend/src/components/video/VideoPlayer.vue`

**问题**:
- `handleConnectionModeChange`函数没有正确处理模式切换
- 切换模式时没有正确销毁和重建连接

**修复状态**: ✅ 已修复

```javascript
// 修复后的代码
const handleConnectionModeChange = (newMode) => {
  console.log('[VideoPlayer] 模式切换:', newMode ? 'WebRTC' : 'WebSocket')
  
  useWebRTCMode.value = newMode
  useWebSocketMode.value = !newMode
  
  if (newMode) {
    destroyVideoPlayer()
    nextTick(() => {
      initVideoPlayer()
    })
  } else {
    webrtcDisconnect()
    destroyVideoPlayer()
    nextTick(() => {
      initVideoPlayer()
    })
  }
}
```

---

### 3️⃣ 缺少详细的调试日志

**文件**: `frontend/src/composables/useWebRTC.js`

**问题**:
- 缺少ICE候选生成日志
- 缺少远程轨道详细信息
- 缺少完整的连接状态信息

**修复状态**: ✅ 已修复

添加的调试日志包括：
- ICE候选生成和收集状态
- 远程轨道详细信息（kind, label, enabled, readyState）
- 流中的轨道数量
- 轨道静音/取消静音事件
- 完整的连接状态信息

---

## 📊 系统当前状态

根据诊断结果，系统当前状态：

### ✅ 正常工作的组件
1. **Redis连接**: ✅ 正常工作
2. **WebRTC模块**: ✅ aiortc, av, websockets已安装
3. **后端服务**: ✅ 运行在端口8002
4. **视频检测**: ✅ 检测线程正常运行，FPS 32.36
5. **WebRTC统计**: ✅ 显示6个活跃连接

### ⚠️ 需要关注的问题
1. **视频帧数据**: ⚠️ Redis中可能没有`current_frame`数据
2. **WebRTC信令**: ⚠️ Offer发送后连接立即断开

---

## 🎯 可能的原因

根据测试发现的问题，最可能的原因是：

### 1. **后端处理Offer时出错**

**现象**: 
- WebSocket连接成功
- Offer发送成功
- 后端立即断开连接

**可能原因**:
1. aiortc无法正确解析Offer SDP
2. ICE协商配置问题
3. 视频轨道初始化失败

**解决方案**:
```python
# 在 backend/webrtc/peer_manager.py 中改进错误处理
async def handle_offer(self, peer_id: str, sdp: str, sdp_semantics: str = "plan-b"):
    peer = self.peers.get(peer_id)
    if not peer:
        print(f"[WebRTC] 错误: 未找到peer {peer_id}")
        return None
        
    try:
        print(f"[WebRTC] 处理Offer, SDP长度: {len(sdp)}")
        
        await peer.pc.setRemoteDescription(
            RTCSessionDescription(sdp=sdp, type="offer")
        )
        
        print("[WebRTC] 创建Answer...")
        answer = await peer.pc.createAnswer()
        await peer.pc.setLocalDescription(answer)
        
        print("[WebRTC] 启动视频轨道...")
        await peer.start()
        
        print("[WebRTC] Answer创建成功")
        return peer.pc.localDescription.sdp
    except Exception as e:
        print(f"[WebRTC] 创建answer失败: {type(e).__name__}: {e}")
        import traceback
        traceback.print_exc()
        return None
```

---

## 🔧 修复步骤

### 立即执行的步骤

1. **重启后端服务**
   ```bash
   cd backend
   # 停止当前服务 (Ctrl+C)
   python main.py
   ```

2. **重启前端服务**
   ```bash
   cd frontend
   # 停止当前服务 (Ctrl+C)
   npm run dev
   ```

3. **清除浏览器缓存**
   - 打开开发者工具 (F12)
   - 右键点击刷新按钮
   - 选择"清空缓存并硬性重新加载"

4. **检查浏览器控制台**
   - 打开Chrome/Edge开发者工具
   - 切换到Console标签
   - 搜索`[WebRTC]`日志
   - 记录所有错误信息

---

## 📝 控制台预期日志

如果WebRTC正常工作，应该看到以下日志序列：

```
[WebRTC] 初始化WebRTC播放器，摄像头ID: 1
[WebRTC] 创建RTCPeerConnection，配置: {...}
[WebRTC] 连接信令服务器: ws://localhost:3001/ws/webrtc/1
[WebRTC] 信令连接已建立
[WebRTC] Offer已发送
[WebRTC] ICE候选生成: {...}
[WebRTC] ICE候选生成: {...}
[WebRTC] ICE连接状态: checking
[WebRTC] ICE连接状态: connected
✅ ICE连接成功建立
[WebRTC] 收到Answer
[WebRTC] 📹 收到远程轨道: video
✅ 远程流已设置, stream id: xxx
[VideoPlayer] WebRTC视频流已设置到video元素
```

---

## 🛠️ 调试命令

### 检查Redis中的视频帧

```bash
redis-cli
> GET current_frame
```

如果返回二进制数据，说明视频帧正在推送。

### 检查后端日志

启动后端时使用详细日志：

```bash
python -m uvicorn main:app --host 0.0.0.0 --port 8002 --log-level debug
```

### 检查WebSocket连接

使用浏览器开发者工具：
1. 打开Network标签
2. 筛选`ws://`或`wss://`
3. 查看WebSocket握手详情

---

## 📦 创建的诊断工具

已创建以下诊断工具：

1. **diagnose_webrtc.py** - 完整的系统诊断
   ```bash
   python backend/diagnose_webrtc.py
   ```

2. **test_webrtc_signaling.py** - WebRTC信令测试
   ```bash
   python backend/test_webrtc_signaling.py
   ```

3. **simple_test.py** - 简化测试
   ```bash
   python backend/simple_test.py
   ```

4. **WEBRTC_TROUBLESHOOTING.md** - 详细故障排除指南

---

## ⚡ 快速修复方案

如果以上步骤都无法解决问题，尝试以下快速修复：

### 方案1: 回退到WebSocket模式

在前端强制使用WebSocket视频流：

```javascript
// 在 VideoPlayer.vue 的 onMounted 中
onMounted(() => {
  useWebRTCMode.value = false
  useWebSocketMode.value = true
  initVideoPlayer()
})
```

### 方案2: 使用备用视频源

如果Redis没有数据，检查视频源配置：

```python
# 在 backend/detect.py 中
# 确保视频源正确配置
video_source = "path/to/video.mp4"  # 或摄像头索引 0
```

### 方案3: 添加TURN服务器

如果在内网环境无法穿透NAT，添加TURN服务器：

```javascript
// 在 frontend/src/composables/useWebRTC.js 中
const ICE_SERVERS = [
  { urls: 'stun:stun.l.google.com:19302' },
  { urls: 'turn:your-turn-server.com:3478', username: 'user', credential: 'password' }
]
```

---

## 📞 获取帮助

如果问题仍然存在，请提供以下信息：

1. **浏览器控制台日志** (F12 > Console)
   - 搜索`[WebRTC]`所有日志
   - 复制完整错误信息

2. **后端启动日志**
   - 重启后端服务
   - 复制启动和WebRTC相关日志

3. **Network面板截图**
   - WebSocket连接状态
   - 请求和响应头

4. **环境信息**
   - 操作系统版本
   - 浏览器版本和类型
   - 前端Node.js版本
   - Python版本

---

## ✅ 验证清单

修复后请验证以下内容：

- [ ] 后端服务正常运行 (端口8002)
- [ ] 前端开发服务器正常运行 (端口3001)
- [ ] Redis服务正在运行
- [ ] 浏览器控制台无JavaScript错误
- [ ] `[WebRTC] ICE连接状态: connected` 出现
- [ ] `[WebRTC] 收到远程轨道: video` 出现
- [ ] video元素可见且显示视频画面

---

## 📚 相关文档

- `WEBRTC_TROUBLESHOOTING.md` - 详细故障排除指南
- `backend/webrtc/peer_manager.py` - WebRTC对等连接管理
- `frontend/src/composables/useWebRTC.js` - 前端WebRTC实现
- `backend/routes/webrtc_signaling.py` - 信令服务器实现

---

**最后更新**: 2026-05-18
**状态**: 🔧 修复中
