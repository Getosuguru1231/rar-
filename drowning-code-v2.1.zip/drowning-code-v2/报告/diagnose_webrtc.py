#!/usr/bin/env python3
"""
WebRTC连接诊断工具 - 检查所有可能导致视频流无法显示的问题
"""

import asyncio
import sys


def print_section(title):
    """打印分节标题"""
    print(f"\n{'='*60}")
    print(f"  {title}")
    print(f"{'='*60}\n")


async def check_redis():
    """检查Redis连接和视频帧数据"""
    print_section("1️⃣ 检查Redis连接")
    
    try:
        import redis
        r = redis.Redis(host='localhost', port=6379, db=0, decode_responses=False)
        
        # 测试连接
        r.ping()
        print("✅ Redis连接成功")
        
        # 检查视频帧数据
        frame_data = r.get("current_frame")
        if frame_data:
            print(f"✅ 找到视频帧数据: {len(frame_data)} bytes")
        else:
            print("⚠️ Redis中没有视频帧数据 (current_frame)")
            print("   这可能导致WebRTC视频流无法显示")
            print("\n   可能原因:")
            print("   - 视频源未启动")
            print("   - 检测线程未运行")
            print("   - 帧数据未被推送到Redis")
            
        return True
    except redis.ConnectionError as e:
        print(f"❌ Redis连接失败: {e}")
        print("\n   解决方案:")
        print("   1. 启动Redis: redis-server")
        print("   2. 或检查Redis配置")
        return False
    except Exception as e:
        print(f"❌ 检查Redis时出错: {e}")
        return False


async def check_webrtc_modules():
    """检查WebRTC相关模块"""
    print_section("2️⃣ 检查WebRTC模块")
    
    modules = {
        'aiortc': 'WebRTC核心库',
        'av': '视频编解码库',
        'websockets': 'WebSocket库'
    }
    
    all_ok = True
    for module, desc in modules.items():
        try:
            __import__(module)
            print(f"✅ {desc} ({module}) 已安装")
        except ImportError:
            print(f"❌ {desc} ({module}) 未安装")
            print(f"   安装: pip install {module}")
            all_ok = False
    
    if not all_ok:
        print("\n   请安装缺失的模块后重试")
    
    return all_ok


async def check_backend_endpoints():
    """检查后端API端点"""
    print_section("3️⃣ 检查后端服务")
    
    try:
        import urllib.request
        import json
        
        # 检查健康端点
        try:
            req = urllib.request.urlopen('http://127.0.0.1:8002/api/health', timeout=5)
            data = json.loads(req.read().decode())
            print(f"✅ 后端健康: {data.get('status', 'unknown')}")
        except Exception as e:
            print(f"❌ 健康检查失败: {e}")
            return False
        
        # 检查WebRTC统计
        try:
            req = urllib.request.urlopen('http://127.0.0.1:8002/stats', timeout=5)
            data = json.loads(req.read().decode())
            print(f"✅ WebRTC统计: {data.get('total_peers', 0)} 个活跃连接")
        except Exception as e:
            print(f"⚠️ WebRTC统计失败: {e}")
        
        return True
    except Exception as e:
        print(f"❌ 无法连接到后端: {e}")
        print("\n   解决方案:")
        print("   1. 启动后端: cd backend && python main.py")
        print("   2. 检查端口8002是否被占用")
        return False


async def check_aiortc_setup():
    """测试aiortc WebRTC设置"""
    print_section("4️⃣ 测试WebRTC设置")
    
    try:
        from aiortc import RTCPeerConnection, RTCSessionDescription
        from webrtc.ice_server import get_ice_servers
        
        print("✅ aiortc导入成功")
        
        # 测试创建PeerConnection
        pc = RTCPeerConnection(get_ice_servers())
        print("✅ RTCPeerConnection创建成功")
        
        # 获取ICE服务器配置
        ice_servers = get_ice_servers()
        print(f"✅ ICE服务器配置: {len(ice_servers)} 个服务器")
        for server in ice_servers:
            print(f"   - {server.get('urls', 'unknown')}")
        
        # 关闭连接
        await pc.close()
        print("✅ RTCPeerConnection关闭成功")
        
        return True
    except Exception as e:
        print(f"❌ WebRTC设置测试失败: {e}")
        import traceback
        traceback.print_exc()
        return False


async def check_video_handler():
    """检查视频处理器"""
    print_section("5️⃣ 检查视频处理器")
    
    try:
        from webrtc.video_handler import WebRTCVideoTrack, VideoFrameHandler
        
        print("✅ 视频处理器模块导入成功")
        
        # 测试创建VideoFrameHandler
        handler = VideoFrameHandler(camera_id=1)
        print("✅ VideoFrameHandler创建成功")
        
        # 测试创建WebRTCVideoTrack
        track = WebRTCVideoTrack(camera_id=1, width=640, height=360, fps=15)
        print("✅ WebRTCVideoTrack创建成功")
        print(f"   分辨率: {track.width}x{track.height}")
        print(f"   帧率: {track.fps} fps")
        
        return True
    except Exception as e:
        print(f"❌ 视频处理器检查失败: {e}")
        import traceback
        traceback.print_exc()
        return False


def print_summary(results):
    """打印诊断摘要"""
    print_section("📋 诊断摘要")
    
    checks = {
        'redis': 'Redis连接',
        'modules': 'WebRTC模块',
        'backend': '后端服务',
        'aiortc': 'WebRTC设置',
        'video': '视频处理器'
    }
    
    passed = sum(1 for r in results.values() if r)
    total = len(results)
    
    print(f"通过检查: {passed}/{total}\n")
    
    for key, name in checks.items():
        status = "✅ 通过" if results.get(key) else "❌ 失败"
        print(f"{status} - {name}")
    
    print("\n" + "="*60)
    if passed == total:
        print("🎉 所有检查通过!")
        print("\n如果WebRTC仍然无法工作，请:")
        print("1. 检查浏览器控制台日志")
        print("2. 搜索 [WebRTC] 开头的所有日志")
        print("3. 查看详细的错误信息")
    else:
        print("⚠️ 部分检查未通过")
        print("\n请根据上面的提示修复问题后重试")
    print("="*60)


async def main():
    """主函数"""
    print("\n" + "="*60)
    print("🔧 WebRTC视频流诊断工具 v1.0")
    print("="*60)
    
    results = {}
    
    # 运行所有检查
    results['redis'] = await check_redis()
    results['modules'] = await check_webrtc_modules()
    results['backend'] = await check_backend_endpoints()
    results['aiortc'] = await check_aiortc_setup()
    results['video'] = await check_video_handler()
    
    # 打印摘要
    print_summary(results)
    
    # 返回退出码
    return 0 if all(results.values()) else 1


if __name__ == "__main__":
    exit_code = asyncio.run(main())
    sys.exit(exit_code)
