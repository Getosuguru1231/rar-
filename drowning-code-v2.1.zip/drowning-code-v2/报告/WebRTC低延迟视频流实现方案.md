# WebRTC 低延迟视频流实现方案

**文档版本**：1.0  
**创建日期**：2026-05-17  
**项目名称**：溺水检测系统视频流优化  
**当前状态**：方案待确认

---

## 1. 背景与问题

### 1.1 当前视频流方案

系统当前使用 **WebSocket** 协议进行视频流传输，存在以下问题：

| 问题 | 描述 | 影响 |
|------|------|------|
| 延迟较高 | WebSocket 基于 TCP，延迟 200-500ms | 实时性不足 |
| 连接不稳定 | Vite 代理配置问题 | 频繁断开重连 |
| 带宽占用 | TCP 拥塞控制 | 网络波动时视频质量下降 |

### 1.2 WebSocket 测试结果

使用 Python 测试脚本验证后端 WebSocket 端点：

```
✅ WebSocket 连接成功
✅ 帧数据正常接收（每帧约 22KB）
✅ 帧率稳定在 15 FPS
✅ 延迟 0.2-0.3 秒
```

**结论**：后端 WebSocket 服务正常工作，问题在前端连接层面。

### 1.3 为什么选择 WebRTC

| 特性 | WebSocket | WebRTC |
|------|-----------|--------|
| **传输协议** | TCP | UDP |
| **理论延迟** | 200-500ms | 50-200ms |
| **NAT穿透** | 自动处理 | 需要 STUN/TURN |
| **带宽适应** | 一般 | 优秀（带宽估计） |
| **丢包处理** | 重传导致延迟 | NACK/PLI 快速修复 |

---

## 2. 技术架构

### 2.1 系统架构图

```
┌──────────────────────────────────────────────────────────────────────────┐
│                              浏览器前端                                   │
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────────────┐  │
│  │ RTCPeerConnection │  │ 信令客户端     │  │   video element        │  │
│  │    (视频接收)    │  │  (WebSocket)   │  │   (视频渲染)            │  │
│  └────────┬────────┘  └────────┬────────┘  └────────────┬────────────┘  │
│           │                    │                       │                │
└───────────┼────────────────────┼───────────────────────┼────────────────┘
            │                    │                       │
            │ UDP DataChannel    │ WebSocket (信令)      │ RTP 流
            │ (视频帧数据)        │ (offer/answer/ICE)    │ (视频轨道)
            ▼                    ▼                       ▼
┌──────────────────────────────────────────────────────────────────────────┐
│                            FastAPI 后端                                  │
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────────────┐  │
│  │  RTCPeerConnection │ │  信令服务器     │  │   VideoTrackSource    │  │
│  │    (aiortc)     │  │  (WebSocket)    │  │   (视频帧生产者)       │  │
│  └─────────────────┘  └─────────────────┘  └─────────────────────────┘  │
└──────────────────────────────────────────────────────────────────────────┘
```

### 2.2 信令交换流程

```
客户端 (浏览器)                          服务端 (FastAPI)
      │                                        │
      │ ─── WebSocket 连接 ──────────────────►  │
      │                                        │
      │ ◄────── 连接成功确认 ─────────────────  │
      │                                        │
      │ ─── offer (SDP + ICE candidates) ───►  │
      │                                        │
      │ ◄── answer (SDP + ICE candidates) ──  │
      │                                        │
      │ ◄════ UDP DataChannel 视频流 ════════  │
      │                                        │
      │ ◄══════ RTP 视频轨道 ════════════════  │
      │                                        │
```

---

## 3. 实现方案

### 3.1 后端实现

#### 3.1.1 依赖安装

```python
# backend/requirements.txt 添加
aiortc>=1.9.0
aioice>=0.8.0
av>=12.0.0
```

#### 3.1.2 目录结构

```
backend/
├── webrtc/
│   ├── __init__.py
│   ├── peer_manager.py      # RTCPeerConnection 管理器
│   ├── video_handler.py     # 视频轨道处理器
│   └── ice_server.py        # ICE 服务器配置
├── routes/
│   └── webrtc_signaling.py  # 信令交换路由
└── main.py                  # 路由注册
```

#### 3.1.3 核心文件说明

| 文件 | 职责 | 主要类/函数 |
|------|------|-------------|
| `peer_manager.py` | 管理所有 RTCPeerConnection | `PeerManager`, `WebRTCPeer` |
| `video_handler.py` | 处理视频帧并推送到轨道 | `VideoFrameHandler` |
| `webrtc_signaling.py` | 处理 offer/answer/ICE 交换 | WebSocket 端点 |
| `main.py` | 注册路由和启动 | 应用初始化 |

### 3.2 前端实现

#### 3.2.1 目录结构

```
frontend/src/
├── components/video/
│   └── WebRTCPlayer.vue     # WebRTC 播放器组件
├── composables/
│   └── useWebRTC.js         # WebRTC 逻辑封装
└── views/
    └── Monitor.vue          # 集成 WebRTCPlayer
```

#### 3.2.2 核心文件说明

| 文件 | 职责 | 主要功能 |
|------|------|----------|
| `useWebRTC.js` | WebRTC 逻辑封装 | 连接管理、状态跟踪 |
| `WebRTCPlayer.vue` | 播放器组件 | 渲染视频、处理事件 |
| `Monitor.vue` | 页面集成 | 替换 VideoPlayer |

---

## 4. API 设计

### 4.1 信令交换协议

#### WebSocket 端点
```
ws://localhost:8001/ws/webrtc/{camera_id}
```

#### 消息格式

**1. 客户端发起 offer**
```json
{
  "type": "offer",
  "camera_id": 1,
  "sdp": "v=0\r\no=- ...",
  "sdp_semantics": "plan-b"
}
```

**2. 服务端返回 answer**
```json
{
  "type": "answer",
  "camera_id": 1,
  "sdp": "v=0\r\no=- ..."
}
```

**3. ICE Candidate 交换**
```json
{
  "type": "ice_candidate",
  "candidate": "a=...",
  "sdpMid": "0",
  "sdpMLineIndex": 0
}
```

**4. 连接关闭**
```json
{
  "type": "close",
  "camera_id": 1
}
```

### 4.2 视频流参数

| 参数 | 值 | 说明 |
|------|-----|------|
| 视频编码 | VP8 / H.264 | 浏览器兼容性优先 |
| 分辨率 | 640×360 | 可配置 |
| 帧率 | 15-30 FPS | 可配置 |
| 码率 | 自适应 | 根据带宽调整 |
| 传输模式 | UDP DataChannel | 低延迟 |

---

## 5. 实现步骤

### 阶段一：后端基础搭建

| 步骤 | 内容 | 文件 | 预计行数 |
|------|------|------|----------|
| 1.1 | 添加依赖到 requirements.txt | `requirements.txt` | +3 行 |
| 1.2 | 创建 webrtc 目录和 __init__.py | `webrtc/__init__.py` | +10 行 |
| 1.3 | 实现 ICE 服务器配置 | `webrtc/ice_server.py` | +30 行 |
| 1.4 | 实现 PeerConnection 管理器 | `webrtc/peer_manager.py` | +80 行 |
| 1.5 | 实现视频轨道处理器 | `webrtc/video_handler.py` | +60 行 |
| 1.6 | 实现信令交换路由 | `routes/webrtc_signaling.py` | +70 行 |
| 1.7 | 在 main.py 注册路由 | `main.py` | +15 行 |

**小计**：约 270 行代码

### 阶段二：前端基础实现

| 步骤 | 内容 | 文件 | 预计行数 |
|------|------|------|----------|
| 2.1 | 创建 useWebRTC composable | `composables/useWebRTC.js` | +150 行 |
| 2.2 | 创建 WebRTCPlayer 组件 | `components/video/WebRTCPlayer.vue` | +200 行 |
| 2.3 | 添加组件导出 | `components/index.js` | +5 行 |

**小计**：约 355 行代码

### 阶段三：集成与测试

| 步骤 | 内容 | 文件 | 预计行数 |
|------|------|------|----------|
| 3.1 | 修改 Monitor.vue 集成 | `views/Monitor.vue` | +30 行 |
| 3.2 | 添加切换逻辑（可选） | `views/Monitor.vue` | +20 行 |
| 3.3 | 测试信令交换 | - | - |
| 3.4 | 测试视频流播放 | - | - |
| 3.5 | 性能测试与调优 | - | - |

**小计**：约 50 行代码

### 总工作量

| 阶段 | 代码行数 | 测试时间 | 合计 |
|------|----------|----------|------|
| 后端 | ~270 行 | ~30 分钟 | ~2 小时 |
| 前端 | ~355 行 | ~30 分钟 | ~2 小时 |
| 集成 | ~50 行 | ~30 分钟 | ~1 小时 |
| **总计** | **~675 行** | **~2.5 小时** | **~5 小时** |

---

## 6. 代码示例

### 6.1 后端 - PeerManager (伪代码)

```python
# webrtc/peer_manager.py
import asyncio
from aiortc import RTCPeerConnection, RTCSessionDescription
from aiortc.contrib.media import MediaRelay

class PeerManager:
    def __init__(self):
        self.peers = {}  # camera_id -> RTCPeerConnection
        self.relay = MediaRelay()

    async def create_offer(self, camera_id: int):
        pc = RTCPeerConnection()
        self.peers[camera_id] = pc

        # 添加视频轨道
        video_track = self.get_video_track(camera_id)
        if video_track:
            pc.addTrack(self.relay.subscribe(video_track))

        # 创建 offer
        await pc.setLocalDescription(await pc.createOffer())
        return pc.localDescription

    async def handle_answer(self, camera_id: int, answer: RTCSessionDescription):
        pc = self.peers.get(camera_id)
        if pc:
            await pc.setRemoteDescription(answer)

    async def close(self, camera_id: int):
        pc = self.peers.pop(camera_id, None)
        if pc:
            await pc.close()
```

### 6.2 前端 - useWebRTC (伪代码)

```javascript
// composables/useWebRTC.js
import { ref, onUnmounted } from 'vue'

export function useWebRTC(cameraId) {
  const pc = ref(null)
  const remoteStream = ref(null)
  const status = ref('disconnected')

  const connect = async () => {
    pc.value = new RTCPeerConnection({
      iceServers: [{ urls: 'stun:stun.l.google.com:19302' }]
    })

    // 接收远程轨道
    pc.value.ontrack = (event) => {
      remoteStream.value = event.streams[0]
    }

    // 创建 offer
    const offer = await pc.value.createOffer()
    await pc.value.setLocalDescription(offer)

    // 通过信令服务器发送
    signalingSocket.send(JSON.stringify({
      type: 'offer',
      camera_id: cameraId,
      sdp: offer.sdp
    }))
  }

  onUnmounted(() => {
    pc.value?.close()
  })

  return { remoteStream, status, connect }
}
```

---

## 7. 配置参数

### 7.1 ICE 服务器配置

```python
ICE_SERVERS = [
    {
        "urls": "stun:stun.l.google.com:19302"
    },
    # 可选：添加 TURN 服务器（用于严格防火墙环境）
    # {
    #     "urls": "turn:your-turn-server.com:3478",
    #     "username": "user",
    #     "credential": "password"
    # }
]
```

### 7.2 视频流配置

```python
VIDEO_CONFIG = {
    "codec": "VP8",           # 或 "H264"
    "resolution": (640, 360), # 宽 × 高
    "framerate": 15,          # 帧率
    "bitrate": 500000,        # 码率 (bps)
    "keyframe_interval": 30   # 关键帧间隔
}
```

### 7.3 前端配置

```javascript
const WEBRTC_CONFIG = {
  iceServers: [
    { urls: 'stun:stun.l.google.com:19302' }
  ],
  video: {
    width: { ideal: 640 },
    height: { ideal: 360 },
    frameRate: { ideal: 15 }
  }
}
```

---

## 8. 风险与注意事项

### 8.1 技术风险

| 风险 | 概率 | 影响 | 缓解措施 |
|------|------|------|----------|
| NAT 穿透失败 | 中 | 高 | 准备 TURN 服务器 |
| 浏览器兼容性 | 低 | 中 | 同时支持 VP8/H264 |
| 防火墙拦截 | 中 | 高 | 使用 TLS 信令 |

### 8.2 性能考虑

| 项目 | 目标 | 备注 |
|------|------|------|
| 端到端延迟 | < 200ms | UDP 传输 |
| CPU 占用 | < 30% | 硬件编解码 |
| 内存占用 | < 200MB | 连接池管理 |

### 8.3 回退方案

如果 WebRTC 无法正常工作，系统应自动回退到 WebSocket 方案：

```javascript
// 前端回退逻辑
async function connectVideo(cameraId) {
  try {
    await connectWebRTC(cameraId)
  } catch (e) {
    console.warn('WebRTC 失败，回退到 WebSocket')
    connectWebSocket(cameraId)
  }
}
```

---

## 9. 测试计划

### 9.1 单元测试

| 测试项 | 方法 | 预期结果 |
|--------|------|----------|
| 信令交换 | Mock WebSocket | offer/answer 正确交换 |
| ICE 连接 | Mock STUN | ICE candidates 生成 |
| 视频帧推送 | 单元测试 | 帧数据正确序列化 |

### 9.2 集成测试

| 测试项 | 方法 | 预期结果 |
|--------|------|----------|
| 端到端连接 | 本地测试 | 视频流正常显示 |
| 延迟测量 | 帧时间戳 | < 200ms |
| 丢包恢复 | 网络模拟 | 自动重连 |

### 9.3 性能测试

| 测试项 | 方法 | 目标 |
|--------|------|------|
| 并发连接 | 10 个摄像头 | CPU < 50% |
| 长时间运行 | 24 小时 | 内存稳定 |
| 网络波动 | 限速测试 | 自动适应 |

---

## 10. 替代方案对比

### 10.1 方案对比

| 方案 | 延迟 | 复杂度 | 兼容性 | 推荐场景 |
|------|------|--------|--------|----------|
| **WebRTC** | 50-200ms | 高 | 良好 | 实时监控、低延迟需求 |
| WebSocket | 200-500ms | 低 | 优秀 | 一般场景、穿透性强 |
| MJPEG | 500ms+ | 低 | 优秀 | 简单场景、兼容性优先 |

### 10.2 本系统选择理由

1. **实时性要求高**：溺水检测需要 < 200ms 响应
2. **多摄像头场景**：需要高效的带宽利用
3. **用户反馈**：当前 WebSocket 延迟可感知

---

## 11. 结论与建议

### 11.1 方案选择

**推荐方案**：WebRTC

理由：
1. 延迟显著低于 WebSocket（50-200ms vs 200-500ms）
2. 带宽利用更高效
3. 更适合实时视频监控场景

### 11.2 下一步行动

1. **确认方案** → 开始实现
2. **准备 TURN 服务器**（可选，用于测试）
3. **分阶段实现**：
   - 阶段一：后端信令 + 基本连接
   - 阶段二：前端播放器
   - 阶段三：集成测试

### 11.3 预估收益

| 指标 | 当前 | 预期 | 改善 |
|------|------|------|------|
| 端到端延迟 | 500ms+ | < 200ms | 60%+ |
| 视频流畅度 | 一般 | 优秀 | 显著提升 |
| 用户体验 | 可感知延迟 | 接近实时 | 大幅改善 |

---

## 12. 附录

### A. 参考资料

- [aiortc 官方文档](https://aiortc.readthedocs.io/)
- [WebRTC 信令流程](https://developer.mozilla.org/en-US/docs/Web/API/WebRTC_API/Signaling_and_video_calling)
- [STUN/TURN 服务器配置](https://www.html5rocks.com/en/tutorials/webrtc/infrastructure/)

### B. 术语表

| 术语 | 说明 |
|------|------|
| STUN | NAT 会话穿越工具 |
| TURN | NAT 中继穿越 |
| ICE | 交互式连接建立 |
| SDP | 会话描述协议 |
| RTP | 实时传输协议 |
| DataChannel | WebRTC 数据通道 |

---

**文档结束**
