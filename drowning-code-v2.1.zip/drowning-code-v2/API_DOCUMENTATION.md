﻿# API接口梳理文档

## 一、API概览

| 模块 | 路径前缀 | 功能描述 |
|------|----------|----------|
| health | `/api/health` | 健康检查和系统状态监控 |
| alerts | `/api/alerts` | 告警管理 |
| camera | `/api/camera` | 摄像头管理 |
| monitoring | `/api/monitoring` | 监控管理 |
| llm | `/api/llm` | LLM相关功能 |
| config | `/api/config` | 配置管理 |
| video | `/api/video` | 视频管理 |
| detection | `/api/detection` | 检测功能 |
| device | `/api/device` | 设备管理 |
| video_feed | `/api/video_feed` | 视频流服务 |
| webrtc | WebSocket | WebRTC信令 |
| video_websocket | WebSocket | WebSocket视频流 |

---

## 二、API端点详细列表

### 2.1 健康检查模块

| API路径 | HTTP方法 | 功能描述 | 所属文件 |
|---------|----------|----------|----------|
| `/api/health/health` | GET | 健康检查端点 | health.py |
| `/api/health/ping` | GET | 快速连接测试 | health.py |
| `/api/health/model/confidence` | GET | 模型置信度统计 | health.py |
| `/api/health/heartbeat` | GET | 心跳检测 | health.py |
| `/api/health/system/status` | GET | 系统状态监控 | health.py |
| `/api/health/` | GET | 根路径 | health.py |

### 2.2 告警管理模块

| API路径 | HTTP方法 | 功能描述 | 所属文件 |
|---------|----------|----------|----------|
| `/api/alerts/trigger` | POST | 触发告警 | alerts.py |
| `/api/alerts/test-alert` | POST | 测试告警推送 | alerts.py |
| `/api/alerts/list` | GET | 获取告警列表 | alerts.py |
| `/api/alerts/drowning-timeline` | GET | 获取溺水事件时间线 | alerts.py |
| `/api/alerts/unacknowledged` | GET | 获取未处理告警 | alerts.py |
| `/api/alerts/acknowledge/{alert_id}` | POST | 确认告警 | alerts.py |
| `/api/alerts/resolve/{alert_id}` | POST | 解决告警 | alerts.py |
| `/api/alerts/today` | GET | 获取今日告警统计 | alerts.py |
| `/api/alerts/statistics` | GET | 获取告警统计信息 | alerts.py |
| `/api/alerts/recent` | GET | 获取最近告警 | alerts.py |
| `/api/alerts/stats` | GET | 获取告警统计 | alerts.py |
| `/api/alerts/delete/{alert_id}` | DELETE | 删除单个告警 | alerts.py |
| `/api/alerts/delete-all` | DELETE | 删除所有告警 | alerts.py |

### 2.3 摄像头管理模块

| API路径 | HTTP方法 | 功能描述 | 所属文件 |
|---------|----------|----------|----------|
| `/api/camera/status` | GET | 获取摄像头状态 | camera.py |
| `/api/camera/health` | GET | 获取摄像头健康状态 | camera.py |
| `/api/camera/list` | GET | 获取摄像头列表 | camera.py |
| `/api/camera/stats` | GET | 获取摄像头统计信息 | camera.py |
| `/api/camera/reconnect` | POST | 重新连接摄像头 | camera.py |

### 2.4 视频流模块

| API路径 | HTTP方法 | 功能描述 | 所属文件 |
|---------|----------|----------|----------|
| `/api/video_feed` | GET | 获取摄像头视频流 | video_feed.py |
| `/api/video_feed/snapshot` | GET | 获取摄像头快照 | video_feed.py |
| `/api/video_feed/stats` | GET | 获取视频流性能统计 | video_feed.py |
| `/api/video_feed/fps` | GET | 获取摄像头实时帧率 | video_feed.py |
| `/api/video_feed/reset-stats` | POST | 重置视频流性能统计 | video_feed.py |
| `/api/video_feed/init-camera/{camera_id}` | POST | 初始化摄像头 | video_feed.py |
| `/api/video_feed/camera-list` | GET | 获取所有摄像头列表 | video_feed.py |
| `/api/video/camera/{camera_id}/toggle` | POST | 切换摄像头状态 | video_feed.py |

### 2.5 检测模块

| API路径 | HTTP方法 | 功能描述 | 所属文件 |
|---------|----------|----------|----------|
| `/api/detection/upload` | POST | 上传视频进行检测 | detection.py |
| `/api/detection/result/{task_id}` | GET | 获取检测结果 | detection.py |
| `/api/detection/tasks` | GET | 获取任务列表 | detection.py |
| `/api/detection/task/{task_id}` | DELETE | 删除任务 | detection.py |
| `/api/detection/videos/list` | GET | 获取视频列表 | detection.py |
| `/api/detection/videos/cleanup` | DELETE | 清理旧视频 | detection.py |
| `/api/detection/results/images/{task_id}` | GET | 获取任务图片列表 | detection.py |
| `/api/detection/results/images/{task_id}/{filename}` | GET | 获取任务图片 | detection.py |
| `/api/detection/live-frame/{task_id}` | GET | 获取检测任务实时帧 | detection.py |

### 2.6 WebSocket端点

| WebSocket路径 | 功能描述 | 所属文件 |
|---------------|----------|----------|
| `/ws/video/{camera_id}` | WebSocket视频流 | video_websocket.py |
| `/ws/webrtc` | WebRTC信令 | webrtc_signaling.py |

---

## 三、主应用端点

| API路径 | HTTP方法 | 功能描述 | 所属文件 |
|---------|----------|----------|----------|
| `/video_feed` | GET | 实时视频流 | main.py |
| `/alert_logs` | GET | 获取告警日志列表 | main.py |
| `/dataset_stats` | GET | 获取数据集数量统计 | main.py |
| `/retrain_model` | POST | 触发模型重训练 | main.py |
| `/stop_system` | POST | 停止检测系统 | main.py |
| `/system/health` | GET | 系统健康检查 | main.py |
| `/camera/{camera_id}/status` | GET | 获取单个摄像头状态 | main.py |
| `/performance` | GET | 获取系统性能统计 | main.py |
| `/rate-limit/stats` | GET | 获取限流统计信息 | main.py |
| `/rate-limit/config` | GET | 获取限流配置 | main.py |

---

## 四、API分类统计

### 4.1 按HTTP方法分类

| HTTP方法 | 数量 | 占比 |
|----------|------|------|
| GET | 34 | 65% |
| POST | 14 | 27% |
| DELETE | 4 | 8% |

### 4.2 按模块分类

| 模块 | API数量 | WebSocket |
|------|----------|-----------|
| health | 6 | 0 |
| alerts | 12 | 0 |
| camera | 5 | 0 |
| video_feed | 8 | 0 |
| detection | 8 | 0 |
| main | 7 | 0 |
| websocket | 0 | 2 |
| **合计** | **46** | **2** |

---

## 五、资源消耗评估

| API类型 | 资源消耗级别 | 说明 |
|----------|--------------|------|
| 健康检查 | 低 | 简单查询，无数据库操作 |
| 告警查询 | 中 | 需要数据库查询 |
| 摄像头状态 | 低 | Redis查询 |
| 视频流 | 高 | 需要持续数据传输 |
| 视频上传 | 高 | 需要文件IO和模型推理 |
| 模型重训练 | 极高 | GPU密集型操作 |

---

## 六、限流建议

| API路径 | 建议限流 | 说明 |
|---------|----------|------|
| `/api/detection/upload` | 5 req/min | 防止同时上传过多视频 |
| `/retrain_model` | 1 req/5min | 模型重训练资源消耗大 |
| `/api/video_feed` | 100 req/min | 视频流资源消耗大 |
| 其他API | 1000 req/min | 常规API |

---

**文档版本**: v1.0  
**生成日期**: 2026年6月