#!/bin/bash
set -e

echo "================================================"
echo "           智能溺水检测系统 - React前端启动脚本"
echo "================================================"
echo ""

NODE_VERSION_REQUIRED="18.0.0"
FRONTEND_PORT="5173"

cd "$(dirname "$0")/react"

echo "[检查Node.js版本]"
if ! command -v node &> /dev/null; then
    echo "[ERROR] 未找到Node.js，请先安装 Node.js >= $NODE_VERSION_REQUIRED"
    exit 1
fi

echo ""
echo "[检查npm依赖]"
if [ ! -d "node_modules" ]; then
    echo "未找到node_modules，正在安装依赖..."
    npm install
    echo "[OK] npm依赖安装成功"
fi

echo ""
echo "[启动React开发服务器]"
echo "服务端口: $FRONTEND_PORT"
echo "访问地址: http://localhost:$FRONTEND_PORT"
echo ""
npm run dev