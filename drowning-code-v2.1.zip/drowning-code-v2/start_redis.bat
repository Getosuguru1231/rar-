@echo off
chcp 65001 >nul
echo ================================================
echo           智能溺水检测系统 - Redis启动脚本
echo ================================================
echo.

set "REDIS_PORT=6379"
set "REDIS_EXE=redis-server"

echo [检查Redis安装]
%REDIS_EXE% --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [WARNING] 未找到redis-server命令行工具
    echo 请确保Redis已安装并添加到系统PATH
    echo 或使用Docker启动Redis: docker-compose up -d redis
    echo.
    pause
    exit /b 1
)

echo.
echo [启动Redis服务]
echo Redis端口: %REDIS_PORT%
echo.
%REDIS_EXE% --port %REDIS_PORT%

pause