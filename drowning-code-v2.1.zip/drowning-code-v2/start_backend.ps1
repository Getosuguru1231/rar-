cd d:\图片\新1\backend
.\venv\Scripts\Activate.ps1
python main.py