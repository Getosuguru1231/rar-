$pids = (Get-NetTCPConnection -LocalPort 8001).OwningProcess | Select-Object -Unique
if ($pids -ne $null) {
    Stop-Process -Id $pids -Force
    Write-Host "已终止占用端口8001的进程"
} else {
    Write-Host "没有找到占用端口8001的进程"
}