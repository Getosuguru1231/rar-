#!/usr/bin/env python
"""摄像头诊断脚本 - 检查摄像头的能力和帧率"""
import cv2
import time

def test_camera(index, backend_name, backend_id):
    """测试特定摄像头"""
    print(f"\n{'='*60}")
    print(f"测试摄像头 {index} (后端: {backend_name})")
    print('='*60)
    
    cap = cv2.VideoCapture(index, backend_id)
    if not cap.isOpened():
        print(f"❌ 无法打开摄像头 {index}")
        return None
    
    print(f"✅ 摄像头 {index} 打开成功")
    
    # 获取摄像头支持的参数
    print(f"\n支持的参数:")
    print(f"  分辨率: {cap.get(cv2.CAP_PROP_FRAME_WIDTH)}x{cap.get(cv2.CAP_PROP_FRAME_HEIGHT)}")
    print(f"  FPS: {cap.get(cv2.CAP_PROP_FPS)}")
    print(f"  格式: {cap.get(cv2.CAP_PROP_FORMAT)}")
    print(f"  模式: {cap.get(cv2.CAP_PROP_MODE)}")
    print(f"  亮度: {cap.get(cv2.CAP_PROP_BRIGHTNESS)}")
    print(f"  对比度: {cap.get(cv2.CAP_PROP_CONTRAST)}")
    
    # 尝试不同分辨率
    resolutions = [
        (1920, 1080),
        (1280, 720),
        (640, 480),
        (320, 240),
    ]
    
    for width, height in resolutions:
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
        actual_w = cap.get(cv2.CAP_PROP_FRAME_WIDTH)
        actual_h = cap.get(cv2.CAP_PROP_FRAME_HEIGHT)
        
        # 测试帧率
        frames = 0
        start_time = time.time()
        test_duration = 3  # 测试 3 秒
        
        while time.time() - start_time < test_duration:
            ret, frame = cap.read()
            if ret:
                frames += 1
        
        elapsed = time.time() - start_time
        actual_fps = frames / elapsed if elapsed > 0 else 0
        
        print(f"\n  分辨率 {width}x{height}:")
        print(f"    实际分辨率: {actual_w}x{actual_h}")
        print(f"    实际帧率: {actual_fps:.2f} fps")
    
    cap.release()
    return True

def main():
    print("摄像头诊断工具")
    print("="*60)
    
    # 测试 DirectShow 后端 (Windows)
    print("\n测试 DirectShow 后端:")
    for i in range(3):
        test_camera(i, "DirectShow", cv2.CAP_DSHOW)
    
    # 测试默认后端
    print("\n测试默认后端:")
    for i in range(3):
        test_camera(i, "默认", cv2.CAP_ANY)
    
    print("\n" + "="*60)
    print("诊断完成")
    print("="*60)

if __name__ == "__main__":
    main()
