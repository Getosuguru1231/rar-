# Start script - Run frontend and backend services

Write-Host "====================================" -ForegroundColor Cyan
Write-Host "Starting Intelligent Drowning Detection System" -ForegroundColor Cyan
Write-Host "====================================" -ForegroundColor Cyan

# Check if Python is installed
if (-not (Get-Command python -ErrorAction SilentlyContinue)) {
    Write-Host "Error: Python not found. Please install Python 3.8+ first." -ForegroundColor Red
    pause
    exit 1
}

# Check if npm is installed
if (-not (Get-Command npm -ErrorAction SilentlyContinue)) {
    Write-Host "Error: npm not found. Please install Node.js first." -ForegroundColor Red
    pause
    exit 1
}

# Start backend service
Write-Host "Starting backend service..." -ForegroundColor Yellow
Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd 'd:\zhuomian\新1\backend'; python main.py"

# Wait for backend to start
Write-Host "Waiting for backend service to start..." -ForegroundColor Yellow
Start-Sleep -Seconds 5

# Start frontend monitoring page
Write-Host "Starting frontend monitoring page..." -ForegroundColor Yellow
if (Test-Path "d:\zhuomian\新1\frontend") {
    Write-Host "Starting frontend monitoring (http://localhost:3001)..." -ForegroundColor Yellow
    Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd 'd:\zhuomian\新1\frontend'; npm run dev"
} else {
    Write-Host "Frontend monitoring directory not found, skipping..." -ForegroundColor Yellow
}

# Wait for frontend monitoring to start
Write-Host "Waiting for frontend monitoring page to start..." -ForegroundColor Yellow
Start-Sleep -Seconds 5

# Start React frontend service (管理员页面)
Write-Host "Starting React frontend service (Admin UI)..." -ForegroundColor Yellow
if (Test-Path "d:\zhuomian\新1\react") {
    Write-Host "Starting admin panel (http://localhost:5173)..." -ForegroundColor Yellow
    Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd 'd:\zhuomian\新1\react'; npm run dev"
} else {
    Write-Host "React directory not found, skipping admin UI..." -ForegroundColor Yellow
}

# Wait for frontend to start
Write-Host "Waiting for React frontend service to start..." -ForegroundColor Yellow
Start-Sleep -Seconds 5

# Display service information
Write-Host "" -ForegroundColor White
Write-Host "====================================" -ForegroundColor Cyan
Write-Host "Services started successfully!" -ForegroundColor Green
Write-Host "====================================" -ForegroundColor Cyan
Write-Host "Backend API: http://localhost:8000/" -ForegroundColor White
Write-Host "API Docs: http://localhost:8000/docs" -ForegroundColor White
Write-Host "Frontend Monitor: http://localhost:3001/" -ForegroundColor White
Write-Host "Admin Panel: http://localhost:5173/" -ForegroundColor White
Write-Host "====================================" -ForegroundColor Cyan
Write-Host "Press any key to exit..." -ForegroundColor Gray

# Wait for user input
$null = $Host.UI.RawUI.ReadKey('NoEcho,IncludeKeyDown')
