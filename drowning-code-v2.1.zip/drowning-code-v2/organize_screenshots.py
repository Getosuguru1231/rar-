import os
import json

# 读取任务数据
tasks_file = r'D:\zhuomian\132456\backend\detection_tasks.json'
with open(tasks_file, 'r', encoding='utf-8') as f:
    tasks = json.load(f)

print(f"当前任务数量: {len(tasks)}")

# 处理每个任务
for task_id, task in tasks.items():
    print(f"\n处理任务: {task_id}")

    # 获取危险事件（in_water 和 in_water2）
    danger_events = [
        e for e in task.get('drowning_events', [])
        if e.get('type') in ['in_water', 'in_water2']
    ]
    print(f"  危险事件总数: {len(danger_events)}")

    # 获取危险截图
    danger_screenshots = [
        e.get('screenshot') for e in danger_events
        if e.get('screenshot')
    ]
    danger_screenshots = list(set(danger_screenshots))  # 去重
    print(f"  危险截图总数（去重后）: {len(danger_screenshots)}")

    # 如果超过20张，只保留前20张
    if len(danger_screenshots) > 20:
        danger_screenshots = danger_screenshots[:20]
        print(f"  已截断到20张")

    # 更新任务的 saved_images，只保留危险截图
    old_saved_images = task.get('saved_images', [])
    new_saved_images = [
        img for img in old_saved_images
        if img.get('filename') in danger_screenshots
    ]
    task['saved_images'] = new_saved_images
    print(f"  更新后的 saved_images 数量: {len(new_saved_images)}")

    # 更新 drowning_events，只保留危险事件
    new_drowning_events = [
        e for e in task.get('drowning_events', [])
        if e.get('type') in ['in_water', 'in_water2']
    ]
    # 如果超过20个事件，只保留前20个
    if len(new_drowning_events) > 20:
        new_drowning_events = new_drowning_events[:20]
    task['drowning_events'] = new_drowning_events
    print(f"  更新后的 drowning_events 数量: {len(new_drowning_events)}")

    # 更新 temp_screenshots（临时截图也应该限制数量）
    temp_screenshots = task.get('temp_screenshots', [])
    if len(temp_screenshots) > 20:
        task['temp_screenshots'] = temp_screenshots[:20]
        print(f"  更新后的 temp_screenshots 数量: {len(task['temp_screenshots'])}")

# 保存更新后的任务数据
with open(tasks_file, 'w', encoding='utf-8') as f:
    json.dump(tasks, f, ensure_ascii=False, indent=2)

print("\n✅ 任务数据整理完成！")
print("说明：")
print("  - 只保留 in_water 和 in_water2 类型的危险事件")
print("  - 事件和截图数量限制在20个以内")
print("  - 临时截图保留最近20张")
