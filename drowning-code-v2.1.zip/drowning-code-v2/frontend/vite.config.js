import { defineConfig, loadEnv } from 'vite'
import vue from '@vitejs/plugin-vue'
import path from 'path'

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, path.resolve(__dirname, '.'))
  
  return {
    plugins: [vue()],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, './src'),
      },
    },
    server: {
      port: 3002,
      host: '0.0.0.0',
      strictPort: true,
      proxy: {
        '/api/remote_video': {
          target: 'http://10.64.90.195:8899',
          changeOrigin: true,
          secure: false,
          rewrite: (path) => path.replace(/^\/api\/remote_video/, '/video'),
        },
        '/api': {
          target: 'http://localhost:8000',
          changeOrigin: true,
          secure: false,
        },
        '/api/water': {
          target: 'http://localhost:8000',
          changeOrigin: true,
          secure: false,
        },
        '/ws': {
          target: 'http://localhost:8000',
          changeOrigin: true,
          ws: true,
          secure: false,
        },
        '/video_feed': {
          target: 'http://localhost:8000',
          changeOrigin: true,
          secure: false,
        },
      },
    },
  }
})
