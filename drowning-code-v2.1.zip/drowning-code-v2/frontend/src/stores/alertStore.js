import { reactive, ref, computed } from 'vue'

class AlertStore {
  constructor() {
    // 告警列表
    this.alertList = ref([])
    
    // 告警统计
    this.stats = reactive({
      total: 0,
      pending: 0,
      resolved: 0,
      highRisk: 0,
      mediumRisk: 0,
      lowRisk: 0,
      todayTotal: 0,
      todayHandled: 0,
      todayPending: 0
    })
    
    // 统计趋势（最近7天）
    this.trendData = ref([])
    
    // 筛选状态
    this.filterState = reactive({
      level: '',
      status: '',
      cameraId: '',
      keyword: ''
    })
    
    // 通知设置
    this.notificationSettings = reactive({
      sound: true,
      desktop: true,
      highPriorityOnly: false
    })
    
    // 告警计数器（用于去重）
    this.alertCounter = new Map()
    
    // 事件监听器
    this.listeners = new Map()
    
    // AudioContext实例（缓存，避免重复创建）
    this.audioContext = null
    
    // 声音播放冷却时间（毫秒）
    this.lastPlayTime = 0
    this.soundCooldownMs = 3000
    
    // 初始化
    this.generateTrendData()
    this.updateStats()
  }
  
  // 添加告警
  addAlert(alertData) {
    // 使用字符串类型的 id，确保与后端广播的告警更新中的 id 格式一致
    const alertId = alertData.id ? String(alertData.id) : `${alertData.time}-${alertData.cameraId}-${alertData.area}`
    
    // 检查是否已存在
    const existingIndex = this.alertList.value.findIndex(a => a.alertId === alertId)
    
    if (existingIndex !== -1) {
        // 更新现有告警 - 保留原有的排序位置，只更新状态
        const oldAlert = this.alertList.value[existingIndex]
        const newAlert = { ...oldAlert }
        
        Object.keys(alertData).forEach(key => {
          // 保留原始字段，不被覆盖
          if (key !== 'time' && key !== 'drowningStartTime' && key !== '_sortIndex') {
            newAlert[key] = alertData[key]
          }
        })
        
        // 替换整个对象触发响应式更新
        this.alertList.value.splice(existingIndex, 1, newAlert)
      } else {
      // 添加新告警到列表开头
      const newAlert = {
        alertId,
        id: alertData.id || alertId,
        time: alertData.time || alertData.timestamp || new Date().toLocaleString('zh-CN'),
        drowningStartTime: alertData.drowningStartTime || alertData.time || alertData.timestamp || new Date().toISOString(),
        cameraId: alertData.cameraId || alertData.camera_id || 1,
        area: alertData.area || '未知区域',
        level: alertData.level || 'high',
        reason: alertData.reason || '检测到异常',
        acknowledged: alertData.acknowledged || false,
        resolved: alertData.resolved || false,
        read: alertData.read || false,
        // 添加排序索引，新告警索引最小（排在最前）
        _sortIndex: Date.now(),
        ...alertData
      }
      
      this.alertList.value.unshift(newAlert)
      
      // 限制列表长度
      if (this.alertList.value.length > 200) {
        this.alertList.value.pop()
      }
      
      // 触发通知（如果启用）
      this.triggerNotification(newAlert)
    }
    
    // 更新统计
    this.updateStats()
    this.generateTrendData()
    
    // 触发事件
    this.emit('alertAdded', this.alertList.value[0])
    this.emit('alertListChanged', this.alertList.value)
  }
  
  // 触发通知
  triggerNotification(alert) {
    // 检查是否只通知高优先级
    if (this.notificationSettings.highPriorityOnly && alert.level !== 'high') {
      return
    }
    
    // 声音通知
    if (this.notificationSettings.sound) {
      this.playNotificationSound(alert.level)
    }
    
    // 语音播报
    this.speakAlert(alert)
    
    // 桌面通知
    if (this.notificationSettings.desktop && 'Notification' in window) {
      this.showDesktopNotification(alert)
    }
  }
  
  // 语音播报告警
  speakAlert(alert) {
    const cameraId = alert.cameraId || alert.camera_id || 1
    const speakText = `摄像头${cameraId}出现溺水行为，请立即处理`
    
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(speakText)
      utterance.lang = 'zh-CN'
      utterance.rate = 1
      utterance.pitch = 1
      utterance.volume = 1
      window.speechSynthesis.speak(utterance)
      console.log('[AlertStore] 语音播报:', speakText)
    } else {
      console.warn('[AlertStore] 当前浏览器不支持语音播报')
    }
  }
  
  // 获取或创建AudioContext实例
  getAudioContext() {
    if (!this.audioContext) {
      this.audioContext = new (window.AudioContext || window.webkitAudioContext)()
    }
    return this.audioContext
  }
  
  // 解锁AudioContext（需要用户交互）
  unlockAudioContext() {
    const ctx = this.getAudioContext()
    if (ctx.state === 'suspended') {
      ctx.resume().then(() => {
        console.log('[AlertStore] AudioContext已解锁')
      }).catch(err => {
        console.error('[AlertStore] 解锁AudioContext失败:', err)
      })
    }
  }
  
  // 播放通知声音
  playNotificationSound(level) {
    if (!this.notificationSettings.sound) {
      return
    }
    
    const now = Date.now()
    if (now - this.lastPlayTime < this.soundCooldownMs) {
      console.log('[AlertStore] 声音播放冷却中，跳过本次播放')
      return
    }
    
    try {
      const ctx = this.getAudioContext()
      const oscillator = ctx.createOscillator()
      const gainNode = ctx.createGain()
      
      oscillator.connect(gainNode)
      gainNode.connect(ctx.destination)
      
      switch(level) {
        case 'high':
          oscillator.type = 'sine'
          oscillator.frequency.setValueAtTime(880, ctx.currentTime)
          oscillator.frequency.setValueAtTime(1100, ctx.currentTime + 0.1)
          oscillator.frequency.setValueAtTime(880, ctx.currentTime + 0.2)
          oscillator.frequency.setValueAtTime(1100, ctx.currentTime + 0.3)
          gainNode.gain.setValueAtTime(0.5, ctx.currentTime)
          gainNode.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.4)
          oscillator.start(ctx.currentTime)
          oscillator.stop(ctx.currentTime + 0.4)
          break
        case 'medium':
          oscillator.type = 'sine'
          oscillator.frequency.setValueAtTime(660, ctx.currentTime)
          oscillator.frequency.setValueAtTime(880, ctx.currentTime + 0.15)
          oscillator.frequency.setValueAtTime(660, ctx.currentTime + 0.3)
          gainNode.gain.setValueAtTime(0.3, ctx.currentTime)
          gainNode.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.45)
          oscillator.start(ctx.currentTime)
          oscillator.stop(ctx.currentTime + 0.45)
          break
        default:
          oscillator.type = 'sine'
          oscillator.frequency.setValueAtTime(440, ctx.currentTime)
          gainNode.gain.setValueAtTime(0.2, ctx.currentTime)
          gainNode.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.5)
          oscillator.start(ctx.currentTime)
          oscillator.stop(ctx.currentTime + 0.5)
      }
      
      this.lastPlayTime = now
    } catch (e) {
      console.warn('无法播放通知声音:', e)
    }
  }
  
  // 显示桌面通知
  showDesktopNotification(alert) {
    if (Notification.permission === 'granted') {
      new Notification(`【${this.getLevelText(alert.level)}】告警`, {
        body: `${alert.reason} - 摄像头${alert.cameraId} (${alert.area})`,
        icon: '/favicon.ico'
      })
    } else if (Notification.permission !== 'denied') {
      Notification.requestPermission()
    }
  }
  
  // 获取级别文本
  getLevelText(level) {
    const texts = {
      high: '高风险',
      medium: '中风险',
      low: '低风险'
    }
    return texts[level] || '未知'
  }
  
  // 标记告警已读
  markAsRead(alertId) {
    const index = this.alertList.value.findIndex(a => a.alertId === alertId)
    if (index !== -1) {
      const oldAlert = this.alertList.value[index]
      const newAlert = { ...oldAlert, read: true }
      this.alertList.value.splice(index, 1, newAlert)
      this.emit('alertUpdated', newAlert)
    }
  }
  
  // 批量确认告警
  batchAcknowledge(alertIds) {
    alertIds.forEach(alertId => {
      this.acknowledgeAlert(alertId)
    })
    this.emit('batchAcknowledge', alertIds)
  }
  
  // 批量删除告警
  batchDelete(alertIds) {
    alertIds.forEach(alertId => {
      this.deleteAlert(alertId)
    })
    this.emit('batchDelete', alertIds)
  }
  
  // 按摄像头获取告警
  getAlertsByCamera(cameraId) {
    return this.alertList.value.filter(a => a.cameraId === cameraId)
  }
  
  // 按风险级别获取告警
  getAlertsByLevel(level) {
    return this.alertList.value.filter(a => a.level === level)
  }
  
  // 获取未读告警数量
  getUnreadCount() {
    return this.alertList.value.filter(a => !a.read && !a.acknowledged).length
  }
  
  // 生成趋势数据（最近7天）
  generateTrendData() {
    const now = new Date()
    const days = []
    
    for (let i = 6; i >= 0; i--) {
      const date = new Date(now)
      date.setDate(date.getDate() - i)
      const dateStr = date.toLocaleDateString('zh-CN', { month: '2-digit', day: '2-digit' })
      
      // 筛选当天的告警
      const dayAlerts = this.alertList.value.filter(alert => {
        try {
          return new Date(alert.time).toDateString() === date.toDateString()
        } catch {
          return false
        }
      })
      
      days.push({
        date: dateStr,
        total: dayAlerts.length,
        high: dayAlerts.filter(a => a.level === 'high').length,
        medium: dayAlerts.filter(a => a.level === 'medium').length,
        low: dayAlerts.filter(a => a.level === 'low').length
      })
    }
    
    this.trendData.value = days
  }
  
  // 更新告警状态
  updateAlertStatus(alertId, updates) {
    const index = this.alertList.value.findIndex(a => a.alertId === alertId)
    if (index !== -1) {
      // 如果是确认告警，自动添加确认时间
      if (updates.acknowledged && !updates.acknowledged_time) {
        updates.acknowledged_time = new Date().toISOString()
      }
      
      // 创建新对象替换旧对象，确保响应式更新
      const oldAlert = this.alertList.value[index]
      const newAlert = { ...oldAlert, ...updates }
      
      // 替换整个对象触发响应式更新
      this.alertList.value.splice(index, 1, newAlert)
      
      // 更新统计
      this.updateStats()
      
      // 触发事件
      this.emit('alertUpdated', newAlert)
      this.emit('alertListChanged', this.alertList.value)
    }
  }
  
  // 确认告警
  acknowledgeAlert(alertId) {
    this.updateAlertStatus(alertId, { acknowledged: true })
  }
  
  // 解决告警
  resolveAlert(alertId) {
    this.updateAlertStatus(alertId, { resolved: true, acknowledged: true })
  }
  
  // 批量设置告警列表
  setAlerts(alerts) {
    if (!Array.isArray(alerts)) {
      console.warn('[AlertStore] setAlerts: 传入的不是数组，已忽略')
      return
    }
    
    // 先按照时间排序，新的在前，然后为每个告警分配排序索引
    const sortedAlerts = [...alerts].sort((a, b) => {
      const timeA = new Date(a.time || a.timestamp).getTime()
      const timeB = new Date(b.time || b.timestamp).getTime()
      return timeB - timeA // 降序，新的在前
    })
    
    this.alertList.value = sortedAlerts.map((alert, index) => ({
      ...alert,
      alertId: alert.id ? String(alert.id) : `${alert.time}-${alert.cameraId}-${alert.area}`,
      time: alert.time || alert.timestamp || new Date().toLocaleString('zh-CN'),
      drowningStartTime: alert.drowningStartTime || alert.time || alert.timestamp || new Date().toISOString(),
      cameraId: alert.cameraId || alert.camera_id || 1,
      area: alert.area || '未知区域',
      level: alert.level || 'high',
      reason: alert.reason || '检测到异常',
      acknowledged: alert.acknowledged || false,
      resolved: alert.resolved || false,
      // 设置排序索引，使用反向索引确保新的在前
      _sortIndex: Date.now() - index
    }))
    
    // 更新统计
    this.updateStats()
    
    // 触发事件
    this.emit('alertListChanged', this.alertList.value)
  }
  
  // 更新统计数据
  updateStats() {
    const today = new Date().toDateString()
    
    // 今日告警
    const todayAlerts = this.alertList.value.filter(alert => {
      try {
        return new Date(alert.time).toDateString() === today
      } catch {
        return false
      }
    })
    
    // 全部告警统计
    this.stats.total = this.alertList.value.length
    this.stats.pending = this.alertList.value.filter(a => !a.acknowledged && !a.resolved).length
    this.stats.resolved = this.alertList.value.filter(a => a.acknowledged || a.resolved).length
    this.stats.highRisk = this.alertList.value.filter(a => a.level === 'high').length
    this.stats.mediumRisk = this.alertList.value.filter(a => a.level === 'medium').length
    this.stats.lowRisk = this.alertList.value.filter(a => a.level === 'low').length
    
    // 今日告警统计
    this.stats.todayTotal = todayAlerts.length
    this.stats.todayHandled = todayAlerts.filter(a => a.acknowledged || a.resolved).length
    this.stats.todayPending = todayAlerts.filter(a => !a.acknowledged && !a.resolved).length
    
    // 按摄像头统计
    this.stats.cameraStats = {}
    this.alertList.value.forEach(alert => {
      const camId = alert.cameraId
      if (!this.stats.cameraStats[camId]) {
        this.stats.cameraStats[camId] = { total: 0, high: 0, medium: 0, low: 0 }
      }
      this.stats.cameraStats[camId].total++
      this.stats.cameraStats[camId][alert.level]++
    })
    
    // 触发统计更新事件
    this.emit('statsUpdated', this.stats)
  }
  
  // 获取趋势数据
  getTrendData() {
    return this.trendData.value
  }
  
  // 更新通知设置
  updateNotificationSettings(settings) {
    Object.assign(this.notificationSettings, settings)
  }
  
  // 设置筛选状态
  setFilterState(filter) {
    Object.assign(this.filterState, filter)
  }
  
  // 获取筛选后的告警列表
  getFilteredAlerts() {
    let result = [...this.alertList.value]
    
    if (this.filterState.level) {
      result = result.filter(a => a.level === this.filterState.level)
    }
    
    if (this.filterState.status === 'pending') {
      result = result.filter(a => !a.acknowledged)
    } else if (this.filterState.status === 'resolved') {
      result = result.filter(a => a.acknowledged)
    }
    
    if (this.filterState.cameraId) {
      result = result.filter(a => a.cameraId === parseInt(this.filterState.cameraId))
    }
    
    if (this.filterState.keyword) {
      const keyword = this.filterState.keyword.toLowerCase()
      result = result.filter(a => 
        (a.reason && a.reason.toLowerCase().includes(keyword)) ||
        (a.area && a.area.toLowerCase().includes(keyword))
      )
    }
    
    return result.sort((a, b) => new Date(b.time) - new Date(a.time))
  }
  
  // 获取告警列表
  getAlerts() {
    return Array.isArray(this.alertList.value) ? this.alertList.value : []
  }
  
  // 获取统计数据
  getStats() {
    return this.stats
  }
  
  // 获取单个告警
  getAlert(alertId) {
    return this.alertList.value.find(a => a.alertId === alertId)
  }
  
  // 添加事件监听器
  on(event, callback) {
    if (!this.listeners.has(event)) {
      this.listeners.set(event, [])
    }
    this.listeners.get(event).push(callback)
  }
  
  // 移除事件监听器
  off(event, callback) {
    const callbacks = this.listeners.get(event)
    if (callbacks) {
      const index = callbacks.indexOf(callback)
      if (index !== -1) {
        callbacks.splice(index, 1)
      }
    }
  }
  
  // 触发事件
  emit(event, ...args) {
    const callbacks = this.listeners.get(event)
    if (callbacks) {
      callbacks.forEach(callback => callback(...args))
    }
  }
  
  // 删除单个告警
  deleteAlert(alertId) {
    const index = this.alertList.value.findIndex(a => a.alertId === alertId || String(a.id) === String(alertId))
    if (index !== -1) {
      const deletedAlert = this.alertList.value.splice(index, 1)[0]
      
      // 更新统计
      this.updateStats()
      
      // 触发事件
      this.emit('alertDeleted', deletedAlert)
      this.emit('alertListChanged', this.alertList.value)
    }
  }
  
  // 清空所有告警
  clearAll() {
    this.alertList.value = []
    this.updateStats()
    this.emit('alertListChanged', [])
    this.emit('alertsCleared')
  }
}

// 创建全局单例
export const alertStore = new AlertStore()

// 默认导出AlertStore类
export default AlertStore

// Vue插件形式导出
export function createAlertStorePlugin(app) {
  app.config.globalProperties.$alertStore = alertStore
}
