import { ref } from 'vue'

// 模块级单例 ref，确保所有组件共享同一组航点
export const waypoints = ref([])
export const returnToHomeFlag = ref(0)
export const startNavFlag = ref(0)

export const triggerReturnToHome = () => {
  returnToHomeFlag.value++
}

export const triggerStartNavigation = () => {
  startNavFlag.value++
}

const MAX_WAYPOINTS = 10

export const addWaypoint = (lng, lat) => {
  if (waypoints.value.length >= MAX_WAYPOINTS) {
    return false
  }
  waypoints.value.push({
    id: Date.now(),
    index: waypoints.value.length + 1,
    lng,
    lat
  })
  return true
}

export const removeWaypoint = (id) => {
  const idx = waypoints.value.findIndex(p => p.id === id)
  if (idx === -1) return
  waypoints.value.splice(idx, 1)
  waypoints.value.forEach((p, i) => {
    p.index = i + 1
  })
}

export const clearWaypoints = () => {
  waypoints.value = []
}

export const setWaypoints = (list) => {
  waypoints.value = list
}
