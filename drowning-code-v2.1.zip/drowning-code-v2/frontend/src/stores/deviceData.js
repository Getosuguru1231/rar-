import { ref } from 'vue'
import { ElMessageBox } from 'element-plus'
import { startMockSSE, closeMockSSE } from './test'

const deviceData = ref([])
const chartHistory = ref({
  IRTemp: [],
  RadarEcho: [],
  SonarDepth: [],
  SignalStr: []
})
const deviceStatus = ref({ online: true, battery: 85, signal: 4 })
let listeners = []
let started = false
let historyLoaded = true  // 纯前端模式，无需等待后端历史数据
let irTempLowWarned = false
let irTempHighWarned = false

export const addDataListener = (callback) => {
  listeners.push(callback)
  return () => {
    listeners = listeners.filter(cb => cb !== callback)
  }
}

const notifyListeners = () => {
  listeners.forEach(cb => cb(deviceData.value))
}

const checkRescueAlarm = (data) => {
  const irItem = data.find(d => d.identifier === 'IRTemp')
  if (!irItem) return
  const ir = parseFloat(irItem.value)

  if (ir < 30.0) {
    if (!irTempLowWarned) {
      irTempLowWarned = true
      ElMessageBox.alert('检测到水面体温异常偏低，可能有人溺水失温！', '溺水风险预警', { type: 'warning' })
    }
  } else {
    irTempLowWarned = false
  }

  if (ir > 40.0) {
    if (!irTempHighWarned) {
      irTempHighWarned = true
      ElMessageBox.alert('检测到水面异常高温信号，请确认是否为人体热源！', '热源检测预警', { type: 'warning' })
    }
  } else {
    irTempHighWarned = false
  }
}

export const setDeviceData = (data) => {
  deviceData.value = data

  const timestamp = Date.now()
  data.forEach(item => {
    if (item.identifier === 'GPS') return
    if (!chartHistory.value[item.identifier]) {
      chartHistory.value[item.identifier] = []
    }
    const history = chartHistory.value[item.identifier]
    if (history.length >= 3600) {
      history.shift()
    }
    history.push([timestamp, parseFloat(item.value)])
  })

  checkRescueAlarm(data)
  notifyListeners()
}

export const startPolling = () => {
  if (started) return
  started = true
  startMockSSE()
}

export const updateDeviceStatus = (status) => {
  deviceStatus.value = status
}

export const stopPolling = () => {
  closeMockSSE()
  started = false
  listeners = []
}

export const getDataByIdentifier = (identifier) => {
  const item = deviceData.value.find(d => d.identifier === identifier)
  return item ? parseFloat(item.value) : null
}

export const getChartHistory = (identifier) => {
  const data = chartHistory.value[identifier]
  if (!data || data.length === 0) {
    return [[Date.now(), 0]]
  }
  return data
}

export const isHistoryLoaded = () => historyLoaded

export const getDeviceStatus = () => deviceStatus.value
