export const WS_PATHS = {
  video: '/ws/video',
  webrtc: '/ws/webrtc',
  alerts: '/ws/alerts',
  rdk_x5: '/ws/rdk_x5/stream',
  monitor: '/ws/monitor'
}

export const VIDEO_STREAM_CONFIG = {
  useDirectStream: false,
  directStreamUrl: '/api/remote_video'
}

// WebRTC点对点模式配置：直接连接后端，绕过Vite代理
export const P2P_CONFIG = {
  enabled: false,
  backendHost: '127.0.0.1',
  backendPort: 8000
}

export const getWsUrl = (path, params = {}) => {
  const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:'
  const host = window.location.host
  
  let url = `${protocol}//${host}${path}`
  
  if (Object.keys(params).length > 0) {
    const queryString = new URLSearchParams(params).toString()
    url += `?${queryString}`
  }
  
  return url
}

export const getWsUrlDirect = (path, params = {}) => {
  const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:'
  const { backendHost, backendPort } = P2P_CONFIG
  const host = `${backendHost}:${backendPort}`
  
  let url = `${protocol}//${host}${path}`
  
  if (Object.keys(params).length > 0) {
    const queryString = new URLSearchParams(params).toString()
    url += `?${queryString}`
  }
  
  return url
}

export const getVideoWsUrl = (cameraId, params = {}) => {
  const path = `${WS_PATHS.video}/${cameraId}`
  return P2P_CONFIG.enabled ? getWsUrlDirect(path, params) : getWsUrl(path, params)
}

export const getWebRtcWsUrl = (cameraId) => {
  const path = `${WS_PATHS.webrtc}/${cameraId}`
  return P2P_CONFIG.enabled ? getWsUrlDirect(path) : getWsUrl(path)
}

export const getAlertsWsUrl = () => {
  return P2P_CONFIG.enabled ? getWsUrlDirect(WS_PATHS.alerts) : getWsUrl(WS_PATHS.alerts)
}

export const getRDK X5 EdgeWsUrl = () => {
  return P2P_CONFIG.enabled ? getWsUrlDirect(WS_PATHS.rdk_x5) : getWsUrl(WS_PATHS.rdk_x5)
}

export const getMonitorWsUrl = () => {
  return P2P_CONFIG.enabled ? getWsUrlDirect(WS_PATHS.monitor) : getWsUrl(WS_PATHS.monitor)
}