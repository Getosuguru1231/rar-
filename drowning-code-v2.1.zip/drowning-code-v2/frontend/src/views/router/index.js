// frontend/src/router/index.js
import { createRouter, createWebHistory } from 'vue-router'
import Monitor from '../views/Monitor.vue'

const routes = [
  {
    path: '/',
    name: 'Monitor',
    component: Monitor
  },
  {
    path: '/dashboard',
    name: 'DrowningDashboard',
    component: () => import('../views/DrowningDashboard.vue')
  }
]

const router = createRouter({
  history: createWebHistory('/'),
  routes
})

export default router