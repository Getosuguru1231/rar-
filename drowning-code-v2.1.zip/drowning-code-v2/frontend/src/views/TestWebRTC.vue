<template>
  <div class="test-container">
    <h1>WebRTC 测试页面</h1>
    <p>状态：{{ status }}</p>
    <div class="video-wrapper">
      <WebRTCPlayer
        ref="webrtcRef"
        :camera-id="1"
        :auto-connect="true"
        @connected="onConnected"
        @error="onError"
        @disconnected="onDisconnected"
      />
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import WebRTCPlayer from '../components/video/WebRTCPlayer.vue'

const status = ref('初始化中...')

const onConnected = (cameraId) => {
  console.log('[TestWebRTC] WebRTC已连接！ cameraId:', cameraId)
  status.value = `已连接 (摄像头${cameraId})`
}

const onError = (cameraId, event) => {
  console.error('[TestWebRTC] WebRTC错误：', cameraId, event)
  status.value = `错误：${event}`
}

const onDisconnected = (cameraId) => {
  console.log('[TestWebRTC] WebRTC断开连接：', cameraId)
  status.value = '已断开'
}

onMounted(() => {
  console.log('[TestWebRTC] 测试页面已挂载！')
  status.value = '页面已加载'
})
</script>

<style scoped>
.test-container {
  width: 100%;
  height: 100vh;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  background: #1a1a2e;
  color: white;
}

h1 {
  margin-bottom: 20px;
}

.video-wrapper {
  width: 360px;
  height: 640px;
  border: 2px solid #ffd700;
}
</style>
