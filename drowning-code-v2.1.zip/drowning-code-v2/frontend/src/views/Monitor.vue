<template>
  <div class="monitor-system">
    <!-- 顶部导航栏 -->
    <el-header class="header">
      <div class="header-left">
        <div class="logo-icon">防</div>
        <h1>AI溺水防控监测系统</h1>
      </div>
      
      <!-- 顶部功能按钮栏 -->
      <div class="header-center">
        <!-- 左侧功能按钮组 -->
        <div class="header-btn-group left-group">
          <el-button class="header-btn btn-green" @click="handleUploadVideo">
            <svg class="btn-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
              <polyline points="17 8 12 3 7 8"></polyline>
              <line x1="12" y1="3" x2="12" y2="15"></line>
            </svg>
            上传检测
          </el-button>
          <el-button class="header-btn btn-blue" @click="handleDetectionHistory">
            <svg class="btn-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
              <line x1="16" y1="2" x2="16" y2="6"></line>
              <line x1="8" y1="2" x2="8" y2="6"></line>
              <line x1="3" y1="10" x2="21" y2="10"></line>
            </svg>
            检测历史
          </el-button>
          <el-button class="header-btn btn-blue" @click="handleCleanVideo">
            <svg class="btn-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <polyline points="3 6 5 6 21 6"></polyline>
              <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
            </svg>
            清理视频
          </el-button>
        </div>

        

        <!-- 告警指示器 -->
        <div class="status-indicators">
          <div class="indicator-item alert-count" v-if="unhandledAlertCount > 0">
            <span class="indicator-dot"></span>
            <span class="indicator-value">{{ unhandledAlertCount }}</span>
            <span class="indicator-label">待处理</span>
          </div>
        </div>

        <!-- 声音开关 -->
        <div class="sound-toggle">
          <el-switch 
            v-model="alertStore.notificationSettings.sound" 
            @change="handleSoundToggle"
            active-text="开"
            inactive-text="关"
          />
          <span class="sound-label">声音</span>
        </div>

        <!-- 右侧操作按钮组 -->
        <div class="header-btn-group right-group">
          <el-button class="header-btn btn-action" @click="refreshAll" title="刷新页面">
            <svg class="btn-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <polyline points="23 4 23 10 17 10"></polyline>
              <polyline points="1 20 1 14 7 14"></polyline>
              <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path>
            </svg>
          </el-button>
          <el-button class="header-btn btn-action" @click="toggleFullscreen" title="全屏">
            <svg class="btn-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <polyline points="16 3 21 3 21 8"></polyline>
              <line x1="4" y1="20" x2="21" y2="20"></line>
              <polyline points="21 16 21 21 16 21"></polyline>
              <line x1="15" y1="15" x2="21" y2="21"></line>
              <polyline points="8 21 3 21 3 16"></polyline>
              <line x1="3" y1="3" x2="3" y2="15"></line>
              <polyline points="3 8 3 3 8 3"></polyline>
              <line x1="15" y1="15" x2="3" y2="3"></line>
            </svg>
          </el-button>
        </div>

        <!-- 分屏选择器 -->
        <div class="split-selector">
          <button class="split-btn" @click="toggleSplitMenu">
            <svg class="btn-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <rect x="3" y="3" width="7" height="7"></rect>
              <rect x="14" y="3" width="7" height="7"></rect>
              <rect x="14" y="14" width="7" height="7"></rect>
              <rect x="3" y="14" width="7" height="7"></rect>
            </svg>
            {{ splitScreen }}分屏<i class="el-icon-arrow-down el-icon--right"></i>
          </button>
          <div v-if="showSplitMenu" class="split-menu">
            <button v-for="n in 16" :key="n" @click="handleSplitSelect(n)" class="split-menu-item">
              {{ n }}分屏
            </button>
          </div>
        </div>

        <!-- 用户信息 -->
        <div class="user-info">
          <svg class="user-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
            <circle cx="12" cy="7" r="4"></circle>
          </svg>
          <span class="user-name">{{ username }} <el-tag v-if="userType === 'admin'" type="warning" size="small">管理员</el-tag></span>
        </div>

        <!-- 退出按钮 -->
        <el-button class="header-btn btn-logout" @click="handleLogout">
          <svg class="btn-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path>
            <polyline points="16 17 21 12 16 7"></polyline>
            <line x1="21" y1="12" x2="9" y2="12"></line>
          </svg>
          退出
        </el-button>
      </div>
    </el-header>

    <el-container :class="{ 'big-screen-mode': isBigScreenMode }" style="height: calc(100vh - 48px);">
      <!-- 左侧警报栏 -->
      <el-aside v-show="!isBigScreenMode" width="25%" class="alert-aside">
        <!-- 实时警报列表 -->
        <div class="alert-panel">
          <div class="panel-header">
            <div class="header-left-part">
              <span class="panel-title">实时告警</span>
              <span class="alert-count-badge">{{ alertList.length }} 条记录</span>
            </div>
            <div class="header-actions">
              <el-badge :value="unhandledAlertCount" class="alert-badge" v-if="unhandledAlertCount > 0">
                <span class="badge-icon"></span>
              </el-badge>
              <span class="view-all-btn" @click="viewAllAlerts">查看全部</span>
              <span class="delete-all-btn" @click="deleteAllAlerts" v-if="alertList.length > 0">全部删除</span>
            </div>
          </div>

          <div class="alert-tabs">
            <span 
              class="tab-item" 
              :class="{ active: activeTab === 'all' }"
              @click="activeTab = 'all'"
            >全部</span>
            <span 
              class="tab-item" 
              :class="{ active: activeTab === 'unhandled' }"
              @click="activeTab = 'unhandled'"
            >待处理</span>
            <span 
              class="tab-item" 
              :class="{ active: activeTab === 'handled' }"
              @click="activeTab = 'handled'"
            >已处理</span>
          </div>

          <div class="alert-list">
            <div 
              class="alert-card" 
              v-for="(alert, index) in filteredAlerts" 
              :key="index"
              :class="{ active: activeAlert === index, acknowledged: alert.acknowledged }"
              @click="jumpToAlert(alert, index)"
            >
              <div class="alert-card-header">
                <span class="alert-type">检测到溺水行为</span>
                <span class="alert-level" :class="alert.level">
                  {{ alert.level === 'high' ? '高风险' : alert.level === 'medium' ? '中风险' : '低风险' }}
                </span>
              </div>
              <div class="alert-card-body">
                <div class="alert-info-row">
                  <span class="alert-camera">摄像头{{ alert.cameraId }}</span>
                  <span class="alert-area">{{ alert.area }}</span>
                </div>
                <div class="alert-info-row">
                  <span class="alert-time">{{ formatAlertTime(alert.time) }}</span>
                  <span class="alert-time-detail">{{ alert.time.split(' ')[1] }}</span>
                </div>
              </div>
              <div class="alert-card-footer">
                <el-button 
                  size="small" 
                  :class="alert.acknowledged ? 'btn-acknowledged' : 'btn-confirm'"
                  @click.stop="confirmAlert(index)"
                >
                  {{ alert.acknowledged ? '已处理' : '处理' }}
                </el-button>
                <el-button 
                  size="small" 
                  class="btn-delete"
                  @click.stop="deleteAlert(index)"
                >
                  删除
                </el-button>
              </div>
            </div>
            <div class="empty-alert" v-if="filteredAlerts.length === 0">
              <div>暂无警报信息</div>
              <div class="empty-hint">系统运行正常</div>
            </div>
          </div>
        </div>

        <!-- 人数统计面板 -->
        <div class="stats-panel">
          <div class="panel-header">
            <span class="panel-title">人数统计</span>
          </div>
          <div class="stats-content">
            <div class="main-stat">
              <span class="stat-label">当前总人数</span>
              <span class="stat-value">{{ totalPeopleCount }}</span>
            </div>
            <div class="section-title">区域人数分布</div>
            <div class="area-list">
              <div v-for="area in areaDistribution" :key="area.name" class="area-item">
                <span class="area-name">{{ area.name }}</span>
                <span class="area-count">{{ area.count }}人</span>
              </div>
            </div>
          </div>
        </div>
      </el-aside>

      <!-- 主内容区 -->
      <el-main class="monitor-main">
        <!-- 大屏模式告警通知 -->
        <div v-if="isBigScreenMode && filteredAlerts.length > 0" class="big-screen-alert-bar">
          <div class="alert-bar-content">
            <span class="alert-bar-icon"></span>
            <span class="alert-bar-text">检测到 {{ unhandledAlertCount }} 条待处理告警</span>
            <span class="alert-bar-hint">点击查看详情</span>
          </div>
        </div>
        
        <!-- 上半部分：摄像头画面 -->
        <div class="monitor-upper" :class="{ 'big-screen': isBigScreenMode }">
          <!-- 大屏模式标题栏 -->
          <div v-if="isBigScreenMode" class="big-screen-header">
            <div class="big-screen-header-left">
              <button class="big-screen-back-btn" @click="toggleBigScreenMode">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <polyline points="15 18 9 12 15 6"></polyline>
                </svg>
                返回
              </button>
              <span class="big-screen-title">监控大屏</span>
            </div>
            <div class="big-screen-header-right">
              <div class="split-selector">
                <button class="split-btn" @click="toggleSplitMenu">
                  <svg class="btn-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <rect x="3" y="3" width="7" height="7"></rect>
                    <rect x="14" y="3" width="7" height="7"></rect>
                    <rect x="14" y="14" width="7" height="7"></rect>
                    <rect x="3" y="14" width="7" height="7"></rect>
                  </svg>
                  {{ splitScreen }}分屏<i class="el-icon-arrow-down el-icon--right"></i>
                </button>
                <div v-if="showSplitMenu" class="split-menu">
                  <button v-for="n in 16" :key="n" @click="handleSplitSelect(n)" class="split-menu-item">
                    {{ n }}分屏
                  </button>
                </div>
              </div>
              <div class="status-indicators">
                <div class="indicator-item alert-count" v-if="unhandledAlertCount > 0">
                  <span class="indicator-dot"></span>
                  <span class="indicator-value">{{ unhandledAlertCount }}</span>
                  <span class="indicator-label">待处理</span>
                </div>

              </div>
            </div>
          </div>

          
          <!-- 多分屏容器 -->
          <div class="screen-container" :class="`split-${splitScreen}`">
            <div 
              class="screen-item" 
              v-for="camera in displayCameras" 
              :key="camera.id"
              :class="{ 
                fullscreen: isFullscreen && activeCameraId === camera.id,
                highlight: camera.hasAlert,
                active: activeCameraId === camera.id,
                'big-screen-item': isBigScreenMode
              }"
              @click="setActiveCamera(camera.id)"
            >
              <div class="screen-item-content">
                <!-- 摄像头标题栏 -->
                <div class="camera-header">
                  <div class="camera-info">
                    <span class="camera-color-dot" :style="{ backgroundColor: getCameraColor(camera.id) }"></span>
                    <span class="camera-name">摄像头{{ camera.id }}</span>
                    <span class="camera-area">{{ camera.area }}</span>
                    <span class="people-count-badge" v-if="camera.peopleCount > 0">
                      {{ camera.peopleCount }}人
                    </span>
                  </div>
                  <div class="camera-status-bar">
                    <span 
                      class="connection-badge" 
                      :class="camera.connectionState"
                    >
                      <span class="status-dot"></span>
                      {{ camera.connectionState === 'connected' ? '在线' : camera.connectionState === 'connecting' ? '连接中' : '离线' }}
                    </span>
                    <span 
                      class="mode-switch-btn"
                      @click="toggleVideoMode(camera.id)"
                      :title="camera.useWebRTC ? '当前: WebRTC模式，点击切换到MJPEG' : '当前: MJPEG模式，点击切换到WebRTC'"
                    >
                      {{ camera.useWebRTC ? 'WebRTC' : 'MJPEG' }}
                    </span>
                  </div>
                </div>
                
                <!-- 视频容器 -->
                <div class="video-container">
                  <!-- WebRTC 实时视频流 -->
                  <WebRTCPlayer
                    v-if="camera.useWebRTC"
                    :cameraId="camera.id"
                    :autoConnect="true"
                    :showStats="false"
                    @connected="handleWebRTCConnected(camera.id)"
                    @error="handleWebRTCError(camera.id, $event)"
                    @stats="handleWebRTCStats(camera.id, $event)"
                  />
                  
                  <!-- MJPEG 备用视频流 -->
                  <MJPEGPlayer
                    v-else
                    :cameraId="camera.id"
                    :showStats="false"
                    @connected="handleMJPEGConnected(camera.id)"
                    @error="handleMJPEGError(camera.id, $event)"
                  />
                  
                  <!-- 视频状态覆盖层 -->
                  <div class="video-overlay" v-if="camera.connectionState !== 'connected'">
                    <div class="overlay-content">
                      <div class="loading-spinner"></div>
                      <span class="overlay-text">{{ camera.connectionState === 'connecting' ? '正在连接...' : '连接断开' }}</span>
                      <span v-if="!camera.useWebRTC" class="switch-webrtc-btn" @click="switchToWebRTC(camera.id)">
                        切换到WebRTC
                      </span>
                    </div>
                  </div>
                  
                  <!-- 告警指示 -->
                  <div class="alert-indicator" v-if="camera.hasAlert">
                    <span class="alert-pulse"></span>
                    <span class="alert-text">告警</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- 视频状态面板（摄像头下方） -->
        <div v-show="!isBigScreenMode" class="video-stats-panel">
          <div class="stats-panel-header">
            <span class="panel-title">视频状态</span>
            <span class="stats-count">{{ cameras.length }}个摄像头</span>
          </div>
          <div class="video-stats-grid">
            <div 
              class="video-stat-card" 
              v-for="camera in cameras" 
              :key="camera.id"
              :class="{ active: activeCameraId === camera.id, alert: camera.hasAlert }"
              @click="setActiveCamera(camera.id)"
            >
              <div class="stat-card-header">
                <span class="stat-camera-name">摄像头{{ camera.id }}</span>
                <div class="stat-header-right">
                  <span 
                    class="stat-status-dot" 
                    :class="camera.connectionState"
                  ></span>
                  <span v-if="camera.hasAlert" class="alert-indicator-mini"></span>
                  <button 
                    class="camera-toggle-btn" 
                    :class="{ active: camera.connectionState === 'connected' }"
                    @click.stop="toggleCamera(camera.id)"
                    :title="camera.connectionState === 'connected' ? '关闭摄像头' : '开启摄像头'"
                  >
                    <svg v-if="camera.connectionState === 'connected'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                      <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
                      <line x1="9" y1="9" x2="15" y2="15"></line>
                      <line x1="15" y1="9" x2="9" y2="15"></line>
                    </svg>
                    <svg v-else viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                      <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
                      <circle cx="8.5" cy="8.5" r="1.5"></circle>
                      <polyline points="21 15 16 10 5 21"></polyline>
                    </svg>
                  </button>
                </div>
              </div>
              <div class="stat-card-body">
                <div class="stat-item-row">
                  <span class="stat-label">区域</span>
                  <span class="stat-value">{{ camera.area }}</span>
                </div>
                <div class="stat-item-row">
                  <span class="stat-label">状态</span>
                  <span class="stat-value status-text" :class="camera.connectionState">
                    {{ camera.connectionState === 'connected' ? '在线' : camera.connectionState === 'connecting' ? '连接中' : '离线' }}
                  </span>
                </div>
                <div class="stat-item-row">
                  <span class="stat-label">模式</span>
                  <span class="stat-value">{{ camera.useWebRTC ? 'WebRTC' : 'MJPEG' }}</span>
                </div>
                <div class="stat-item-row">
                  <span class="stat-label">帧率</span>
                  <span class="stat-value">{{ camera.fps || '--' }}<span class="stat-unit">fps</span></span>
                </div>
                <div class="stat-item-row">
                  <span class="stat-label">人数</span>
                  <span class="stat-value people">{{ camera.peopleCount || 0 }}</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- 功能按钮区域 -->
        <div class="function-buttons">
          <el-button 
            class="btn-bottom" 
            @click="handleDashboard"
          >
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18">
              <rect x="3" y="3" width="7" height="7"></rect>
              <rect x="14" y="3" width="7" height="7"></rect>
              <rect x="14" y="14" width="7" height="7"></rect>
              <rect x="3" y="14" width="7" height="7"></rect>
            </svg>
            数据大屏
          </el-button>

          <el-button 
            class="btn-bottom" 
            @click="toggleBigScreenMode" 
            :class="{ active: isBigScreenMode }"
          >
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18">
              <rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect>
              <line x1="8" y1="21" x2="16" y2="21"></line>
              <line x1="12" y1="17" x2="12" y2="21"></line>
            </svg>
            {{ isBigScreenMode ? '退出监控大屏' : '进入监控大屏' }}
          </el-button>
          <el-button 
            class="btn-bottom btn-green" 
            v-if="llmStatus === 'connected'"
            @click="openChatDialog"
          >
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18">
              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
              <polyline points="17 8 12 3 7 8"></polyline>
              <line x1="12" y1="3" x2="12" y2="15"></line>
            </svg>
            智能助手
          </el-button>
          <el-button class="btn-bottom btn-blue" @click="handleStartModel">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="18" height="18">
              <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"></path>
            </svg>
            启动模型
          </el-button>
          </div>

      </el-main>
    </el-container>
  </div>

  <!-- 上传视频对话框 -->
  <ElDialog
    title="上传视频检测"
    v-model="showUploadDialog"
    width="500px"
    :close-on-click-modal="false"
    @close="cancelUpload"
  >
    <div class="upload-content">
      <div class="upload-area">
        <ElUpload
          ref="uploadRef"
          class="upload-demo"
          :action="''"
          :auto-upload="false"
          :on-change="handleFileSelect"
          :show-file-list="false"
          accept=".mp4,.avi,.mov,.jpg,.jpeg,.png"
          multiple="false"
        >
          <div class="upload-box" :class="{ 'has-file': selectedFile }">
            <svg v-if="!selectedFile" class="upload-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
              <polyline points="17 8 12 3 7 8"></polyline>
              <line x1="12" y1="3" x2="12" y2="15"></line>
            </svg>
            <div v-if="!selectedFile" class="upload-text">
              <span class="upload-title">点击或拖拽上传文件</span>
              <span class="upload-hint">支持 MP4/AVI/MOV 视频或 JPG/JPEG/PNG 图片</span>
              <span class="upload-hint">视频最大500MB，图片最大50MB</span>
            </div>
            <div v-else class="file-info">
              <span class="file-name">{{ selectedFile.name }}</span>
              <span class="file-size">{{ (selectedFile.size / 1024 / 1024).toFixed(2) }} MB</span>
            </div>
          </div>
        </ElUpload>
      </div>

      <div v-if="isUploading" class="upload-progress">
        <ElProgress :percentage="uploadProgress" status="active" />
        <span class="progress-text">{{ uploadStatus || '上传中...' }}</span>
      </div>
    </div>

    <template #footer>
      <span class="dialog-footer">
        <el-button @click="cancelUpload">取消</el-button>
        <el-button 
          type="primary" 
          :loading="isUploading"
          :disabled="!selectedFile || isUploading"
          @click="startUpload"
        >
          {{ isUploading ? '上传中' : '开始检测' }}
        </el-button>
      </span>
    </template>
  </ElDialog>

  <!-- 清理视频文件对话框 -->
  <ElDialog
    title="清理视频文件"
    v-model="showCleanupDialog"
    width="600px"
    :close-on-click-modal="false"
  >
    <div class="cleanup-content">
      <div class="stats-row">
        <span class="stats-label">视频总数</span>
        <span class="stats-value">{{ videoStats.total_count }} 个</span>
      </div>
      <div class="stats-row">
        <span class="stats-label">总大小</span>
        <span class="stats-value">{{ (videoStats.total_size / 1024 / 1024).toFixed(2) }} MB</span>
      </div>

      <div class="cleanup-config">
        <label class="config-label">清理天数</label>
        <el-select v-model="cleanupDays" class="config-select">
          <el-option label="3天前" :value="3" />
          <el-option label="7天前" :value="7" />
          <el-option label="14天前" :value="14" />
          <el-option label="30天前" :value="30" />
        </el-select>
        <span class="config-hint">删除指定天数之前的视频文件</span>
      </div>

      <div class="video-list-container" v-if="videoFolders.length > 0">
        <div class="list-header">视频文件夹列表</div>
        <div class="video-list">
          <div v-for="folder in videoFolders" :key="folder.name" class="video-item">
            <div class="video-info">
              <span class="video-name">{{ folder.name }}</span>
              <span class="video-date">类型: {{ folder.type === 'video' ? '普通视频' : '告警视频' }}</span>
              <span class="video-date">文件数: {{ folder.file_count }} 个</span>
              <span class="video-date">大小: {{ (folder.size / 1024 / 1024).toFixed(2) }} MB</span>
            </div>
            <el-button 
              type="danger" 
              size="small" 
              :loading="isCleaningUp"
              @click="deleteVideoFolder(folder.name)"
            >
              删除
            </el-button>
          </div>
        </div>
      </div>
      <div v-else class="empty-videos">暂无视频文件夹</div>
    </div>

    <template #footer>
      <span class="dialog-footer">
        <el-button @click="showCleanupDialog = false">取消</el-button>
        <el-button 
          type="warning" 
          :loading="isCleaningUp"
          @click="deleteAllVideos"
        >
          删除全部
        </el-button>
        <el-button 
          type="primary" 
          :loading="isCleaningUp"
          :disabled="videoStats.total_count === 0"
          @click="cleanupOldVideos"
        >
          清理旧视频
        </el-button>
      </span>
    </template>
  </ElDialog>

  <!-- 检测结果对话框 -->
  <ElDialog
    title="视频检测结果"
    v-model="showResultDialog"
    width="1000px"
    :close-on-click-modal="false"
    @close="closeResultDialog"
  >
    <div class="result-content">
      <!-- 实时视频预览区域 -->
      <div class="preview-section">
        <div class="preview-header">
          <span class="preview-title">实时检测</span>
          <div class="preview-status">
            <el-tag :type="detectionResult?.status === 'completed' ? 'success' : detectionResult?.status === 'processing' ? 'warning' : 'info'">
              {{ getStatusText(detectionResult?.status) }}
            </el-tag>
          </div>
        </div>
        <div class="preview-container">
          <div v-if="liveFrameData.frame" class="live-frame">
            <img :src="liveFrameData.frame" alt="实时检测画面" class="frame-image" />
            <!-- 检测框覆盖层 -->
            <div class="detection-overlay">
              <div v-for="(person, idx) in liveFrameData.detected_persons || []" 
                   :key="idx"
                   class="person-box"
                   :style="getPersonBoxStyle(person)"
              >
                <span class="person-label">{{ person.class_name || '人员' }} {{ (person.confidence * 100).toFixed(0) }}%</span>
              </div>
            </div>
          </div>
          <div v-else class="frame-placeholder">
            <svg class="placeholder-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
              <circle cx="8.5" cy="8.5" r="1.5"></circle>
              <polyline points="21 15 16 10 5 21"></polyline>
            </svg>
            <span class="placeholder-text">等待画面加载...</span>
          </div>
        </div>
        <!-- 进度条 -->
        <div class="progress-section" v-if="detectionResult">
          <div class="progress-info">
            <span class="progress-label">处理进度</span>
            <span class="progress-value">{{ Math.round(detectionResult.progress || 0) }}%</span>
          </div>
          <el-progress :percentage="detectionResult.progress || 0" :status="detectionResult.status === 'completed' ? 'success' : ''" />
        </div>
      </div>

      <!-- 检测结果区域 -->
      <div class="result-section">
        <div class="section-header">
          <span class="section-title">检测结果</span>
        </div>
        <div v-if="detectionResult" class="result-info">
          <el-descriptions :column="1" border size="small">
            <el-descriptions-item label="文件名">
              {{ detectionResult.filename || '-' }}
            </el-descriptions-item>
            <el-descriptions-item label="文件类型">
              <el-tag :type="detectionResult.file_type === 'image' ? 'success' : 'info'">
                {{ detectionResult.file_type === 'image' ? '图片' : '视频' }}
              </el-tag>
            </el-descriptions-item>
            <el-descriptions-item label="检测人数">
              {{ detectionResult.people_count || 0 }} 人
            </el-descriptions-item>
            <el-descriptions-item label="溺水风险">
              <el-tag :type="detectionResult.drowning_risk === 'high' ? 'danger' : detectionResult.drowning_risk === 'medium' ? 'warning' : 'success'">
                {{ detectionResult.drowning_risk === 'high' ? '高风险' : detectionResult.drowning_risk === 'medium' ? '中风险' : '正常' }}
              </el-tag>
            </el-descriptions-item>
            <el-descriptions-item label="告警数量">
              <span :class="(detectionResult.drowning_events?.length || 0) > 0 ? 'alert-count' : ''">
                {{ detectionResult.drowning_events?.length || 0 }} 条
              </span>
            </el-descriptions-item>
          </el-descriptions>
        </div>

        <!-- 告警列表 -->
        <div v-if="detectionResult?.drowning_events?.length > 0" class="alert-list-section">
          <div class="list-title">告警事件</div>
          <div class="alert-items">
            <div v-for="(event, idx) in detectionResult.drowning_events" :key="idx" class="alert-item">
              <div class="alert-time">帧 {{ event.frame }} - {{ formatTime(event.timestamp) }}</div>
              <div class="alert-detail">
                <span class="alert-type">{{ event.type || '溺水检测' }}</span>
                <span class="alert-conf">置信度 {{ (event.confidence * 100).toFixed(1) }}%</span>
              </div>
            </div>
          </div>
        </div>

        <!-- 保存的截图 -->
        <div v-if="detectionResult?.saved_images?.length > 0" class="images-section">
          <div class="list-title">检测截图 ({{ detectionResult.saved_images.length }})</div>
          <div class="images-grid">
            <div v-for="(img, idx) in detectionResult.saved_images" :key="idx" class="image-item">
              <img :src="getSavedImageUrl(detectionResult.task_id, img.filename)" class="screenshot" />
              <div class="image-info">
                <span class="image-frame">帧 {{ img.frame }}</span>
                <span class="image-time">{{ formatTime(img.timestamp) }}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <template #footer>
      <span class="dialog-footer">
        <el-button @click="closeResultDialog">关闭</el-button>
        <el-button type="primary" @click="goToHistory">查看历史</el-button>
      </span>
    </template>
  </ElDialog>

  <!-- LLM大模型状态对话框 -->
  <el-dialog
    v-model="showLLMDdialog"
    title="语言大模型状态"
    width="600px"
    :close-on-click-modal="false"
  >
    <div class="llm-status-container">
      <!-- 连接状态 -->
      <el-card shadow="hover" style="margin-bottom: 20px;">
        <template #header>
          <div class="card-header">
            <span>连接状态</span>
            <el-tag :type="llmStatus === 'connected' ? 'success' : llmStatus === 'testing' ? 'warning' : 'info'">
              {{ llmStatusText }}
            </el-tag>
          </div>
        </template>
        
        <el-descriptions :column="1" border>
          <el-descriptions-item label="提供商">{{ llmConfig.provider || '未配置' }}</el-descriptions-item>
          <el-descriptions-item label="模型">{{ llmConfig.model || '未配置' }}</el-descriptions-item>
          <el-descriptions-item label="API密钥">
            <el-tag :type="llmConfig.api_key_configured ? 'success' : 'danger'">
              {{ llmConfig.api_key_configured ? '已配置' : '未配置' }}
            </el-tag>
          </el-descriptions-item>
          <el-descriptions-item label="降级策略">
            <el-tag :type="llmConfig.fallback_enabled ? 'success' : 'warning'">
              {{ llmConfig.fallback_enabled ? '已启用' : '未启用' }}
            </el-tag>
          </el-descriptions-item>
        </el-descriptions>
      </el-card>

      <!-- 测试结果 -->
      <el-card v-if="llmTestResult" shadow="hover">
        <template #header>
          <div class="card-header">
            <span>测试结果</span>
          </div>
        </template>
        
        <el-alert
          :title="llmTestResult.success ? '连接成功' : '连接失败'"
          :type="llmTestResult.success ? 'success' : 'error'"
          :description="llmTestResult.message"
          show-icon
          :closable="false"
          style="margin-bottom: 15px;"
        />
        
        <div v-if="llmTestResult.response" class="test-response">
          <p><strong>AI回复：</strong></p>
          <p class="response-text">{{ llmTestResult.response }}</p>
        </div>
      </el-card>

      <!-- 使用说明 -->
      <el-card shadow="hover" style="margin-top: 20px;">
        <template #header>
          <div class="card-header">
            <span>使用说明</span>
          </div>
        </template>
        <ul class="usage-tips">
          <li>系统会自动使用LLM分析溺水事件，生成智能报告</li>
          <li>API调用失败时，系统会自动切换到降级模板</li>
          <li>需要配置API密钥才能使用完整功能</li>
          <li>支持通义千问、文心一言等多种模型</li>
          <li>管理员可在后端配置文件中设置API密钥</li>
        </ul>
      </el-card>
    </div>

    <template #footer>
      <span class="dialog-footer">
        <el-button @click="showLLMDdialog = false">关闭</el-button>
        <el-button 
          type="success"
          :disabled="llmStatus !== 'connected'"
          @click="openChatDialog"
        >
          进入聊天
        </el-button>
        <el-button 
          type="primary" 
          @click="testLLMConnection"
          :loading="llmStatus === 'testing'"
        >
          {{ llmStatus === 'testing' ? '测试中...' : '重新测试' }}
        </el-button>
      </span>
    </template>
  </el-dialog>

  <!-- LLM智能问答对话框 -->
  <el-dialog
    title="智能助手"
    v-model="showLLMChatDialog"
    width="700px"
    :close-on-click-modal="false"
  >
    <div class="llm-chat-container">
      <div ref="chatMessagesRef" class="chat-messages">
        <div 
          v-for="(msg, index) in chatMessages" 
          :key="index"
          class="chat-message"
          :class="msg.role"
        >
          <div class="message-avatar">
            <svg v-if="msg.role === 'user'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
              <circle cx="12" cy="7" r="4"></circle>
            </svg>
            <svg v-else viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
              <polyline points="17 8 12 3 7 8"></polyline>
              <line x1="12" y1="3" x2="12" y2="15"></line>
            </svg>
          </div>
          <div class="message-content">
            <div class="message-role">{{ msg.role === 'user' ? '我' : '智能助手' }}</div>
            <div class="message-bubble">
              <div class="message-text">{{ msg.content }}</div>
            </div>
            <div class="message-footer">
              <span class="message-time">{{ msg.time }}</span>
              <button 
                class="copy-btn" 
                @click="copyMessage(msg.content)" 
                title="复制消息"
              >
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14">
                  <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
                  <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
                </svg>
              </button>
            </div>
          </div>
        </div>
        <div v-if="isChatLoading" class="chat-loading">
          <div class="loading-dots">
            <span></span><span></span><span></span>
          </div>
          <span class="loading-text">智能助手正在思考...</span>
        </div>
      </div>

      <div class="chat-quick-questions" v-if="quickQuestions.length > 0">
        <div class="quick-header">
          <span class="quick-label">快捷问题：</span>
          <div class="category-tabs">
            <span 
              v-for="cat in quickCategories" 
              :key="cat"
              class="category-tab"
              :class="{ active: selectedCategory === cat }"
              @click="selectedCategory = cat"
            >
              {{ cat }}
            </span>
          </div>
        </div>
        <div class="quick-tags">
          <el-tag 
            v-for="(q, index) in filteredQuickQuestions" 
            :key="index"
            size="small"
            type="info"
            class="quick-tag"
            @click="useQuickQuestion(q.question)"
          >
            {{ q.question }}
          </el-tag>
        </div>
      </div>

      <div class="chat-input-area">
        <div class="chat-input-wrapper">
          <el-input
            v-model="chatInput"
            type="textarea"
            :rows="2"
            placeholder="输入您的问题..."
            :disabled="isChatLoading"
            @keyup.enter.exact="handleEnterKey"
            class="chat-input"
          />
          <span class="input-hint">Enter 发送 · Shift+Enter 换行</span>
        </div>
        <div class="chat-actions">
          <el-button @click="clearChatHistory" size="small">清空记录</el-button>
          <el-button 
            class="chat-send-btn"
            @click="sendChatMessage"
            :loading="isChatLoading"
            :disabled="!chatInput.trim()"
          >
            发送
          </el-button>
        </div>
      </div>
    </div>

    <template #footer>
      <span class="dialog-footer">
        <el-button @click="showLLMChatDialog = false">关闭</el-button>
      </span>
    </template>
  </el-dialog>
</template>

<script setup>
import { ref, reactive, computed, onMounted, onUnmounted } from 'vue'
import { ElMessage, ElMessageBox, ElUpload, ElDialog, ElProgress, ElTag, ElDescriptions, ElDescriptionsItem } from 'element-plus'
import { useRouter } from 'vue-router'
import WebRTCPlayer from '../components/video/WebRTCPlayer.vue'
import { useVideoDetection } from '../composables/useVideoDetection.js'
import { useLLM } from '../composables/useLLM.js'
import { getMonitorWsUrl } from '../config/websocket.js'
import MJPEGPlayer from '../components/video/MJPEGPlayer.vue'
import { alertStore } from '../stores/alertStore.js'

const router = useRouter()

const username = ref(localStorage.getItem('username') || '用户')
const userType = ref(localStorage.getItem('userType') || 'user')

const cameraViewMode = ref('local')

// 初始化视频检测和LLM功能
const {
  showUploadDialog,
  showResultDialog,
  showCleanupDialog,
  videoList,
  videoStats,
  videoFolders,
  cleanupDays,
  isCleaningUp,
  uploadProgress,
  isUploading,
  uploadStatus,
  selectedFile,
  uploadRef,
  currentTaskId,
  detectionResult,
  liveFrameData,
  handleFileSelect,
  startUpload,
  cancelUpload,
  loadVideoList,
  loadVideoFolders,
  cleanupOldVideos,
  deleteAllVideos,
  deleteVideoFolder,
  closeResultDialog
} = useVideoDetection()

// 以下useVideoDetection导出项在此组件中未使用（已省略导入）
// showResultDialog, showTasksDialog, currentTaskId, detectionResult, taskList, liveFrameData
// pollDetectionResult, startLiveFramePolling, fetchLiveFrame, stopLiveFramePolling
// showHistoryDialog, loadTaskList, viewTaskResult, deleteTask, closeResultDialog
// showCleanupHandler, handleVideoError, handleImageLoad, handleImageError, handleFrameError, reloadVideo

const {
  showLLMDdialog,
  llmStatus,
  llmConfig,
  llmTestResult,
  llmStatusText,
  testLLMConnection,
  loadLLMConfig,
  showLLMChatDialog,
  chatMessages,
  chatInput,
  isChatLoading,
  chatMessagesRef,
  sendChatMessage,
  clearChatHistory,
  openChatDialog,
  quickQuestions,
  useQuickQuestion
} = useLLM()

const selectedCategory = ref('全部')

const quickCategories = computed(() => {
  return ['全部', ...new Set(quickQuestions.map(q => q.category))]
})

const filteredQuickQuestions = computed(() => {
  if (!selectedCategory.value || selectedCategory.value === '全部') {
    return quickQuestions
  }
  return quickQuestions.filter(q => q.category === selectedCategory.value)
})

const handleEnterKey = (e) => {
  if (!e.shiftKey) {
    e.preventDefault()
    sendChatMessage()
  }
}

const copyMessage = async (content) => {
  try {
    await navigator.clipboard.writeText(content)
    ElMessage.success('复制成功')
  } catch (err) {
    ElMessage.error('复制失败')
  }
}

let peopleCountInterval = null
let monitorWs = null
let isFetchingPeopleCount = false

const cameraColors = {
  1: '#4ecdc4',
  2: '#ff6b6b',
  3: '#ffe66d',
  4: '#a855f7',
  5: '#3b82f6',
  6: '#10b981',
  7: '#f59e0b',
  8: '#ec4899',
  9: '#06b6d4',
  10: '#84cc16',
  11: '#f97316',
  12: '#6366f1',
  13: '#14b8a6',
  14: '#f43f5e',
  15: '#eab308',
  16: '#8b5cf6'
}

const getCameraColor = (cameraId) => {
  return cameraColors[cameraId] || '#4ecdc4'
}

const handleKeydown = (e) => {
  if (e.key === 'Escape' && isBigScreenMode.value) {
    isBigScreenMode.value = false
    ElMessage.info('已退出监控大屏模式')
  }
}

// 组件挂载时获取人数统计数据
onMounted(() => {
  loadVideoList()
  initUnifiedMonitor()
  fetchAlerts()
  loadLLMConfig()
  window.addEventListener('keydown', handleKeydown)
})

// 组件卸载时清理定时器和WebSocket
onUnmounted(() => {
  if (monitorWs) {
    monitorWs.onclose = null
    monitorWs.close()
    monitorWs = null
  }
  if (peopleCountInterval) {
    clearInterval(peopleCountInterval)
    peopleCountInterval = null
  }
  window.removeEventListener('keydown', handleKeydown)
})

// 初始化统一实时监控 WebSocket
const initUnifiedMonitor = () => {
  try {
    const wsUrl = getMonitorWsUrl()
    console.log('[Monitor] 连接统一监控通道:', wsUrl)
    
    if (monitorWs) {
      try {
        monitorWs.onclose = null
        monitorWs.close()
      } catch (e) {}
    }
    
    monitorWs = new WebSocket(wsUrl)
    
    monitorWs.onopen = () => {
      console.log('[Monitor] 统一监控通道已连接')
      if (peopleCountInterval) {
        clearInterval(peopleCountInterval)
        peopleCountInterval = null
      }
      
      cameras.forEach(camera => {
        camera.isConfigured = true
      })
    }
    
    monitorWs.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data)
        handleMonitorUpdate(data)
      } catch (e) {
        console.error('[Monitor] 解析监控数据失败:', e)
      }
    }
    
    monitorWs.onerror = (error) => {
      console.error('[Monitor] 监控通道错误:', error)
      // 回退到HTTP轮询
      if (!peopleCountInterval) {
        fetchPeopleCount()
        peopleCountInterval = setInterval(fetchPeopleCount, 30000)
      }
    }
    
    monitorWs.onclose = () => {
      console.log('[Monitor] 监控通道已关闭')
      // 回退到HTTP轮询
      if (!peopleCountInterval) {
        fetchPeopleCount()
        peopleCountInterval = setInterval(fetchPeopleCount, 30000)
      }
    }
  } catch (e) {
    console.error('[Monitor] 初始化监控通道失败:', e)
    // 回退到HTTP轮询
    if (!peopleCountInterval) {
      fetchPeopleCount()
      peopleCountInterval = setInterval(fetchPeopleCount, 30000)
    }
  }
}

// 处理监控更新数据 - 优化：减少数据平滑，提高实时性，只更新已连接摄像头的数据
const handleMonitorUpdate = (data) => {
  if (data.type === 'monitor_update' && data.people_count) {
    try {
      const pc = data.people_count
      
      const safeParseInt = (value) => {
        if (value === null || value === undefined) return 0
        if (typeof value === 'number' && !isNaN(value) && isFinite(value)) {
          return Math.max(0, Math.floor(value))
        }
        const parsed = parseInt(value, 10)
        return (isNaN(parsed) || parsed < 0) ? 0 : parsed
      }
      
      const rawCount = safeParseInt(pc.people_count)
      
      if (!handleMonitorUpdate.lastUpdate || Date.now() - handleMonitorUpdate.lastUpdate >= 500) {
        handleMonitorUpdate.lastUpdate = Date.now()
        
        totalPeopleCount.value = rawCount
        
        if (pc.cameras && typeof pc.cameras === 'object') {
          cameras.forEach(camera => {
            const camData = pc.cameras[camera.id.toString()]
            if (camData) {
              camera.peopleCount = safeParseInt(camData.people_count)
              camera.inWaterCount = safeParseInt(camData.in_water_count)
              camera.outWaterCount = safeParseInt(camData.out_water_count)
            } else {
              camera.peopleCount = 0
              camera.inWaterCount = 0
              camera.outWaterCount = 0
            }
          })
        } else {
          cameras.forEach(camera => {
            camera.peopleCount = 0
            camera.inWaterCount = 0
            camera.outWaterCount = 0
          })
        }
        
        let totalCount = 0
        cameras.forEach(camera => {
          totalCount += camera.peopleCount || 0
        })
        totalPeopleCount.value = totalCount
        
        cameras.forEach(camera => {
          if (!camera.isConfigured) return
          const cameraId = camera.id
          const camData = pc.cameras && pc.cameras[cameraId.toString()]
          if (camData) {
            const count = safeParseInt(camData.people_count)
            const inWater = safeParseInt(camData.in_water_count)
            const outWater = safeParseInt(camData.out_water_count)
          }
        })
      }
    } catch (e) {
      console.error('[Monitor] 解析人数统计失败:', e)
    }
  } else if (data.type === 'alert') {
    handleAlertPush(data.data)
  } else if (data.type === 'alert_update') {
    handleAlertUpdate(data.data)
  } else if (data.type === 'alert_delete') {
    handleAlertDelete(data.data.id)
  } else if (data.type === 'alert_clear') {
    handleAlertClear()
  } else if (data.type === 'frame_update') {
    console.log('[Monitor] 收到帧数据更新:', Object.keys(data.frames || {}).length, '个摄像头')
  }
}

// 处理实时告警推送
const handleAlertPush = (alert) => {
  try {
    console.log('[Monitor] 收到实时告警:', alert)
    
    // 格式化告警时间
    const alertTime = alert.time || new Date().toISOString()
    const formattedTime = new Date(alertTime).toLocaleString('zh-CN', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    })
    
    // 创建告警对象
    const newAlert = {
      id: alert.id || Date.now(),
      time: formattedTime,
      cameraId: alert.cameraId || 1,
      area: alert.area || '主游泳池',
      level: alert.level || 'high',
      reason: alert.reason || '检测到溺水行为',
      acknowledged: alert.acknowledged || false,
      resolved: alert.resolved || false
    }
    
    // 检查是否已存在相同的告警（避免重复）
    const exists = alertStore.getAlert(String(newAlert.id))
    if (!exists) {
      // 通过 alertStore 添加告警（alertList 会自动同步）
      alertStore.addAlert(newAlert)
      
      // 更新摄像头告警状态
      const camera = cameras.find(c => c.id === newAlert.cameraId)
      if (camera) {
        camera.hasAlert = true
      }
      
      // 播放告警声音
      alertStore.playNotificationSound(newAlert.level)
      
      // 显示桌面通知
      alertStore.showDesktopNotification(newAlert)
      
      console.log('[Monitor] 告警已添加到列表')
    }
  } catch (e) {
    console.error('[Monitor] 处理告警推送失败:', e)
  }
}

// 处理告警状态更新
const handleAlertUpdate = (alert) => {
  try {
    console.log('[Monitor] 收到告警状态更新:', alert)
    
    // 通过 alertStore 更新告警状态（alertList 会自动同步）
    alertStore.updateAlertStatus(String(alert.id), {
      acknowledged: alert.acknowledged,
      resolved: alert.resolved,
      acknowledged_time: alert.acknowledged_time
    })
    
    // 如果告警已处理，更新摄像头告警状态
    if (alert.acknowledged) {
      const camera = cameras.find(c => c.id === alert.cameraId)
      if (camera) {
        const alerts = alertStore.getAlerts()
        const hasPendingAlerts = alerts.some(a => !a.acknowledged && a.cameraId === camera.id)
        camera.hasAlert = hasPendingAlerts
      }
    }
    
    console.log('[Monitor] 告警状态已更新')
  } catch (e) {
    console.error('[Monitor] 处理告警状态更新失败:', e)
  }
}

// 处理告警删除
const handleAlertDelete = (alertId) => {
  try {
    console.log('[Monitor] 收到告警删除通知:', alertId)
    
    // 通过 alertStore 删除告警（alertList 会自动同步）
    alertStore.deleteAlert(String(alertId))
    console.log('[Monitor] 告警已删除')
  } catch (e) {
    console.error('[Monitor] 处理告警删除失败:', e)
  }
}

// 处理清空所有告警
const handleAlertClear = () => {
  try {
    console.log('[Monitor] 收到清空告警通知')
    
    // 通过 alertStore 清空告警（alertList 会自动同步）
    alertStore.clearAll()
    
    // 重置所有摄像头告警状态
    cameras.forEach(camera => {
      camera.hasAlert = false
    })
    
    console.log('[Monitor] 所有告警已清空')
  } catch (e) {
    console.error('[Monitor] 处理清空告警失败:', e)
  }
}

// 从API获取历史告警
const fetchAlerts = async () => {
  try {
    console.log('[Monitor] 正在获取历史告警...')
    
    const response = await fetch('/api/alerts/list')
    const result = await response.json()
    
    if (result.code === 200 && result.data) {
      const alerts = result.data
      
      // 通过 alertStore 设置告警列表（alertList 会自动同步）
      alertStore.setAlerts(alerts)
      
      // 更新摄像头告警状态
      const storedAlerts = alertStore.getAlerts()
      const unhandledAlerts = storedAlerts.filter(a => !a.acknowledged)
      unhandledAlerts.forEach(alert => {
        const camera = cameras.find(c => c.id === alert.cameraId)
        if (camera) {
          camera.hasAlert = true
        }
      })
      
      console.log(`[Monitor] 成功获取 ${alerts.length} 条历史告警`)
    }
  } catch (e) {
    console.error('[Monitor] 获取历史告警失败:', e)
  }
}

// API_BASE 已移除 - 此组件中未使用
const splitScreen = ref('1')
const isFullscreen = ref(false)
const isBigScreenMode = ref(false)
const activeCameraId = ref(1)
const activeAlert = ref(-1)
const activeTab = ref('all')
const totalPeopleCount = ref(0)  // 将从API获取真实数据
const areaDistribution = reactive([
  { name: "主游泳池", count: 0 },
  { name: "儿童池", count: 0 },
  { name: "训练池", count: 0 }
])

const areas = ["主游泳池", "儿童池", "训练池", "休闲池", "深水区", "浅水区", "室外池", "室内池", "VIP区", "教学区", "比赛区", "热身区", "按摩池", "桑拿区", "观景台", "更衣室"]

const cameras = reactive(
  Array.from({ length: 16 }, (_, i) => ({
    id: i + 1,
    area: areas[i] || `区域${i + 1}`,
    cameraType: 'remote',
    peopleCount: 0,
    inWaterCount: 0,
    outWaterCount: 0,
    hasAlert: false,
    connectionState: 'disconnected',
    useWebRTC: true,
    people: [],
    fps: 0,
    packetsLost: 0,
    isConfigured: i === 0 ? false : true
  }))
)

const alertList = computed(() => alertStore.getAlerts())

const filteredAlerts = computed(() => {
  const alerts = Array.isArray(alertList.value) ? alertList.value : []
  if (activeTab.value === 'unhandled') {
    return alerts.filter(alert => !alert.acknowledged)
  } else if (activeTab.value === 'handled') {
    return alerts.filter(alert => alert.acknowledged)
  }
  return alerts
})

const unhandledAlertCount = computed(() => {
  const alerts = Array.isArray(alertList.value) ? alertList.value : []
  return alerts.filter(alert => !alert.acknowledged).length
})

const displayCameras = computed(() => {
        const count = parseInt(splitScreen.value)
        return cameras.slice(0, count)
    })

const showSplitMenu = ref(false)

const toggleSplitMenu = () => {
  showSplitMenu.value = !showSplitMenu.value
}

const handleSplitSelect = (n) => {
  console.log('[Monitor] 分屏切换:', n)
  splitScreen.value = String(n)
  showSplitMenu.value = false
  ElMessage.info(`已切换到 ${n} 分屏`)
}

const formatAlertTime = (timeStr) => {
  const alertTime = new Date(timeStr)
  const now = new Date()
  const diff = now - alertTime
  const minutes = Math.floor(diff / 60000)
  if (minutes < 1) return '刚刚'
  if (minutes < 60) return `${minutes}分钟前`
  return timeStr.split(' ')[1]
}

const toggleFullscreen = () => {
  const element = document.documentElement
  if (!document.fullscreenElement) {
    element.requestFullscreen().catch(err => {
      ElMessage.error("全屏切换失败：" + err.message)
    })
    isFullscreen.value = true
  } else {
    document.exitFullscreen()
    isFullscreen.value = false
  }
}

const toggleBigScreenMode = () => {
  isBigScreenMode.value = !isBigScreenMode.value
  if (isBigScreenMode.value) {
    ElMessage.success('已进入监控大屏模式，按 ESC 键退出')
  } else {
    ElMessage.info('已退出监控大屏模式')
  }
}

const handleSoundToggle = (value) => {
  if (value) {
    alertStore.unlockAudioContext()
    alertStore.playNotificationSound('high')
    ElMessage.success('声音功能已开启，告警时将播放声音')
  } else {
    ElMessage.info('声音功能已关闭')
  }
}

const refreshAll = async () => {
  try {
    ElMessage.info("正在刷新页面...")
    
    cameras.forEach(camera => {
      camera.connectionState = 'connecting'
      camera.useWebRTC = true
    })
    
    if (monitorWs) {
      monitorWs.onclose = null
      monitorWs.close()
      monitorWs = null
    }
    
    if (peopleCountInterval) {
      clearInterval(peopleCountInterval)
      peopleCountInterval = null
    }
    
    initUnifiedMonitor()
    
    await fetchPeopleCount()
    
    loadVideoList()
    
    ElMessage.success("页面刷新成功")
  } catch (error) {
    console.error('[Monitor] 刷新页面失败:', error)
    ElMessage.error("刷新页面失败，请重试")
  }
}

// 获取真实的人数统计数据（支持多摄像头）
const fetchPeopleCount = async () => {
  if (isFetchingPeopleCount) {
    return
  }
  isFetchingPeopleCount = true
  
  try {
    const response = await fetch('/api/video/people-count')
    if (response.ok) {
      const data = await response.json()
      if (data.code === 200 || data.success === true) {
        const stats = data.data || data
        const count = stats.total_people || stats.people_count || 0
        totalPeopleCount.value = count
        
        if (stats.cameras && typeof stats.cameras === 'object') {
          cameras.forEach(camera => {
            const camData = stats.cameras[camera.id.toString()]
            camera.peopleCount = camData ? (camData.people_count || camData.total_people || 0) : 0
          })
        } else {
          cameras.forEach(camera => {
            camera.peopleCount = 0
          })
        }
        
        areaDistribution.forEach(area => {
          area.count = area.name === "主游泳池" ? count : 0
        })
        
        console.log('[Monitor] 人数统计数据已更新:', stats)
      }
    }
  } catch (error) {
    const errorMsg = error.message || ''
    if (!errorMsg.includes('ERR_ABORTED') && !errorMsg.includes('NetworkError') && !errorMsg.includes('Failed to fetch')) {
      console.warn('[Monitor] 获取人数统计数据失败:', error)
    }
  } finally {
    isFetchingPeopleCount = false
  }
}

const changeSplitScreen = (val) => {
  console.log('[Monitor] 分屏切换:', val)
  splitScreen.value = val
  ElMessage.info(`已切换到 ${val} 分屏`)
}

const setActiveCamera = (id) => {
  activeCameraId.value = id
}

const handleWebRTCConnected = (cameraId) => {
  const camera = cameras.find(item => item.id === cameraId)
  if (camera) {
    camera.connectionState = 'connected'
  }
}

const handleWebRTCStats = (cameraId, stats) => {
  const camera = cameras.find(item => item.id === cameraId)
  if (camera && stats) {
    camera.fps = stats.video?.fps || 0
    camera.packetsLost = stats.video?.packetsLost || 0
  }
}

const lastModeSwitchTime = {}

const handleWebRTCError = (cameraId, event) => {
  const camera = cameras.find(item => item.id === cameraId)
  if (camera) {
    const now = Date.now()
    const lastSwitch = lastModeSwitchTime[cameraId] || 0
    
    if (now - lastSwitch < 3000) {
      console.log(`[Monitor] WebRTC 连接失败，距离上次切换不足3秒，跳过切换: ${cameraId}`)
      return
    }
    
    console.log(`[Monitor] WebRTC 连接失败，自动切换到 MJPEG 模式: ${cameraId}`)
    camera.connectionState = 'connecting'
    camera.useWebRTC = false
    lastModeSwitchTime[cameraId] = now
    
    if (cameraId === 1) {
      ElMessage.warning('WebRTC 连接失败，已切换到 MJPEG 视频流模式')
    }
  }
}

const handleMJPEGConnected = (cameraId) => {
  const camera = cameras.find(item => item.id === cameraId)
  if (camera) {
    camera.connectionState = 'connected'
    console.log(`[Monitor] MJPEG 视频流连接成功: ${cameraId}`)
  }
}

const switchToWebRTC = (cameraId) => {
  const camera = cameras.find(item => item.id === cameraId)
  if (camera) {
    camera.useWebRTC = true
    camera.connectionState = 'connecting'
    ElMessage.info('正在切换到 WebRTC 模式...')
    console.log(`[Monitor] 手动切换到 WebRTC 模式: ${cameraId}`)
  }
}

const toggleVideoMode = (cameraId) => {
  const camera = cameras.find(item => item.id === cameraId)
  if (camera) {
    camera.useWebRTC = !camera.useWebRTC
    camera.connectionState = 'connecting'
    const mode = camera.useWebRTC ? 'WebRTC' : 'MJPEG'
    ElMessage.info(`正在切换到 ${mode} 模式...`)
    console.log(`[Monitor] 切换视频流模式到 ${mode}: ${cameraId}`)
  }
}

const handleMJPEGError = (cameraId, event) => {
  const camera = cameras.find(item => item.id === cameraId)
  if (camera) {
    camera.connectionState = 'error'
    console.error(`[Monitor] MJPEG 视频流加载失败: ${cameraId}`)
    
    const now = Date.now()
    const lastSwitch = lastModeSwitchTime[cameraId] || 0
    
    if (now - lastSwitch >= 5000) {
      console.log(`[Monitor] MJPEG 连接失败，自动切换到 WebRTC 模式: ${cameraId}`)
      camera.connectionState = 'connecting'
      camera.useWebRTC = true
      lastModeSwitchTime[cameraId] = now
      
      if (cameraId === 1) {
        ElMessage.info('MJPEG 连接失败，已切换到 WebRTC 视频流模式')
      }
    }
  }
}

const jumpToAlert = (alert, index) => {
  activeAlert.value = index
  activeCameraId.value = alert.cameraId
  cameras.forEach(camera => {
    camera.hasAlert = camera.id === alert.cameraId
  })
}

const confirmAlert = async (index) => {
  const alerts = Array.isArray(alertList.value) ? alertList.value : []
  const alert = alerts[index]
  if (!alert) return
  ElMessageBox.confirm(
    '确认已处理该告警？',
    '提示',
    {
      confirmButtonText: '确认',
      cancelButtonText: '取消',
      type: 'warning'
    }
  ).then(async () => {
    try {
      const response = await fetch(`/api/alerts/acknowledge/${alert.id}`, {
        method: 'POST'
      })
      const result = await response.json()
      
      if (result.code === 200) {
        // 同步到全局 alertStore
        alertStore.updateAlertStatus(String(alert.id), {
          acknowledged: true,
          resolved: false,
          acknowledged_time: new Date().toISOString()
        })
        cameras.forEach(camera => {
          if (camera.id === alert.cameraId) {
            camera.hasAlert = false
          }
        })
        ElMessage.success('告警已确认处理')
      } else {
        ElMessage.error('确认告警失败')
      }
    } catch (e) {
      console.error('[Monitor] 确认告警失败:', e)
      // 同步到全局 alertStore
      alertStore.updateAlertStatus(String(alert.id), {
        acknowledged: true,
        resolved: false,
        acknowledged_time: new Date().toISOString()
      })
      cameras.forEach(camera => {
        if (camera.id === alert.cameraId) {
          camera.hasAlert = false
        }
      })
      ElMessage.success('告警已确认处理')
    }
  })
}

const deleteAlert = async (index) => {
  const alerts = Array.isArray(alertList.value) ? alertList.value : []
  const alert = alerts[index]
  if (!alert) return
  ElMessageBox.confirm(
    '确认删除该告警？',
    '提示',
    {
      confirmButtonText: '删除',
      cancelButtonText: '取消',
      type: 'error'
    }
  ).then(async () => {
    try {
      const response = await fetch(`/api/alerts/delete/${alert.id}`, {
        method: 'DELETE'
      })
      const result = await response.json()
      
      if (result.code === 200) {
        // 通过 alertStore 删除告警（alertList 会自动同步）
        alertStore.deleteAlert(String(alert.id))
        ElMessage.success('告警已删除')
      } else {
        ElMessage.error('删除告警失败')
      }
    } catch (e) {
      console.error('[Monitor] 删除告警失败:', e)
      // 即使API调用失败，也更新本地状态
      // 通过 alertStore 删除告警（alertList 会自动同步）
      alertStore.deleteAlert(String(alert.id))
      ElMessage.success('告警已删除')
    }
  })
}

const deleteAllAlerts = async () => {
  ElMessageBox.confirm(
    '确认删除所有告警？',
    '提示',
    {
      confirmButtonText: '全部删除',
      cancelButtonText: '取消',
      type: 'error'
    }
  ).then(async () => {
    try {
      const response = await fetch('/api/alerts/delete-all', {
        method: 'DELETE'
      })
      const result = await response.json()
      
      if (result.code === 200) {
        // 通过 alertStore 清空告警（alertList 会自动同步）
        alertStore.clearAll()
        cameras.forEach(camera => {
          camera.hasAlert = false
        })
        ElMessage.success('所有告警已删除')
      } else {
        ElMessage.error('删除所有告警失败')
      }
    } catch (e) {
      console.error('[Monitor] 删除所有告警失败:', e)
      // 即使API调用失败，也更新本地状态
      // 通过 alertStore 清空告警（alertList 会自动同步）
      alertStore.clearAll()
      cameras.forEach(camera => {
        camera.hasAlert = false
      })
      ElMessage.success('所有告警已删除')
    }
  })
}

const handleLogout = () => {
  ElMessageBox.confirm(
    '确定要退出登录吗？',
    '提示',
    {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    }
  ).then(() => {
    localStorage.removeItem('token')
    localStorage.removeItem('username')
    localStorage.removeItem('userType')
    router.push('/login')
    ElMessage.success('已退出登录')
  })
}

const handleUploadVideo = () => {
  console.log('[Monitor] handleUploadVideo 点击被触发，showUploadDialog 当前值:', showUploadDialog.value)
  showUploadDialog.value = true
  console.log('[Monitor] 设置后 showUploadDialog:', showUploadDialog.value)
}

const handleDetectionHistory = () => {
  router.push('/history')
}

const handleDashboard = () => {
  router.push('/dashboard')
}

const handleCleanVideo = async () => {
  await loadVideoFolders()
  await loadVideoList()
  showCleanupDialog.value = true
}

const handleStartModel = () => {
  testLLMConnection()
}

const viewAllAlerts = () => {
  router.push('/alerts')
}

const toggleCamera = async (cameraId) => {
  try {
    const camera = cameras.find(c => c.id === cameraId)
    if (!camera) return

    const isConnected = camera.connectionState === 'connected'
    const action = isConnected ? '关闭' : '开启'

    const response = await fetch(`/api/video/camera/${cameraId}/toggle`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ enabled: !isConnected })
    })

    const result = await response.json()
    
    if (result.code === 200) {
      if (isConnected) {
        camera.connectionState = 'offline'
        camera.peopleCount = 0
        camera.hasAlert = false
        ElMessage.success(`摄像头${cameraId}已关闭`)
      } else {
        camera.connectionState = 'connecting'
        ElMessage.success(`摄像头${cameraId}已启动，正在连接...`)
      }
    } else {
      ElMessage.error(result.message || `${action}摄像头失败`)
    }
  } catch (error) {
    console.error('[Monitor] 切换摄像头状态失败:', error)
    ElMessage.error('操作失败，请稍后重试')
  }
}

// 检测结果相关辅助函数
const getStatusText = (status) => {
  const statusMap = {
    'pending': '等待中',
    'processing': '处理中',
    'completed': '已完成',
    'failed': '失败'
  }
  return statusMap[status] || status || '未知'
}

const formatTime = (seconds) => {
  if (!seconds && seconds !== 0) return '0:00'
  const mins = Math.floor(seconds / 60)
  const secs = Math.floor(seconds % 60)
  return `${mins}:${secs.toString().padStart(2, '0')}`
}

const getPersonBoxStyle = (person) => {
  if (!person || !person.bbox) return {}
  const [x, y, w, h] = person.bbox
  return {
    left: `${x * 100}%`,
    top: `${y * 100}%`,
    width: `${w * 100}%`,
    height: `${h * 100}%`
  }
}

const getSavedImageUrl = (taskId, filename) => {
  return `/api/detection/results/images/${taskId}/${filename}`
}

const goToHistory = () => {
  closeResultDialog()
  router.push('/history')
}
</script>

<style scoped>
.monitor-system {
  width: 100%;
  height: 100vh;
  display: flex;
  flex-direction: column;
  background: #F0F2F5;
  font-family: 'Microsoft YaHei', 'PingFang SC', sans-serif;
}

.monitor-system * {
  font-family: inherit;
}

.monitor-system .stat-value,
.monitor-system .area-count,
.monitor-system .indicator-value,
.monitor-system .legend-count,
.monitor-system .people-count-badge {
  font-family: 'SF Mono', 'DIN', 'Consolas', monospace;
}

.header {
  display: flex;
  align-items: center;
  padding: 0 16px;
  background: #FFFFFF;
  color: #2D3436;
  height: 48px;
  border-bottom: 1px solid #DFE6E9;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
}

.header-left {
  display: flex;
  align-items: center;
  gap: 12px;
}

.logo-icon {
  width: 32px;
  height: 32px;
  background-color: #D63031;
  color: #FFFFFF;
  font-size: 18px;
  font-weight: bold;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 4px;
}

.header-left h1 {
  font-size: 16px;
  font-weight: 600;
  margin: 0;
  color: #2D3436;
}

.user-role {
  font-size: 13px;
  color: #636E72;
  padding: 4px 12px;
  background: #F0F2F5;
  border-radius: 4px;
  border: 1px solid #DFE6E9;
}

.header-center {
  display: flex;
  align-items: center;
  justify-content: center;
  flex: 1;
  flex-wrap: nowrap;
  overflow-x: auto;
  gap: 8px;
}

.header-divider {
  width: 1px;
  height: 24px;
  background: #DFE6E9;
  margin: 0 12px;
  flex-shrink: 0;
}

.header-btn-group {
  display: flex;
  align-items: center;
  gap: 6px;
}

.sound-toggle {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 4px 10px;
  background: #F8F9FA;
  border-radius: 4px;
  border: 1px solid #DFE6E9;
}

.sound-label {
  font-size: 12px;
  color: #636E72;
}

.btn-icon {
  width: 14px;
  height: 14px;
  margin-right: 4px;
}

.user-icon {
  width: 16px;
  height: 16px;
  margin-right: 4px;
}

.header-btn {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 3px;
  padding: 5px 12px;
  border-radius: 4px;
  font-size: 12px;
  font-weight: 500;
  border: 1px solid #DFE6E9;
  cursor: pointer;
  transition: all 0.2s ease;
  min-width: 60px;
}

.header-btn:hover {
  opacity: 0.9;
}

.header-btn:active {
  opacity: 0.8;
}

.btn-green {
  background: #00B894;
  color: #fff;
  border: 1px solid #00B894;
}

.btn-green:hover {
  background: #00A885;
}

.btn-green:active {
  background: #009976;
}

.btn-blue {
  background: #FFFFFF;
  color: #0984E3;
  border: 1px solid #0984E3;
}

.btn-blue:hover {
  background: #EAF5FF;
}

.btn-blue:active {
  background: #D6EFFF;
}

.btn-orange {
  background: #FFFFFF;
  color: #FD79A8;
  border: 1px solid #FD79A8;
}

.btn-orange:hover {
  background: #FFF0F5;
}

.btn-orange:active {
  background: #FFE4F0;
}

.btn-red {
  background: #FFFFFF;
  color: #D63031;
  border: 1px solid #D63031;
}

.btn-red:hover {
  background: #FFF0F0;
}

.btn-red:active {
  background: #FFE0E0;
}

.btn-gray {
  background: #FFFFFF;
  color: #636E72;
  border: 1px solid #DFE6E9;
}

.btn-gray:hover {
  background: #F0F2F5;
}

.btn-gray:active {
  background: #E8EAED;
}

.btn-action, .btn-fullscreen, .btn-refresh, .btn-split {
  background: #F0F2F5;
  color: #636E72 !important;
  border: 1px solid #DFE6E9;
  font-size: 12px !important;
  font-weight: 500 !important;
  text-indent: 0 !important;
  padding: 6px 12px !important;
  line-height: 1.5 !important;
  white-space: nowrap !important;
  background-image: none !important;
  min-width: 40px;
}

.btn-action {
  padding: 6px !important;
  min-width: 36px;
}

.btn-action .btn-icon {
  margin-right: 0;
}

.btn-action::before,
.btn-action::after,
.btn-fullscreen::before,
.btn-fullscreen::after,
.btn-refresh::before,
.btn-refresh::after,
.btn-split::before,
.btn-split::after {
  display: none !important;
  content: none !important;
}

/* 分屏选择器样式 */
.split-selector {
  position: relative;
  display: inline-block;
}

.split-btn {
  background: #F0F2F5;
  color: #636E72;
  border: 1px solid #DFE6E9;
  font-size: 12px;
  font-weight: 500;
  padding: 6px 12px;
  line-height: 1.5;
  white-space: nowrap;
  min-width: 80px;
  border-radius: 4px;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 6px;
  transition: all 0.2s;
}

.split-btn:hover {
  background: #E8EAED;
  border-color: #B2BEC3;
}

.split-btn svg {
  width: 16px;
  height: 16px;
}

.split-menu {
  position: absolute;
  top: 100%;
  right: 0;
  margin-top: 4px;
  background: #fff;
  border: 1px solid #DFE6E9;
  border-radius: 4px;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.1);
  padding: 4px;
  z-index: 1000;
  min-width: 80px;
}

.split-menu-item {
  display: block;
  width: 100%;
  padding: 6px 12px;
  border: none;
  background: transparent;
  text-align: left;
  font-size: 12px;
  color: #636E72;
  cursor: pointer;
  border-radius: 2px;
  transition: background 0.2s;
}

.split-menu-item:hover {
  background: #F0F2F5;
}

.btn-action:hover, .btn-fullscreen:hover, .btn-refresh:hover, .btn-split:hover {
  background: #E8EAED;
  border-color: #B2BEC3;
}

.btn-action:active, .btn-fullscreen:active, .btn-refresh:active, .btn-split:active {
  background: #DDE0E3;
}

.btn-logout {
  background: #FFFFFF;
  color: #D63031;
  border: 1px solid #D63031;
}

.btn-logout:hover {
  background: #FFF0F0;
}

.btn-logout:active {
  background: #FFE0E0;
}

.status-indicators {
  display: flex;
  gap: 8px;
}

.indicator-item {
  display: flex;
  align-items: center;
  gap: 6px;
}

.alert-count {
  background: #D63031;
  padding: 5px 12px;
  border-radius: 4px;
  border: 1px solid #D63031;
  display: flex;
  align-items: center;
  gap: 6px;
}

.indicator-dot {
  width: 8px;
  height: 8px;
  background: #fff;
  border-radius: 50%;
  animation: blink 1s infinite;
}

@keyframes blink {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.3; }
}

.indicator-value {
  font-size: 16px;
  font-weight: bold;
  color: #fff;
}

.indicator-label {
  font-size: 12px;
  color: rgba(255, 255, 255, 0.8);
}



.user-info {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 6px 12px;
  background: #F0F2F5;
  border-radius: 4px;
  border: 1px solid #DFE6E9;
}

.user-name {
  font-size: 14px;
  color: #2D3436;
}

.alert-aside {
  background: #FFFFFF;
  border-right: 1px solid #DFE6E9;
  overflow-y: auto;
}

.alert-panel, .stats-panel {
  margin: 6px;
  background: #FFFFFF;
  border-radius: 4px;
  border: 1px solid #DFE6E9;
  overflow: hidden;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
}

.panel-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 12px 16px;
  border-bottom: 1px solid #DFE6E9;
}

.header-left-part {
  display: flex;
  align-items: center;
  gap: 12px;
  flex-shrink: 0;
}

.panel-title {
  font-size: 15px;
  font-weight: 700;
  color: #2D3436;
  white-space: nowrap;
}

.alert-count-badge {
  font-size: 12px;
  color: #636E72;
  background: #F0F2F5;
  padding: 2px 8px;
  border-radius: 10px;
}

.header-actions {
  display: flex;
  align-items: center;
  gap: 12px;
  flex-shrink: 0;
}

.view-all-btn {
  font-size: 12px;
  color: #0984E3;
  cursor: pointer;
  padding: 4px 10px;
  border-radius: 4px;
  transition: all 0.3s ease;
  white-space: nowrap;
}

.view-all-btn:hover {
  background: rgba(9, 132, 227, 0.1);
}

.delete-all-btn {
  font-size: 12px;
  color: #D63031;
  cursor: pointer;
  padding: 4px 10px;
  border-radius: 4px;
  transition: all 0.3s ease;
  white-space: nowrap;
}

.delete-all-btn:hover {
  background: rgba(214, 48, 49, 0.1);
}

.alert-tabs {
  display: flex;
  padding: 8px 12px;
  gap: 4px;
  border-bottom: 1px solid #DFE6E9;
}

.tab-item {
  font-size: 12px;
  color: #636E72;
  cursor: pointer;
  padding: 6px 16px;
  border-radius: 4px;
  transition: all 0.3s ease;
  margin-right: 2px;
  font-weight: 500;
}

.tab-item:hover {
  color: #2D3436;
  background: #F0F2F5;
}

.tab-item.active {
  color: #fff;
  background: #D63031;
}

.alert-list {
  padding: 6px;
}

.alert-card {
  background: #FFFFFF;
  border-radius: 4px;
  padding: 10px 12px;
  margin-bottom: 8px;
  cursor: pointer;
  border: 1px solid #DFE6E9;
  transition: all 0.2s ease;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
}

.alert-card:hover {
  border-color: #0984E3;
  background: #F8FAFC;
}

.alert-card.active {
  border-color: #D63031;
  background: #FFF5F5;
}

.alert-card.acknowledged {
  opacity: 0.6;
  border-color: #B2BEC3;
}

.alert-card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 5px;
}

.alert-type {
  font-size: 12px;
  font-weight: 600;
  color: #D63031;
}

.alert-level {
  font-size: 10px;
  padding: 1px 6px;
  border-radius: 4px;
}

.alert-level.high {
  background: rgba(214, 48, 49, 0.15);
  color: #D63031;
}

.alert-level.medium {
  background: rgba(225, 112, 85, 0.15);
  color: #E17055;
}

.alert-card-body {
  margin-bottom: 6px;
}

.alert-info-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 11px;
  color: #636E72;
  margin-bottom: 3px;
}

.alert-camera {
  color: #0984E3;
}

.alert-area {
  color: #00B894;
}

.alert-time {
  color: #636E72;
}

.alert-time-detail {
  color: #2D3436;
}

.alert-card-footer {
  display: flex;
  justify-content: flex-end;
}

.btn-confirm {
  background: #00B894;
  color: #fff;
  border: 1px solid #00B894;
  border-radius: 4px;
  padding: 4px 12px;
  font-size: 12px;
  cursor: pointer;
  transition: all 0.2s ease;
}

.btn-confirm:hover {
  background: #00A885;
  border-color: #00A885;
}

.btn-confirm:active {
  background: #009976;
  border-color: #009976;
}

.btn-acknowledged {
  background: #6c757d;
  color: white;
  border: none;
  border-radius: 4px;
  padding: 4px 12px;
  font-size: 12px;
  cursor: not-allowed;
  opacity: 0.7;
}

.btn-delete {
  background: rgba(214, 48, 49, 0.1);
  color: #D63031;
  border: 1px solid rgba(214, 48, 49, 0.2);
  border-radius: 4px;
  padding: 4px 12px;
  font-size: 12px;
  cursor: pointer;
  transition: all 0.2s ease;
}

.btn-delete:hover {
  background: rgba(214, 48, 49, 0.15);
  border-color: rgba(214, 48, 49, 0.3);
}

.btn-delete:active {
  background: rgba(214, 48, 49, 0.2);
  border-color: rgba(214, 48, 49, 0.4);
}

.empty-alert {
  text-align: center;
  padding: 30px;
  color: #6c757d;
}

.empty-hint {
  font-size: 12px;
  margin-top: 5px;
  color: #495057;
}

.stats-content {
  padding: 10px;
}

.main-stat {
  text-align: center;
  padding: 12px;
  background: #F0F2F5;
  border-radius: 4px;
  border: 1px solid #DFE6E9;
  margin-bottom: 10px;
}

.stat-label {
  display: block;
  font-size: 12px;
  color: #636E72;
  margin-bottom: 5px;
}

.stat-value {
  font-size: 36px;
  font-weight: bold;
  color: #00B894;
}

.section-title {
  font-size: 12px;
  color: #636E72;
  margin-bottom: 8px;
  font-weight: 600;
}

.area-list {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.area-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 6px 8px;
  background: #F0F2F5;
  border-radius: 4px;
  border: 1px solid #DFE6E9;
}

.area-name {
  font-size: 12px;
  color: #636E72;
}

.area-count {
  font-size: 16px;
  font-weight: bold;
  color: #00B894;
}

.monitor-main {
  display: flex;
  flex-direction: column;
  background: #FFFFFF;
  padding: 0;
  height: 100%;
  min-height: 0;
}

.monitor-upper {
  flex: 1;
  display: flex;
  flex-direction: column;
  min-height: 0;
  background: #000000;
  border-radius: 0;
  border: none;
  overflow: hidden;
  position: relative;
}

.camera-type-tabs {
  display: flex;
  padding: 8px 12px;
  background: #FFFFFF;
  border-bottom: 1px solid #DFE6E9;
  gap: 8px;
}

.camera-type-tab {
  padding: 6px 16px;
  border-radius: 4px;
  font-size: 13px;
  font-weight: 500;
  color: #666666;
  cursor: pointer;
  transition: all 0.3s ease;
  background: #F5F5F5;
}

.camera-type-tab:hover {
  background: #E8F5E9;
  color: #4CAF50;
}

.camera-type-tab.active {
  background: #4CAF50;
  color: #FFFFFF;
  box-shadow: 0 2px 4px rgba(76, 175, 80, 0.3);
}

.monitor-lower {
  flex: 0.3;
  display: flex;
  flex-direction: column;
  min-height: 0;
  background: #FFFFFF;
  border-radius: 0;
  border-top: 1px solid #DFE6E9;
  overflow: hidden;
}

.camera-title-bar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 8px 12px;
  background: #FFFFFF;
  border-bottom: 1px solid #DFE6E9;
}

.camera-title-bar .camera-name {
  font-size: 13px;
  font-weight: 600;
  color: #2D3436;
}

.status-badge {
  font-size: 12px;
  padding: 3px 10px;
  border-radius: 4px;
  font-weight: 500;
}

.status-badge.connected {
  background: rgba(0, 184, 148, 0.15);
  color: #00B894;
  border: 1px solid rgba(0, 184, 148, 0.2);
}

.status-badge.connecting {
  background: rgba(253, 203, 110, 0.15);
  color: #FDCB6E;
  border: 1px solid rgba(253, 203, 110, 0.2);
}

.screen-container {
  flex: 1;
  display: grid;
  gap: 4px;
  padding: 4px;
  overflow: hidden;
}

.split-1 {
  grid-template-columns: 1fr;
  grid-template-rows: 1fr;
}

.split-2 {
  grid-template-columns: repeat(2, 1fr);
  grid-template-rows: 1fr;
}

.split-3 {
  grid-template-columns: repeat(3, 1fr);
  grid-template-rows: 1fr;
}

.split-4 {
  grid-template-columns: repeat(2, 1fr);
  grid-template-rows: repeat(2, 1fr);
}

.split-5 {
  grid-template-columns: repeat(3, 1fr);
  grid-template-rows: repeat(2, 1fr);
}

.split-5 .screen-item:nth-child(1) {
  grid-column: span 2;
  grid-row: span 2;
}

.split-6 {
  grid-template-columns: repeat(3, 1fr);
  grid-template-rows: repeat(2, 1fr);
}

.split-7 {
  grid-template-columns: repeat(4, 1fr);
  grid-template-rows: repeat(2, 1fr);
}

.split-7 .screen-item:nth-child(1) {
  grid-column: span 2;
  grid-row: span 2;
}

.split-8 {
  grid-template-columns: repeat(4, 1fr);
  grid-template-rows: repeat(2, 1fr);
}

.split-9 {
  grid-template-columns: repeat(3, 1fr);
  grid-template-rows: repeat(3, 1fr);
}

.split-10 {
  grid-template-columns: repeat(4, 1fr);
  grid-template-rows: repeat(3, 1fr);
}

.split-10 .screen-item:nth-child(1) {
  grid-column: span 2;
  grid-row: span 2;
}

.split-11 {
  grid-template-columns: repeat(4, 1fr);
  grid-template-rows: repeat(3, 1fr);
}

.split-11 .screen-item:nth-child(1) {
  grid-column: span 2;
  grid-row: span 2;
}

.split-12 {
  grid-template-columns: repeat(4, 1fr);
  grid-template-rows: repeat(3, 1fr);
}

.split-13 {
  grid-template-columns: repeat(4, 1fr);
  grid-template-rows: repeat(4, 1fr);
}

.split-13 .screen-item:nth-child(1) {
  grid-column: span 2;
  grid-row: span 2;
}

.split-14 {
  grid-template-columns: repeat(4, 1fr);
  grid-template-rows: repeat(4, 1fr);
}

.split-14 .screen-item:nth-child(1) {
  grid-column: span 2;
  grid-row: span 2;
}

.split-15 {
  grid-template-columns: repeat(4, 1fr);
  grid-template-rows: repeat(4, 1fr);
}

.split-15 .screen-item:nth-child(1) {
  grid-column: span 2;
  grid-row: span 2;
}

.split-16 {
  grid-template-columns: repeat(4, 1fr);
  grid-template-rows: repeat(4, 1fr);
}

.screen-item {
  background: #000000;
  border-radius: 4px;
  overflow: hidden;
  border: 1px solid rgba(255, 255, 255, 0.1);
  transition: all 0.2s ease;
  max-height: 100%;
  height: 100%;
  min-height: 150px;
  min-width: 200px;
}

.split-8 .screen-item,
.split-9 .screen-item,
.split-10 .screen-item,
.split-11 .screen-item,
.split-12 .screen-item,
.split-13 .screen-item,
.split-14 .screen-item,
.split-15 .screen-item,
.split-16 .screen-item {
  min-height: 120px;
  min-width: 150px;
}

.screen-item:hover {
  border-color: #0984E3;
  box-shadow: 0 2px 8px rgba(9, 132, 227, 0.1);
}

.screen-item.active {
  border-color: #00B894;
  box-shadow: 0 2px 8px rgba(0, 184, 148, 0.1);
}

.screen-item.highlight {
  border-color: #D63031;
  animation: pulse-border 2s infinite;
}

@keyframes pulse-border {
  0%, 100% { box-shadow: 0 0 0 0 rgba(214, 48, 49, 0.4); }
  50% { box-shadow: 0 0 0 4px rgba(214, 48, 49, 0); }
}

.camera-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 2px 6px;
  background: rgba(0, 0, 0, 0.6);
  font-size: 11px;
  border-bottom: none;
}

.camera-header .camera-info {
  display: flex;
  align-items: center;
  gap: 8px;
}

.camera-header .camera-name {
  font-size: 12px;
  font-weight: 600;
  color: #FFFFFF;
  display: flex;
  align-items: center;
  gap: 5px;
}

.camera-header .camera-name::before {
  content: '';
  width: 6px;
  height: 6px;
  background: #00B894;
  border-radius: 50%;
}

.camera-header .camera-area {
  font-size: 10px;
  color: #FFFFFF;
  padding: 1px 6px;
  background: rgba(255, 255, 255, 0.1);
  border-radius: 4px;
  border: 1px solid rgba(255, 255, 255, 0.2);
}

.camera-header .people-count-badge {
  font-size: 10px;
  color: #00FF88;
  padding: 1px 6px;
  background: rgba(0, 255, 136, 0.1);
  border-radius: 4px;
  font-weight: 600;
  border: 1px solid rgba(0, 255, 136, 0.2);
}

.camera-status-bar {
  display: flex;
  gap: 8px;
  align-items: center;
}

.connection-badge {
  display: flex;
  align-items: center;
  gap: 4px;
  font-size: 11px;
  padding: 2px 8px;
  border-radius: 4px;
  font-weight: 500;
}

.connection-badge.connected {
  background: rgba(0, 184, 148, 0.1);
  color: #00B894;
  border: 1px solid rgba(0, 184, 148, 0.2);
}

.connection-badge.connecting {
  background: rgba(253, 203, 110, 0.1);
  color: #FDCB6E;
  border: 1px solid rgba(253, 203, 110, 0.2);
}

.connection-badge.error, .connection-badge.offline {
  background: rgba(214, 48, 49, 0.1);
  color: #D63031;
  border: 1px solid rgba(214, 48, 49, 0.2);
}

.status-dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: currentColor;
}

.connection-badge.connecting .status-dot {
  animation: blink 1s infinite;
}

@keyframes blink {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.3; }
}

.mode-switch-btn {
  font-size: 11px;
  padding: 3px 10px;
  border-radius: 4px;
  background: rgba(9, 132, 227, 0.1);
  color: #0984E3;
  border: 1px solid rgba(9, 132, 227, 0.2);
  cursor: pointer;
  transition: all 0.2s ease;
}

.mode-switch-btn:hover {
  background: rgba(9, 132, 227, 0.15);
}

.people-badge {
  font-size: 12px;
  padding: 2px 8px;
  background: rgba(0, 184, 148, 0.1);
  color: #00B894;
  border-radius: 4px;
  border: 1px solid rgba(0, 184, 148, 0.2);
}

.screen-item-content {
  position: relative;
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
}

.video-container {
  flex: 1;
  position: relative;
  background: #000000;
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
  width: 100%;
  height: 100%;
}

.video-container video {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.video-overlay {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  background: rgba(240, 242, 245, 0.9);
  z-index: 10;
}

.overlay-content {
  text-align: center;
}

.loading-spinner {
  width: 50px;
  height: 50px;
  border: 4px solid rgba(9, 132, 227, 0.2);
  border-top-color: #0984E3;
  border-radius: 50%;
  animation: spin 1s linear infinite;
  margin: 0 auto 15px;
}

@keyframes spin {
  to { transform: rotate(360deg); }
}

.overlay-text {
  color: #636E72;
  font-size: 16px;
  display: block;
  margin-top: 10px;
}

.switch-webrtc-btn {
  display: block;
  margin-top: 15px;
  padding: 8px 16px;
  background: #0984E3;
  color: white;
  border-radius: 4px;
  font-size: 14px;
  cursor: pointer;
  transition: all 0.3s ease;
}

.switch-webrtc-btn:hover {
  background: #0773C9;
}

.alert-indicator {
  position: absolute;
  top: 10px;
  right: 10px;
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 6px 12px;
  background: rgba(220, 53, 69, 0.9);
  border-radius: 20px;
  z-index: 30;
}

.alert-pulse {
  width: 10px;
  height: 10px;
  background: white;
  border-radius: 50%;
  animation: pulse 1s infinite;
}

.alert-text {
  color: white;
  font-size: 13px;
  font-weight: 600;
}

.video-stats-aside {
  background: #FFFFFF;
  border-left: 1px solid #DFE6E9;
  padding: 16px 12px;
  overflow-y: auto;
}

.stats-aside-header {
  padding-bottom: 12px;
  border-bottom: 1px solid #DFE6E9;
  margin-bottom: 12px;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.aside-title {
  font-size: 14px;
  font-weight: 600;
  color: #2D3436;
}

.stats-count {
  font-size: 12px;
  color: #636E72;
  padding: 2px 8px;
  background: #F0F2F5;
  border-radius: 4px;
}

.video-stats-list {
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.video-stat-card {
  background: #FFFFFF;
  border-radius: 4px;
  padding: 8px;
  cursor: pointer;
  transition: all 0.2s ease;
  border: 1px solid #DFE6E9;
  position: relative;
  overflow: hidden;
}

.video-stat-card::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  width: 2px;
  height: 100%;
  background: transparent;
  transition: background 0.2s ease;
}

.video-stat-card:hover {
  border-color: #0984E3;
  transform: translateY(-1px);
  box-shadow: 0 2px 8px rgba(9, 132, 227, 0.15);
}

.video-stat-card:hover::before {
  background: #0984E3;
}

.video-stat-card.active {
  background: #F0F7FF;
  border-color: #0984E3;
}

.video-stat-card.active::before {
  background: #0984E3;
}

.video-stat-card.alert {
  border-color: rgba(214, 48, 49, 0.5);
}

.video-stat-card.alert::before {
  background: #D63031;
}

.stat-card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 6px;
}

.stat-header-right {
  display: flex;
  align-items: center;
  gap: 6px;
}

.camera-toggle-btn {
  width: 24px;
  height: 24px;
  border-radius: 4px;
  background: #F0F2F5;
  border: 1px solid #DFE6E9;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: all 0.3s ease;
  color: #636E72;
}

.camera-toggle-btn:hover {
  background: #E8EAED;
  border-color: #B2BEC3;
}

.camera-toggle-btn.active {
  background: rgba(0, 184, 148, 0.15);
  border-color: rgba(0, 184, 148, 0.3);
  color: #00B894;
}

.camera-toggle-btn svg {
  width: 14px;
  height: 14px;
}

.stat-camera-name {
  font-size: 13px;
  font-weight: 600;
  color: #2D3436;
}

.stat-status-dot {
  width: 10px;
  height: 10px;
  border-radius: 50%;
}

.stat-status-dot.connected {
  background: #00B894;
}

.stat-status-dot.connecting {
  background: #FDCB6E;
  animation: pulse 1s infinite;
}

.stat-status-dot.disconnected,
.stat-status-dot.error,
.stat-status-dot.offline,
.stat-status-dot.new {
  background: #D63031;
}

.alert-indicator-mini {
  width: 8px;
  height: 8px;
  background: #D63031;
  border-radius: 50%;
  animation: pulse 1s infinite;
}

.stat-card-body {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.stat-item-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.stat-label {
  font-size: 11px;
  color: #636E72;
}

.stat-value {
  font-size: 12px;
  color: #2D3436;
  font-weight: 500;
}

.stat-unit {
  font-size: 10px;
  color: #636E72;
  margin-left: 2px;
}

.stat-value.status-text.connected {
  color: #00B894;
}

.stat-value.status-text.connecting {
  color: #FDCB6E;
}

.stat-value.status-text.disconnected,
.stat-value.status-text.error,
.stat-value.status-text.offline,
.stat-value.status-text.new {
  color: #D63031;
}

.stat-value.people {
  color: #00B894;
  font-weight: 600;
}

/* 上传对话框样式 */
.upload-content {
  padding: 20px;
}

.upload-area {
  margin-bottom: 20px;
}

.upload-box {
  border: 2px dashed #d9d9d9;
  border-radius: 8px;
  padding: 40px;
  text-align: center;
  cursor: pointer;
  transition: all 0.3s ease;
}

.upload-box:hover {
  border-color: #409eff;
  background: rgba(64, 158, 255, 0.05);
}

.upload-box.has-file {
  border-color: #67c23a;
  background: rgba(103, 194, 58, 0.05);
}

.upload-icon {
  width: 48px;
  height: 48px;
  color: #409eff;
  margin-bottom: 15px;
}

.upload-text {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.upload-title {
  font-size: 16px;
  font-weight: 600;
  color: #303133;
}

.upload-hint {
  font-size: 13px;
  color: #909399;
}

.file-info {
  display: flex;
  flex-direction: column;
  gap: 5px;
}

.file-name {
  font-size: 14px;
  font-weight: 500;
  color: #303133;
}

.file-size {
  font-size: 12px;
  color: #909399;
}

.upload-progress {
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.progress-text {
  font-size: 13px;
  color: #67c23a;
  text-align: center;
}

/* 清理对话框样式 */
.cleanup-content {
  padding: 20px;
}

.stats-row {
  display: flex;
  justify-content: space-between;
  padding: 10px 0;
  border-bottom: 1px solid #ebf0f5;
}

.stats-label {
  font-size: 14px;
  color: #606266;
}

.stats-value {
  font-size: 14px;
  font-weight: 600;
  color: #303133;
}

.cleanup-config {
  margin-top: 20px;
  padding: 15px;
  background: #f5f7fa;
  border-radius: 8px;
}

.config-label {
  font-size: 14px;
  color: #606266;
  margin-right: 10px;
}

.config-select {
  width: 120px;
}

.config-hint {
  font-size: 12px;
  color: #909399;
  margin-left: 10px;
}

.video-list-container {
  margin-top: 20px;
}

.list-header {
  font-size: 14px;
  font-weight: 600;
  color: #303133;
  margin-bottom: 10px;
}

.video-list {
  max-height: 150px;
  overflow-y: auto;
}

.video-item {
  display: flex;
  justify-content: space-between;
  padding: 8px 0;
  border-bottom: 1px solid #f0f0f0;
}

.video-name {
  font-size: 13px;
  color: #303133;
}

.video-date {
  font-size: 12px;
  color: #909399;
}

.more-videos {
  font-size: 12px;
  color: #909399;
  text-align: center;
  padding: 10px;
}

.empty-videos {
  text-align: center;
  padding: 30px;
  color: #909399;
}

/* 波形图相关样式 */
.chart-panel {
  margin: 10px;
  background: #FFFFFF;
  border-radius: 4px;
  border: 1px solid #DFE6E9;
  overflow: hidden;
  flex: 1;
  display: flex;
  flex-direction: column;
  min-height: 0;
}

.chart-panel .panel-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 12px 16px;
  background: #F0F2F5;
  border-bottom: 1px solid #DFE6E9;
}

.panel-subtitle {
  font-size: 12px;
  color: #636E72;
}

.chart-container {
  flex: 1;
  padding: 16px;
  overflow: auto;
  min-height: 0;
  display: flex;
  flex-direction: column;
  gap: 12px;
  background: #FFFFFF;
  border-radius: 4px;
  border: 1px solid #DFE6E9;
}

.chart-legend {
  display: flex;
  flex-wrap: wrap;
  gap: 16px;
  padding-bottom: 8px;
  border-bottom: 1px solid #DFE6E9;
}

.legend-item {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 13px;
}

.legend-dot {
  width: 10px;
  height: 10px;
  border-radius: 50%;
}

.legend-text {
  color: #636E72;
}

.legend-count {
  color: #2D3436;
  font-weight: 600;
  background: #F0F2F5;
  padding: 2px 8px;
  border-radius: 4px;
}

.dialog-footer {
  display: flex;
  gap: 10px;
  justify-content: flex-end;
  width: 100%;
}

/* 检测结果对话框样式 */
.result-content {
  display: flex;
  gap: 20px;
  max-height: 90vh;
  overflow-y: auto;
}

.preview-section {
  flex: 1;
  min-width: 0;
}

.preview-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 15px;
}

.preview-title {
  font-size: 16px;
  font-weight: 600;
  color: #2D3436;
}

.preview-container {
  position: relative;
  width: 100%;
  height: 500px;
  background: #F0F2F5;
  border: 1px solid #DFE6E9;
  border-radius: 4px;
  overflow: hidden;
}

.live-frame {
  position: relative;
  width: 100%;
  height: 100%;
}

.frame-image {
  width: 100%;
  height: 100%;
  object-fit: contain;
}

.detection-overlay {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  pointer-events: none;
}

.person-box {
  position: absolute;
  border: 2px solid #4ecdc4;
  border-radius: 4px;
  background: rgba(78, 205, 196, 0.1);
}

.person-label {
  position: absolute;
  top: -24px;
  left: 0;
  background: #4ecdc4;
  color: #fff;
  padding: 2px 8px;
  font-size: 12px;
  border-radius: 4px;
  white-space: nowrap;
}

.frame-placeholder {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100%;
  color: #6c757d;
}

.placeholder-icon {
  width: 64px;
  height: 64px;
  margin-bottom: 15px;
  opacity: 0.5;
}

.placeholder-text {
  font-size: 14px;
}

.progress-section {
  margin-top: 15px;
}

.progress-info {
  display: flex;
  justify-content: space-between;
  margin-bottom: 8px;
}

.progress-label {
  font-size: 14px;
  color: #606266;
}

.progress-value {
  font-size: 14px;
  font-weight: 600;
  color: #409eff;
}

.result-section {
  flex: 0 0 380px;
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.section-header {
  margin-bottom: 15px;
}

.section-title {
  font-size: 16px;
  font-weight: 600;
  color: #303133;
}

.result-info {
  background: #F0F2F5;
  border-radius: 4px;
  border: 1px solid #DFE6E9;
  padding: 15px;
}

.alert-list-section,
.images-section {
  background: #F0F2F5;
  border-radius: 4px;
  border: 1px solid #DFE6E9;
  padding: 15px;
}

.list-title {
  font-size: 14px;
  font-weight: 600;
  color: #2D3436;
  margin-bottom: 10px;
}

.alert-items {
  display: flex;
  flex-direction: column;
  gap: 10px;
  max-height: 200px;
  overflow-y: auto;
}

.alert-item {
  background: #fff;
  border-radius: 4px;
  padding: 10px;
  border-left: 3px solid #D63031;
  border: 1px solid #DFE6E9;
}

.alert-time {
  font-size: 12px;
  color: #636E72;
  margin-bottom: 5px;
}

.alert-detail {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.alert-type {
  font-size: 14px;
  font-weight: 500;
  color: #D63031;
}

.alert-conf {
  font-size: 12px;
  color: #636E72;
}

.images-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 10px;
  max-height: 300px;
  overflow-y: auto;
}

.image-item {
  background: #fff;
  border-radius: 6px;
  overflow: hidden;
  cursor: pointer;
  transition: all 0.3s;
}

.image-item:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
}

.screenshot {
  width: 100%;
  aspect-ratio: 4/3;
  object-fit: cover;
}

.image-info {
  padding: 8px;
  display: flex;
  justify-content: space-between;
  font-size: 12px;
  color: #909399;
}

.image-frame,
.image-time {
  font-size: 12px;
}

/* LLM 对话框样式补充 */
.llm-status-container {
  padding: 10px 0;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.test-response {
  background: #f5f7fa;
  padding: 15px;
  border-radius: 8px;
}

.response-text {
  margin: 0;
  font-size: 14px;
  color: #606266;
  line-height: 1.6;
}

.usage-tips {
  margin: 0;
  padding-left: 20px;
}

.usage-tips li {
  margin-bottom: 8px;
  font-size: 14px;
  color: #606266;
  line-height: 1.6;
}

/* 告警计数样式 */
.alert-count {
  color: #f56c6c;
  font-weight: 600;
}

.llm-chat-container {
  display: flex;
  flex-direction: column;
  height: 520px;
  background: #ffffff;
  border-radius: 12px;
  overflow: hidden;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
}

.chat-messages {
  flex: 1;
  overflow-y: auto;
  padding: 16px;
  background: linear-gradient(180deg, #f8fafc 0%, #ffffff 100%);
}

.chat-messages::-webkit-scrollbar {
  width: 6px;
}

.chat-messages::-webkit-scrollbar-track {
  background: #f1f5f9;
  border-radius: 3px;
}

.chat-messages::-webkit-scrollbar-thumb {
  background: #cbd5e1;
  border-radius: 3px;
}

.chat-messages::-webkit-scrollbar-thumb:hover {
  background: #94a3b8;
}

.chat-message {
  display: flex;
  gap: 12px;
  margin-bottom: 20px;
  animation: fadeIn 0.3s ease-out;
}

@keyframes fadeIn {
  from { opacity: 0; transform: translateY(8px); }
  to { opacity: 1; transform: translateY(0); }
}

.chat-message.user {
  flex-direction: row-reverse;
}

.chat-message.user .message-content {
  align-items: flex-end;
}

.message-avatar {
  width: 42px;
  height: 42px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  transition: transform 0.2s ease;
}

.chat-message:hover .message-avatar {
  transform: scale(1.05);
}

.chat-message.user .message-avatar {
  background: #0984E3;
  color: #fff;
}

.chat-message.assistant .message-avatar {
  background: #00B894;
  color: #fff;
}

.message-avatar svg {
  width: 22px;
  height: 22px;
}

.message-content {
  display: flex;
  flex-direction: column;
  max-width: 75%;
}

.chat-message.user .message-content {
  max-width: 75%;
}

.message-role {
  font-size: 12px;
  color: #636E72;
  margin-bottom: 6px;
  font-weight: 500;
}

.chat-message.user .message-role {
  text-align: right;
}

.message-bubble {
  position: relative;
  background: #FFFFFF;
  padding: 12px 16px;
  border-radius: 4px;
  font-size: 14px;
  line-height: 1.6;
  color: #2D3436;
  word-break: break-all;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.06);
  border: 1px solid #DFE6E9;
}

.chat-message.user .message-bubble {
  background: #0984E3;
  color: #ffffff;
  border: none;
}

.message-bubble::before {
  content: '';
  position: absolute;
  top: 12px;
  width: 0;
  height: 0;
  border: 6px solid transparent;
}

.chat-message.assistant .message-bubble::before {
  left: -12px;
  border-right-color: #e2e8f0;
}

.chat-message.user .message-bubble::before {
  right: -12px;
  border-left-color: #6366f1;
}

.message-text {
  white-space: pre-wrap;
}

.message-footer {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-top: 6px;
}

.message-time {
  font-size: 11px;
  color: #94a3b8;
}

.chat-message.user .message-footer {
  justify-content: flex-end;
}

.copy-btn {
  background: transparent;
  border: none;
  cursor: pointer;
  color: #94a3b8;
  font-size: 12px;
  padding: 2px 6px;
  border-radius: 4px;
  transition: all 0.2s;
}

.copy-btn:hover {
  background: rgba(0, 0, 0, 0.05);
  color: #4f46e5;
}

.chat-message.user .copy-btn:hover {
  background: rgba(255, 255, 255, 0.15);
  color: #ffffff;
}

.chat-loading {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 12px 16px;
  background: #f8fafc;
  border-radius: 16px;
  width: fit-content;
  margin-bottom: 15px;
  animation: fadeIn 0.3s ease-out;
}

.loading-dots {
  display: flex;
  gap: 6px;
}

.loading-dots span {
  width: 8px;
  height: 8px;
  background: #00B894;
  border-radius: 50%;
  animation: loading-dot 1.4s infinite ease-in-out both;
}

.loading-dots span:nth-child(1) { animation-delay: -0.32s; }
.loading-dots span:nth-child(2) { animation-delay: -0.16s; }

@keyframes loading-dot {
  0%, 80%, 100% { transform: scale(0.6); opacity: 0.5; }
  40% { transform: scale(1); opacity: 1; }
}

.loading-text {
  font-size: 13px;
  color: #636E72;
}

.chat-quick-questions {
  padding: 12px 16px;
  background: #F0F2F5;
  border-top: 1px solid #DFE6E9;
  border-bottom: 1px solid #DFE6E9;
}

.quick-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 10px;
}

.quick-label {
  font-size: 12px;
  color: #636E72;
  font-weight: 500;
}

.category-tabs {
  display: flex;
  gap: 4px;
}

.category-tab {
  font-size: 11px;
  padding: 3px 8px;
  border-radius: 4px;
  cursor: pointer;
  transition: all 0.2s;
  background: #DFE6E9;
  color: #636E72;
}

.category-tab.active {
  background: #0984E3;
  color: #ffffff;
}

.category-tab:hover {
  opacity: 0.8;
}

.quick-tags {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}

.quick-tag {
  cursor: pointer;
  transition: all 0.2s;
  background: #ffffff;
  border: 1px solid #DFE6E9;
}

.quick-tag:hover {
  border-color: #0984E3;
}

.chat-input-area {
  display: flex;
  flex-direction: column;
  gap: 16px;
  padding: 16px;
  background: #ffffff;
  border-top: 1px solid #DFE6E9;
}

.chat-input-wrapper {
  position: relative;
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.chat-input {
  resize: none;
  border-radius: 8px;
  border: 1px solid #DFE6E9;
  padding: 12px 16px;
  font-size: 14px;
  transition: all 0.2s;
  background: #F0F2F5;
  min-height: 60px;
}

.chat-input:focus {
  border-color: #0984E3;
  box-shadow: 0 0 0 2px rgba(9, 132, 227, 0.1);
  background: #ffffff;
}

.chat-input::placeholder {
  color: #636E72;
}

.input-hint {
  font-size: 11px;
  color: #94a3b8;
  text-align: right;
}

.chat-actions {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 12px;
}

.chat-send-btn {
  background: #0984E3;
  border: none;
  color: #ffffff;
  padding: 8px 24px;
  border-radius: 4px;
  font-size: 14px;
  font-weight: 500;
  transition: all 0.2s;
}

.chat-send-btn:hover:not(:disabled) {
  background: #0773C9;
}

.chat-send-btn:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

/* 大屏模式样式 */
.big-screen-mode {
  background: #F0F2F5 !important;
}

.big-screen-mode .header {
  background: #FFFFFF !important;
  border-bottom: 1px solid #DFE6E9 !important;
}

.big-screen-mode .header-left h1 {
  color: #2D3436 !important;
}

.big-screen-mode .header-btn {
  background: #F0F2F5 !important;
  border-color: #DFE6E9 !important;
  color: #2D3436 !important;
}

.big-screen-mode .header-btn:hover {
  background: #E8EAED !important;
}

.big-screen-mode .btn-green {
  background: #00B894 !important;
  border-color: #00B894 !important;
  color: #fff !important;
}

.big-screen-mode .btn-blue {
  background: rgba(9, 132, 227, 0.1) !important;
  border-color: rgba(9, 132, 227, 0.2) !important;
  color: #0984E3 !important;
}

.big-screen-mode .sound-toggle {
  background: #F0F2F5 !important;
  border-color: #DFE6E9 !important;
}

.big-screen-mode .sound-label {
  color: #636E72 !important;
}

.big-screen-mode .user-info {
  background: #F0F2F5 !important;
  border-color: #DFE6E9 !important;
}

.big-screen-mode .user-name {
  color: #2D3436 !important;
}

.big-screen-mode .indicator-item {
  color: #2D3436 !important;
}

.big-screen-mode .indicator-value {
  color: #2D3436 !important;
}

.big-screen-mode .btn-split {
  background: #F0F2F5 !important;
  border-color: #DFE6E9 !important;
  color: #636E72 !important;
}

.big-screen-mode .monitor-main {
  background: #F0F2F5 !important;
}

.big-screen-mode .monitor-upper {
  background: #F0F2F5 !important;
  border: 1px solid #DFE6E9 !important;
}

.big-screen-mode .screen-container {
  background: #F0F2F5 !important;
  gap: 6px !important;
  padding: 8px !important;
}

.big-screen-mode .screen-item {
  background: #FFFFFF !important;
  border-color: #DFE6E9 !important;
  border-radius: 6px !important;
  min-height: 180px;
  min-width: 240px;
}

.big-screen-mode .split-8 .screen-item,
.big-screen-mode .split-9 .screen-item,
.big-screen-mode .split-10 .screen-item,
.big-screen-mode .split-11 .screen-item,
.big-screen-mode .split-12 .screen-item,
.big-screen-mode .split-13 .screen-item,
.big-screen-mode .split-14 .screen-item,
.big-screen-mode .split-15 .screen-item,
.big-screen-mode .split-16 .screen-item {
  min-height: 140px;
  min-width: 180px;
}

.big-screen-mode .screen-item:hover {
  border-color: #0984E3 !important;
}

.big-screen-mode .screen-item.active {
  border-color: #00B894 !important;
}

.big-screen-mode .screen-item.highlight {
  border-color: #D63031 !important;
}

.big-screen-mode .camera-header {
  background: #FFFFFF !important;
  border-bottom: 1px solid #DFE6E9 !important;
}

.big-screen-mode .camera-name {
  color: #2D3436 !important;
}

.big-screen-mode .camera-area {
  color: #636E72 !important;
  background: #F0F2F5 !important;
  border-color: #DFE6E9 !important;
}

.big-screen-mode .people-count-badge {
  color: #00B894 !important;
  background: rgba(0, 184, 148, 0.1) !important;
  border-color: rgba(0, 184, 148, 0.2) !important;
}

.big-screen-mode .connection-badge.connected {
  background: rgba(0, 184, 148, 0.1) !important;
  color: #00B894 !important;
  border-color: rgba(0, 184, 148, 0.2) !important;
}

.big-screen-mode .connection-badge.connecting {
  background: rgba(253, 203, 110, 0.1) !important;
  color: #FDCB6E !important;
  border-color: rgba(253, 203, 110, 0.2) !important;
}

.big-screen-mode .connection-badge.error,
.big-screen-mode .connection-badge.offline {
  background: rgba(214, 48, 49, 0.1) !important;
  color: #D63031 !important;
  border-color: rgba(214, 48, 49, 0.2) !important;
}

.big-screen-mode .mode-switch-btn {
  background: rgba(9, 132, 227, 0.1) !important;
  color: #0984E3 !important;
  border-color: rgba(9, 132, 227, 0.2) !important;
}

.big-screen-mode .video-container {
  background: #F0F2F5 !important;
}

.big-screen-mode .video-overlay {
  background: rgba(240, 242, 245, 0.95) !important;
}

.big-screen-mode .overlay-text {
  color: #636E72 !important;
}

.big-screen-mode .switch-webrtc-btn {
  background: rgba(9, 132, 227, 0.1) !important;
  color: #0984E3 !important;
  border: 1px solid rgba(9, 132, 227, 0.2) !important;
}

.big-screen-mode .alert-indicator {
  background: #FFFFFF !important;
  border: 1px solid #D63031 !important;
}

/* 大屏模式告警通知栏 */
.big-screen-alert-bar {
  background: #FFFFFF;
  padding: 10px 16px;
  border-radius: 4px;
  margin-bottom: 8px;
  border: 1px solid #D63031;
  box-shadow: 0 2px 8px rgba(214, 48, 49, 0.1);
}

.alert-bar-content {
  display: flex;
  align-items: center;
  gap: 12px;
}

.alert-bar-icon {
  width: 8px;
  height: 8px;
  background: #D63031;
  border-radius: 50%;
  animation: blink 1s infinite;
}

.alert-bar-text {
  font-size: 14px;
  font-weight: 600;
  color: #D63031;
}

.alert-bar-hint {
  font-size: 12px;
  color: #636E72;
  margin-left: auto;
}

/* 大屏监控按钮样式 */
.btn-big-screen {
  background: rgba(9, 132, 227, 0.1) !important;
  border-color: rgba(9, 132, 227, 0.2) !important;
  color: #0984E3 !important;
}

.btn-big-screen:hover {
  background: rgba(9, 132, 227, 0.15) !important;
}

.btn-big-screen.active {
  background: #0984E3 !important;
  border-color: #0984E3 !important;
  color: #fff !important;
}

/* 大屏模式视频项 */
.big-screen-item {
  border-radius: 4px !important;
}

/* 大屏模式全屏视频区域 */
.monitor-upper.big-screen {
  flex: 1 !important;
  min-height: 0 !important;
  height: 100% !important;
}

/* 视频状态面板样式 */
.video-stats-panel {
  background: #FFFFFF;
  border-radius: 0;
  border: none;
  border-top: 1px solid #DFE6E9;
  padding: 4px;
  margin-top: 0;
  max-height: 150px;
  overflow-y: auto;
  flex-shrink: 0;
}

.stats-panel-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 2px 8px;
  border-bottom: 1px solid #DFE6E9;
  margin-bottom: 2px;
}

.stats-panel-header .panel-title {
  font-size: 11px;
  font-weight: 600;
  color: #2D3436;
}

.stats-panel-header .stats-count {
  font-size: 10px;
  color: #636E72;
}

.video-stats-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(140px, 1fr));
  gap: 3px;
}

.video-stat-card {
  background: #FFFFFF;
  border-radius: 4px;
  padding: 6px;
  border: 1px solid #DFE6E9;
  cursor: pointer;
  transition: all 0.2s ease;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
}

.video-stat-card:hover {
  border-color: #0984E3;
  background: #F8FAFC;
}

.video-stat-card.active {
  border-color: #00B894;
  background: #F0F2F5;
}

.video-stat-card.alert {
  border-color: #D63031;
  background: #FFF5F5;
}

.stat-card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 4px;
}

.stat-camera-name {
  font-size: 11px;
  font-weight: 600;
  color: #2D3436;
}

.stat-header-right {
  display: flex;
  align-items: center;
  gap: 4px;
}

.stat-status-dot {
  width: 6px;
  height: 6px;
  border-radius: 50%;
}

.stat-status-dot.connected {
  background: #00B894;
  box-shadow: 0 0 0 2px rgba(0, 184, 148, 0.2);
}

.stat-status-dot.connecting {
  background: #FDCB6E;
  animation: blink 1s infinite;
}

.stat-status-dot.disconnected {
  background: #636E72;
}

.alert-indicator-mini {
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: #D63031;
  animation: alert-pulse 1s infinite;
}

.camera-toggle-btn {
  background: none;
  border: none;
  color: #636E72;
  cursor: pointer;
  padding: 2px;
  border-radius: 3px;
  transition: all 0.2s ease;
}

.camera-toggle-btn:hover {
  background: rgba(0, 0, 0, 0.05);
}

.camera-toggle-btn.active {
  color: #00B894;
}

.camera-toggle-btn svg {
  width: 12px;
  height: 12px;
}

.stat-card-body {
  display: flex;
  flex-direction: column;
  gap: 3px;
}

.stat-item-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 10px;
}

.stat-label {
  color: #636E72;
}

.stat-value {
  color: #2D3436;
  font-weight: 500;
}

.stat-value.status-text.connected {
  color: #00B894;
}

.stat-value.status-text.connecting {
  color: #FDCB6E;
}

.stat-value.status-text.disconnected {
  color: #636E72;
}

.stat-value.people {
  color: #0984E3;
}

.stat-unit {
  font-size: 9px;
  color: #636E72;
  margin-left: 2px;
}

@keyframes blink {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.5; }
}

@keyframes alert-pulse {
  0%, 100% { box-shadow: 0 0 0 0 rgba(214, 48, 49, 0.4); }
  50% { box-shadow: 0 0 0 4px rgba(214, 48, 49, 0); }
}

/* 功能按钮区域样式 */
.function-buttons {
  display: flex;
  justify-content: center;
  padding: 6px;
  margin-top: 0;
  gap: 10px;
  border-top: 1px solid #DFE6E9;
  flex-shrink: 0;
  background: #FFFFFF;
}

.btn-bottom {
  background: rgba(9, 132, 227, 0.1);
  border-color: #0984E3;
  color: #0984E3;
  font-size: 12px;
  padding: 5px 16px;
  border-radius: 4px;
  transition: all 0.2s ease;
  display: flex;
  align-items: center;
  gap: 4px;
}

.btn-bottom:hover {
  background: rgba(9, 132, 227, 0.2);
}

.btn-bottom.active {
  background: #0984E3;
  color: #fff;
}

.btn-bottom.btn-green {
  background: rgba(0, 184, 148, 0.1);
  border-color: #00B894;
  color: #00B894;
}

.btn-bottom.btn-green:hover {
  background: rgba(0, 184, 148, 0.2);
}

.btn-bottom.btn-green.active {
  background: #00B894;
  color: #fff;
}

.btn-bottom.btn-blue {
  background: rgba(9, 132, 227, 0.1);
  border-color: rgba(9, 132, 227, 0.2);
  color: #0984E3;
}

.btn-bottom.btn-blue:hover {
  background: rgba(9, 132, 227, 0.15);
}

.btn-bottom svg {
  margin-right: 6px;
}

.big-screen-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 8px 16px;
  background: #FFFFFF;
  border-bottom: 1px solid #DFE6E9;
}

.big-screen-header-left {
  display: flex;
  align-items: center;
  gap: 12px;
}

.big-screen-back-btn {
  display: flex;
  align-items: center;
  gap: 4px;
  padding: 5px 12px;
  background: #FFFFFF;
  border: 1px solid #DFE6E9;
  border-radius: 4px;
  color: #2D3436;
  font-size: 12px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.2s ease;
}

.big-screen-back-btn:hover {
  background: #F0F2F5;
  border-color: #B2BEC3;
}

.big-screen-back-btn svg {
  width: 14px;
  height: 14px;
}

.big-screen-title {
  font-size: 14px;
  font-weight: 600;
  color: #2D3436;
}

.big-screen-header-right {
  display: flex;
  align-items: center;
  gap: 16px;
}

.big-screen-header-right .status-indicators {
  display: flex;
  gap: 12px;
}

.big-screen-header-right .indicator-item {
  display: flex;
  align-items: center;
  gap: 4px;
  padding: 4px 8px;
  background: #F0F2F5;
  border-radius: 4px;
}

.big-screen-header-right .indicator-dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
}

.big-screen-header-right .indicator-item.alert-count .indicator-dot {
  background: #D63031;
  animation: alert-pulse 1s infinite;
}

.big-screen-header-right .indicator-value {
  font-size: 12px;
  font-weight: 600;
  color: #2D3436;
}

.big-screen-header-right .indicator-label {
  font-size: 11px;
  color: #636E72;
}
</style>