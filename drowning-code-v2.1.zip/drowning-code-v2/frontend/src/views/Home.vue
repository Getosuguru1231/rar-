<template>
  <div class="test-page">
    <h1>系统首页</h1>
    <p>系统运行正常！</p>
    <el-button type="primary" @click="goToLogin">前往登录</el-button>
  </div>
</template>

<script setup>
import { useRouter } from 'vue-router'

const router = useRouter()

const goToLogin = () => {
  router.push('/login')
}
</script>

<style scoped>
.test-page {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  height: 100vh;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
}

.test-page h1 {
  font-size: 48px;
  margin-bottom: 20px;
}

.test-page p {
  font-size: 24px;
  margin-bottom: 30px;
}
</style>
