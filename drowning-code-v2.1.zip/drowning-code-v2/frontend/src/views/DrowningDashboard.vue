<template>
  <div class="dashboard">
    <DashboardHeader @go-back="handleGoBack" />
    
    <aside class="panel-left">
      <StatCard 
        :patrols="statPatrols" 
        :warnings="statWarnings" 
        :monitors="statMonitors" 
        :accuracy="statAccuracy" 
      />
      <RiskDistChart 
        :high-count="highRiskCount" 
        :mid-count="midRiskCount" 
        :low-count="lowRiskCount" 
        :safe-count="safeCount" 
      />
      <TrendChart />
    </aside>
    
    <main class="panel-main">
      <MapContainer 
        :hazard-points="hazardPoints" 
        :camera-points="cameraPoints"
        :selected-legend="selectedLegend"
        :high-risk-count="highRiskCount"
        :mid-risk-count="midRiskCount"
        :low-risk-count="lowRiskCount"
        :camera-count="cameraCount"
        :focus-count="focusCount"
        @toggle-legend="toggleLegend"
      />
    </main>
    
    <aside class="panel-right">
      <WarningFeed :warnings="warnings" />
      <CameraStatus :cameras="cameraPoints" />
      <TopSpots :spots="topSpots" />
    </aside>
    
    <TickerBar :items="warnings" />
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import DashboardHeader from '@/components/dashboard/DashboardHeader.vue'
import StatCard from '@/components/dashboard/StatCard.vue'
import RiskDistChart from '@/components/dashboard/RiskDistChart.vue'
import TrendChart from '@/components/dashboard/TrendChart.vue'
import MapContainer from '@/components/dashboard/MapContainer.vue'
import WarningFeed from '@/components/dashboard/WarningFeed.vue'
import CameraStatus from '@/components/dashboard/CameraStatus.vue'
import TopSpots from '@/components/dashboard/TopSpots.vue'
import TickerBar from '@/components/dashboard/TickerBar.vue'
import { useDashboardData } from '@/composables/useDashboardData'

const router = useRouter()

const {
  hazardPoints,
  cameraPoints,
  warnings,
  highRiskCount,
  midRiskCount,
  lowRiskCount,
  safeCount,
  cameraCount,
  topSpots
} = useDashboardData()

const statPatrols = ref('0')
const statWarnings = ref(0)
const statMonitors = ref(0)
const statAccuracy = ref(0)
const focusCount = ref(0)
const selectedLegend = ref('danger')

function handleGoBack() {
  router.push('/monitor')
}

function toggleLegend(legend) {
  selectedLegend.value = legend
}
</script>

<style>
.dashboard {
  display: grid;
  grid-template-columns: 280px 1fr 300px;
  grid-template-rows: 70px 1fr 44px;
  grid-template-areas: 
    "header header header"
    "panel-left panel-main panel-right"
    "ticker ticker ticker";
  height: 100vh;
  width: 100%;
  font-family: "Microsoft YaHei", "PingFang SC", "Noto Sans SC", "Helvetica Neue", sans-serif;
  background: #F8FAFC;
  overflow: hidden;
}

.panel-left {
  grid-area: panel-left;
  padding: 16px;
  padding-right: 10px;
  overflow-y: auto;
  display: flex; flex-direction: column; gap: 14px;
}

.panel-left::-webkit-scrollbar { width: 4px; }
.panel-left::-webkit-scrollbar-track { background: #F1F5F9; }
.panel-left::-webkit-scrollbar-thumb { background: #CBD5E1; border-radius: 2px; }

.panel-main {
  grid-area: panel-main;
  padding: 16px;
  padding-left: 6px;
  padding-right: 6px;
}

.panel-right {
  grid-area: panel-right;
  padding: 16px;
  padding-left: 10px;
  overflow-y: auto;
  display: flex; flex-direction: column; gap: 14px;
}

.panel-right::-webkit-scrollbar { width: 4px; }
.panel-right::-webkit-scrollbar-track { background: #F1F5F9; }
.panel-right::-webkit-scrollbar-thumb { background: #CBD5E1; border-radius: 2px; }
</style>