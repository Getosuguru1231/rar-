<template>
  <div class="video-test-page">
    <el-header class="header">
      <h1>视频流连接测试</h1>
      <div class="header-right">
        <el-button type="danger" @click="handleLogout">退出登录</el-button>
      </div>
    </el-header>
    
    <el-main class="main-content">
      <el-row :gutter="20">
        <!-- WebSocket视频流测试 -->
        <el-col :span="12">
          <el-card title="WebSocket视频流测试" shadow="always">
            <div class="video-container">
              <img
                v-if="wsConnected"
                ref="wsImageRef"
                class="video-stream"
              />
              <div v-else class="video-placeholder">
                <el-icon class="is-loading"><Loading /></el-icon>
                <span>{{ wsStatus }}</span>
              </div>
            </div>
            <div class="video-info">
              <span>状态: {{ wsConnected ? '已连接' : '未连接' }}</span>
              <span>FPS: {{ wsFps }}</span>
              <span>延迟: {{ wsLatency }}ms</span>
            </div>
            <el-button 
              type="primary" 
              @click="toggleWs"
              :loading="wsLoading"
            >
              {{ wsConnected ? '断开' : '连接' }}
            </el-button>
          </el-card>
        </el-col>
        
        <!-- WebRTC视频流测试 -->
        <el-col :span="12">
          <el-card title="WebRTC视频流测试" shadow="always">
            <div class="video-container">
              <video
                ref="webrtcVideoRef"
                class="video-stream"
                autoplay
                muted
                playsinline
                style="width: 100%; height: 100%; object-fit: cover; background-color: #000;"
              />
              <div v-if="!webrtcConnected" class="video-placeholder">
                <el-icon class="is-loading"><Loading /></el-icon>
                <span>{{ webrtcStatus }}</span>
              </div>
            </div>
            <div class="video-info">
              <span>状态: {{ webrtcConnected ? '已连接' : '未连接' }}</span>
              <span>连接状态: {{ webrtcConnectionState }}</span>
              <span>ICE状态: {{ webrtcIceState }}</span>
            </div>
            <el-button 
              type="primary" 
              @click="toggleWebRTC"
              :loading="webrtcLoading"
            >
              {{ webrtcConnected ? '断开' : '连接' }}
            </el-button>
          </el-card>
        </el-col>
        
        <!-- 连接日志 -->
        <el-col :span="12">
          <el-card title="连接日志" shadow="always">
            <div class="log-container">
              <div 
                v-for="(log, index) in logs" 
                :key="index" 
                class="log-item"
                :class="log.type"
              >
                <span class="log-time">{{ log.time }}</span>
                <span class="log-message">{{ log.message }}</span>
              </div>
            </div>
            <el-button 
              type="warning" 
              size="small" 
              @click="clearLogs"
            >
              清空日志
            </el-button>
          </el-card>
        </el-col>
      </el-row>
      
      <!-- 测试配置 -->
      <el-card title="测试配置" shadow="always" style="margin-top: 20px;">
        <el-form :model="testConfig" inline>
          <el-form-item label="摄像头ID">
            <el-input v-model.number="testConfig.cameraId" style="width: 100px;" />
          </el-form-item>
          <el-form-item label="视频质量">
            <el-select v-model="testConfig.quality">
              <el-option label="低" value="low" />
              <el-option label="中" value="medium" />
              <el-option label="高" value="high" />
              <el-option label="超高" value="ultra" />
            </el-select>
          </el-form-item>
          <el-form-item label="帧率">
            <el-select v-model.number="testConfig.fps">
              <el-option label="10" :value="10" />
              <el-option label="15" :value="15" />
              <el-option label="20" :value="20" />
              <el-option label="30" :value="30" />
            </el-select>
          </el-form-item>
          <el-button type="primary" @click="applyConfig">应用配置</el-button>
        </el-form>
      </el-card>
    </el-main>
  </div>
</template>

<script setup>
import { ref, reactive, onUnmounted, nextTick, watch } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Loading } from '@element-plus/icons-vue'
import { useWebRTC } from '../composables/useWebRTC.js'
import { getVideoWsUrl } from '@/config/websocket.js'

const router = useRouter()

// 测试配置
const testConfig = reactive({
  cameraId: 1,
  quality: 'medium',
  fps: 15
})

// 日志
const logs = ref([])
const addLog = (type, message) => {
  const time = new Date().toLocaleTimeString()
  logs.value.unshift({ time, type, message })
  if (logs.value.length > 100) {
    logs.value.pop()
  }
}

const clearLogs = () => {
  logs.value = []
}

// 退出登录
const handleLogout = () => {
  ElMessageBox.confirm('确定要退出登录吗？', '提示', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning'
  }).then(() => {
    localStorage.removeItem('token')
    localStorage.removeItem('username')
    localStorage.removeItem('userType')
    router.push('/login')
    ElMessage.success('已退出登录')
  }).catch(() => {})
}

// WebSocket测试
const wsImageRef = ref(null)
const wsConnected = ref(false)
const wsLoading = ref(false)
const wsStatus = ref('准备连接')
const wsFps = ref(0)
const wsLatency = ref(0)

let ws = null
let wsFrameCount = 0
let wsStartTime = 0

const toggleWs = () => {
  if (wsConnected.value) {
    closeWs()
    wsConnected.value = false
    wsStatus.value = '已断开'
    addLog('info', 'WebSocket视频流已断开')
  } else {
    wsLoading.value = true
    wsStatus.value = '连接中...'
    addLog('info', '正在连接WebSocket视频流...')
    
    try {
      const qualityMap = { low: 35, medium: 45, high: 50, ultra: 55 }
      const wsUrl = getVideoWsUrl(testConfig.cameraId, { 
        quality: qualityMap[testConfig.quality], 
        fps: testConfig.fps 
      })
      ws = new WebSocket(wsUrl)
      ws.binaryType = 'blob'
      
      ws.onopen = () => {
        wsConnected.value = true
        wsStatus.value = '已连接'
        wsStartTime = Date.now()
        wsFrameCount = 0
        wsLoading.value = false
        addLog('success', 'WebSocket视频流连接成功')
      }
      
      ws.onmessage = (event) => {
        if (event.data instanceof Blob && wsImageRef.value) {
          wsFrameCount++
          const now = Date.now()
          wsLatency.value = now - wsStartTime
          
          if (wsFrameCount % 10 === 0) {
            wsFps.value = Math.round(wsFrameCount * 1000 / (now - wsStartTime))
          }
          
          const blobUrl = URL.createObjectURL(event.data)
          wsImageRef.value.src = blobUrl
          requestIdleCallback(() => {
            URL.revokeObjectURL(blobUrl)
          })
        }
      }
      
      ws.onerror = (e) => {
        wsStatus.value = '连接失败'
        wsLoading.value = false
        const errorMsg = e.message || '未知错误'
        addLog('error', `WebSocket错误: ${errorMsg}`)
      }
      
      ws.onclose = () => {
        if (wsConnected.value) {
          wsConnected.value = false
          wsStatus.value = '连接断开'
          addLog('warning', 'WebSocket连接已断开')
        }
      }
    } catch (e) {
      wsStatus.value = '连接失败'
      wsLoading.value = false
      addLog('error', `WebSocket连接失败: ${e.message}`)
    }
  }
}

const closeWs = () => {
  if (ws) {
    try {
      ws.close()
    } catch (e) {
      console.warn('关闭WebSocket失败:', e)
    }
    ws = null
  }
}

// WebRTC测试
const webrtcVideoRef = ref(null)
const webrtcConnected = ref(false)
const webrtcLoading = ref(false)
const webrtcStatus = ref('准备连接')
const webrtcConnectionState = ref('new')
const webrtcIceState = ref('new')

const {
  remoteStream: webrtcStream,
  isConnected: webrtcIsConnected,
  isConnecting: webrtcIsConnecting,
  connectionState: webrtcConnState,
  iceConnectionState: webrtcIceConnState,
  connect: webrtcConnect,
  disconnect: webrtcDisconnect
} = useWebRTC(testConfig.cameraId)

const toggleWebRTC = () => {
  if (webrtcConnected.value) {
    webrtcDisconnect()
    webrtcConnected.value = false
    webrtcStatus.value = '已断开'
    addLog('info', 'WebRTC视频流已断开')
  } else {
    webrtcLoading.value = true
    webrtcStatus.value = '连接中...'
    addLog('info', '正在连接WebRTC视频流...')
    webrtcConnect()
  }
}



watch(webrtcIsConnected, (connected) => {
  webrtcConnected.value = connected
  webrtcLoading.value = false
  
  if (connected) {
    webrtcStatus.value = '已连接'
    addLog('success', 'WebRTC视频流连接成功')
  } else if (!webrtcIsConnecting.value) {
    webrtcStatus.value = '连接失败'
  }
})

watch(webrtcConnState, (state) => {
  webrtcConnectionState.value = state
})

watch(webrtcIceConnState, (state) => {
  webrtcIceState.value = state
})

watch(webrtcStream, async (stream) => {
  if (stream) {
    await nextTick()
    if (webrtcVideoRef.value) {
      webrtcVideoRef.value.srcObject = stream
      console.log('[VideoTest] WebRTC视频流已设置:', stream.id)
    }
  }
})

const applyConfig = () => {
  addLog('info', `配置已更新: 摄像头${testConfig.cameraId}, 质量${testConfig.quality}, 帧率${testConfig.fps}`)
}

onUnmounted(() => {
  closeWs()
  webrtcDisconnect()
})
</script>

<style scoped>
.video-test-page {
  height: 100vh;
  display: flex;
  flex-direction: column;
}

.header {
  background-color: #1989fa;
  color: #fff;
  padding: 15px 20px;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.header h1 {
  margin: 0;
  font-size: 18px;
}

.header-right {
  display: flex;
  gap: 10px;
}

.main-content {
  flex: 1;
  padding: 20px;
  overflow-y: auto;
}

.video-container {
  width: 100%;
  height: 450px;
  background-color: #000;
  border-radius: 8px;
  overflow: hidden;
  position: relative;
}

.video-stream {
  width: 100%;
  height: 100%;
  object-fit: contain;
  position: absolute;
  top: 0;
  left: 0;
}

.video-stream.hidden {
  display: none;
}

.video-placeholder {
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  color: #fff;
}

.video-info {
  display: flex;
  gap: 20px;
  margin: 10px 0;
  font-size: 14px;
  color: #666;
}

.log-container {
  max-height: 300px;
  overflow-y: auto;
  margin-bottom: 10px;
}

.log-item {
  padding: 5px 10px;
  margin-bottom: 5px;
  border-radius: 4px;
  font-size: 13px;
}

.log-item.info {
  background-color: #e8f4ff;
  color: #409eff;
}

.log-item.success {
  background-color: #e8f5e9;
  color: #67c23a;
}

.log-item.error {
  background-color: #fef0f0;
  color: #f56c6c;
}

.log-item.warning {
  background-color: #fdf6ec;
  color: #e6a23c;
}

.log-time {
  margin-right: 10px;
  color: #999;
}
</style>