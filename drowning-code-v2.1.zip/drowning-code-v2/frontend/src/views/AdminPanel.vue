<template>
  <div class="admin-panel">
    <!-- 顶部导航栏 -->
    <div class="header">
      <div class="header-left">
        <div class="logo-icon">防</div>
        <h1>AI溺水防控监测系统</h1>
      </div>
      <div class="header-right">
        <el-tag type="success" effect="dark">管理员模式</el-tag>
        <el-button 
          :type="llmStatus === 'connected' ? 'success' : llmStatus === 'testing' ? 'warning' : 'info'"
          @click="testLLMConnection"
          :loading="llmStatus === 'testing'"
          size="small"
          class="btn-hover-effect ripple-effect"
        >
          {{ llmStatusText }}
        </el-button>
        <el-button 
          v-if="llmStatus === 'connected'"
          type="primary" 
          @click="openChatDialog"
          size="small"
          class="btn-hover-effect ripple-effect"
        >
          智能问答
        </el-button>
        <span class="username">{{ username }}</span>
        <el-button type="info" @click="goToMonitor" size="small" class="btn-hover-effect ripple-effect">
          用户端监控
        </el-button>
        <el-button @click="handleLogout" size="small" class="btn-hover-effect ripple-effect">退出登录</el-button>
      </div>
    </div>

    <!-- 标签页导航 -->
    <div class="tabs-nav">
      <el-tabs v-model="activeTab" @tab-click="handleTabClick">
        <el-tab-pane label="系统概览" name="overview"></el-tab-pane>
        <el-tab-pane label="实时监控" name="monitor"></el-tab-pane>
        <el-tab-pane label="告警管理" name="alerts"></el-tab-pane>
        <el-tab-pane label="用户管理" name="users"></el-tab-pane>
        <el-tab-pane label="系统设置" name="settings"></el-tab-pane>
        <el-tab-pane label="性能监控" name="performance"></el-tab-pane>
        <el-tab-pane label="活动日志" name="logs"></el-tab-pane>
      </el-tabs>
    </div>

    <!-- 主内容区 -->
    <div class="main-content">
      <!-- 系统概览 -->
      <div v-show="activeTab === 'overview'" class="tab-content">
        <el-row :gutter="20">
          <el-col :span="6">
            <el-card class="stat-card" shadow="hover">
              <template #header>
                <div class="card-header">
                  <span>今日告警总数</span>
                </div>
              </template>
              <div class="stat-value-large">{{ todayAlertStats.total }}</div>
            </el-card>
          </el-col>
          <el-col :span="6">
            <el-card class="stat-card" shadow="hover">
              <template #header>
                <div class="card-header">
                  <span>待处理告警</span>
                </div>
              </template>
              <div class="stat-value-large warning">{{ todayAlertStats.pending }}</div>
            </el-card>
          </el-col>
          <el-col :span="6">
            <el-card class="stat-card" shadow="hover">
              <template #header>
                <div class="card-header">
                  <span>活跃用户</span>
                </div>
              </template>
              <div class="stat-value-large info">{{ activeUsers }}</div>
            </el-card>
          </el-col>
          <el-col :span="6">
            <el-card class="stat-card" shadow="hover">
              <template #header>
                <div class="card-header">
                  <span>活跃摄像头</span>
                </div>
              </template>
              <div class="stat-value-large success">{{ stats.activeCameras }}</div>
            </el-card>
          </el-col>
        </el-row>
        <el-row :gutter="20" style="margin-top: 20px;">
          <el-col :span="12">
            <el-card class="stat-card" shadow="hover">
              <template #header>
                <div class="card-header">
                  <span>系统状态</span>
                  <el-tag type="success">{{ stats.systemStatus }}</el-tag>
                </div>
              </template>
              <div class="system-status-info">
                <div class="status-item">
                  <span class="status-label">运行时间</span>
                  <span class="status-value">{{ systemUptime }}</span>
                </div>
                <div class="status-item">
                  <span class="status-label">后端地址</span>
                  <span class="status-value">http://localhost:8000</span>
                </div>
                <div class="status-item">
                  <span class="status-label">前端地址</span>
                  <span class="status-value">http://localhost:3000</span>
                </div>
              </div>
            </el-card>
          </el-col>
          <el-col :span="12">
            <el-card class="stat-card" shadow="hover">
              <template #header>
                <div class="card-header">
                  <span>视频流状态</span>
                  <el-tag :type="videoStreamStatus.stream_running ? 'success' : 'danger'">
                    {{ videoStreamStatus.stream_running ? '运行中' : '未运行' }}
                  </el-tag>
                </div>
              </template>
              <div class="system-status-info">
                <div class="status-item">
                  <span class="status-label">运行时长</span>
                  <span class="status-value">{{ formatDuration(videoStreamStatus.video_duration) }}</span>
                </div>
                <div class="status-item">
                  <span class="status-label">估计FPS</span>
                  <span class="status-value">{{ videoStreamStatus.fps_estimate.toFixed(1) }}</span>
                </div>
                <div class="status-item">
                  <span class="status-label">帧新鲜度</span>
                  <el-tag :type="videoStreamStatus.is_fresh ? 'success' : 'warning'">
                    {{ videoStreamStatus.is_fresh ? '新鲜' : '过期' }}
                  </el-tag>
                </div>
              </div>
            </el-card>
          </el-col>
        </el-row>
        <el-card class="actions-card" shadow="hover" style="margin-top: 20px;">
          <template #header>
            <div class="card-header">
              <span>快速操作</span>
            </div>
          </template>
          <div class="quick-actions">
            <el-button type="primary" @click="activeTab = 'monitor'" class="btn-hover-effect ripple-effect">
              查看实时监控
            </el-button>
            <el-button type="success" @click="activeTab = 'alerts'" class="btn-hover-effect ripple-effect">
              处理告警
            </el-button>
            <el-button type="warning" @click="exportData" class="btn-hover-effect ripple-effect">
              导出数据
            </el-button>
            <el-button type="info" @click="refreshSystem" class="btn-hover-effect ripple-effect">
              刷新系统状态
            </el-button>
          </div>
        </el-card>
      </div>

      <!-- 实时监控（用户端功能） -->
      <div v-show="activeTab === 'monitor'" class="tab-content">
        <el-card class="live-preview-card" shadow="hover">
          <template #header>
            <div class="card-header">
              <span>实时监控预览</span>
              <el-tag type="danger" effect="dark" size="small">LIVE</el-tag>
              <el-button size="small" @click="goToMonitor" class="btn-hover-effect ripple-effect">
                全屏查看
              </el-button>
            </div>
          </template>
          <div class="video-preview-container">
            <div v-if="!videoLoaded" class="video-loading">
              <p>正在加载视频流...</p>
            </div>
            <img 
              v-show="videoLoaded"
              :src="videoStreamUrl" 
              alt="实时监控"
              class="preview-video"
              @load="handleVideoLoad"
              @error="handleVideoError"
            />
            <div v-if="videoError" class="video-error">
              <p>视频流加载失败</p>
              <el-button type="primary" size="small" @click="retryVideo">重试</el-button>
            </div>
          </div>
          <div class="preview-actions">
            <el-button size="small" type="danger" @click="captureScreenshot" class="btn-hover-effect ripple-effect">
              截图保存
            </el-button>
          </div>
        </el-card>
        <el-row :gutter="20" style="margin-top: 20px;">
          <el-col :span="12">
            <el-card shadow="hover">
              <template #header>
                <div class="card-header">
                  <span>人数统计</span>
                </div>
              </template>
              <div class="stat-item">
                <div class="stat-label">当前总人数</div>
                <div class="stat-value">{{ totalPeopleCount }}</div>
              </div>
            </el-card>
          </el-col>
          <el-col :span="12">
            <el-card shadow="hover">
              <template #header>
                <div class="card-header">
                  <span>摄像头状态</span>
                </div>
              </template>
              <div class="camera-status-list">
                <div v-for="camera in cameras" :key="camera.id" class="camera-status-item">
                  <span class="camera-name">摄像头{{ camera.id }}</span>
                  <el-tag :type="camera.connectionState === 'connected' ? 'success' : 'danger'">
                    {{ camera.connectionState === 'connected' ? '在线' : '离线' }}
                  </el-tag>
                  <span v-if="camera.peopleCount > 0" class="camera-people">👥 {{ camera.peopleCount }}人</span>
                </div>
              </div>
            </el-card>
          </el-col>
        </el-row>
      </div>

      <!-- 告警管理（用户端功能） -->
      <div v-show="activeTab === 'alerts'" class="tab-content">
        <el-row :gutter="20">
          <el-col :span="6">
            <el-card class="stat-card" shadow="hover">
              <div class="stat-info">
                <div class="stat-value">{{ alertStats.total }}</div>
                <div class="stat-label">总告警数</div>
              </div>
            </el-card>
          </el-col>
          <el-col :span="6">
            <el-card class="stat-card pending" shadow="hover">
              <div class="stat-info">
                <div class="stat-value">{{ alertStats.pending }}</div>
                <div class="stat-label">待处理</div>
              </div>
            </el-card>
          </el-col>
          <el-col :span="6">
            <el-card class="stat-card resolved" shadow="hover">
              <div class="stat-info">
                <div class="stat-value">{{ alertStats.resolved }}</div>
                <div class="stat-label">已处理</div>
              </div>
            </el-card>
          </el-col>
          <el-col :span="6">
            <el-card class="stat-card high-risk" shadow="hover">
              <div class="stat-info">
                <div class="stat-value">{{ alertStats.highRisk }}</div>
                <div class="stat-label">高风险</div>
              </div>
            </el-card>
          </el-col>
        </el-row>
        <el-card shadow="hover" style="margin-top: 20px;">
          <template #header>
            <div class="card-header">
              <span>告警列表</span>
              <el-button size="small" @click="refreshAlerts" class="btn-hover-effect ripple-effect">刷新</el-button>
            </div>
          </template>
          <div class="alert-list-admin">
            <div v-for="(alert, index) in alertList" :key="index" class="alert-item-admin" :class="{ acknowledged: alert.acknowledged }">
              <div class="alert-header-admin">
                <span class="alert-type-admin">{{ alert.reason || '检测到溺水行为' }}</span>
                <el-tag :type="getLevelTagType(alert.level)" size="small">
                  {{ getLevelText(alert.level) }}
                </el-tag>
              </div>
              <div class="alert-body-admin">
                <span>摄像头{{ alert.cameraId }}</span>
                <span>{{ alert.area }}</span>
                <span>{{ alert.time }}</span>
              </div>
              <div class="alert-footer-admin">
                <el-button v-if="!alert.acknowledged" size="small" type="primary" @click="confirmAlert(alert)">处理</el-button>
                <el-button v-else size="small" type="success">已处理</el-button>
                <el-button size="small" type="danger" @click="deleteAlert(alert)">删除</el-button>
              </div>
            </div>
            <div v-if="alertList.length === 0" class="empty-alerts-admin">
              <el-empty description="暂无告警"></el-empty>
            </div>
          </div>
        </el-card>
      </div>

      <!-- 用户管理 -->
      <div v-show="activeTab === 'users'" class="tab-content">
        <el-card shadow="hover">
          <template #header>
            <div class="card-header">
              <span>用户列表</span>
              <el-button size="small" type="primary" @click="refreshUsers" class="btn-hover-effect ripple-effect">刷新</el-button>
            </div>
          </template>
          <el-table :data="userList" border>
            <el-table-column label="用户名" prop="username" />
            <el-table-column label="用户类型" prop="userType">
              <template #default="scope">
                <el-tag :type="scope.row.userType === 'admin' ? 'danger' : 'success'">
                  {{ scope.row.userType === 'admin' ? '管理员' : '普通用户' }}
                </el-tag>
              </template>
            </el-table-column>
            <el-table-column label="注册时间" prop="createdAt" />
            <el-table-column label="最后登录" prop="lastLogin" />
            <el-table-column label="状态" prop="status">
              <template #default="scope">
                <el-tag :type="scope.row.status === 'online' ? 'success' : 'info'">
                  {{ scope.row.status === 'online' ? '在线' : '离线' }}
                </el-tag>
              </template>
            </el-table-column>
            <el-table-column label="操作">
              <template #default="scope">
                <el-button size="small" @click="viewUserDetail(scope.row)">查看详情</el-button>
                <el-button v-if="scope.row.userType !== 'admin'" size="small" type="danger" @click="deleteUser(scope.row)">删除</el-button>
              </template>
            </el-table-column>
          </el-table>
        </el-card>
        <el-card shadow="hover" style="margin-top: 20px;">
          <template #header>
            <div class="card-header">
              <span>用户统计</span>
            </div>
          </template>
          <el-row :gutter="20">
            <el-col :span="6">
              <div class="user-stat-item">
                <div class="user-stat-value">{{ userStats.total }}</div>
                <div class="user-stat-label">总用户数</div>
              </div>
            </el-col>
            <el-col :span="6">
              <div class="user-stat-item">
                <div class="user-stat-value success">{{ userStats.online }}</div>
                <div class="user-stat-label">在线用户</div>
              </div>
            </el-col>
            <el-col :span="6">
              <div class="user-stat-item">
                <div class="user-stat-value info">{{ userStats.admin }}</div>
                <div class="user-stat-label">管理员</div>
              </div>
            </el-col>
            <el-col :span="6">
              <div class="user-stat-item">
                <div class="user-stat-value warning">{{ userStats.normal }}</div>
                <div class="user-stat-label">普通用户</div>
              </div>
            </el-col>
          </el-row>
        </el-card>
      </div>

      <!-- 系统设置 -->
      <div v-show="activeTab === 'settings'" class="tab-content">
        <el-card shadow="hover">
          <template #header>
            <div class="card-header">
              <span>系统设置</span>
            </div>
          </template>
          <el-form :model="settings" label-width="150px" style="max-width: 600px;">
            <el-form-item label="视频源路径">
              <el-input v-model="settings.videoSource" placeholder="视频文件路径或摄像头索引"></el-input>
            </el-form-item>
            <el-form-item label="水域区域">
              <el-input v-model="settings.waterArea" placeholder="监控水域名称"></el-input>
            </el-form-item>
            <el-form-item label="告警延迟(秒)">
              <el-input-number v-model="settings.alertDelay" :min="1" :max="10"></el-input-number>
            </el-form-item>
            <el-form-item label="置信度阈值">
              <el-slider v-model="settings.confThreshold" :min="0.1" :max="1.0" :step="0.1"></el-slider>
            </el-form-item>
            <el-form-item label="语音告警">
              <el-switch v-model="settings.voiceAlert"></el-switch>
            </el-form-item>
            <el-form-item>
              <el-button type="primary" @click="saveSettings" class="btn-hover-effect ripple-effect">保存设置</el-button>
              <el-button @click="resetSettings" class="btn-hover-effect ripple-effect">恢复默认</el-button>
            </el-form-item>
          </el-form>
        </el-card>
      </div>

      <!-- 性能监控 -->
      <div v-show="activeTab === 'performance'" class="tab-content">
        <el-row :gutter="20">
          <el-col :span="12">
            <el-card class="stat-card" shadow="hover">
              <template #header>
                <div class="card-header">
                  <span>系统性能</span>
                  <el-button size="small" @click="refreshPerformanceData" class="btn-hover-effect ripple-effect">
                    刷新
                  </el-button>
                </div>
              </template>
              <div class="stat-item">
                <div class="stat-label">CPU使用率</div>
                <div class="stat-value">{{ performanceData.cpu.percent }}%</div>
              </div>
              <div class="stat-item">
                <div class="stat-label">内存使用率</div>
                <div class="stat-value">{{ performanceData.memory.percent }}%</div>
              </div>
              <div class="stat-item">
                <div class="stat-label">磁盘使用率</div>
                <div class="stat-value">{{ performanceData.disk.percent }}%</div>
              </div>
              <div class="stat-item">
                <div class="stat-label">网络流量</div>
                <div class="stat-value">
                  <span>↑ {{ performanceData.network.bytes_sent.toFixed(2) }}MB</span>
                  <span style="margin-left: 10px;">↓ {{ performanceData.network.bytes_recv.toFixed(2) }}MB</span>
                </div>
              </div>
            </el-card>
          </el-col>
          <el-col :span="12">
            <el-card class="stat-card" shadow="hover">
              <template #header>
                <div class="card-header">
                  <span>告警统计</span>
                </div>
              </template>
              <div class="stat-item">
                <div class="stat-label">总告警数</div>
                <div class="stat-value">{{ alertTrendData[0]?.alerts || 0 }}</div>
              </div>
              <div class="stat-item">
                <div class="stat-label">已确认</div>
                <div class="stat-value success">{{ alertTrendData[1]?.alerts || 0 }}</div>
              </div>
              <div class="stat-item">
                <div class="stat-label">已解决</div>
                <div class="stat-value success">{{ alertTrendData[2]?.alerts || 0 }}</div>
              </div>
              <div class="stat-item">
                <div class="stat-label">未确认</div>
                <div class="stat-value warning">{{ alertTrendData[3]?.alerts || 0 }}</div>
              </div>
            </el-card>
          </el-col>
        </el-row>
      </div>

      <!-- 活动日志 -->
      <div v-show="activeTab === 'logs'" class="tab-content">
        <el-card shadow="hover">
          <template #header>
            <div class="card-header">
              <span>活动日志</span>
              <el-button size="small" @click="clearLogs" class="btn-hover-effect ripple-effect">清空</el-button>
            </div>
          </template>
          <div class="activity-logs">
            <div v-for="(log, index) in activityLogs" :key="index" class="log-item">
              <div class="log-time">{{ log.time }}</div>
              <div class="log-user">{{ log.user }}</div>
              <div class="log-action">{{ log.action }}</div>
              <div class="log-details">{{ log.details }}</div>
            </div>
            <div v-if="activityLogs.length === 0" class="empty-logs">
              <el-empty description="暂无活动日志"></el-empty>
            </div>
          </div>
        </el-card>
      </div>
    </div>

    <!-- LLM大模型状态对话框 -->
    <el-dialog
      v-model="showLLMDdialog"
      title="语言大模型状态"
      width="600px"
      :close-on-click-modal="false"
    >
      <div class="llm-status-container">
        <el-card shadow="hover" style="margin-bottom: 20px;">
          <template #header>
            <div class="card-header">
              <span>连接状态</span>
              <el-tag :type="llmStatus === 'connected' ? 'success' : llmStatus === 'testing' ? 'warning' : 'info'">
                {{ llmStatusText }}
              </el-tag>
            </div>
          </template>
          <el-descriptions :column="1" border>
            <el-descriptions-item label="提供商">{{ llmConfig.provider || '未配置' }}</el-descriptions-item>
            <el-descriptions-item label="模型">{{ llmConfig.model || '未配置' }}</el-descriptions-item>
            <el-descriptions-item label="API密钥">
              <el-tag :type="llmConfig.api_key_configured ? 'success' : 'danger'">
                {{ llmConfig.api_key_configured ? '已配置' : '未配置' }}
              </el-tag>
            </el-descriptions-item>
            <el-descriptions-item label="降级策略">
              <el-tag :type="llmConfig.fallback_enabled ? 'success' : 'warning'">
                {{ llmConfig.fallback_enabled ? '已启用' : '未启用' }}
              </el-tag>
            </el-descriptions-item>
          </el-descriptions>
        </el-card>
        <el-card v-if="llmTestResult" shadow="hover">
          <template #header>
            <div class="card-header">
              <span>测试结果</span>
            </div>
          </template>
          <el-alert
            :title="llmTestResult.success ? '连接成功' : '连接失败'"
            :type="llmTestResult.success ? 'success' : 'error'"
            :description="llmTestResult.message"
            show-icon
            :closable="false"
            style="margin-bottom: 15px;"
          />
          <div v-if="llmTestResult.response" class="test-response">
            <p><strong>AI回复：</strong></p>
            <p class="response-text">{{ llmTestResult.response }}</p>
          </div>
        </el-card>
        <el-card shadow="hover" style="margin-top: 20px;">
          <template #header>
            <div class="card-header">
              <span>使用说明</span>
            </div>
          </template>
          <ul class="usage-tips">
            <li>系统会自动使用LLM分析溺水事件，生成智能报告</li>
            <li>API调用失败时，系统会自动切换到降级模板</li>
            <li>需要配置API密钥才能使用完整功能</li>
            <li>支持通义千问、文心一言等多种模型</li>
            <li>管理员可在后端配置文件中设置API密钥</li>
          </ul>
        </el-card>
      </div>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="showLLMDdialog = false" class="btn-hover-effect ripple-effect">关闭</el-button>
          <el-button 
            type="primary" 
            @click="testLLMConnection"
            :loading="llmStatus === 'testing'"
            class="btn-hover-effect ripple-effect"
          >
            {{ llmStatus === 'testing' ? '测试中...' : '重新测试' }}
          </el-button>
        </span>
      </template>
    </el-dialog>

    <!-- 智能问答对话框 -->
    <el-dialog
      v-model="showChatDialog"
      title="智能问答"
      width="600px"
      :close-on-click-modal="false"
    >
      <div class="chat-container">
        <div class="chat-messages">
          <div 
            v-for="(message, index) in chatMessages" 
            :key="index"
            class="message-item"
            :class="message.role"
          >
            <div class="message-avatar">
              <span v-if="message.role === 'user'">U</span>
              <span v-else>AI</span>
            </div>
            <div class="message-content">
              <div class="message-text">{{ message.content }}</div>
              <div class="message-time">{{ message.time }}</div>
            </div>
          </div>
          <div v-if="chatLoading" class="message-item assistant">
            <div class="message-avatar">
              <span>AI</span>
            </div>
            <div class="message-content">
              <div class="message-loading">
                正在思考...
              </div>
            </div>
          </div>
        </div>
        <div class="chat-input-area">
          <el-input
            v-model="chatInput"
            type="textarea"
            :rows="3"
            placeholder="请输入您的问题，例如：如何处理溺水事件？"
            @keyup.enter.exact="sendMessage"
          ></el-input>
          <div class="input-actions">
            <span class="tip-text">按 Enter 发送消息</span>
            <el-button 
              type="primary" 
              @click="sendMessage"
              :loading="chatLoading"
              :disabled="!chatInput.trim()"
              class="btn-hover-effect ripple-effect"
            >
              发送
            </el-button>
          </div>
        </div>
      </div>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="showChatDialog = false" class="btn-hover-effect ripple-effect">关闭</el-button>
          <el-button type="primary" @click="clearChat" class="btn-hover-effect ripple-effect">清空对话</el-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted, computed } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import { axios } from '../utils/index.js'
import { useLLM } from '../composables/useLLM.js'
import { alertStore } from '../stores/alertStore.js'

const router = useRouter()
const username = ref(localStorage.getItem('username') || 'admin')
const activeTab = ref('overview')

const showLivePreview = ref(false)
const videoStreamUrl = ref('')
const videoLoaded = ref(false)
const videoError = ref(false)

const todayAlertStats = reactive({
  total: 0,
  handled: 0,
  pending: 0
})

const stats = reactive({
  activeCameras: 0,
  systemStatus: '运行中'
})

const systemUptime = ref('运行中')
const activeUsers = ref(0)
const totalPeopleCount = ref(0)

const cameras = ref([
  { id: 1, connectionState: 'connected', peopleCount: 0 },
  { id: 2, connectionState: 'connected', peopleCount: 0 },
  { id: 3, connectionState: 'offline', peopleCount: 0 },
  { id: 4, connectionState: 'connected', peopleCount: 0 }
])

const alertList = computed(() => alertStore.getAlerts())
const alertStats = computed(() => {
  const stats = alertStore.getStats()
  return {
    total: stats.total,
    pending: stats.pending,
    resolved: stats.resolved,
    highRisk: stats.high,
    mediumRisk: stats.medium,
    lowRisk: stats.low
  }
})

const userList = ref([
  { username: 'admin', userType: 'admin', createdAt: '2026-01-01', lastLogin: '2026-06-09 14:00', status: 'online' },
  { username: 'user', userType: 'user', createdAt: '2026-02-15', lastLogin: '2026-06-09 13:30', status: 'online' },
  { username: 'guard1', userType: 'user', createdAt: '2026-03-20', lastLogin: '2026-06-08 10:00', status: 'offline' }
])

const userStats = reactive({
  total: 3,
  online: 2,
  admin: 1,
  normal: 2
})

const activityLogs = ref([
  { time: '2026-06-09 14:50:00', user: 'admin', action: '登录系统', details: 'IP: 192.168.1.100' },
  { time: '2026-06-09 14:45:00', user: 'admin', action: '查看管理面板', details: '访问管理页面' }
])

const defaultSettings = {
  videoSource: '0',
  waterArea: '主游泳池',
  alertDelay: 3,
  confThreshold: 0.5,
  voiceAlert: true
}

const settings = reactive({ ...defaultSettings })

const performanceData = reactive({
  cpu: { percent: 0 },
  memory: { percent: 0 },
  disk: { percent: 0 },
  network: { bytes_sent: 0, bytes_recv: 0 }
})

const videoStreamStatus = reactive({
  stream_running: false,
  video_duration: 0,
  frame_age: 0,
  is_fresh: false,
  fps_estimate: 0
})

const alertTrendData = ref([
  { time: '总数', alerts: 0 },
  { time: '已确认', alerts: 0 },
  { time: '已解决', alerts: 0 },
  { time: '未确认', alerts: 0 }
])

const {
  showLLMDdialog,
  llmStatus,
  llmConfig,
  llmTestResult,
  llmStatusText,
  testLLMConnection,
  loadLLMConfig,
  getLLMResponse
} = useLLM()

const showChatDialog = ref(false)
const chatInput = ref('')
const chatMessages = ref([])
const chatLoading = ref(false)

onMounted(() => {
  loadTodayAlertStats()
  updateSystemUptime()
  loadLLMConfig()
  refreshPerformanceData()
  loadVideoStreamStatus()
  loadAlertTrendData()
  loadAlerts()
  
  setInterval(() => {
    refreshPerformanceData()
    loadVideoStreamStatus()
  }, 5000)
})

const handleTabClick = (tab) => {
  console.log('切换到标签页:', tab.props.name)
  if (tab.props.name === 'monitor') {
    startVideoPreview()
  }
}

const loadTodayAlertStats = async () => {
  try {
    const response = await axios.get('/alerts/today')
    if (response.data && (response.data.success || response.data.code === 200)) {
      const data = response.data.data
      if (data) {
        todayAlertStats.total = data.total || 0
        todayAlertStats.handled = data.handled || 0
        todayAlertStats.pending = data.pending || 0
      }
    }
  } catch (error) {
    console.error('加载告警统计失败:', error)
  }
}

const updateSystemUptime = () => {
  systemUptime.value = '运行中'
}

const saveSettings = async () => {
  try {
    await axios.post('/config/settings', settings)
    ElMessage.success('配置已保存')
    addActivityLog('系统设置', '更新系统配置')
  } catch (error) {
    ElMessage.error('保存配置失败')
  }
}

const resetSettings = () => {
  Object.assign(settings, defaultSettings)
  ElMessage.info('已恢复默认设置')
}

const addActivityLog = (action, details) => {
  activityLogs.value.unshift({
    time: new Date().toLocaleString('zh-CN'),
    user: username.value,
    action,
    details
  })
  if (activityLogs.value.length > 100) {
    activityLogs.value.pop()
  }
}

const clearLogs = () => {
  ElMessageBox.confirm('确定要清空所有活动日志吗？', '提示', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning'
  }).then(() => {
    activityLogs.value = []
    ElMessage.success('日志已清空')
  }).catch(() => {})
}

const goToMonitor = () => {
  router.push('/monitor')
}

const startVideoPreview = () => {
  videoLoaded.value = false
  videoError.value = false
  if (!videoStreamUrl.value) {
    videoStreamUrl.value = '/api/video_feed'
  }
}

const stopVideoPreview = () => {
  videoStreamUrl.value = ''
  videoLoaded.value = false
  videoError.value = false
}

const handleVideoLoad = () => {
  videoLoaded.value = true
  videoError.value = false
  ElMessage.success('实时监控已连接')
}

const handleVideoError = () => {
  videoError.value = true
  videoLoaded.value = false
  ElMessage.error('视频流连接失败')
}

const retryVideo = () => {
  ElMessage.info('正在重新连接...')
  startVideoPreview()
}

const captureScreenshot = () => {
  const img = document.querySelector('.preview-video')
  if (!img) return
  try {
    const canvas = document.createElement('canvas')
    canvas.width = img.naturalWidth
    canvas.height = img.naturalHeight
    const ctx = canvas.getContext('2d')
    ctx.drawImage(img, 0, 0)
    canvas.toBlob((blob) => {
      const url = URL.createObjectURL(blob)
      const link = document.createElement('a')
      link.href = url
      link.download = `screenshot_${new Date().getTime()}.png`
      link.click()
      URL.revokeObjectURL(url)
      ElMessage.success('截图已保存')
      addActivityLog('截图保存', '保存实时监控截图')
    }, 'image/png')
  } catch (error) {
    ElMessage.error('截图失败')
  }
}

const refreshSystem = async () => {
  ElMessage.info('正在刷新系统状态...')
  await loadTodayAlertStats()
  await loadAlerts()
  await refreshUsers()
  addActivityLog('刷新系统', '手动刷新系统状态')
  ElMessage.success('系统状态已刷新')
}

const exportData = async () => {
  try {
    ElMessage.info('正在准备导出数据...')
    const response = await axios.get('/export/data', {
      responseType: 'blob'
    })
    const url = window.URL.createObjectURL(new Blob([response.data]))
    const link = document.createElement('a')
    link.href = url
    link.setAttribute('download', `drowning_data_${new Date().getTime()}.csv`)
    document.body.appendChild(link)
    link.click()
    link.remove()
    ElMessage.success('数据导出成功')
    addActivityLog('导出数据', '导出系统数据')
  } catch (error) {
    ElMessage.error('数据导出失败')
  }
}

const openChatDialog = () => {
  showChatDialog.value = true
  addActivityLog('智能问答', '打开LLM智能问答对话框')
}

const sendMessage = async () => {
  const message = chatInput.value.trim()
  if (!message) return
  chatMessages.value.push({
    role: 'user',
    content: message,
    time: new Date().toLocaleTimeString('zh-CN')
  })
  chatInput.value = ''
  chatLoading.value = true
  try {
    const { askLLMQuestion } = await import('../utils/index.js')
    const response = await askLLMQuestion(message)
    if (response.code === 200) {
      chatMessages.value.push({
        role: 'assistant',
        content: response.data.answer,
        time: new Date().toLocaleTimeString('zh-CN')
      })
    } else {
      chatMessages.value.push({
        role: 'assistant',
        content: `抱歉，我遇到了一些问题：${response.message || '请稍后重试'}`,
        time: new Date().toLocaleTimeString('zh-CN')
      })
    }
    addActivityLog('智能问答', '与LLM交互')
  } catch (error) {
    console.error('发送消息失败:', error)
    ElMessage.error('获取AI回复失败')
    chatMessages.value.push({
      role: 'assistant',
      content: '网络连接异常，请检查网络后重试',
      time: new Date().toLocaleTimeString('zh-CN')
    })
  } finally {
    chatLoading.value = false
  }
}

const clearChat = () => {
  chatMessages.value = []
  ElMessage.success('对话已清空')
  addActivityLog('智能问答', '清空对话历史')
}

const handleLogout = () => {
  ElMessageBox.confirm('确定要退出登录吗？', '提示', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning'
  }).then(() => {
    localStorage.removeItem('token')
    localStorage.removeItem('username')
    localStorage.removeItem('userType')
    router.push('/login')
    ElMessage.success('已退出登录')
  }).catch(() => {})
}

const refreshPerformanceData = async () => {
  try {
    const response = await axios.get('/system/status')
    if (response.data && response.data.code === 200) {
      const data = response.data.data
      if (data) {
        Object.assign(performanceData, {
          cpu: data.cpu || { percent: 0 },
          memory: data.memory || { percent: 0 },
          disk: data.disk || { percent: 0 },
          network: data.network || { bytes_sent: 0, bytes_recv: 0 }
        })
      }
    }
  } catch (error) {
    console.error('加载系统性能数据失败:', error)
  }
}

const loadVideoStreamStatus = async () => {
  try {
    const response = await axios.get('/video/timestamp')
    if (response.data && response.data.code === 200) {
      const data = response.data.data
      if (data) {
        Object.assign(videoStreamStatus, {
          stream_running: data.stream_running || false,
          video_duration: data.video_duration || 0,
          frame_age: data.frame_age || 0,
          is_fresh: data.is_fresh || false,
          fps_estimate: data.fps_estimate || 0
        })
      }
    }
  } catch (error) {
    console.error('加载视频流状态失败:', error)
  }
}

const loadAlertTrendData = async () => {
  try {
    const response = await axios.get('/alerts/statistics')
    if (response.data && response.data.code === 200) {
      const data = response.data.data
      if (data && typeof data === 'object') {
        alertTrendData.value = [
          { time: '总数', alerts: data.total_alerts || 0 },
          { time: '已确认', alerts: data.total_acknowledged || 0 },
          { time: '已解决', alerts: data.total_resolved || 0 },
          { time: '未确认', alerts: data.unacknowledged_alerts || 0 }
        ]
      }
    }
  } catch (error) {
    console.error('加载告警趋势数据失败:', error)
  }
}

const loadAlerts = async () => {
  try {
    const response = await axios.get('/alerts/list')
    if (response.data && response.data.code === 200) {
      const alerts = response.data.data || []
      alerts.forEach(alert => {
        alertStore.addAlert(alert)
      })
    }
  } catch (error) {
    console.error('加载告警列表失败:', error)
  }
}

const refreshAlerts = async () => {
  await loadAlerts()
  ElMessage.success('告警列表已刷新')
}

const confirmAlert = async (alert) => {
  try {
    await axios.post(`/alerts/acknowledge/${alert.id}`)
    alertStore.updateAlertStatus(String(alert.id), {
      acknowledged: true,
      resolved: false,
      acknowledged_time: new Date().toISOString()
    })
    ElMessage.success('告警已处理')
    addActivityLog('处理告警', `处理告警 ${alert.id}`)
  } catch (error) {
    ElMessage.error('处理告警失败')
  }
}

const deleteAlert = async (alert) => {
  try {
    await ElMessageBox.confirm('确定要删除这条告警吗？', '警告', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    })
    await axios.delete(`/alerts/delete/${alert.id}`)
    alertStore.deleteAlert(String(alert.id))
    ElMessage.success('告警已删除')
    addActivityLog('删除告警', `删除告警 ${alert.id}`)
  } catch (error) {
    if (error !== 'cancel') {
      ElMessage.error('删除告警失败')
    }
  }
}

const refreshUsers = async () => {
  try {
    const response = await axios.get('/users')
    if (response.data && response.data.code === 200) {
      userList.value = response.data.data || userList.value
      userStats.total = userList.value.length
      userStats.online = userList.value.filter(u => u.status === 'online').length
      userStats.admin = userList.value.filter(u => u.userType === 'admin').length
      userStats.normal = userList.value.filter(u => u.userType !== 'admin').length
    }
  } catch (error) {
    console.error('加载用户列表失败:', error)
  }
}

const viewUserDetail = (user) => {
  ElMessage.info(`查看用户 ${user.username} 的详情`)
}

const deleteUser = async (user) => {
  try {
    await ElMessageBox.confirm(`确定要删除用户 ${user.username} 吗？`, '警告', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    })
    await axios.delete(`/users/${user.username}`)
    const index = userList.value.findIndex(u => u.username === user.username)
    if (index > -1) {
      userList.value.splice(index, 1)
    }
    userStats.total--
    if (user.status === 'online') userStats.online--
    if (user.userType === 'admin') userStats.admin--
    else userStats.normal--
    ElMessage.success('用户已删除')
    addActivityLog('删除用户', `删除用户 ${user.username}`)
  } catch (error) {
    if (error !== 'cancel') {
      ElMessage.error('删除用户失败')
    }
  }
}

const getLevelTagType = (level) => {
  const types = { high: 'danger', medium: 'warning', low: 'success' }
  return types[level] || 'info'
}

const getLevelText = (level) => {
  const texts = { high: '高风险', medium: '中风险', low: '低风险' }
  return texts[level] || '未知'
}

const formatDuration = (seconds) => {
  if (!seconds) return '00:00:00'
  const hours = Math.floor(seconds / 3600)
  const minutes = Math.floor((seconds % 3600) / 60)
  const secs = Math.floor(seconds % 60)
  return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`
}
</script>

<style scoped>
.admin-panel {
  height: 100vh;
  display: flex;
  flex-direction: column;
}

.header {
  background: #FFFFFF;
  color: #2D3436;
  padding: 15px 20px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  border-bottom: 1px solid #DFE6E9;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
  font-family: 'Microsoft YaHei', 'PingFang SC', sans-serif;
}

.header-left {
  display: flex;
  align-items: center;
  gap: 15px;
}

.logo-icon {
  width: 40px;
  height: 40px;
  background-color: #DC3545;
  color: #FFFFFF;
  font-size: 24px;
  font-weight: bold;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 4px;
}

.header h1 {
  margin: 0;
  font-size: 20px;
  font-weight: bold;
  color: #2D3436;
}

.header-right {
  display: flex;
  align-items: center;
  gap: 15px;
}

.username {
  font-size: 14px;
  color: #636E72;
}

.tabs-nav {
  background: white;
  padding: 0 20px;
  border-bottom: 1px solid #DFE6E9;
}

.tabs-nav :deep(.el-tabs__header) {
  margin: 0;
}

.main-content {
  flex: 1;
  padding: 20px;
  overflow-y: auto;
  background: #F0F2F5;
}

.tab-content {
  animation: fadeIn 0.3s ease-in;
}

@keyframes fadeIn {
  from { opacity: 0; transform: translateY(10px); }
  to { opacity: 1; transform: translateY(0); }
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.stat-card {
  margin-bottom: 20px;
}

.stat-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 15px 0;
  border-bottom: 1px solid #ebeef5;
}

.stat-item:last-child {
  border-bottom: none;
}

.stat-label {
  color: #606266;
  font-size: 14px;
}

.stat-value {
  font-size: 24px;
  font-weight: bold;
  color: #303133;
}

.stat-value-large {
  font-size: 48px;
  font-weight: bold;
  color: #303133;
  text-align: center;
}

.stat-value-large.success { color: #67c23a; }
.stat-value-large.warning { color: #e6a23c; }
.stat-value-large.info { color: #409eff; }

.stat-value.success { color: #67c23a; }
.stat-value.warning { color: #e6a23c; }
.stat-value.info { color: #409eff; }

.stat-info {
  text-align: center;
}

.stat-card.pending .stat-value { color: #e6a23c; }
.stat-card.resolved .stat-value { color: #67c23a; }
.stat-card.high-risk .stat-value { color: #f56c6c; }

.system-status-info {
  padding: 10px 0;
}

.status-item {
  display: flex;
  justify-content: space-between;
  padding: 10px 0;
  border-bottom: 1px solid #ebeef5;
}

.status-item:last-child {
  border-bottom: none;
}

.status-label {
  color: #606266;
}

.status-value {
  color: #303133;
  font-weight: 500;
}

.quick-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
}

.quick-actions .el-button {
  flex: 1;
  min-width: 150px;
}

.live-preview-card {
  border: 2px solid #409eff;
}

.video-preview-container {
  position: relative;
  width: 100%;
  min-height: 360px;
  background: #000;
  border-radius: 4px;
  overflow: hidden;
  display: flex;
  align-items: center;
  justify-content: center;
}

.preview-video {
  width: 100%;
  height: auto;
  max-height: 720px;
  object-fit: contain;
  display: block;
}

.video-loading, .video-error {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  text-align: center;
  color: white;
}

.video-loading p, .video-error p {
  margin-top: 10px;
  font-size: 14px;
}

.video-error {
  color: #f56c6c;
}

.preview-actions {
  margin-top: 15px;
  display: flex;
  gap: 10px;
  justify-content: center;
}

.camera-status-list {
  padding: 10px 0;
}

.camera-status-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px 0;
  border-bottom: 1px solid #ebeef5;
}

.camera-status-item:last-child {
  border-bottom: none;
}

.camera-name {
  font-weight: 500;
}

.camera-people {
  color: #409eff;
}

.alert-list-admin {
  max-height: 500px;
  overflow-y: auto;
}

.alert-item-admin {
  padding: 15px;
  border-bottom: 1px solid #ebeef5;
  transition: background-color 0.3s;
}

.alert-item-admin:hover {
  background-color: #f5f7fa;
}

.alert-item-admin.acknowledged {
  opacity: 0.6;
}

.alert-header-admin {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 10px;
}

.alert-type-admin {
  font-weight: 600;
  color: #303133;
}

.alert-body-admin {
  display: flex;
  gap: 15px;
  color: #606266;
  font-size: 14px;
  margin-bottom: 10px;
}

.alert-footer-admin {
  display: flex;
  gap: 10px;
  justify-content: flex-end;
}

.empty-alerts-admin {
  padding: 40px 0;
}

.user-stat-item {
  text-align: center;
  padding: 20px 0;
}

.user-stat-value {
  font-size: 32px;
  font-weight: bold;
  color: #303133;
}

.user-stat-value.success { color: #67c23a; }
.user-stat-value.info { color: #409eff; }
.user-stat-value.warning { color: #e6a23c; }

.user-stat-label {
  font-size: 14px;
  color: #909399;
  margin-top: 5px;
}

.activity-logs {
  max-height: 500px;
  overflow-y: auto;
}

.log-item {
  padding: 15px;
  border-bottom: 1px solid #ebeef5;
  transition: background-color 0.3s;
}

.log-item:hover {
  background-color: #f5f7fa;
}

.log-time {
  font-size: 12px;
  color: #909399;
  margin-bottom: 5px;
}

.log-user {
  font-size: 14px;
  color: #409eff;
  font-weight: bold;
  margin-bottom: 5px;
}

.log-action {
  font-size: 14px;
  color: #303133;
  margin-bottom: 5px;
}

.log-details {
  font-size: 12px;
  color: #606266;
}

.empty-logs {
  padding: 40px 0;
}

.llm-status-container {
  padding: 10px;
}

.test-response {
  margin-top: 15px;
  padding: 15px;
  background-color: #f5f7fa;
  border-radius: 4px;
  border-left: 4px solid #409eff;
}

.test-response p {
  margin: 5px 0;
}

.response-text {
  color: #606266;
  line-height: 1.6;
  white-space: pre-wrap;
  word-break: break-word;
}

.usage-tips {
  list-style: none;
  padding: 0;
  margin: 0;
}

.usage-tips li {
  padding: 8px 0;
  line-height: 1.6;
  color: #606266;
  border-bottom: 1px solid #ebeef5;
}

.usage-tips li:last-child {
  border-bottom: none;
}

.chat-container {
  height: 500px;
  display: flex;
  flex-direction: column;
}

.chat-messages {
  flex: 1;
  overflow-y: auto;
  padding: 10px;
  background-color: #f5f7fa;
  border-radius: 4px;
  margin-bottom: 15px;
}

.message-item {
  display: flex;
  margin-bottom: 15px;
  animation: fadeIn 0.3s ease-in;
}

.message-item.user {
  flex-direction: row-reverse;
}

.message-avatar {
  width: 36px;
  height: 36px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  margin: 0 10px;
}

.message-item.user .message-avatar {
  background-color: #409eff;
  color: white;
}

.message-item.assistant .message-avatar {
  background-color: #67c23a;
  color: white;
}

.message-content {
  max-width: 70%;
  display: flex;
  flex-direction: column;
}

.message-item.user .message-content {
  align-items: flex-end;
}

.message-item.assistant .message-content {
  align-items: flex-start;
}

.message-text {
  padding: 10px 14px;
  border-radius: 8px;
  word-break: break-word;
  line-height: 1.5;
  font-size: 14px;
}

.message-item.user .message-text {
  background-color: #409eff;
  color: white;
}

.message-item.assistant .message-text {
  background-color: white;
  color: #333;
  border: 1px solid #e4e7ed;
}

.message-time {
  font-size: 12px;
  color: #999;
  margin-top: 4px;
  padding: 0 4px;
}

.message-loading {
  padding: 10px 14px;
  background-color: white;
  border: 1px solid #e4e7ed;
  border-radius: 8px;
  color: #666;
  font-size: 14px;
}

.chat-input-area {
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.input-actions {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.tip-text {
  font-size: 12px;
  color: #999;
}

@media (max-width: 768px) {
  .stat-item {
    flex-direction: column;
    align-items: flex-start;
    gap: 5px;
  }
  .stat-value {
    font-size: 20px;
  }
  .quick-actions {
    flex-direction: column;
  }
  .quick-actions .el-button {
    width: 100%;
  }
  .video-preview-container {
    min-height: 240px;
  }
  .chat-container {
    height: 400px;
  }
}
</style>