<template>
  <div class="detection-history-page">
    <!-- 顶部导航 -->
    <el-header class="header">
      <div class="header-left">
        <button class="back-btn" @click="goBack">
          <span class="back-icon">←</span>
          返回
        </button>
        <h1>检测历史</h1>
      </div>
      <div class="header-right">
        <el-button type="primary" @click="handleRefresh">刷新列表</el-button>
      </div>
    </el-header>

    <el-main class="main-content">
      <!-- 统计卡片 -->
      <div class="stats-row">
        <el-card class="stat-card">
          <div class="stat-icon">📊</div>
          <div class="stat-info">
            <div class="stat-value">{{ taskList.length }}</div>
            <div class="stat-label">总检测任务</div>
          </div>
        </el-card>
        <el-card class="stat-card completed">
          <div class="stat-icon">✅</div>
          <div class="stat-info">
            <div class="stat-value">{{ completedCount }}</div>
            <div class="stat-label">已完成</div>
          </div>
        </el-card>
        <el-card class="stat-card processing">
          <div class="stat-icon">⏳</div>
          <div class="stat-info">
            <div class="stat-value">{{ processingCount }}</div>
            <div class="stat-label">处理中</div>
          </div>
        </el-card>
        <el-card class="stat-card failed">
          <div class="stat-icon">❌</div>
          <div class="stat-info">
            <div class="stat-value">{{ failedCount }}</div>
            <div class="stat-label">失败</div>
          </div>
        </el-card>
      </div>

      <!-- 搜索和筛选 -->
      <div class="filter-bar">
        <el-input 
          v-model="searchKeyword" 
          placeholder="搜索文件名..." 
          class="search-input"
          @input="handleSearch"
        />
        <el-select v-model="statusFilter" placeholder="状态筛选" class="status-select">
          <el-option label="全部" value="" />
          <el-option label="处理中" value="processing" />
          <el-option label="已完成" value="completed" />
          <el-option label="失败" value="failed" />
        </el-select>
        <el-select v-model="typeFilter" placeholder="文件类型" class="type-select">
          <el-option label="全部" value="" />
          <el-option label="视频" value="video" />
          <el-option label="图片" value="image" />
        </el-select>
      </div>

      <!-- 任务列表 -->
      <el-card class="task-list-card" v-if="filteredTasks.length > 0">
        <template #header>
          <span class="card-title">检测任务列表</span>
          <span class="card-count">共 {{ filteredTasks.length }} 条记录</span>
        </template>
        
        <div class="task-list">
          <div 
            class="task-card" 
            v-for="task in filteredTasks" 
            :key="task.task_id"
            @click="viewTask(task)"
          >
            <div class="task-thumbnail">
              <img 
                v-if="getTaskPreview(task)" 
                :src="getTaskPreview(task)" 
                :alt="task.filename"
                class="preview-image"
              />
              <div v-else class="no-preview">
                <span class="file-icon">{{ task.file_type === 'image' ? '🖼️' : '🎬' }}</span>
              </div>
            </div>
            <div class="task-info">
              <div class="task-filename">{{ task.filename }}</div>
              <div class="task-meta">
                <span class="task-type">{{ task.file_type === 'image' ? '图片' : '视频' }}</span>
                <span class="task-date">{{ formatDate(task.created_at) }}</span>
              </div>
              <div class="task-stats">
                <span class="stat-item">
                  <i class="el-icon-files"></i>
                  {{ task.total_frames || 1 }} 帧
                </span>
                <span class="stat-item" v-if="task.drowning_events?.length > 0">
                  <i class="el-icon-warning"></i>
                  {{ task.drowning_events.length }} 告警
                </span>
              </div>
            </div>
            <div class="task-status">
              <el-tag 
                :type="getStatusTagType(task.status)" 
                size="small"
                class="status-tag"
              >
                {{ getStatusText(task.status) }}
              </el-tag>
              <div v-if="task.status === 'processing'" class="progress-container">
                <el-progress 
                  :percentage="task.progress || 0" 
                  :stroke-width="6"
                  :show-text="false"
                  class="task-progress"
                />
                <span class="progress-text">{{ Math.round(task.progress || 0) }}%</span>
              </div>
            </div>
            <div class="task-actions">
              <el-button size="small" @click.stop="viewTask(task)">查看</el-button>
              <el-button 
                size="small" 
                type="danger" 
                @click.stop="deleteTask(task.task_id)"
              >删除</el-button>
            </div>
          </div>
        </div>
      </el-card>

      <!-- 空状态 -->
      <div class="empty-state" v-else>
        <div class="empty-icon">📋</div>
        <div class="empty-title">暂无检测任务</div>
        <div class="empty-desc">点击右上角"上传视频检测"按钮开始检测</div>
        <el-button type="primary" @click="goToUpload">去检测</el-button>
      </div>
    </el-main>

    <!-- 任务详情弹窗 -->
    <el-dialog 
      :visible="showDetailDialog" 
      :title="currentTask?.filename || '检测详情'"
      width="90%"
      :close-on-click-modal="false"
      @close="closeDetailDialog"
    >
      <div class="detail-content" v-if="currentTask">
        <!-- 视频/图片预览 -->
        <div class="preview-section">
          <div class="preview-header">
            <span class="section-title">检测预览</span>
            <div class="preview-controls" v-if="currentTask.file_type === 'video'">
              <button class="control-btn" @click="playVideo">
                <span>▶️</span> 播放
              </button>
              <button class="control-btn" @click="pauseVideo">
                <span>⏸️</span> 暂停
              </button>
            </div>
          </div>
          <div class="preview-container">
            <img 
              v-if="currentTask.current_frame && isValidBase64(currentTask.current_frame)" 
              :src="`data:image/jpeg;base64,${currentTask.current_frame}`" 
              class="preview-image-large"
            />
            <div v-else-if="currentTask.saved_images?.length > 0" class="image-carousel">
              <img 
                :src="getSavedImageUrl(currentTask.task_id, currentTask.saved_images[0].filename)" 
                class="preview-image-large"
              />
            </div>
            <div v-else class="no-preview-large">
              <span class="no-preview-icon">📷</span>
              <span>暂无预览图片</span>
            </div>
          </div>
        </div>

        <!-- 检测信息 -->
        <div class="info-section">
          <div class="section-title">检测信息</div>
          <el-descriptions :column="3" border size="small">
            <el-descriptions-item label="任务ID">
              <span class="mono-text">{{ currentTask.task_id }}</span>
            </el-descriptions-item>
            <el-descriptions-item label="文件类型">
              <el-tag :type="currentTask.file_type === 'image' ? 'success' : 'info'">
                {{ currentTask.file_type === 'image' ? '图片' : '视频' }}
              </el-tag>
            </el-descriptions-item>
            <el-descriptions-item label="状态">
              <el-tag :type="getStatusTagType(currentTask.status)">
                {{ getStatusText(currentTask.status) }}
              </el-tag>
            </el-descriptions-item>
            <el-descriptions-item label="总帧数">
              {{ currentTask.total_frames || 1 }} 帧
            </el-descriptions-item>
            <el-descriptions-item label="处理进度">
              {{ Math.round(currentTask.progress || 0) }}%
            </el-descriptions-item>
            <el-descriptions-item label="告警数量">
              <span :class="currentTask.drowning_events?.length > 0 ? 'alert-count' : ''">
                {{ currentTask.drowning_events?.length || 0 }}
              </span>
            </el-descriptions-item>
            <el-descriptions-item label="创建时间" :span="2">
              {{ formatFullDate(currentTask.created_at) }}
            </el-descriptions-item>
            <el-descriptions-item label="完成时间">
              {{ currentTask.completed_at ? formatFullDate(currentTask.completed_at) : '-' }}
            </el-descriptions-item>
          </el-descriptions>
        </div>

        <!-- 检测结果截图 -->
        <div class="images-section" v-if="currentTask.saved_images?.length > 0">
          <div class="section-title">检测结果截图 ({{ currentTask.saved_images.length }})</div>
          <div class="images-grid">
            <div 
              class="image-item" 
              v-for="(img, index) in currentTask.saved_images" 
              :key="index"
              @click="showImagePreview(img)"
            >
              <img 
                :src="getSavedImageUrl(currentTask.task_id, img.filename)" 
                :alt="img.filename"
                class="thumbnail-image"
              />
              <div class="image-info">
                <span class="image-frame">帧 {{ img.frame }}</span>
                <span class="image-time">{{ formatTime(img.timestamp) }}</span>
              </div>
            </div>
          </div>
        </div>

        <!-- 告警事件列表 -->
        <div class="events-section" v-if="currentTask.drowning_events?.length > 0">
          <div class="section-title">告警事件 ({{ currentTask.drowning_events.length }})</div>
          <el-table :data="currentTask.drowning_events" border>
            <el-table-column label="帧号" prop="frame" width="80" />
            <el-table-column label="时间" prop="timestamp" width="100">
              <template #default="scope">
                {{ formatTime(scope.row.timestamp) }}
              </template>
            </el-table-column>
            <el-table-column label="类型" prop="type" width="120">
              <template #default="scope">
                <el-tag :type="scope.row.class_id === 1 ? 'danger' : 'warning'">
                  {{ scope.row.type }}
                </el-tag>
              </template>
            </el-table-column>
            <el-table-column label="置信度" prop="confidence" width="100">
              <template #default="scope">
                {{ (scope.row.confidence * 100).toFixed(1) }}%
              </template>
            </el-table-column>
            <el-table-column label="检测框" prop="bbox">
              <template #default="scope">
                <span class="mono-text small">
                  {{ scope.row.bbox.join(', ') }}
                </span>
              </template>
            </el-table-column>
          </el-table>
        </div>

        <!-- 错误信息 -->
        <div class="error-section" v-if="currentTask.error_message">
          <div class="section-title">错误信息</div>
          <el-alert 
            type="error" 
            :title="currentTask.error_message" 
            :closable="false"
          />
        </div>
      </div>
    </el-dialog>

    <!-- 图片预览弹窗 -->
    <el-dialog 
      :visible="showImageDialog" 
      title="检测截图"
      width="80%"
      :close-on-click-modal="true"
      @close="showImageDialog = false"
    >
      <div class="image-preview-content">
        <img :src="previewImageUrl" class="preview-image-full" />
        <div class="image-meta" v-if="previewImageInfo">
          <span>帧 {{ previewImageInfo.frame }}</span>
          <span>{{ formatTime(previewImageInfo.timestamp) }}</span>
        </div>
      </div>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import { useVideoDetection } from '../composables/useVideoDetection.js'
import { isValidBase64 } from '../utils/api.js'

const router = useRouter()

const {
  taskList,
  loadTaskList,
  viewTaskResult,
  deleteTask,
  detectionResult
} = useVideoDetection()

// 状态
const showDetailDialog = ref(false)
const currentTask = ref(null)
const searchKeyword = ref('')
const statusFilter = ref('')
const typeFilter = ref('')
const showImageDialog = ref(false)
const previewImageUrl = ref('')
const previewImageInfo = ref(null)

// 计算属性
const completedCount = computed(() => taskList.value.filter(t => t.status === 'completed').length)
const processingCount = computed(() => taskList.value.filter(t => t.status === 'processing').length)
const failedCount = computed(() => taskList.value.filter(t => t.status === 'failed').length)

const filteredTasks = computed(() => {
  return taskList.value.filter(task => {
    // 搜索过滤
    if (searchKeyword.value && !task.filename?.toLowerCase().includes(searchKeyword.value.toLowerCase())) {
      return false
    }
    // 状态过滤
    if (statusFilter.value && task.status !== statusFilter.value) {
      return false
    }
    // 类型过滤
    if (typeFilter.value && task.file_type !== typeFilter.value) {
      return false
    }
    return true
  })
})

// 方法
const goBack = () => {
  router.push('/monitor')
}

const goToUpload = () => {
  router.push('/monitor')
}

const handleRefresh = async () => {
  await loadTaskList()
  ElMessage.success('列表已刷新')
}

const handleSearch = () => {
  // 搜索逻辑由计算属性处理
}

const viewTask = async (task) => {
  await viewTaskResult(task.task_id)
  currentTask.value = detectionResult.value?.data || task
  showDetailDialog.value = true
}

const closeDetailDialog = () => {
  showDetailDialog.value = false
  currentTask.value = null
}

const deleteTaskConfirm = async (taskId) => {
  try {
    await ElMessageBox.confirm('确定要删除此任务吗？', '提示', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    })
    await deleteTask(taskId)
    ElMessage.success('任务已删除')
  } catch (error) {
    if (error !== 'cancel') {
      console.error('删除任务失败:', error)
    }
  }
}

const showImagePreview = (img) => {
  if (currentTask.value) {
    previewImageUrl.value = getSavedImageUrl(currentTask.value.task_id, img.filename)
    previewImageInfo.value = img
    showImageDialog.value = true
  }
}

const getSavedImageUrl = (taskId, filename) => {
  return `/api/detection/results/images/${taskId}/${filename}`
}

const getTaskPreview = (task) => {
  if (task.current_frame && isValidBase64(task.current_frame)) {
    return `data:image/jpeg;base64,${task.current_frame}`
  }
  if (task.saved_images?.length > 0) {
    return getSavedImageUrl(task.task_id, task.saved_images[0].filename)
  }
  return null
}

const getStatusTagType = (status) => {
  const types = {
    'pending': 'info',
    'processing': 'warning',
    'completed': 'success',
    'failed': 'danger'
  }
  return types[status] || 'info'
}

const getStatusText = (status) => {
  const texts = {
    'pending': '待处理',
    'processing': '处理中',
    'completed': '已完成',
    'failed': '失败'
  }
  return texts[status] || status
}

const formatDate = (dateStr) => {
  if (!dateStr) return '-'
  const date = new Date(dateStr)
  return date.toLocaleDateString('zh-CN', {
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  })
}

const formatFullDate = (dateStr) => {
  if (!dateStr) return '-'
  const date = new Date(dateStr)
  return date.toLocaleString('zh-CN')
}

const formatTime = (seconds) => {
  if (!seconds) return '0:00'
  const mins = Math.floor(seconds / 60)
  const secs = Math.floor(seconds % 60)
  return `${mins}:${secs.toString().padStart(2, '0')}`
}

const playVideo = () => {
  ElMessage.info('视频播放功能开发中')
}

const pauseVideo = () => {
  ElMessage.info('视频暂停功能开发中')
}

// 挂载时加载任务列表
onMounted(() => {
  loadTaskList()
})
</script>

<style scoped>
.detection-history-page {
  min-height: 100vh;
  background-color: #F0F2F5;
  display: flex;
  flex-direction: column;
  font-family: 'Microsoft YaHei', 'PingFang SC', sans-serif;
}

.header {
  background: #FFFFFF;
  color: #2D3436;
  padding: 15px 20px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  border-bottom: 1px solid #DFE6E9;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
}

.header-left {
  display: flex;
  align-items: center;
  gap: 15px;
}

.back-btn {
  background: #F0F2F5;
  border: 1px solid #DFE6E9;
  color: #2D3436;
  padding: 8px 15px;
  border-radius: 4px;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 5px;
  transition: background 0.3s;
}

.back-btn:hover {
  background: #E8EAED;
}

.back-icon {
  font-size: 16px;
}

.header h1 {
  margin: 0;
  font-size: 18px;
}

.main-content {
  flex: 1;
  padding: 20px;
  overflow-y: auto;
}

.stats-row {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 15px;
  margin-bottom: 20px;
}

.stat-card {
  display: flex;
  align-items: center;
  gap: 15px;
  padding: 20px;
  background: white;
  border-radius: 4px;
  border: 1px solid #DFE6E9;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
}

.stat-card.completed .stat-value { color: #00B894; }
.stat-card.processing .stat-value { color: #FDCB6E; }
.stat-card.failed .stat-value { color: #D63031; }

.stat-icon {
  font-size: 32px;
  width: 50px;
  height: 50px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #f5f7fa;
  border-radius: 12px;
}

.stat-info {
  flex: 1;
}

.stat-value {
  font-size: 24px;
  font-weight: bold;
  color: #303133;
}

.stat-label {
  font-size: 13px;
  color: #909399;
}

.filter-bar {
  display: flex;
  gap: 15px;
  margin-bottom: 20px;
}

.search-input {
  flex: 1;
  max-width: 300px;
}

.status-select, .type-select {
  width: 150px;
}

.task-list-card {
  background: white;
  border-radius: 12px;
}

.card-title {
  font-weight: 600;
}

.card-count {
  color: #909399;
  font-size: 13px;
}

.task-list {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.task-card {
  display: flex;
  align-items: center;
  gap: 15px;
  padding: 15px;
  background: #fafafa;
  border-radius: 10px;
  cursor: pointer;
  transition: all 0.3s;
  border: 1px solid transparent;
}

.task-card:hover {
  background: #f0f0f0;
  border-color: #409eff;
}

.task-thumbnail {
  width: 80px;
  height: 60px;
  border-radius: 8px;
  overflow: hidden;
  background: #e8e8e8;
  flex-shrink: 0;
}

.preview-image {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.no-preview {
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
}

.file-icon {
  font-size: 24px;
}

.task-info {
  flex: 1;
  min-width: 0;
}

.task-filename {
  font-weight: 500;
  color: #303133;
  margin-bottom: 5px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.task-meta {
  display: flex;
  gap: 10px;
  margin-bottom: 5px;
}

.task-type {
  font-size: 12px;
  color: #67c23a;
  background: rgba(103, 194, 58, 0.1);
  padding: 2px 8px;
  border-radius: 10px;
}

.task-date {
  font-size: 12px;
  color: #909399;
}

.task-stats {
  display: flex;
  gap: 15px;
}

.stat-item {
  font-size: 12px;
  color: #606266;
  display: flex;
  align-items: center;
  gap: 4px;
}

.task-status {
  text-align: center;
  min-width: 100px;
}

.status-tag {
  margin-bottom: 8px;
}

.progress-container {
  display: flex;
  align-items: center;
  gap: 8px;
}

.task-progress {
  flex: 1;
  width: 80px;
}

.progress-text {
  font-size: 12px;
  color: #606266;
}

.task-actions {
  display: flex;
  gap: 8px;
}

.empty-state {
  text-align: center;
  padding: 60px 20px;
}

.empty-icon {
  font-size: 64px;
  margin-bottom: 20px;
}

.empty-title {
  font-size: 18px;
  font-weight: 600;
  color: #303133;
  margin-bottom: 10px;
}

.empty-desc {
  color: #909399;
  margin-bottom: 20px;
}

/* 详情弹窗样式 */
.detail-content {
  max-height: 70vh;
  overflow-y: auto;
}

.section-title {
  font-size: 16px;
  font-weight: 600;
  color: #303133;
  margin-bottom: 15px;
}

.preview-section {
  margin-bottom: 20px;
}

.preview-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 10px;
}

.preview-controls {
  display: flex;
  gap: 10px;
}

.control-btn {
  background: #f5f7fa;
  border: 1px solid #dcdfe6;
  padding: 6px 12px;
  border-radius: 6px;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 5px;
  font-size: 13px;
}

.control-btn:hover {
  background: #e4e7ed;
}

.preview-container {
  width: 100%;
  height: 400px;
  background: #000;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
}

.preview-image-large {
  max-width: 100%;
  max-height: 100%;
  object-fit: contain;
}

.no-preview-large {
  color: #666;
  text-align: center;
}

.no-preview-icon {
  font-size: 48px;
  display: block;
  margin-bottom: 10px;
}

.info-section {
  margin-bottom: 20px;
}

.mono-text {
  font-family: monospace;
  font-size: 12px;
  color: #606266;
}

.mono-text.small {
  font-size: 11px;
}

.alert-count {
  color: #f56c6c;
  font-weight: bold;
}

.images-section {
  margin-bottom: 20px;
}

.images-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
  gap: 15px;
}

.image-item {
  cursor: pointer;
  border-radius: 8px;
  overflow: hidden;
  background: #f5f7fa;
}

.thumbnail-image {
  width: 100%;
  height: 120px;
  object-fit: cover;
}

.image-info {
  padding: 8px;
  display: flex;
  justify-content: space-between;
  font-size: 12px;
  color: #606266;
}

.events-section {
  margin-bottom: 20px;
}

.error-section {
  margin-bottom: 20px;
}

/* 图片预览弹窗 */
.image-preview-content {
  text-align: center;
}

.preview-image-full {
  max-width: 100%;
  max-height: 60vh;
  object-fit: contain;
}

.image-meta {
  margin-top: 15px;
  display: flex;
  justify-content: center;
  gap: 20px;
  font-size: 14px;
  color: #606266;
}
</style>