<template>
  <div class="alert-management">
    <!-- 顶部导航 -->
    <div class="page-header">
      <div class="header-content">
        <div class="header-left">
          <h1>告警管理中心</h1>
          <el-tag v-if="unreadCount > 0" type="danger" effect="dark">
            {{ unreadCount }} 条未读
          </el-tag>
        </div>
        <div class="header-right">
          <el-button @click="toggleSettings">
            设置
          </el-button>
          <el-button @click="goBack">
            返回
          </el-button>
          <el-button type="primary" @click="refreshAlerts">
            刷新
          </el-button>
          <el-button 
            v-if="selectedAlerts.length > 0"
            type="warning" 
            @click="batchAcknowledge"
          >
            批量处理 ({{ selectedAlerts.length }})
          </el-button>
          <el-button 
            v-if="selectedAlerts.length > 0"
            type="danger" 
            @click="batchDelete"
          >
            批量删除 ({{ selectedAlerts.length }})
          </el-button>
          <el-button 
            v-if="alertList.length > 0"
            type="danger" 
            @click="handleDeleteAllAlerts"
          >
            删除全部
          </el-button>
          <el-button @click="exportAlerts">
            导出
          </el-button>
          <el-button type="danger" @click="handleLogout">
            退出登录
          </el-button>
        </div>
      </div>
    </div>

    <!-- 统计卡片 -->
    <div class="stats-section">
      <el-row :gutter="16">
        <el-col :span="4">
          <el-card class="stat-card total" shadow="hover">
            <div class="stat-icon-wrapper">
              <WarningFilled class="stat-icon" />
            </div>
            <div class="stat-info">
              <div class="stat-value">{{ alertStats.total }}</div>
              <div class="stat-label">总告警数</div>
            </div>
          </el-card>
        </el-col>
        <el-col :span="4">
          <el-card class="stat-card pending" shadow="hover">
            <div class="stat-icon-wrapper">
              <WarningFilled class="stat-icon" />
            </div>
            <div class="stat-info">
              <div class="stat-value">{{ alertStats.pending }}</div>
              <div class="stat-label">待处理</div>
            </div>
          </el-card>
        </el-col>
        <el-col :span="4">
          <el-card class="stat-card resolved" shadow="hover">
            <div class="stat-icon-wrapper">
              <CircleCheck class="stat-icon" />
            </div>
            <div class="stat-info">
              <div class="stat-value">{{ alertStats.resolved }}</div>
              <div class="stat-label">已处理</div>
            </div>
          </el-card>
        </el-col>
        <el-col :span="4">
          <el-card class="stat-card high-risk" shadow="hover">
            <div class="stat-icon-wrapper">
              <WarningFilled class="stat-icon" />
            </div>
            <div class="stat-info">
              <div class="stat-value">{{ alertStats.highRisk }}</div>
              <div class="stat-label">高风险</div>
            </div>
          </el-card>
        </el-col>
        <el-col :span="4">
          <el-card class="stat-card medium-risk" shadow="hover">
            <div class="stat-icon-wrapper">
              <WarningFilled class="stat-icon" />
            </div>
            <div class="stat-info">
              <div class="stat-value">{{ alertStats.mediumRisk }}</div>
              <div class="stat-label">中风险</div>
            </div>
          </el-card>
        </el-col>
        <el-col :span="4">
          <el-card class="stat-card low-risk" shadow="hover">
            <div class="stat-icon-wrapper">
              <CircleCheck class="stat-icon" />
            </div>
            <div class="stat-info">
              <div class="stat-value">{{ alertStats.lowRisk }}</div>
              <div class="stat-label">低风险</div>
            </div>
          </el-card>
        </el-col>
      </el-row>
    </div>

    <!-- 趋势图表区域 -->
    <div class="trend-section">
      <el-card shadow="hover">
        <template #header>
          <div class="card-header">
            <span class="card-title">告警趋势（最近7天）</span>
            <div class="card-actions">
              <el-button-group>
                <el-button size="small" :type="viewMode === 'card' ? 'primary' : ''" @click="viewMode = 'card'">卡片视图</el-button>
                <el-button size="small" :type="viewMode === 'table' ? 'primary' : ''" @click="viewMode = 'table'">表格视图</el-button>
              </el-button-group>
            </div>
          </div>
        </template>
        <div class="trend-chart">
          <div v-for="(item, index) in trendData" :key="index" class="trend-item">
            <div class="trend-date">{{ item.date }}</div>
            <div class="trend-bars">
              <div class="trend-bar high" :style="{ height: item.high * 20 + 'px' }">
                <span class="bar-value">{{ item.high }}</span>
              </div>
              <div class="trend-bar medium" :style="{ height: item.medium * 20 + 'px' }">
                <span class="bar-value">{{ item.medium }}</span>
              </div>
              <div class="trend-bar low" :style="{ height: item.low * 20 + 'px' }">
                <span class="bar-value">{{ item.low }}</span>
              </div>
            </div>
            <div class="trend-total">总计: {{ item.total }}</div>
          </div>
        </div>
        <div class="trend-legend">
          <div class="legend-item">
            <span class="legend-color high"></span>
            <span>高风险</span>
          </div>
          <div class="legend-item">
            <span class="legend-color medium"></span>
            <span>中风险</span>
          </div>
          <div class="legend-item">
            <span class="legend-color low"></span>
            <span>低风险</span>
          </div>
        </div>
      </el-card>
    </div>

    <!-- 筛选区域 -->
    <div class="filter-section">
      <el-row :gutter="16" align="middle">
        <el-col :span="4">
          <el-select v-model="filter.level" placeholder="风险级别" class="filter-select" clearable>
            <el-option label="全部" value="" />
            <el-option label="高风险" value="high" />
            <el-option label="中风险" value="medium" />
            <el-option label="低风险" value="low" />
          </el-select>
        </el-col>
        <el-col :span="4">
          <el-select v-model="filter.status" placeholder="告警状态" class="filter-select" clearable>
            <el-option label="全部" value="" />
            <el-option label="待处理" value="pending" />
            <el-option label="已处理" value="resolved" />
            <el-option label="未读" value="unread" />
          </el-select>
        </el-col>
        <el-col :span="4">
          <el-select v-model="filter.cameraId" placeholder="摄像头" class="filter-select" clearable>
            <el-option label="全部" value="" />
            <el-option 
              v-for="camera in cameras" 
              :key="camera.id" 
              :label="`摄像头 ${camera.id}`" 
              :value="camera.id" 
            />
          </el-select>
        </el-col>
        <el-col :span="6">
          <el-date-picker
            v-model="dateRange"
            type="daterange"
            range-separator="至"
            start-placeholder="开始日期"
            end-placeholder="结束日期"
            class="filter-date"
            clearable
          />
        </el-col>
        <el-col :span="4">
          <el-input 
            v-model="filter.keyword" 
            placeholder="搜索告警信息..." 
            class="filter-input"
            prefix-icon="Search"
            clearable
          />
        </el-col>
        <el-col :span="2">
          <el-button type="primary" @click="applyFilter">应用筛选</el-button>
        </el-col>
      </el-row>
    </div>

    <!-- 告警列表 - 使用虚拟滚动 -->
    <div class="alert-list-section">
      <div class="list-header">
        <el-checkbox v-model="selectAll" @change="handleSelectAll" />
        <span class="list-title">告警列表 ({{ filteredAlerts.length }})</span>
        <div v-if="selectedAlerts.length > 0" class="selected-info">
          已选择 {{ selectedAlerts.length }} 条
        </div>
      </div>
      
      <div v-if="viewMode === 'table'" class="table-mode">
        <VirtualAlertTable
          :alerts="paginatedAlerts"
          :selectedIndex="selectedIndex"
          :processingIndex="processingIndex"
          :selectedAlerts="selectedAlerts"
          @row-click="handleRowClick"
          @view-detail="viewAlertDetail"
          @confirm="handleAlert"
          @delete="handleDeleteAlert"
          @select-row="handleSelectRow"
          @select-all="handleSelectAll"
        />
      </div>
      
      <div v-else class="card-mode">
        <div class="card-grid">
          <div 
            v-for="(alert, index) in paginatedAlerts" 
            :key="alert.alertId"
            class="alert-card"
            :class="['level-' + alert.level, { 
              active: selectedIndex === index,
              acknowledged: alert.acknowledged,
              unread: !alert.read && !alert.acknowledged,
              selected: selectedAlerts.includes(alert.alertId)
            }]"
            @click="handleRowClick(alert, index)"
          >
            <div class="card-checkbox">
              <el-checkbox :model-value="selectedAlerts.includes(alert.alertId)" @click.stop="handleSelectRow(alert)" />
            </div>
            <div class="card-content">
              <div class="card-header">
                <div class="alert-type">
                  <span>{{ alert.reason || '未知告警' }}</span>
                </div>
                <div class="card-actions">
                  <el-tag :type="getLevelTagType(alert.level)" size="small">
                    {{ getLevelText(alert.level) }}
                  </el-tag>
                  <div v-if="alert.acknowledged" class="status-badge success">已处理</div>
                </div>
              </div>
              
              <div class="card-info">
                <div class="info-item">
                  <span>摄像头 {{ alert.cameraId }}</span>
                </div>
                <div class="info-item">
                  <span>{{ alert.area }}</span>
                </div>
                <div class="info-item">
                  <span>{{ formatTime(alert.time) }}</span>
                </div>
              </div>
              
              <div class="card-footer">
                <div class="alert-actions">
                  <el-button 
                    v-if="!alert.acknowledged"
                    size="small"
                    type="primary" 
                    @click.stop="handleAlert(alert, index)"
                    :loading="processingIndex === index"
                  >
                    处理
                  </el-button>
                  <el-button 
                    size="small"
                    type="danger" 
                    @click.stop="handleDeleteAlert(alert)"
                  >
                    删除
                  </el-button>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div v-if="filteredAlerts.length === 0" class="alert-empty-state">
          <h4>暂无告警</h4>
          <p>系统运行正常，没有检测到任何异常</p>
        </div>
      </div>

      <!-- 分页 -->
      <div class="pagination-section">
        <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page="currentPage"
          :page-sizes="[10, 20, 50, 100]"
          :page-size="pageSize"
          :total="filteredAlerts.length"
          layout="total, sizes, prev, pager, next, jumper"
        />
      </div>
    </div>

    <!-- 告警详情弹窗 -->
    <el-dialog 
      v-model="showDetailDialog" 
      title="告警详情" 
      width="900px"
      :close-on-click-modal="false"
    >
      <div class="alert-detail" v-if="selectedAlert">
        <el-descriptions :column="2" border>
          <el-descriptions-item label="告警ID" span="2">
            <span class="detail-value">{{ selectedAlert.id || selectedAlert.alertId }}</span>
          </el-descriptions-item>
          <el-descriptions-item label="告警级别">
            <el-tag :type="getLevelTagType(selectedAlert.level)" size="large">
              {{ getLevelText(selectedAlert.level) }}
            </el-tag>
          </el-descriptions-item>
          <el-descriptions-item label="告警原因">
            <span class="detail-value">{{ selectedAlert.reason || '未知告警' }}</span>
          </el-descriptions-item>
          <el-descriptions-item label="摄像头ID">
            <span class="detail-value">摄像头 {{ selectedAlert.cameraId }}</span>
          </el-descriptions-item>
          <el-descriptions-item label="区域">
            <span class="detail-value">{{ selectedAlert.area || '未知区域' }}</span>
          </el-descriptions-item>
          <el-descriptions-item label="触发时间">
            <span class="detail-value">{{ formatTime(selectedAlert.time) }}</span>
          </el-descriptions-item>
          <el-descriptions-item label="溺水开始时间">
            <span class="detail-value">{{ selectedAlert.drowningStartTime ? formatTime(selectedAlert.drowningStartTime) : '-' }}</span>
          </el-descriptions-item>
          <el-descriptions-item label="状态">
            <el-tag :type="selectedAlert.acknowledged ? 'success' : 'warning'" size="medium">
              {{ selectedAlert.acknowledged ? '已处理' : '待处理' }}
            </el-tag>
            <el-tag v-if="selectedAlert.read" type="info" size="medium" style="margin-left: 8px;">已读</el-tag>
          </el-descriptions-item>
          <el-descriptions-item label="处理时间" v-if="selectedAlert.acknowledged_time">
            <span class="detail-value">{{ formatTime(selectedAlert.acknowledged_time) }}</span>
          </el-descriptions-item>
          <el-descriptions-item label="是否已解决">
            <el-tag :type="selectedAlert.resolved ? 'success' : 'info'" size="medium">
              {{ selectedAlert.resolved ? '已解决' : '未解决' }}
            </el-tag>
          </el-descriptions-item>
        </el-descriptions>
        
        <!-- 视频回放区域 -->
        <div class="alert-video-section" v-if="selectedAlert.videoPath || selectedAlert.video_url">
          <el-divider content-position="left">关联录像回放</el-divider>
          <div class="video-container">
            <video 
              ref="videoPlayer"
              class="alert-video"
              :src="getVideoUrl(selectedAlert)"
              controls
              autoplay
              loop
              muted
            >
              您的浏览器不支持HTML5视频播放
            </video>
            <div v-if="!selectedAlert.videoPath && !selectedAlert.video_url" class="video-placeholder">
              <el-empty description="暂无关联录像" />
            </div>
          </div>
        </div>
        
        <div class="alert-detail-actions" v-if="selectedAlert">
          <el-divider content-position="left">快捷操作</el-divider>
          <div class="detail-action-buttons">
            <el-button 
              v-if="!selectedAlert.acknowledged"
              type="primary" 
              @click="handleAlert(selectedAlert)"
            >
              处理告警
            </el-button>
            <el-button 
              v-if="!selectedAlert.resolved && selectedAlert.acknowledged"
              type="success" 
              @click="resolveAlert(selectedAlert)"
            >
              标记已解决
            </el-button>
            <el-button 
              type="danger" 
              @click="handleDeleteAlert(selectedAlert)"
            >
              删除告警
            </el-button>
          </div>
        </div>
      </div>

      <template #footer>
        <span class="dialog-footer">
          <el-button @click="showDetailDialog = false">关闭</el-button>
          <el-button 
            v-if="selectedAlert && !selectedAlert.acknowledged"
            type="primary" 
            @click="handleAlert(selectedAlert)"
          >
            处理告警
          </el-button>
        </span>
      </template>
    </el-dialog>

    <!-- 设置弹窗 -->
    <el-dialog 
      v-model="showSettingsDialog" 
      title="通知设置" 
      width="400px"
    >
      <div class="settings-content">
        <el-form label-position="top">
          <el-form-item label="声音通知">
            <el-switch v-model="notificationSettings.sound" />
          </el-form-item>
          <el-form-item label="桌面通知">
            <el-switch v-model="notificationSettings.desktop" />
          </el-form-item>
          <el-form-item label="仅高优先级告警通知">
            <el-switch v-model="notificationSettings.highPriorityOnly" />
          </el-form-item>
        </el-form>
      </div>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="showSettingsDialog = false">取消</el-button>
          <el-button type="primary" @click="saveSettings">保存</el-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, onUnmounted } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import { 
  CircleCheck, 
  WarningFilled,
  Search
} from '@element-plus/icons-vue'

import { useMonitor } from '../composables/useMonitor.js'
import { alertStore } from '../stores/alertStore.js'
import VirtualAlertTable from '../components/business/VirtualAlertTable.vue'

const router = useRouter()
const { cameras, confirmAlert, fetchAlertList, deleteAlert, deleteAllAlerts } = useMonitor()

// 视图模式
const viewMode = ref('card')

const goBack = () => {
  router.push('/monitor')
}

// 退出登录
const handleLogout = () => {
  ElMessageBox.confirm('确定要退出登录吗？', '提示', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning'
  }).then(() => {
    localStorage.removeItem('token')
    localStorage.removeItem('username')
    localStorage.removeItem('userType')
    router.push('/login')
    ElMessage.success('已退出登录')
  }).catch(() => {})
}

// 使用 alertStore 的告警列表作为数据源
const alertList = computed(() => alertStore.getAlerts())
const unreadCount = computed(() => alertStore.getUnreadCount())
const trendData = computed(() => alertStore.getTrendData())
const notificationSettings = computed({
  get: () => alertStore.notificationSettings,
  set: (val) => alertStore.updateNotificationSettings(val)
})

const loading = ref(false)
const currentPage = ref(1)
const pageSize = ref(20)
const showDetailDialog = ref(false)
const showSettingsDialog = ref(false)
const selectedAlert = ref(null)
const selectedIndex = ref(-1)
const processingIndex = ref(-1)
const selectedAlerts = ref([])
const selectAll = ref(false)
const videoPlayer = ref(null)

const filter = ref({
  level: '',
  status: '',
  cameraId: '',
  keyword: ''
})

const dateRange = ref([])

const alertStats = computed(() => {
  const stats = alertStore.getStats()
  return {
    total: stats.total,
    pending: stats.pending,
    resolved: stats.resolved,
    highRisk: stats.highRisk,
    mediumRisk: stats.mediumRisk,
    lowRisk: stats.lowRisk
  }
})

const filteredAlerts = computed(() => {
  let result = [...alertList.value]
  
  if (filter.value.level) {
    result = result.filter(a => a.level === filter.value.level)
  }
  
  if (filter.value.status === 'pending') {
    result = result.filter(a => !a.acknowledged)
  } else if (filter.value.status === 'resolved') {
    result = result.filter(a => a.acknowledged)
  } else if (filter.value.status === 'unread') {
    result = result.filter(a => !a.read && !a.acknowledged)
  }
  
  if (filter.value.cameraId) {
    result = result.filter(a => a.cameraId === parseInt(filter.value.cameraId))
  }
  
  if (filter.value.keyword) {
    const keyword = filter.value.keyword.toLowerCase()
    result = result.filter(a => 
      (a.reason && a.reason.toLowerCase().includes(keyword)) ||
      (a.area && a.area.toLowerCase().includes(keyword))
    )
  }
  
  if (dateRange.value && dateRange.value.length === 2) {
    const startDate = new Date(dateRange.value[0])
    const endDate = new Date(dateRange.value[1])
    endDate.setHours(23, 59, 59, 999)
    result = result.filter(a => {
      const alertDate = new Date(a.time)
      return alertDate >= startDate && alertDate <= endDate
    })
  }
  
  return result.sort((a, b) => new Date(b.time) - new Date(a.time))
})

// 分页数据
const paginatedAlerts = computed(() => {
  const start = (currentPage.value - 1) * pageSize.value
  const end = start + pageSize.value
  return filteredAlerts.value.slice(start, end)
})

const getLevelTagType = (level) => {
  const types = {
    high: 'danger',
    medium: 'warning',
    low: 'success'
  }
  return types[level] || 'info'
}

const getLevelText = (level) => {
  const texts = {
    high: '高风险',
    medium: '中风险',
    low: '低风险'
  }
  return texts[level] || '未知'
}

const formatTime = (time) => {
  if (!time) return '-'
  try {
    const date = new Date(time)
    return date.toLocaleString('zh-CN', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    })
  } catch {
    return time
  }
}

const getVideoUrl = (alert) => {
  if (alert.video_url) {
    return alert.video_url
  }
  if (alert.videoPath) {
    return `/api/video/play?path=${encodeURIComponent(alert.videoPath)}`
  }
  return ''
}

const refreshAlerts = async () => {
  loading.value = true
  try {
    await fetchAlertList()
    alertStore.generateTrendData()
    ElMessage.success('告警列表已刷新')
  } catch (error) {
    ElMessage.error('刷新告警列表失败')
    console.error('[AlertManagement] 刷新告警列表失败:', error)
  } finally {
    loading.value = false
  }
}

const applyFilter = () => {
  alertStore.setFilterState(filter.value)
  currentPage.value = 1
  ElMessage.success('筛选已应用')
}

const exportAlerts = () => {
  if (filteredAlerts.value.length === 0) {
    ElMessage.warning('没有可导出的告警数据')
    return
  }
  
  const data = filteredAlerts.value.map(alert => ({
    '告警ID': alert.id || alert.alertId,
    '级别': getLevelText(alert.level),
    '原因': alert.reason,
    '摄像头': alert.cameraId,
    '区域': alert.area,
    '时间': formatTime(alert.time),
    '状态': alert.acknowledged ? '已处理' : '待处理'
  }))
  
  const csvContent = [
    Object.keys(data[0]).join(','),
    ...data.map(row => Object.values(row).join(','))
  ].join('\n')
  
  const blob = new Blob([`\uFEFF${csvContent}`], { type: 'text/csv;charset=utf-8;' })
  const link = document.createElement('a')
  link.href = URL.createObjectURL(blob)
  link.download = `告警记录_${new Date().toLocaleDateString('zh-CN').replace(/\//g, '-')}.csv`
  link.click()
  
  ElMessage.success('告警记录已导出')
}

const handleRowClick = (alert, index) => {
  selectedAlert.value = alert
  selectedIndex.value = index
  // 标记为已读
  if (!alert.read) {
    alertStore.markAsRead(alert.alertId)
  }
  showDetailDialog.value = true
}

const viewAlertDetail = (alert) => {
  selectedAlert.value = alert
  if (!alert.read) {
    alertStore.markAsRead(alert.alertId)
  }
  showDetailDialog.value = true
}

const handleAlert = async (alert, index) => {
  processingIndex.value = index
  try {
    await confirmAlert(alert)
    ElMessage.success('告警已处理')
    showDetailDialog.value = false
  } catch (error) {
    ElMessage.error('处理告警失败')
  } finally {
    processingIndex.value = -1
  }
}

const resolveAlert = async (alert) => {
  try {
    await ElMessageBox.confirm(
      '确定要标记这条告警为已解决吗？',
      '确认',
      {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'info'
      }
    )
    alertStore.resolveAlert(alert.alertId)
    ElMessage.success('告警已标记为已解决')
    showDetailDialog.value = false
  } catch (error) {
    if (error !== 'cancel') {
      ElMessage.error('标记已解决失败')
    }
  } finally {
    processingIndex.value = -1
  }
}

const handleDeleteAlert = async (alert) => {
  try {
    await ElMessageBox.confirm(
      '确定要删除这条告警吗？',
      '警告',
      {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }
    )
    await deleteAlert(alert)
    // 从选择列表中移除
    const idx = selectedAlerts.value.indexOf(alert.alertId)
    if (idx > -1) {
      selectedAlerts.value.splice(idx, 1)
    }
    ElMessage.success('告警已删除')
    showDetailDialog.value = false
  } catch (error) {
    if (error !== 'cancel') {
      console.error('[AlertManagement] 删除告警失败:', error)
    }
  }
}

const handleDeleteAllAlerts = async () => {
  try {
    await ElMessageBox.confirm(
      '确定要删除所有告警吗？此操作不可恢复！',
      '警告',
      {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }
    )
    await deleteAllAlerts()
    selectedAlerts.value = []
    selectAll.value = false
    ElMessage.success('所有告警已删除')
  } catch (error) {
    if (error !== 'cancel') {
      console.error('[AlertManagement] 删除全部告警失败:', error)
    }
  }
}

const handleSelectAll = (val) => {
  if (val) {
    selectedAlerts.value = paginatedAlerts.value.map(a => a.alertId)
  } else {
    selectedAlerts.value = []
  }
}

const handleSelectRow = (alert) => {
  const idx = selectedAlerts.value.indexOf(alert.alertId)
  if (idx > -1) {
    selectedAlerts.value.splice(idx, 1)
  } else {
    selectedAlerts.value.push(alert.alertId)
  }
}

const batchAcknowledge = async () => {
  try {
    await ElMessageBox.confirm(
      `确定要处理选中的 ${selectedAlerts.value.length} 条告警吗？`,
      '确认',
      {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'info'
      }
    )
    alertStore.batchAcknowledge(selectedAlerts.value)
    selectedAlerts.value = []
    selectAll.value = false
    ElMessage.success('批量处理成功')
  } catch (error) {
    if (error !== 'cancel') {
      console.error('[AlertManagement] 批量处理失败:', error)
    }
  }
}

const batchDelete = async () => {
  try {
    await ElMessageBox.confirm(
      `确定要删除选中的 ${selectedAlerts.value.length} 条告警吗？此操作不可恢复！`,
      '警告',
      {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }
    )
    alertStore.batchDelete(selectedAlerts.value)
    selectedAlerts.value = []
    selectAll.value = false
    ElMessage.success('批量删除成功')
  } catch (error) {
    if (error !== 'cancel') {
      console.error('[AlertManagement] 批量删除失败:', error)
    }
  }
}

const toggleSettings = () => {
  showSettingsDialog.value = true
}

const saveSettings = () => {
  alertStore.updateNotificationSettings(notificationSettings.value)
  ElMessage.success('设置已保存')
  showSettingsDialog.value = false
}

const handleSizeChange = (size) => {
  pageSize.value = size
  currentPage.value = 1
}

const handleCurrentChange = (page) => {
  currentPage.value = page
}

onMounted(() => {
  console.log('告警管理页面已挂载')
  // 页面加载时获取告警列表
  refreshAlerts()
})

onUnmounted(() => {
  console.log('告警管理页面已卸载')
})
</script>

<style scoped>
.alert-management {
  min-height: 100vh;
  background-color: #F0F2F5;
  padding: 20px;
  font-family: 'Microsoft YaHei', 'PingFang SC', sans-serif;
}

.page-header {
  background: #FFFFFF;
  border-radius: 4px;
  border: 1px solid #DFE6E9;
  padding: 20px 24px;
  margin-bottom: 20px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
}

.header-content {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.header-left {
  display: flex;
  align-items: center;
  gap: 12px;
  color: #2D3436;
}

.header-icon {
  font-size: 28px;
}

.header-left h1 {
  margin: 0;
  font-size: 24px;
  font-weight: 600;
}

.header-right {
  display: flex;
  gap: 10px;
}

.stats-section {
  margin-bottom: 20px;
}

.stat-card {
  display: flex;
  align-items: center;
  gap: 16px;
  padding: 20px;
  border-radius: 4px;
  border: 1px solid #DFE6E9;
  transition: all 0.3s ease;
}

.stat-card .el-card__body {
  padding: 0;
  display: flex;
  align-items: center;
  gap: 16px;
  width: 100%;
}

.stat-icon-wrapper {
  width: 56px;
  height: 56px;
  border-radius: 4px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 28px;
}

.stat-card.total .stat-icon-wrapper {
  background: #0984E3;
  color: white;
}

.stat-card.pending .stat-icon-wrapper {
  background: #FDCB6E;
  color: #2D3436;
}

.stat-card.resolved .stat-icon-wrapper {
  background: #00B894;
  color: white;
}

.stat-card.high-risk .stat-icon-wrapper {
  background: #D63031;
  color: white;
}

.stat-card.medium-risk .stat-icon-wrapper {
  background: #E17055;
  color: white;
}

.stat-card.low-risk .stat-icon-wrapper {
  background: #00B894;
  color: white;
}

.stat-info {
  flex: 1;
}

.stat-value {
  font-size: 32px;
  font-weight: 700;
  color: #303133;
  line-height: 1.2;
}

.stat-label {
  font-size: 14px;
  color: #909399;
}

.trend-section {
  margin-bottom: 20px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.card-title {
  font-weight: 600;
  font-size: 16px;
}

.card-actions {
  display: flex;
  gap: 8px;
}

.trend-chart {
  display: flex;
  justify-content: space-around;
  align-items: flex-end;
  padding: 20px 0;
  min-height: 200px;
}

.trend-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
}

.trend-date {
  font-weight: 600;
  color: #606266;
  font-size: 14px;
}

.trend-bars {
  display: flex;
  gap: 4px;
  align-items: flex-end;
  min-height: 100px;
}

.trend-bar {
  width: 24px;
  border-radius: 4px 4px 0 0;
  display: flex;
  align-items: flex-start;
  justify-content: center;
  padding-top: 4px;
  position: relative;
  min-height: 20px;
}

.trend-bar.high {
  background: #D63031;
}

.trend-bar.medium {
  background: #E17055;
}

.trend-bar.low {
  background: #00B894;
}

.bar-value {
  color: white;
  font-size: 12px;
  font-weight: 600;
}

.trend-total {
  font-size: 12px;
  color: #909399;
  font-weight: 500;
}

.trend-legend {
  display: flex;
  justify-content: center;
  gap: 24px;
  padding-top: 16px;
  border-top: 1px solid #ebeef5;
}

.legend-item {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 14px;
  color: #606266;
}

.legend-color {
  width: 16px;
  height: 16px;
  border-radius: 4px;
}

.legend-color.high {
  background: #D63031;
}

.legend-color.medium {
  background: #E17055;
}

.legend-color.low {
  background: #00B894;
}

.filter-section {
  background: white;
  border-radius: 4px;
  border: 1px solid #DFE6E9;
  padding: 16px 20px;
  margin-bottom: 20px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
}

.filter-select, .filter-input, .filter-date {
  width: 100%;
}

.alert-list-section {
  background: white;
  border-radius: 4px;
  border: 1px solid #DFE6E9;
  padding: 20px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
}

.list-header {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 16px;
  padding-bottom: 12px;
  border-bottom: 1px solid #DFE6E9;
}

.list-title {
  font-weight: 600;
  font-size: 16px;
  color: #2D3436;
}

.selected-info {
  color: #0984E3;
  font-weight: 500;
}

.card-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
  gap: 16px;
}

.alert-card {
  border-radius: 4px;
  padding: 16px;
  cursor: pointer;
  transition: all 0.3s;
  border: 1px solid #DFE6E9;
  display: flex;
  gap: 12px;
}

.alert-card.level-high {
  background: #FFF5F5;
  border-left: 4px solid #D63031;
}

.alert-card.level-medium {
  background: #FFF8F0;
  border-left: 4px solid #E17055;
}

.alert-card.level-low {
  background: #F0FFF4;
  border-left: 4px solid #00B894;
}

.alert-card:hover {
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
}

.alert-card.active {
  border-color: #D63031;
  box-shadow: 0 0 0 2px rgba(214, 48, 49, 0.15);
}

.alert-card.acknowledged {
  opacity: 0.6;
}

.alert-card.unread {
  position: relative;
}

.alert-card.unread::before {
  content: '';
  position: absolute;
  top: 8px;
  right: 8px;
  width: 10px;
  height: 10px;
  background: #D63031;
  border-radius: 50%;
  animation: pulse 2s infinite;
}

.alert-card.selected {
  border-color: #0984E3;
  background: #F0F7FF;
}

@keyframes pulse {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.5; }
}

.card-checkbox {
  display: flex;
  align-items: flex-start;
  padding-top: 4px;
}

.card-content {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  gap: 12px;
}

.alert-type {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 15px;
  font-weight: 600;
  color: #303133;
  flex: 1;
}

.card-actions {
  display: flex;
  align-items: center;
  gap: 8px;
}

.status-badge {
  padding: 4px 8px;
  border-radius: 4px;
  font-size: 12px;
  font-weight: 500;
}

.status-badge.success {
  background: #f6ffed;
  color: #52c41a;
}

.card-info {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.info-item {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 13px;
  color: #606266;
}

.card-footer {
  display: flex;
  justify-content: flex-end;
  padding-top: 8px;
  border-top: 1px solid rgba(0, 0, 0, 0.05);
}

.alert-actions {
  display: flex;
  gap: 8px;
}

.alert-empty-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  color: #909399;
  text-align: center;
  padding: 60px 20px;
  grid-column: 1 / -1;
}

.alert-empty-state h4 {
  margin: 0 0 10px 0;
  font-size: 18px;
  font-weight: 600;
  color: #909399;
}

.alert-empty-state p {
  margin: 0;
  font-size: 14px;
  color: #c0c4cc;
}

.pagination-section {
  display: flex;
  justify-content: center;
  margin-top: 24px;
  padding-top: 16px;
  border-top: 1px solid #ebeef5;
}

.alert-detail {
  padding: 10px 0;
}

.detail-value {
  color: #303133;
  font-weight: 500;
}

.alert-detail-actions {
  margin-top: 20px;
}

.detail-action-buttons {
  display: flex;
  gap: 12px;
  flex-wrap: wrap;
}

.dialog-footer {
  display: flex;
  justify-content: flex-end;
  gap: 10px;
}

.settings-content {
  padding: 10px 0;
}

.alert-video-section {
  margin-top: 20px;
}

.video-container {
  background: #1a1a1a;
  border-radius: 8px;
  overflow: hidden;
}

.alert-video {
  width: 100%;
  height: 360px;
  object-fit: cover;
}

.video-placeholder {
  padding: 40px;
  text-align: center;
}

@media (max-width: 768px) {
  .alert-video {
    height: 240px;
  }
}
</style>
