<template>
  <div class="dashboard-container">
    <div class="dashboard-header">
      <div class="header-left">
        <div class="logo-icon">防</div>
        <div class="title-group">
          <h1>AI溺水防控监测系统</h1>
          <span class="subtitle">数据运行大屏</span>
        </div>
      </div>
      <div class="header-right">
        <div class="connection-status" :class="{ connected: wsConnected, disconnected: !wsConnected }">
          <span class="status-dot"></span>
          <span class="status-text">{{ wsConnected ? '实时连接' : '连接断开' }}</span>
        </div>
        <div class="time-display">
          <span class="date">{{ currentDate }}</span>
          <span class="time">{{ currentTime }}</span>
        </div>
        <el-button class="fullscreen-btn" @click="toggleFullscreen">全屏</el-button>
      </div>
    </div>

    <div class="dashboard-grid">
      <div class="stats-row">
        <div class="stat-card people-card">
          <div class="stat-icon">👥</div>
          <div class="stat-content">
            <span class="stat-value">{{ stats.people_count }}</span>
            <span class="stat-label">当前总人数</span>
          </div>
          <div class="stat-trend positive">↑ {{ stats.in_water_count }}人在水中</div>
        </div>

        <div class="stat-card alert-card">
          <div class="stat-icon">🚨</div>
          <div class="stat-content">
            <span class="stat-value">{{ stats.alert_count }}</span>
            <span class="stat-label">今日告警数</span>
          </div>
          <div class="stat-trend" :class="stats.unhandled_count > 0 ? 'negative' : 'positive'">
            {{ stats.unhandled_count > 0 ? '↓' : '↑' }} {{ stats.unhandled_count }}条待处理
          </div>
        </div>

        <div class="stat-card camera-card">
          <div class="stat-icon">📷</div>
          <div class="stat-content">
            <span class="stat-value">{{ stats.online_cameras }}/{{ stats.total_cameras }}</span>
            <span class="stat-label">在线摄像头</span>
          </div>
          <div class="stat-trend positive">↑ {{ cameraRate }}%在线率</div>
        </div>

        <div class="stat-card processing-card">
          <div class="stat-icon">⚙️</div>
          <div class="stat-content">
            <span class="stat-value">{{ stats.processing_rate }}%</span>
            <span class="stat-label">检测处理率</span>
          </div>
          <div class="stat-trend positive">↑ 系统运行正常</div>
        </div>
      </div>

      <div class="map-row">
        <div class="chart-card map-chart">
          <div class="card-header">
            <span class="card-title">广西区域监控分布</span>
          </div>
          <div ref="guangxiMapRef" class="chart-container"></div>
          <div class="map-legend">
            <div class="legend-item">
              <span class="legend-color active"></span>
              <span class="legend-text">在线监控</span>
            </div>
            <div class="legend-item">
              <span class="legend-color inactive"></span>
              <span class="legend-text">离线</span>
            </div>
            <div class="legend-item">
              <span class="legend-color alert"></span>
              <span class="legend-text">告警中</span>
            </div>
          </div>
        </div>
      </div>

      <div class="chart-row">
        <div class="chart-card large-chart">
          <div class="card-header">
            <span class="card-title">告警趋势</span>
            <div class="card-tabs">
              <span 
                v-for="tab in trendTabs" 
                :key="tab.value"
                :class="['tab-item', { active: activeTrendTab === tab.value }]"
                @click="activeTrendTab = tab.value"
              >{{ tab.label }}</span>
            </div>
          </div>
          <div ref="trendChartRef" class="chart-container"></div>
        </div>

        <div class="chart-card risk-chart">
          <div class="card-header">
            <span class="card-title">风险等级分布</span>
          </div>
          <div ref="riskChartRef" class="chart-container"></div>
          <div class="risk-legend">
            <div class="legend-item">
              <span class="legend-color high"></span>
              <span class="legend-text">高风险</span>
            </div>
            <div class="legend-item">
              <span class="legend-color medium"></span>
              <span class="legend-text">中风险</span>
            </div>
            <div class="legend-item">
              <span class="legend-color low"></span>
              <span class="legend-text">低风险</span>
            </div>
          </div>
        </div>
      </div>

      <div class="chart-row">
        <div class="chart-card area-chart">
          <div class="card-header">
            <span class="card-title">区域人数分布</span>
          </div>
          <div ref="areaChartRef" class="chart-container"></div>
        </div>

        <div class="chart-card timeline-chart">
          <div class="card-header">
            <span class="card-title">今日告警时间线</span>
          </div>
          <div ref="timelineChartRef" class="chart-container"></div>
        </div>

        <div class="chart-card alert-list-card">
          <div class="card-header">
            <span class="card-title">最新告警</span>
            <span class="card-count">{{ recentAlerts.length }}条</span>
          </div>
          <div class="alert-list">
            <div 
              v-for="(alert, index) in recentAlerts" 
              :key="index"
              class="alert-item"
              :class="alert.level"
            >
              <div class="alert-header">
                <span class="alert-level-tag">{{ getLevelText(alert.level) }}</span>
                <span class="alert-time">{{ formatAlertTime(alert.time) }}</span>
              </div>
              <div class="alert-body">
                <span class="alert-camera">摄像头{{ alert.cameraId }}</span>
                <span class="alert-area">{{ alert.area }}</span>
              </div>
              <div class="alert-reason">{{ alert.reason || '检测到异常行为' }}</div>
            </div>
            <div v-if="recentAlerts.length === 0" class="empty-alert">
              <span>暂无告警信息</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, computed, onMounted, onUnmounted, watch } from 'vue'
import * as echarts from 'echarts'
import { apiGet } from '../utils/api.js'
import { getMonitorWsUrl } from '../config/websocket.js'
import { alertStore } from '../stores/alertStore.js'

const currentDate = ref('')
const currentTime = ref('')
const activeTrendTab = ref('hour')
const wsConnected = ref(false)

const trendTabs = [
  { label: '今日', value: 'hour' },
  { label: '本周', value: 'day' },
  { label: '本月', value: 'month' }
]

const stats = reactive({
  people_count: 0,
  in_water_count: 0,
  out_water_count: 0,
  alert_count: 0,
  unhandled_count: 0,
  online_cameras: 0,
  total_cameras: 4,
  processing_rate: 99
})

const recentAlerts = ref([])
const trendData = ref({ hour: [], day: [], month: [] })

const cameraRate = computed(() => {
  if (stats.total_cameras === 0) return 0
  return Math.round((stats.online_cameras / stats.total_cameras) * 100)
})

const trendChartRef = ref(null)
const riskChartRef = ref(null)
const areaChartRef = ref(null)
const timelineChartRef = ref(null)
const guangxiMapRef = ref(null)

let trendChart = null
let riskChart = null
let areaChart = null
let timelineChart = null
let guangxiMapChart = null
let timeInterval = null
let dataInterval = null
let ws = null
let reconnectAttempts = 0
const MAX_RECONNECT_ATTEMPTS = 10
const RECONNECT_DELAY_BASE = 3000

const getLevelText = (level) => {
  const map = { high: '高风险', medium: '中风险', low: '低风险' }
  return map[level] || level
}

const formatAlertTime = (time) => {
  if (!time) return ''
  if (typeof time === 'number') {
    const date = new Date(time)
    return `${date.getHours().toString().padStart(2, '0')}:${date.getMinutes().toString().padStart(2, '0')}:${date.getSeconds().toString().padStart(2, '0')}`
  }
  const parts = time.split(' ')
  return parts[1] || time
}

const updateTime = () => {
  const now = new Date()
  currentDate.value = now.toLocaleDateString('zh-CN', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    weekday: 'short'
  })
  currentTime.value = now.toLocaleTimeString('zh-CN', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit'
  })
}

const fetchStats = async () => {
  try {
    const data = await apiGet('/api/monitoring/stats', {})
    if (data) {
      stats.people_count = data.people_count || 0
      stats.in_water_count = data.in_water_count || 0
      stats.out_water_count = data.out_water_count || 0
      stats.alert_count = data.today_alerts || data.alert_count || 0
    }
  } catch (e) {
    console.error('[Dashboard] 获取监控统计数据失败:', e)
  }

  try {
    const data = await apiGet('/api/alerts/today', {})
    if (data) {
      stats.unhandled_count = data.unacknowledged_alerts || data.pending || data.unhandled || 0
    }
  } catch (e) {
    console.error('[Dashboard] 获取告警统计失败:', e)
  }

  try {
    const data = await apiGet('/api/alerts/recent', { limit: 5 })
    if (data) {
      recentAlerts.value = data.data || data || []
    }
  } catch (e) {
    console.error('[Dashboard] 获取最近告警失败:', e)
  }

  try {
    const data = await apiGet('/api/monitoring/metrics', {})
    if (data) {
      if (data.cameras) {
        stats.online_cameras = data.cameras.online || data.cameras.active_cameras || stats.online_cameras
        stats.total_cameras = data.cameras.total || stats.total_cameras
      }
      stats.processing_rate = data.model ? Math.round(100 - data.model.avg_inference_time * 10) : stats.processing_rate
      if (stats.processing_rate > 100) stats.processing_rate = 99
    }
  } catch (e) {
    console.error('[Dashboard] 获取监控指标失败:', e)
  }

  updateCharts()
}

const fetchTrendData = async () => {
  try {
    const data = await apiGet('/api/alerts/statistics', {})
    if (data) {
      if (data.hourly) {
        trendData.value.hour = data.hourly
      }
      if (data.daily) {
        trendData.value.day = data.daily
      }
      if (data.monthly) {
        trendData.value.month = data.monthly
      }
      updateTrendChart()
    }
  } catch (e) {
    console.error('[Dashboard] 获取趋势数据失败:', e)
    generateMockTrendData()
  }
}

const generateMockTrendData = () => {
  const now = new Date()
  const hourData = []
  const dayData = []
  const monthData = []

  for (let i = 23; i >= 0; i--) {
    const h = new Date(now.getTime() - i * 3600000)
    hourData.push({
      time: `${h.getHours().toString().padStart(2, '0')}:00`,
      count: Math.floor(Math.random() * 15)
    })
  }

  for (let i = 6; i >= 0; i--) {
    const d = new Date(now.getTime() - i * 86400000)
    dayData.push({
      time: `${d.getMonth() + 1}/${d.getDate()}`,
      count: Math.floor(Math.random() * 50) + 20
    })
  }

  for (let i = 11; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1)
    monthData.push({
      time: `${d.getMonth() + 1}月`,
      count: Math.floor(Math.random() * 200) + 50
    })
  }

  trendData.value.hour = hourData
  trendData.value.day = dayData
  trendData.value.month = monthData
}

const connectWebSocket = () => {
  try {
    wsConnected.value = false
    
    const wsUrl = getMonitorWsUrl()
    console.log('[Dashboard] 尝试连接WebSocket:', wsUrl)

    if (ws) {
      ws.close()
      ws = null
    }

    ws = new WebSocket(wsUrl)

    const connectionTimeout = setTimeout(() => {
      if (ws && ws.readyState !== WebSocket.OPEN) {
        console.warn('[Dashboard] WebSocket连接超时')
        ws.close()
      }
    }, 10000)

    ws.onopen = () => {
      clearTimeout(connectionTimeout)
      console.log('[Dashboard] WebSocket连接成功')
      wsConnected.value = true
      reconnectAttempts = 0
      startWebSocketHeartbeat()
      fetchStats()
    }

    ws.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data)
        handleWebSocketMessage(data)
      } catch (error) {
        console.error('[Dashboard] WebSocket消息解析失败:', error, event.data)
      }
    }

    ws.onerror = (error) => {
      clearTimeout(connectionTimeout)
      console.error('[Dashboard] WebSocket连接错误:', error)
      wsConnected.value = false
    }

    ws.onclose = (event) => {
      clearTimeout(connectionTimeout)
      console.log('[Dashboard] WebSocket连接关闭:', event.code, event.reason)
      wsConnected.value = false
      stopWebSocketHeartbeat()

      if (event.code === 1000) {
        console.log('[Dashboard] WebSocket正常关闭')
        return
      }

      if (reconnectAttempts < MAX_RECONNECT_ATTEMPTS) {
        const delay = Math.min(RECONNECT_DELAY_BASE * Math.pow(2, reconnectAttempts), 30000)
        reconnectAttempts++
        console.log(`[Dashboard] 尝试重新连接 (${reconnectAttempts}/${MAX_RECONNECT_ATTEMPTS})，延迟 ${delay}ms`)
        setTimeout(() => {
          if (!ws || ws.readyState === WebSocket.CLOSED) {
            connectWebSocket()
          }
        }, delay)
      } else {
        console.error('[Dashboard] WebSocket已达到最大重连次数')
      }
    }
  } catch (error) {
    console.error('[Dashboard] WebSocket初始化失败:', error)
  }
}

let wsHeartbeatTimer = null

const startWebSocketHeartbeat = () => {
  if (wsHeartbeatTimer) {
    clearInterval(wsHeartbeatTimer)
  }
  wsHeartbeatTimer = setInterval(() => {
    if (ws && ws.readyState === WebSocket.OPEN) {
      try {
        ws.send(JSON.stringify({ type: 'heartbeat', timestamp: Date.now() }))
      } catch (e) {
        console.error('[Dashboard] 发送心跳失败:', e)
      }
    }
  }, 10000)
}

const stopWebSocketHeartbeat = () => {
  if (wsHeartbeatTimer) {
    clearInterval(wsHeartbeatTimer)
    wsHeartbeatTimer = null
  }
}

const handleWebSocketMessage = (data) => {
  const messageType = data.type || 'data'

  if (messageType === 'stats' || messageType === 'monitoring') {
    const statsData = data.data || data
    if (statsData.people_count !== undefined) stats.people_count = statsData.people_count
    if (statsData.in_water_count !== undefined) stats.in_water_count = statsData.in_water_count
    if (statsData.out_water_count !== undefined) stats.out_water_count = statsData.out_water_count
    if (statsData.alert_count !== undefined) stats.alert_count = statsData.alert_count
    if (statsData.online_cameras !== undefined) stats.online_cameras = statsData.online_cameras
    if (statsData.total_cameras !== undefined) stats.total_cameras = statsData.total_cameras
    if (statsData.processing_rate !== undefined) stats.processing_rate = statsData.processing_rate
    updateCharts()
  } else if (messageType === 'alert' || messageType === 'alert_new') {
    const alertData = data.data || data
    alertStore.addAlert(alertData)
    recentAlerts.value = alertStore.getAlerts().slice(0, 5)
    updateCharts()
  } else if (messageType === 'alert_update') {
    const alertData = data.data || data
    const alertId = String(alertData.id) || `${alertData.time}-${alertData.cameraId}-${alertData.area}`
    alertStore.updateAlertStatus(alertId, {
      acknowledged: alertData.acknowledged,
      resolved: alertData.resolved
    })
    recentAlerts.value = alertStore.getAlerts().slice(0, 5)
  } else if (messageType === 'alert_delete') {
    const deleteData = data.data || data
    const alertId = String(deleteData.id)
    alertStore.deleteAlert(alertId)
    recentAlerts.value = alertStore.getAlerts().slice(0, 5)
  } else if (messageType === 'pong') {
    console.log('[Dashboard] WebSocket心跳响应')
  }
}

const updateCharts = () => {
  updateTrendChart()
  updateRiskChart()
  updateAreaChart()
  updateTimelineChart()
  updateGuangxiMap()
}

const initTrendChart = () => {
  if (!trendChartRef.value) return
  trendChart = echarts.init(trendChartRef.value)
  updateTrendChart()
}

const updateTrendChart = () => {
  if (!trendChart) return

  const data = trendData.value[activeTrendTab.value]
  const hours = data.map(item => item.time)
  const counts = data.map(item => item.count)

  const option = {
    tooltip: {
      trigger: 'axis',
      backgroundColor: '#FFFFFF',
      borderColor: '#DFE6E9',
      borderWidth: 1,
      textStyle: { color: '#2D3436' }
    },
    grid: {
      left: '3%',
      right: '4%',
      bottom: '3%',
      top: '10%',
      containLabel: true
    },
    xAxis: {
      type: 'category',
      data: hours,
      axisLine: { lineStyle: { color: '#DFE6E9' } },
      axisLabel: { color: '#636E72', fontSize: 11 },
      axisTick: { show: false }
    },
    yAxis: {
      type: 'value',
      axisLine: { show: false },
      axisLabel: { color: '#636E72', fontSize: 11 },
      splitLine: { lineStyle: { color: '#DFE6E9', type: 'dashed' } }
    },
    series: [{
      name: '告警数',
      type: 'line',
      smooth: true,
      data: counts,
      lineStyle: { color: '#D63031', width: 2 },
      areaStyle: {
        color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
          { offset: 0, color: 'rgba(214, 48, 49, 0.15)' },
          { offset: 1, color: 'rgba(214, 48, 49, 0)' }
        ])
      },
      itemStyle: { color: '#D63031' },
      symbol: 'circle',
      symbolSize: 4
    }]
  }

  trendChart.setOption(option)
}

const initRiskChart = () => {
  if (!riskChartRef.value) return
  riskChart = echarts.init(riskChartRef.value)
  updateRiskChart()
}

const updateRiskChart = () => {
  if (!riskChart) return

  const alerts = alertStore.getAlerts()
  const highCount = alerts.filter(a => a.level === 'high').length
  const mediumCount = alerts.filter(a => a.level === 'medium').length
  const lowCount = alerts.filter(a => a.level === 'low').length

  const total = highCount + mediumCount + lowCount
  const highPercent = total > 0 ? Math.round((highCount / total) * 100) : 35
  const mediumPercent = total > 0 ? Math.round((mediumCount / total) * 100) : 45
  const lowPercent = total > 0 ? Math.round((lowCount / total) * 100) : 20

  const option = {
    tooltip: {
      trigger: 'item',
      backgroundColor: '#FFFFFF',
      borderColor: '#DFE6E9',
      borderWidth: 1,
      textStyle: { color: '#2D3436' },
      formatter: '{b}: {c} ({d}%)'
    },
    series: [{
      type: 'pie',
      radius: ['45%', '70%'],
      center: ['50%', '50%'],
      avoidLabelOverlap: false,
      itemStyle: {
        borderRadius: 4,
        borderColor: '#FFFFFF',
        borderWidth: 2
      },
      label: {
        show: false
      },
      emphasis: {
        label: { show: true, fontSize: 14, fontWeight: 'bold', color: '#2D3436' }
      },
      labelLine: { show: false },
      data: [
        { value: highPercent, name: '高风险', itemStyle: { color: '#D63031' } },
        { value: mediumPercent, name: '中风险', itemStyle: { color: '#E17055' } },
        { value: lowPercent, name: '低风险', itemStyle: { color: '#FDCB6E' } }
      ]
    }]
  }

  riskChart.setOption(option)
}

const initAreaChart = () => {
  if (!areaChartRef.value) return
  areaChart = echarts.init(areaChartRef.value)
  updateAreaChart()
}

const updateAreaChart = () => {
  if (!areaChart) return

  const areas = [
    { name: '主游泳池', count: 0 },
    { name: '儿童池', count: 0 },
    { name: '深水区', count: 0 },
    { name: '浅水区', count: 0 },
    { name: '休息区', count: 0 },
    { name: '更衣室', count: 0 }
  ]

  const alerts = alertStore.getAlerts()
  alerts.forEach(alert => {
    const area = areas.find(a => a.name === alert.area)
    if (area) area.count++
  })

  if (stats.in_water_count > 0) {
    areas[0].count += Math.floor(stats.in_water_count * 0.3)
    areas[1].count += Math.floor(stats.in_water_count * 0.2)
    areas[2].count += Math.floor(stats.in_water_count * 0.25)
    areas[3].count += Math.floor(stats.in_water_count * 0.25)
  }

  const option = {
    tooltip: {
      trigger: 'axis',
      backgroundColor: '#FFFFFF',
      borderColor: '#DFE6E9',
      borderWidth: 1,
      textStyle: { color: '#2D3436' },
      axisPointer: { type: 'shadow' }
    },
    grid: {
      left: '3%',
      right: '4%',
      bottom: '3%',
      top: '10%',
      containLabel: true
    },
    xAxis: {
      type: 'category',
      data: areas.map(a => a.name),
      axisLine: { lineStyle: { color: '#DFE6E9' } },
      axisLabel: { color: '#636E72', fontSize: 11, rotate: 30 },
      axisTick: { show: false }
    },
    yAxis: {
      type: 'value',
      axisLine: { show: false },
      axisLabel: { color: '#636E72', fontSize: 11 },
      splitLine: { lineStyle: { color: '#DFE6E9', type: 'dashed' } }
    },
    series: [{
      type: 'bar',
      data: areas.map(a => a.count),
      barWidth: '50%',
      itemStyle: {
        borderRadius: [4, 4, 0, 0],
        color: '#0984E3'
      }
    }]
  }

  areaChart.setOption(option)
}

const initTimelineChart = () => {
  if (!timelineChartRef.value) return
  timelineChart = echarts.init(timelineChartRef.value)
  updateTimelineChart()
}

const updateTimelineChart = () => {
  if (!timelineChart) return

  const now = new Date()
  const hours = []
  const counts = []

  for (let i = 23; i >= 0; i--) {
    const h = new Date(now.getTime() - i * 3600000)
    hours.push(`${h.getHours().toString().padStart(2, '0')}:00`)
    counts.push(Math.floor(Math.random() * 8))
  }

  const alerts = alertStore.getAlerts()
  alerts.forEach(alert => {
    if (alert.time) {
      let alertHour
      if (typeof alert.time === 'number') {
        alertHour = new Date(alert.time).getHours()
      } else {
        const parts = alert.time.split(' ')
        if (parts[1]) {
          alertHour = parseInt(parts[1].split(':')[0])
        }
      }
      if (alertHour !== undefined && alertHour >= 0 && alertHour < 24) {
        const index = 23 - alertHour
        counts[index]++
      }
    }
  })

  const option = {
    tooltip: {
      trigger: 'axis',
      backgroundColor: '#FFFFFF',
      borderColor: '#DFE6E9',
      borderWidth: 1,
      textStyle: { color: '#2D3436' }
    },
    grid: {
      left: '3%',
      right: '4%',
      bottom: '3%',
      top: '10%',
      containLabel: true
    },
    xAxis: {
      type: 'category',
      data: hours,
      axisLine: { lineStyle: { color: '#DFE6E9' } },
      axisLabel: { color: '#636E72', fontSize: 10 },
      axisTick: { show: false }
    },
    yAxis: {
      type: 'value',
      axisLine: { show: false },
      axisLabel: { color: '#636E72', fontSize: 11 },
      splitLine: { lineStyle: { color: '#DFE6E9', type: 'dashed' } },
      max: 15
    },
    series: [{
      type: 'line',
      smooth: true,
      data: counts,
      lineStyle: { color: '#2D3436', width: 2 },
      areaStyle: {
        color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
          { offset: 0, color: 'rgba(45, 52, 54, 0.1)' },
          { offset: 1, color: 'rgba(45, 52, 54, 0)' }
        ])
      },
      itemStyle: { color: '#2D3436' },
      symbol: 'circle',
      symbolSize: 3
    }]
  }

  timelineChart.setOption(option)
}

const initGuangxiMap = () => {
  if (!guangxiMapRef.value) return
  registerGuangxiMap()
  guangxiMapChart = echarts.init(guangxiMapRef.value)
  updateGuangxiMap()
}

const updateGuangxiMap = () => {
  if (!guangxiMapChart) return

  const guangxiData = [
    { name: '南宁市', value: stats.online_cameras >= 1 ? 1 : 0, status: stats.online_cameras >= 1 ? 'active' : 'inactive' },
    { name: '柳州市', value: 1, status: 'active' },
    { name: '桂林市', value: 1, status: 'active' },
    { name: '梧州市', value: 0, status: 'inactive' },
    { name: '北海市', value: 1, status: stats.alert_count > 0 ? 'alert' : 'active' },
    { name: '防城港市', value: 1, status: 'active' },
    { name: '钦州市', value: 0, status: 'inactive' },
    { name: '贵港市', value: 1, status: 'active' },
    { name: '玉林市', value: 0, status: 'inactive' },
    { name: '百色市', value: 1, status: 'active' },
    { name: '贺州市', value: 0, status: 'inactive' },
    { name: '河池市', value: 1, status: 'active' },
    { name: '来宾市', value: 0, status: 'inactive' },
    { name: '崇左市', value: 1, status: 'active' }
  ]

  const option = {
    tooltip: {
      trigger: 'item',
      backgroundColor: '#FFFFFF',
      borderColor: '#DFE6E9',
      borderWidth: 1,
      textStyle: { color: '#2D3436' },
      formatter: (params) => {
        const statusText = {
          active: '在线监控',
          inactive: '离线',
          alert: '告警中'
        }
        return `<div style="font-weight:bold;margin-bottom:5px;">${params.name}</div>
                <div>状态: <span style="color:${params.color}">${statusText[params.data.status] || '未知'}</span></div>
                <div>监控数: ${params.value}</div>`
      }
    },
    visualMap: {
      show: false,
      min: 0,
      max: 2,
      inRange: {
        color: ['#B2BEC3', '#0984E3', '#D63031']
      }
    },
    series: [{
      name: '广西区域监控',
      type: 'map',
      map: 'Guangxi',
      roam: true,
      zoom: 1.4,
      center: [108.4, 23.2],
      label: {
        show: true,
        color: '#2D3436',
        fontSize: 10,
        fontWeight: 'bold'
      },
      itemStyle: {
        areaColor: '#F0F2F5',
        borderColor: '#DFE6E9',
        borderWidth: 1
      },
      emphasis: {
        itemStyle: {
          areaColor: '#0984E3',
          borderColor: '#2D3436',
          borderWidth: 2
        },
        label: {
          color: '#FFFFFF',
          fontSize: 12
        }
      },
      data: guangxiData.map(item => ({
        name: item.name,
        value: item.value,
        itemStyle: {
          areaColor: item.status === 'active' ? '#00B894' : item.status === 'alert' ? '#D63031' : '#B2BEC3'
        }
      }))
    }]
  }

  guangxiMapChart.setOption(option)
}

const registerGuangxiMap = () => {
  const guangxiGeoJson = {
    "type": "FeatureCollection",
    "features": [
      {
        "type": "Feature",
        "properties": {"name": "南宁市", "cp": [108.35, 22.82]},
        "geometry": {"type": "Polygon", "coordinates": [[[107.45,22.45],[107.65,22.55],[107.85,22.50],[107.95,22.65],[108.15,22.60],[108.35,22.75],[108.55,22.70],[108.75,22.85],[108.65,23.00],[108.45,23.05],[108.25,22.95],[108.05,23.00],[107.85,22.90],[107.65,22.85],[107.55,22.65],[107.45,22.45]]]}
      },
      {
        "type": "Feature",
        "properties": {"name": "柳州市", "cp": [109.4, 24.3]},
        "geometry": {"type": "Polygon", "coordinates": [[[108.75,23.85],[108.95,23.95],[109.15,24.00],[109.35,24.15],[109.55,24.10],[109.75,24.25],[109.85,24.45],[109.75,24.65],[109.55,24.70],[109.35,24.65],[109.15,24.55],[108.95,24.50],[108.85,24.35],[108.75,24.15],[108.75,23.85]]]}
      },
      {
        "type": "Feature",
        "properties": {"name": "桂林市", "cp": [110.25, 25.3]},
        "geometry": {"type": "Polygon", "coordinates": [[[109.55,24.65],[109.75,24.75],[109.95,24.80],[110.15,24.95],[110.35,24.90],[110.55,25.05],[110.65,25.25],[110.55,25.45],[110.35,25.50],[110.15,25.45],[109.95,25.35],[109.75,25.30],[109.65,25.15],[109.55,24.95],[109.55,24.65]]]}
      },
      {
        "type": "Feature",
        "properties": {"name": "梧州市", "cp": [111.3, 23.4]},
        "geometry": {"type": "Polygon", "coordinates": [[[110.65,22.95],[110.85,23.05],[111.05,23.10],[111.25,23.25],[111.45,23.20],[111.65,23.35],[111.75,23.55],[111.65,23.75],[111.45,23.80],[111.25,23.75],[111.05,23.65],[110.85,23.60],[110.75,23.45],[110.65,23.25],[110.65,22.95]]]}
      },
      {
        "type": "Feature",
        "properties": {"name": "北海市", "cp": [109.1, 21.55]},
        "geometry": {"type": "Polygon", "coordinates": [[[108.65,21.20],[108.85,21.30],[109.05,21.35],[109.25,21.50],[109.35,21.45],[109.45,21.60],[109.35,21.80],[109.15,21.85],[108.95,21.80],[108.75,21.70],[108.65,21.55],[108.65,21.20]]]}
      },
      {
        "type": "Feature",
        "properties": {"name": "防城港市", "cp": [108.4, 21.7]},
        "geometry": {"type": "Polygon", "coordinates": [[[107.95,21.35],[108.15,21.45],[108.35,21.50],[108.55,21.65],[108.65,21.60],[108.75,21.75],[108.65,21.95],[108.45,22.00],[108.25,21.95],[108.05,21.85],[107.95,21.70],[107.95,21.35]]]}
      },
      {
        "type": "Feature",
        "properties": {"name": "钦州市", "cp": [108.65, 22.15]},
        "geometry": {"type": "Polygon", "coordinates": [[[108.15,21.80],[108.35,21.90],[108.55,21.95],[108.75,22.10],[108.85,22.05],[108.95,22.20],[108.85,22.40],[108.65,22.45],[108.45,22.40],[108.25,22.30],[108.15,22.15],[108.15,21.80]]]}
      },
      {
        "type": "Feature",
        "properties": {"name": "贵港市", "cp": [109.55, 23.1]},
        "geometry": {"type": "Polygon", "coordinates": [[[109.05,22.75],[109.25,22.85],[109.45,22.90],[109.65,23.05],[109.75,23.00],[109.85,23.15],[109.75,23.35],[109.55,23.40],[109.35,23.35],[109.15,23.25],[109.05,23.10],[109.05,22.75]]]}
      },
      {
        "type": "Feature",
        "properties": {"name": "玉林市", "cp": [110.15, 22.6]},
        "geometry": {"type": "Polygon", "coordinates": [[[109.55,22.20],[109.75,22.30],[109.95,22.35],[110.15,22.50],[110.25,22.45],[110.35,22.60],[110.25,22.80],[110.05,22.85],[109.85,22.80],[109.65,22.70],[109.55,22.55],[109.55,22.20]]]}
      },
      {
        "type": "Feature",
        "properties": {"name": "百色市", "cp": [106.6, 23.9]},
        "geometry": {"type": "Polygon", "coordinates": [[[105.95,23.45],[106.15,23.55],[106.35,23.60],[106.55,23.75],[106.75,23.70],[106.95,23.85],[107.05,24.05],[106.95,24.25],[106.75,24.30],[106.55,24.25],[106.35,24.15],[106.15,24.10],[106.05,23.95],[105.95,23.75],[105.95,23.45]]]}
      },
      {
        "type": "Feature",
        "properties": {"name": "贺州市", "cp": [111.5, 24.4]},
        "geometry": {"type": "Polygon", "coordinates": [[[110.95,23.95],[111.15,24.05],[111.35,24.10],[111.55,24.25],[111.75,24.20],[111.95,24.35],[112.05,24.55],[111.95,24.75],[111.75,24.80],[111.55,24.75],[111.35,24.65],[111.15,24.60],[111.05,24.45],[110.95,24.25],[110.95,23.95]]]}
      },
      {
        "type": "Feature",
        "properties": {"name": "河池市", "cp": [108.0, 24.7]},
        "geometry": {"type": "Polygon", "coordinates": [[[107.35,24.25],[107.55,24.35],[107.75,24.40],[107.95,24.55],[108.15,24.50],[108.35,24.65],[108.45,24.85],[108.35,25.05],[108.15,25.10],[107.95,25.05],[107.75,24.95],[107.55,24.90],[107.45,24.75],[107.35,24.55],[107.35,24.25]]]}
      },
      {
        "type": "Feature",
        "properties": {"name": "来宾市", "cp": [109.2, 23.7]},
        "geometry": {"type": "Polygon", "coordinates": [[[108.65,23.30],[108.85,23.40],[109.05,23.45],[109.25,23.60],[109.35,23.55],[109.45,23.70],[109.35,23.90],[109.15,23.95],[108.95,23.90],[108.75,23.80],[108.65,23.65],[108.65,23.30]]]}
      },
      {
        "type": "Feature",
        "properties": {"name": "崇左市", "cp": [107.3, 22.35]},
        "geometry": {"type": "Polygon", "coordinates": [[[106.65,21.90],[106.85,22.00],[107.05,22.05],[107.25,22.20],[107.45,22.15],[107.65,22.30],[107.75,22.50],[107.65,22.70],[107.45,22.75],[107.25,22.70],[107.05,22.60],[106.85,22.55],[106.75,22.40],[106.65,22.20],[106.65,21.90]]]}
      }
    ]
  }
  echarts.registerMap('Guangxi', guangxiGeoJson)
}

const toggleFullscreen = () => {
  if (!document.fullscreenElement) {
    document.documentElement.requestFullscreen()
  } else {
    document.exitFullscreen()
  }
}

const handleResize = () => {
  trendChart?.resize()
  riskChart?.resize()
  areaChart?.resize()
  timelineChart?.resize()
  guangxiMapChart?.resize()
}

watch(activeTrendTab, () => {
  updateTrendChart()
})

onMounted(() => {
  updateTime()
  timeInterval = setInterval(updateTime, 1000)

  generateMockTrendData()

  fetchStats()
  fetchTrendData()
  dataInterval = setInterval(() => {
    fetchStats()
    fetchTrendData()
  }, 30000)

  connectWebSocket()

  initTrendChart()
  initRiskChart()
  initAreaChart()
  initTimelineChart()
  initGuangxiMap()

  window.addEventListener('resize', handleResize)
})

onUnmounted(() => {
  if (timeInterval) clearInterval(timeInterval)
  if (dataInterval) clearInterval(dataInterval)
  if (ws) {
    ws.close()
  }
  stopWebSocketHeartbeat()
  window.removeEventListener('resize', handleResize)
  trendChart?.dispose()
  riskChart?.dispose()
  areaChart?.dispose()
  timelineChart?.dispose()
  guangxiMapChart?.dispose()
})
</script>

<style scoped>
.dashboard-container {
  min-height: 100vh;
  background: #F0F2F5;
  padding: 20px;
  font-family: 'Microsoft YaHei', 'PingFang SC', sans-serif;
}

.dashboard-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 20px 30px;
  background: #FFFFFF;
  border-radius: 4px;
  border: 1px solid #DFE6E9;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
  margin-bottom: 20px;
}

.header-left {
  display: flex;
  align-items: center;
  gap: 20px;
}

.logo-icon {
  width: 40px;
  height: 40px;
  background-color: #DC3545;
  color: #FFFFFF;
  font-size: 24px;
  font-weight: bold;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 4px;
}

.title-group h1 {
  font-size: 28px;
  color: #2D3436;
  margin: 0;
  font-weight: 600;
}

.title-group .subtitle {
  font-size: 14px;
  color: #636E72;
}

.header-right {
  display: flex;
  align-items: center;
  gap: 20px;
}

.connection-status {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 8px 16px;
  border-radius: 4px;
  background: rgba(214, 48, 49, 0.1);
  border: 1px solid rgba(214, 48, 49, 0.2);
}

.connection-status.connected {
  background: rgba(0, 184, 148, 0.1);
  border-color: rgba(0, 184, 148, 0.2);
}

.status-dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: #D63031;
}

.connection-status.connected .status-dot {
  background: #00B894;
  animation: pulse 2s infinite;
}

@keyframes pulse {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.5; }
}

.status-text {
  font-size: 12px;
  color: #636E72;
}

.connection-status.connected .status-text {
  color: #00B894;
}

.time-display {
  text-align: right;
}

.time-display .date {
  display: block;
  font-size: 14px;
  color: #636E72;
}

.time-display .time {
  display: block;
  font-size: 24px;
  color: #2D3436;
  font-weight: 600;
  font-family: 'SF Mono', 'DIN', 'Courier New', monospace;
}

.fullscreen-btn {
  width: 80px;
  height: 44px;
  background: #FFFFFF;
  border: 1px solid #DFE6E9;
  border-radius: 4px;
  color: #636E72;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.3s;
  font-size: 14px;
}

.fullscreen-btn:hover {
  background: #F0F2F5;
  color: #2D3436;
}

.dashboard-grid {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.stats-row {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 16px;
}

.stat-card {
  background: #FFFFFF;
  border-radius: 4px;
  border: 1px solid #DFE6E9;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
  padding: 20px;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
}

.stat-icon {
  width: 48px;
  height: 48px;
  border-radius: 4px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 24px;
}

.people-card .stat-icon { background: rgba(0, 184, 148, 0.1); color: #00B894; }
.alert-card .stat-icon { background: rgba(214, 48, 49, 0.1); color: #D63031; }
.camera-card .stat-icon { background: rgba(9, 132, 227, 0.1); color: #0984E3; }
.processing-card .stat-icon { background: rgba(45, 52, 54, 0.1); color: #2D3436; }

.stat-content {
  margin-top: 15px;
}

.stat-value {
  display: block;
  font-size: 36px;
  font-weight: 700;
  color: #2D3436;
  font-family: 'SF Mono', 'DIN', 'Courier New', monospace;
}

.stat-label {
  display: block;
  font-size: 14px;
  color: #636E72;
  margin-top: 4px;
}

.stat-trend {
  display: flex;
  align-items: center;
  gap: 6px;
  margin-top: 10px;
  font-size: 12px;
}

.stat-trend.positive { color: #00B894; }
.stat-trend.negative { color: #D63031; }

.map-row {
  display: flex;
  justify-content: center;
  gap: 16px;
}

.map-chart {
  width: 60%;
}

.chart-row {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 16px;
}

.chart-row:first-of-type {
  grid-template-columns: repeat(3, 1fr);
}

.chart-card {
  background: #FFFFFF;
  border-radius: 4px;
  border: 1px solid #DFE6E9;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
  padding: 20px;
}

.large-chart {
  grid-column: span 2;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 15px;
}

.card-title {
  font-size: 16px;
  color: #2D3436;
  font-weight: 600;
}

.card-count {
  font-size: 12px;
  color: #636E72;
  background: #F0F2F5;
  padding: 4px 10px;
  border-radius: 4px;
}

.card-tabs {
  display: flex;
  gap: 10px;
}

.tab-item {
  font-size: 12px;
  color: #636E72;
  padding: 4px 12px;
  border-radius: 4px;
  cursor: pointer;
  transition: all 0.3s;
}

.tab-item:hover {
  background: #F0F2F5;
}

.tab-item.active {
  background: rgba(9, 132, 227, 0.1);
  color: #0984E3;
}

.chart-container {
  height: 280px;
}

.risk-chart .chart-container {
  height: 200px;
}

.risk-legend {
  display: flex;
  justify-content: center;
  gap: 20px;
  margin-top: 15px;
}

.legend-item {
  display: flex;
  align-items: center;
  gap: 6px;
}

.legend-color {
  width: 12px;
  height: 12px;
  border-radius: 4px;
}

.legend-color.high { background: #D63031; }
.legend-color.medium { background: #E17055; }
.legend-color.low { background: #FDCB6E; }
.legend-color.active { background: #00B894; }
.legend-color.inactive { background: #B2BEC3; }
.legend-color.alert { background: #D63031; }

.legend-text {
  font-size: 12px;
  color: #636E72;
}

.map-chart .chart-container {
  height: 280px;
}

.map-legend {
  display: flex;
  justify-content: center;
  gap: 20px;
  margin-top: 10px;
}

.alert-list {
  max-height: 280px;
  overflow-y: auto;
}

.alert-list::-webkit-scrollbar {
  width: 6px;
}

.alert-list::-webkit-scrollbar-thumb {
  background: #B2BEC3;
  border-radius: 3px;
}

.alert-item {
  background: #FFFFFF;
  border-radius: 4px;
  padding: 12px;
  margin-bottom: 10px;
  border: 1px solid #DFE6E9;
}

.alert-item.high { border-left: 3px solid #D63031; }
.alert-item.medium { border-left: 3px solid #E17055; }
.alert-item.low { border-left: 3px solid #FDCB6E; }

.alert-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 8px;
}

.alert-level-tag {
  font-size: 11px;
  padding: 2px 8px;
  border-radius: 4px;
  font-weight: 600;
}

.alert-item.high .alert-level-tag {
  background: rgba(214, 48, 49, 0.1);
  color: #D63031;
}

.alert-item.medium .alert-level-tag {
  background: rgba(225, 112, 85, 0.1);
  color: #E17055;
}

.alert-item.low .alert-level-tag {
  background: rgba(253, 203, 110, 0.1);
  color: #FDCB6E;
}

.alert-time {
  font-size: 12px;
  color: #636E72;
}

.alert-body {
  display: flex;
  gap: 12px;
  margin-bottom: 6px;
}

.alert-camera, .alert-area {
  font-size: 12px;
  color: #636E72;
}

.alert-reason {
  font-size: 13px;
  color: #2D3436;
}

.empty-alert {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 40px;
  color: #636E72;
}

.empty-alert span {
  font-size: 14px;
}

@media (max-width: 1200px) {
  .stats-row {
    grid-template-columns: repeat(2, 1fr);
  }
  
  .chart-row {
    grid-template-columns: 1fr;
  }
  
  .chart-row:first-of-type {
    grid-template-columns: 1fr;
  }
  
  .large-chart {
    grid-column: span 1;
  }
  
  .map-chart {
    grid-column: span 1;
  }
}

@media (max-width: 768px) {
  .stats-row {
    grid-template-columns: 1fr;
  }
  
  .dashboard-header {
    flex-direction: column;
    gap: 15px;
    text-align: center;
  }
  
  .header-right {
    flex-direction: column;
  }
  
  .time-display {
    text-align: center;
  }
}
</style>