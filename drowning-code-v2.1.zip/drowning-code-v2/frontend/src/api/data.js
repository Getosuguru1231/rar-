import request from "@/util/request";
import { updateDeviceStatus } from '@/stores/deviceData'
import { wgs84ToGcj02 } from '@/util/coordTransform'
import { parseNmeaGPS } from '@/util/gpsParser'

const BASE_URL = import.meta.env.VITE_API_BASE_URL || '/api';

let eventSource = null;
let reconnectTimer = null;
let shouldReconnect = true;
let savedOnMessage = null;
let savedOnError = null;

/**
 * 获取历史数据
 * @param {number} limit - 返回条数，默认100
 */
export function getHistoryData(limit = 100) {
  return request({
    url: '/device/history',
    method: 'get',
    params: { limit }
  })
}

/**
 * 连接SSE获取设备数据
 * @param {Function} onMessage - 接收数据的回调函数
 * @param {Function} onError - 错误处理回调函数
 */
export function connectSSE(onMessage, onError) {
  savedOnMessage = onMessage;
  savedOnError = onError;
  shouldReconnect = true;

  if (eventSource && eventSource.readyState === EventSource.OPEN) {
    console.log('SSE连接已存在且正常，跳过重建');
    return eventSource;
  }

  if (eventSource) {
    eventSource.close();
  }

  const clientId = 'client_' + Date.now();
  const url = `${BASE_URL}/device/stream?clientId=${clientId}`;
  
  eventSource = new EventSource(url);

  eventSource.addEventListener('deviceData', (e) => {
    const rawData = JSON.parse(e.data);
    console.log('原始数据:', rawData);
    
    let timestamp = parseInt(rawData.timestamp) || parseInt(rawData.dataTime)
    
    if (timestamp && timestamp < 10000000000) {
      timestamp = timestamp * 1000
    }
    
    if (!timestamp) {
      timestamp = Date.now()
    }
    
    const result = {
      deviceId: rawData.deviceId || 'boat',
      timestamp: timestamp,
      data: [
        { identifier: 'IRTemp', value: parseFloat(rawData.irTempValue) || 0 },
        { identifier: 'RadarEcho', value: parseFloat(rawData.radarValue) || 0 },
        { identifier: 'SonarDepth', value: parseFloat(rawData.sonarValue) || 0 },
        { identifier: 'SignalStr', value: parseFloat(rawData.signalValue) || 0 }
      ]
    };

    // 加入 GPS 数据（如果存在）
    if (rawData.gpsData) {
      const gps = rawData.gpsData
      let lat = typeof gps.latitude === 'number' ? gps.latitude : null
      let lng = typeof gps.longitude === 'number' ? gps.longitude : null

      // 如果没有解析好的十进制坐标，从 Lat/Lon 字符串直接转数字
      if ((lat === null || lng === null) && gps.Lat && gps.Lon) {
        lat = parseFloat(gps.Lat)
        lng = parseFloat(gps.Lon)
      }

      // WGS-84 转 GCJ-02（高德地图使用火星坐标系）—— 已注释，直接使用 GPS 原始坐标
      // if (lat !== null && lng !== null) {
      //   const [gcjLat, gcjLng] = wgs84ToGcj02(lat, lng)
      //   lat = gcjLat
      //   lng = gcjLng
      // }

      result.data.push({
        identifier: 'GPS',
        value: '定位',
        lat: lat,
        lng: lng,
        rawLat: gps.Lat || null,
        rawLon: gps.Lon || null,
        sig: gps.Sig || null
      })
    }
    
    console.log('转换后数据:', result);
    
    if (onMessage) {
      onMessage(result);
    }
  });

  eventSource.addEventListener('deviceStatus', (e) => {
    const status = JSON.parse(e.data);
    console.log('设备状态:', status);
    updateDeviceStatus(status);
  });

  eventSource.onopen = () => {
    console.log('SSE连接已建立');
    if (savedOnMessage) {
      import('element-plus').then(({ ElMessage }) => {
        ElMessage.success('SSE 连接已恢复，开始接收实时数据')
      }).catch(() => {})
    }
  };

  eventSource.onerror = (error) => {
    console.error('SSE连接错误:', error);
    if (onError) {
      onError(error);
    }
    // 强制清理旧连接并重建，防止浏览器卡死状态
    if (shouldReconnect) {
      if (reconnectTimer) clearTimeout(reconnectTimer);
      reconnectTimer = setTimeout(() => {
        reconnectTimer = null;
        if (eventSource) {
          eventSource.close();
          eventSource = null;
        }
        console.log('正在重连SSE...');
        connectSSE(savedOnMessage, savedOnError);
      }, 2000);
    }
  };

  return eventSource;
}

/**
 * 关闭SSE连接
 */
export function closeSSE() {
  shouldReconnect = false;
  if (reconnectTimer) {
    clearTimeout(reconnectTimer);
    reconnectTimer = null;
  }
  if (eventSource) {
    eventSource.close();
    eventSource = null;
    console.log('SSE连接已手动关闭');
  }
}
