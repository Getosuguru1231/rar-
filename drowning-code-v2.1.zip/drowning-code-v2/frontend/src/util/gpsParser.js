/**
 * 解析 NMEA 格式的经纬度字符串
 * 例如: "2240.9255838N" -> 22.6820930633
 *       "11011.7295610E" -> 110.1954926833
 * @param {string} latStr - 纬度字符串，如 "2240.9255838N"
 * @param {string} lonStr - 经度字符串，如 "11011.7295610E"
 * @returns {{latitude: number, longitude: number}}
 */
export function parseNmeaGPS(latStr, lonStr) {
  const parseCoord = (str, isLat) => {
    if (!str || typeof str !== 'string') return null
    const degreesLength = isLat ? 2 : 3
    const degrees = parseInt(str.slice(0, degreesLength), 10)
    const minutes = parseFloat(str.slice(degreesLength, -1))
    const direction = str.slice(-1).toUpperCase()
    
    if (isNaN(degrees) || isNaN(minutes)) return null
    
    let decimal = degrees + minutes / 60
    if (direction === 'S' || direction === 'W') {
      decimal = -decimal
    }
    return decimal
  }

  return {
    latitude: parseCoord(latStr, true),
    longitude: parseCoord(lonStr, false)
  }
}

/**
 * 解析后端返回的完整 gpsData 对象
 * 优先使用已解析好的 latitude/longitude，否则从 NMEA 字符串解析
 * @param {Object} gpsData - { Lat, Lon, latitude, longitude }
 * @returns {{latitude: number|null, longitude: number|null}}
 */
export function parseGPSData(gpsData) {
  if (!gpsData || typeof gpsData !== 'object') {
    return { latitude: null, longitude: null }
  }

  // 优先使用已经解析好的十进制坐标
  if (typeof gpsData.latitude === 'number' && typeof gpsData.longitude === 'number') {
    return {
      latitude: gpsData.latitude,
      longitude: gpsData.longitude
    }
  }

  // 尝试从 NMEA 字符串解析
  if (gpsData.Lat && gpsData.Lon) {
    return parseNmeaGPS(gpsData.Lat, gpsData.Lon)
  }

  return { latitude: null, longitude: null }
}
