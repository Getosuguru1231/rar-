/**
 * WGS-84 与 GCJ-02（火星坐标系）相互转换
 * 高德地图使用 GCJ-02，GPS 模块通常输出 WGS-84
 */

const PI = 3.14159265358979324
const A = 6378245.0
const EE = 0.00669342162296594323

function transformLat(lng, lat) {
  let ret = -100.0 + 2.0 * lng + 3.0 * lat + 0.2 * lat * lat + 0.1 * lng * lat + 0.2 * Math.sqrt(Math.abs(lng))
  ret += (20.0 * Math.sin(6.0 * lng * PI) + 20.0 * Math.sin(2.0 * lng * PI)) * 2.0 / 3.0
  ret += (20.0 * Math.sin(lat * PI) + 40.0 * Math.sin(lat / 3.0 * PI)) * 2.0 / 3.0
  ret += (160.0 * Math.sin(lat / 12.0 * PI) + 320 * Math.sin(lat * PI / 30.0)) * 2.0 / 3.0
  return ret
}

function transformLon(lng, lat) {
  let ret = 300.0 + lng + 2.0 * lat + 0.1 * lng * lng + 0.1 * lng * lat + 0.1 * Math.sqrt(Math.abs(lng))
  ret += (20.0 * Math.sin(6.0 * lng * PI) + 20.0 * Math.sin(2.0 * lng * PI)) * 2.0 / 3.0
  ret += (20.0 * Math.sin(lng * PI) + 40.0 * Math.sin(lng / 3.0 * PI)) * 2.0 / 3.0
  ret += (150.0 * Math.sin(lng / 12.0 * PI) + 300.0 * Math.sin(lng / 30.0 * PI)) * 2.0 / 3.0
  return ret
}

function outOfChina(lat, lng) {
  return (lng < 72.004 || lng > 137.8347) || (lat < 0.8293 || lat > 55.8271)
}

/**
 * WGS-84 转 GCJ-02（火星坐标系）
 * @param {number} lat - WGS-84 纬度
 * @param {number} lng - WGS-84 经度
 * @returns {[number, number]} [gcjLat, gcjLng]
 */
export function wgs84ToGcj02(lat, lng) {
  if (outOfChina(lat, lng)) {
    return [lat, lng]
  }
  let dLat = transformLat(lng - 105.0, lat - 35.0)
  let dLng = transformLon(lng - 105.0, lat - 35.0)
  const radLat = lat / 180.0 * PI
  let magic = Math.sin(radLat)
  magic = 1 - EE * magic * magic
  const sqrtMagic = Math.sqrt(magic)
  dLat = (dLat * 180.0) / ((A * (1 - EE)) / (magic * sqrtMagic) * PI)
  dLng = (dLng * 180.0) / (A / sqrtMagic * Math.cos(radLat) * PI)
  const mgLat = lat + dLat
  const mgLng = lng + dLng
  return [mgLat, mgLng]
}

/**
 * GCJ-02（火星坐标系）转 WGS-84
 * @param {number} lat - GCJ-02 纬度
 * @param {number} lng - GCJ-02 经度
 * @returns {[number, number]} [wgsLat, wgsLng]
 */
export function gcj02ToWgs84(lat, lng) {
  if (outOfChina(lat, lng)) {
    return [lat, lng]
  }
  const [gcjLat, gcjLng] = wgs84ToGcj02(lat, lng)
  const wgsLat = lat * 2 - gcjLat
  const wgsLng = lng * 2 - gcjLng
  return [wgsLat, wgsLng]
}
