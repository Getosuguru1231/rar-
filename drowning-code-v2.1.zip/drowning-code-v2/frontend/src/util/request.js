import axios from 'axios'
import { ElMessage } from 'element-plus'

const request = axios.create({
  baseURL: '/api',
  timeout: 5000
})

// 纯前端模式：不拦截，不校验 token
request.interceptors.response.use(
  response => response.data,
  error => {
    console.error('响应错误:', error)
    const err = new Error(error.message || '网络错误')
    err.isHandled = true
    return Promise.reject(err)
  }
)

export default request
