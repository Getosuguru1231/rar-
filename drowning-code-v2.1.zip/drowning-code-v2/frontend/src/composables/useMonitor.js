/**
 * 监控页面核心逻辑 Composable
 * 管理摄像头、告警、WebSocket连接等核心功能
 * 使用 alertStore 作为统一的告警数据源
 */
import { ref, reactive, computed, onMounted, onUnmounted } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import { useVideoStream } from './useVideoStream.js'
import { apiGet, apiDelete, executeWithRetry } from '../utils/api.js'
import { API_CONSTANTS } from '../utils/index.js'
import { alertStore } from '../stores/alertStore.js'
import { getAlertsWsUrl, getMonitorWsUrl } from '../config/websocket.js'

export function useMonitor() {
  const router = useRouter()
  const isMounted = ref(true)
  
  // ========== 视频流处理(使用统一的Composable) ==========
  const {
    handleImageLoad,
    handleImageError,
    handleVideoError,
    reloadVideo: reloadVideoStream,
    getVideoStreamState,
    initVideoStreamState,
    startHeartbeatCheck,
    stopHeartbeatCheck
  } = useVideoStream()
  
  // ========== 用户信息 ==========
  const username = ref(localStorage.getItem('username') || 'admin')
  const userType = ref(localStorage.getItem('userType') || 'user')
  
  // ========== 基础状态 ==========
  const activeTab = ref('alerts')
  const splitScreen = ref(1)
  const isFullscreen = ref(false)
  const activeCameraId = ref(1)
  
  // ========== 视频回放相关状态 ==========
  const currentTime = ref(0)
  const timelineMax = ref(3600)
  const isPlaying = ref(false)
  const selectDate = ref(null)
  const alertMarks = ref([])
  
  // ========== 视频流时间戳同步 ==========
  let timestampPollingTimer = null
  const TIMESTAMP_POLLING_INTERVAL = 5000 // 5秒轮询一次，减少请求频率，提高稳定性
  
  /**
   * 启动视频流时间戳轮询
   * 定期从后端获取视频流的实时时间戳信息
   * 用于同步显示视频进度和总时长
   */
  const startTimestampPolling = () => {
    // 清除已存在的定时器
    stopTimestampPolling()
    
    console.log('[Monitor] 🕒 启动视频流时间戳轮询')
    
    // 立即执行一次
    fetchVideoTimestamp()
    
    // 设置定时轮询
    timestampPollingTimer = setInterval(() => {
      fetchVideoTimestamp()
    }, TIMESTAMP_POLLING_INTERVAL)
  }
  
  /**
   * 停止视频流时间戳轮询
   */
  const stopTimestampPolling = () => {
    if (timestampPollingTimer) {
      clearInterval(timestampPollingTimer)
      timestampPollingTimer = null
      console.log('[Monitor] 🕒 停止视频流时间戳轮询')
    }
  }
  
  /**
   * 从后端获取视频流时间戳
   */
  const fetchVideoTimestamp = async () => {
    try {
      // 使用 apiGet 函数调用后端API
      const result = await apiGet('/api/video/timestamp', {});
      
      if (result.stream_running) {
        const { video_duration, frame_age, is_fresh, fps_estimate } = result
        
        // 更新视频总时长（从后端获取的实际运行时长）
        if (video_duration !== null && video_duration !== undefined) {
          timelineMax.value = Math.round(video_duration)
        }
        
        // 更新当前播放时间（基于视频运行时长）
        // 对于实时视频流，当前时间就是视频总时长
        currentTime.value = Math.round(video_duration || 0)
      } else {
        // 如果视频流未运行，使用默认值
        timelineMax.value = 3600 // 默认1小时
        currentTime.value = 0
      }
    } catch (error) {
      // 网络错误，使用默认值
      timelineMax.value = 3600 // 默认1小时
      currentTime.value = 0
    }
  }
  
  /**
   * 格式化秒数为 HH:MM:SS 格式
   * @param {number} seconds - 秒数
   * @returns {string} 格式化后的时间字符串
   */
  const formatSeconds = (seconds) => {
    if (!seconds || seconds < 0) return '00:00:00'
    
    const hours = Math.floor(seconds / 3600)
    const minutes = Math.floor((seconds % 3600) / 60)
    const secs = Math.floor(seconds % 60)
    
    return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(secs).padStart(2, '0')}`
  }
  
  // ========== 标记提示状态 ==========
  const markerTipVisible = ref(false)
  const markerTipX = ref(0)
  const markerTipY = ref(0)
  const markerTipText = ref('')
  const markerTipOverflow = ref(false)
  
  // ========== 摄像头和警报状态 ==========
  const cameras = ref([
    { id: 1, area: '主摄像头', peopleCount: 0, inWaterCount: 0, outOfWaterCount: 0, hasAlert: false, videoLoaded: false, videoError: false, retryCount: 0, isConfigured: false },
    { id: 2, area: 'RDK X5 Edge摄像头', peopleCount: 0, inWaterCount: 0, outOfWaterCount: 0, hasAlert: false, videoLoaded: false, videoError: false, retryCount: 0, isConfigured: false },
    { id: 3, area: '远程摄像头3', peopleCount: 0, inWaterCount: 0, outOfWaterCount: 0, hasAlert: false, videoLoaded: false, videoError: false, retryCount: 0, isConfigured: false },
    { id: 4, area: '远程摄像头4', peopleCount: 0, inWaterCount: 0, outOfWaterCount: 0, hasAlert: false, videoLoaded: false, videoError: false, retryCount: 0, isConfigured: false }
  ])

  // 使用 alertStore 的告警列表作为统一数据源
  const alertList = computed(() => alertStore.getAlerts())
  const activeAlert = ref(-1)
  
  // ========== 计算属性 ==========
  const totalPeopleCount = computed(() => 
    cameras.value.reduce((sum, c) => sum + c.peopleCount, 0)
  )
  
  const areaDistribution = computed(() => {
    return cameras.value.map(c => ({ name: c.area, count: c.peopleCount }))
  })
  
  const displayedCameras = computed(() => {
    if (splitScreen.value === 1) {
      const active = cameras.value.find(c => c.id === activeCameraId.value)
      return active ? [active] : []
    }
    return cameras.value.slice(0, splitScreen.value)
  })
  
  // 使用 alertStore 的统计数据
  const todayAlertStats = computed(() => {
    const stats = alertStore.getStats()
    return {
      total: stats.todayTotal,
      handled: stats.todayHandled,
      pending: stats.todayPending
    }
  })
  
  // 同步更新统计数据
  const updateAlertStats = () => {
    alertStore.updateStats()
    console.log('[Monitor] 告警统计已更新:', alertStore.getStats())
  }
  
  const systemUptime = ref('0 天 0 小时')
  
  // ========== WebSocket连接 ==========
  let ws = null
  let reconnectAttempts = 0
  const MAX_RECONNECT_ATTEMPTS = 10
  const RECONNECT_DELAY_BASE = 3000
  
  // WebSocket连接状态
  const wsConnected = ref(false)
  
  const connectWebSocket = () => {
    try {
      // 重置连接状态
      wsConnected.value = false
      
      const wsUrl = getMonitorWsUrl()
      
      console.log('[WebSocket] 尝试连接:', wsUrl)
      
      // 关闭旧连接
      if (ws) {
        ws.close()
        ws = null
      }
      
      ws = new WebSocket(wsUrl)
      
      // 设置超时
      const connectionTimeout = setTimeout(() => {
        if (ws && ws.readyState !== WebSocket.OPEN) {
          console.warn('[WebSocket] 连接超时，关闭连接')
          ws.close()
        }
      }, 10000) // 10秒超时
      
      ws.onopen = () => {
        clearTimeout(connectionTimeout)
        console.log('[WebSocket] 连接成功')
        wsConnected.value = true
        reconnectAttempts = 0
        // 连接成功后立即获取一次告警列表，确保数据同步
        fetchAlertList().catch(console.error)
        
        // 启动心跳
        startWebSocketHeartbeat()
      }
      
      ws.onmessage = (event) => {
        try {
          console.log('[WebSocket] 收到消息:', event.data)
          const data = JSON.parse(event.data)
          handleAlertEvent(data)
        } catch (error) {
          console.error('[WebSocket] 解析消息失败:', error, event.data)
        }
      }
      
      ws.onerror = (error) => {
        clearTimeout(connectionTimeout)
        console.error('[WebSocket] 连接错误:', error)
        wsConnected.value = false
      }
      
      ws.onclose = (event) => {
        clearTimeout(connectionTimeout)
        console.log('[WebSocket] 连接关闭:', event.code, event.reason)
        wsConnected.value = false
        
        // 停止心跳
        stopWebSocketHeartbeat()
        
        // 根据关闭码决定是否重新连接
        // 1000: 正常关闭, 1001: 端点离开, 1005: 无状态码
        if (event.code === 1000) {
          console.log('[WebSocket] 正常关闭，不再重连')
          return
        }
        
        // 指数退避重连
        if (reconnectAttempts < MAX_RECONNECT_ATTEMPTS) {
          const delay = Math.min(RECONNECT_DELAY_BASE * Math.pow(2, reconnectAttempts), 30000)
          reconnectAttempts++
          console.log(`[WebSocket] 尝试重新连接 (${reconnectAttempts}/${MAX_RECONNECT_ATTEMPTS})，延迟 ${delay}ms`)
          setTimeout(() => {
            if (!ws || ws.readyState === WebSocket.CLOSED) {
              connectWebSocket()
            }
          }, delay)
        } else {
          console.error('[WebSocket] 已达到最大重连次数，停止尝试')
          ElMessage.error('WebSocket连接失败，将使用轮询方式获取告警')
        }
      }
    } catch (error) {
      console.error('[WebSocket] 初始化失败:', error)
    }
  }
  
  let wsHeartbeatTimer = null
  
  const startWebSocketHeartbeat = () => {
    if (wsHeartbeatTimer) {
      clearInterval(wsHeartbeatTimer)
    }
    wsHeartbeatTimer = setInterval(() => {
      if (ws && ws.readyState === WebSocket.OPEN) {
        try {
          ws.send('ping')
          console.log('[WebSocket] 发送心跳')
        } catch (e) {
          console.error('[WebSocket] 发送心跳失败:', e)
        }
      }
    }, 10000) // 10秒心跳
  }
  
  const stopWebSocketHeartbeat = () => {
    if (wsHeartbeatTimer) {
      clearInterval(wsHeartbeatTimer)
      wsHeartbeatTimer = null
    }
  }
  
  const handleAlertEvent = (data) => {
    if (!isMounted.value) {
      console.warn('[Monitor] 组件已卸载，跳过事件处理')
      return
    }
    const messageType = data.type || 'alert'
    
    if (messageType === 'alert_delete') {
      // 删除告警
      const deleteData = data.data || data
      const alertId = String(deleteData.id)
      alertStore.deleteAlert(alertId)
      
      // 更新摄像头的告警状态
      const alerts = alertStore.getAlerts()
      cameras.value.forEach(camera => {
        const hasPendingAlerts = alerts.some(a => !a.acknowledged && a.cameraId === camera.id)
        camera.hasAlert = hasPendingAlerts
      })
      
    } else if (messageType === 'alert_clear') {
      // 清空所有告警
      alertStore.clearAll()
      
      // 更新摄像头的告警状态
      cameras.value.forEach(camera => {
        camera.hasAlert = false
      })
      
    } else if (messageType === 'alert_update') {
      // 更新告警状态
      const alertData = data.data || data
      const alertId = String(alertData.id) || `${alertData.time}-${alertData.cameraId}-${alertData.area}`
      alertStore.updateAlertStatus(alertId, {
        acknowledged: alertData.acknowledged,
        resolved: alertData.resolved,
        acknowledged_time: alertData.acknowledged_time
      })
      
      // 如果第一次匹配失败，尝试其他可能的 alertId 格式
      const existingAlert = alertStore.getAlert(alertId)
      if (!existingAlert) {
        const alternativeAlertId = `${alertData.time}-${alertData.cameraId}-${alertData.area}`
        alertStore.updateAlertStatus(alternativeAlertId, {
          acknowledged: alertData.acknowledged,
          resolved: alertData.resolved
        })
      }
      
      // 更新摄像头的告警状态
      const cameraId = alertData.cameraId || alertData.camera_id || 1
      const camera = cameras.value.find(c => c.id === cameraId)
      if (camera) {
        const alerts = alertStore.getAlerts()
        const hasPendingAlerts = alerts.some(a => !a.acknowledged && a.cameraId === camera.id)
        camera.hasAlert = hasPendingAlerts
      }
      
    } else {
      // 添加新告警（内部已包含 updateStats 调用）
      const alertData = data.data || data
      alertStore.addAlert(alertData)
      const cameraId = alertData.cameraId || alertData.camera_id || 1
      playAlertSound(cameraId)
      
      // 更新摄像头的告警状态
      const camera = cameras.value.find(c => c.id === cameraId)
      if (camera) {
        const alerts = alertStore.getAlerts()
        const hasPendingAlerts = alerts.some(a => !a.acknowledged && a.cameraId === camera.id)
        camera.hasAlert = hasPendingAlerts
      }
    }
  }
  
  // ========== 心跳机制 ==========
  let heartbeatTimer = null
  
  const startHeartbeat = () => {
    heartbeatTimer = setInterval(() => {
      if (ws && ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({ type: 'heartbeat', timestamp: Date.now() }))
      }
    }, 30000)
  }
  
  const stopHeartbeat = () => {
    if (heartbeatTimer) {
      clearInterval(heartbeatTimer)
    }
  }
  
  // ========== 定时刷新 ==========
  let refreshTimer = null
  let alertPollingTimer = null
  const ALERT_POLLING_INTERVAL = 10000 // 10秒轮询一次告警
  
  const startPeriodicRefresh = () => {
    refreshTimer = setInterval(() => {
      refreshCameraStatus()
      updateSystemUptime()
    }, 2000) // 调整为2秒，确保人数统计实时更新
  }
  
  // 启动告警轮询（WebSocket失败时的备份机制）
  const startAlertPolling = () => {
    if (alertPollingTimer) {
      clearInterval(alertPollingTimer)
    }
    
    alertPollingTimer = setInterval(() => {
      // 只有在WebSocket断开时才轮询
      if (!wsConnected.value) {
        fetchAlertList().catch(console.error)
      }
    }, ALERT_POLLING_INTERVAL)
    
    console.log('[Monitor] 告警轮询已启动')
  }
  
  // 停止告警轮询
  const stopAlertPolling = () => {
    if (alertPollingTimer) {
      clearInterval(alertPollingTimer)
      alertPollingTimer = null
      console.log('[Monitor] 告警轮询已停止')
    }
  }
  
  // 测试函数：使用 apiGet 函数发送请求（使用统一的API调用方式）
  const testApiConnection = async () => {
    console.log('[Test] 开始测试 API 连接');
    
    try {
      console.log('[Test] 发送 API 请求到 /video/people-count');
      const result = await apiGet('/api/video/people-count', {});
      
      const data = result.data || result;
      
      console.log('[Test] API 连接成功!');
      console.log('[Test] 人数统计:', data);
    } catch (error) {
      console.error('[Test] API 请求错误:', error);
      console.error('[Test] 网络错误，无法连接到后端服务');
    }
  }  

  const refreshCameraStatus = async () => {
    try {
      const result = await apiGet('/api/video/people-count', {});
      const data = result.data || result;
      
      const peopleCount = data.people_count || data.total_people || 0
      const inWaterCount = data.in_water_count || data.people_in_water || 0
      const outOfWaterCount = data.out_of_water_count || data.people_out_water || 0
      
      if (cameras.value.length > 0) {
        cameras.value[0].peopleCount = peopleCount
        cameras.value[0].inWaterCount = inWaterCount
        cameras.value[0].outOfWaterCount = outOfWaterCount
      }
      
      if (data.cameras && typeof data.cameras === 'object') {
        Object.keys(data.cameras).forEach(cameraId => {
          const camera = cameras.value.find(c => c.id === parseInt(cameraId))
          if (camera && data.cameras[cameraId]) {
            const camData = data.cameras[cameraId]
            camera.peopleCount = camData.people_count || camData.peopleCount || 0
            camera.inWaterCount = camData.in_water_count || camData.inWaterCount || 0
            camera.outOfWaterCount = camData.out_of_water_count || camData.outOfWaterCount || 0
          }
        })
      }
      
      console.log('[Monitor] 人数统计已更新:', { peopleCount, inWaterCount, outOfWaterCount })
    } catch (error) {
      console.error('[Monitor] 获取人数统计失败:', error);
      if (cameras.value.length > 0) {
        cameras.value[0].peopleCount = 0
        cameras.value[0].inWaterCount = 0
        cameras.value[0].outOfWaterCount = 0
      }
    }
  }
  
  const updateSystemUptime = () => {
    const now = new Date()
    const start = new Date(now.getFullYear(), now.getMonth(), now.getDate())
    const diff = now - start
    const hours = Math.floor(diff / (1000 * 60 * 60))
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60))
    systemUptime.value = `0 天 ${hours}小时 ${minutes}分钟`
  }
  
  // ========== 界面交互方法 ==========
  const toggleFullscreen = async (cameraId = null) => {
    try {
      let element
      let targetName = '页面'
      
      // 检查参数类型，确保 cameraId 是数字或 null
      if (cameraId && typeof cameraId !== 'number') {
        // 如果不是数字，可能是事件对象，使用 null 处理
        console.warn('[Fullscreen] ⚠️ 收到无效的 cameraId 参数，使用页面全屏')
        cameraId = null
      }
      
      if (cameraId) {
        // 通过data属性精确查找对应的摄像头容器
        element = document.querySelector(`.screen-item[data-camera-id="${cameraId}"]`)
        targetName = `摄像头${cameraId}`
        
        if (!element) {
          console.warn(`[Fullscreen] ⚠️ 未找到${targetName}的容器元素`)
          ElMessage.warning(`${targetName}的画面不存在,请刷新页面重试`)
          return
        }
        
        console.log(`[Fullscreen] 📺 准备全屏显示${targetName}`)
      } else {
        // 全屏整个页面
        element = document.documentElement
        console.log('[Fullscreen] 🖥️  准备全屏显示整个页面')
      }
      
      // 检查浏览器支持
      const hasFullscreenSupport = !!(
        element.requestFullscreen ||
        element.webkitRequestFullscreen ||
        element.mozRequestFullScreen ||
        element.msRequestFullscreen
      )
      
      if (!hasFullscreenSupport) {
        throw new Error('当前浏览器不支持全屏功能,请使用Chrome、Firefox、Edge或Safari浏览器')
      }
      
      if (!document.fullscreenElement && 
          !document.webkitFullscreenElement && 
          !document.mozFullScreenElement && 
          !document.msFullscreenElement) {
        // 进入全屏
        console.log(`[Fullscreen] ✅ 正在进入全屏模式...`)
        
        if (element.requestFullscreen) {
          await element.requestFullscreen({ navigationUI: 'hide' })
        } else if (element.webkitRequestFullscreen) {
          await element.webkitRequestFullscreen()
        } else if (element.mozRequestFullScreen) {
          await element.mozRequestFullScreen()
        } else if (element.msRequestFullscreen) {
          await element.msRequestFullscreen()
        }
        
        isFullscreen.value = true
        console.log(`[Fullscreen] ✨ ${targetName}已进入全屏模式`)
        ElMessage.success(`${targetName}已进入全屏模式，按 ESC 退出`)
      } else {
        // 退出全屏
        console.log('[Fullscreen] 🚪 正在退出全屏模式...')
        
        if (document.exitFullscreen) {
          await document.exitFullscreen()
        } else if (document.webkitExitFullscreen) {
          await document.webkitExitFullscreen()
        } else if (document.mozCancelFullScreen) {
          await document.mozCancelFullScreen()
        } else if (document.msExitFullscreen) {
          await document.msExitFullscreen()
        }
        
        isFullscreen.value = false
        console.log('[Fullscreen] 👋 已退出全屏模式')
      }
    } catch (error) {
      console.error('[Fullscreen] ❌ 全屏切换失败:', error)
      
      // 提供更友好的错误提示
      let errorMessage = '全屏模式不可用'
      
      if (error.name === 'NotAllowedError') {
        errorMessage = '全屏请求被拒绝,请确保用户交互(点击/双击)后再试'
      } else if (error.name === 'NotSupportedError') {
        errorMessage = '当前元素不支持全屏显示'
      } else if (error.message.includes('浏览器不支持')) {
        errorMessage = error.message
      } else {
        errorMessage = `全屏失败: ${error.message}`
      }
      
      ElMessage.error(errorMessage)
    }
  }
  
  const handleFullscreenChange = () => {
    const isCurrentlyFullscreen = !!(document.fullscreenElement || 
                            document.webkitFullscreenElement || 
                            document.mozFullScreenElement || 
                            document.msFullscreenElement)
    isFullscreen.value = isCurrentlyFullscreen
  }
  
  const refreshAll = () => {
    console.log('[Monitor] 🔄 刷新所有画面')
    // 重置所有摄像头的状态
    cameras.value.forEach(camera => {
      camera.hasAlert = false
      camera.videoLoaded = false
      camera.videoError = false
      camera.retryCount = 0
      // 调用 useVideoStream 的刷新方法
      reloadVideoStream(camera.id)
    })
    ElMessage.success('所有画面已刷新')
  }
  
  const changeSplitScreen = (command) => {
    splitScreen.value = parseInt(command)
    const count = splitScreen.value
    while (cameras.value.length < count) {
      const nextId = cameras.value.length + 1
      cameras.value.push({
        id: nextId,
        area: `监控区域${nextId}`,
        peopleCount: 0,
        inWaterCount: 0,
        outOfWaterCount: 0,
        hasAlert: false
      })
    }
  }
  
  const setActiveCamera = (cameraId) => {
    // 检查参数类型，确保 cameraId 是数字
    if (typeof cameraId === 'number') {
      activeCameraId.value = cameraId
    } else {
      // 如果不是数字，可能是事件对象，忽略
      console.warn('[Monitor] ⚠️ 收到无效的 cameraId 参数，忽略设置')
    }
  }
  
  const jumpToAlert = (alert, index) => {
    activeAlert.value = index
    activeCameraId.value = alert.cameraId
    splitScreen.value = 1
  }
  
  const confirmAlert = async (alert) => {
    if (!alert) return
    
    // 在 try 块外定义 alertId，确保 catch 块中可以访问
    const alertId = alert.alertId || String(alert.id) || `${alert.time}-${alert.cameraId}-${alert.area}`
    
    try {
      // 使用统一的 alertId（数字ID）调用后端API
      const numericId = alert.id || (alert.alertId ? parseInt(alert.alertId) : null)
      
      if (!numericId) {
        ElMessage.error('告警ID无效')
        return
      }
      
      const response = await fetch(`${API_CONSTANTS.BASE_URL}/alert/acknowledge/${numericId}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      })
      
      if (response.ok) {
        // 使用 alertStore 更新告警状态 - 使用字符串格式的 alertId
        alertStore.updateAlertStatus(alertId, { acknowledged: true })
        ElMessage.success('告警已确认处理')
        
        // 更新摄像头的告警状态
        const camera = cameras.value.find(c => c.id === alert.cameraId)
        if (camera) {
          const alerts = alertStore.getAlerts()
          const hasPendingAlerts = alerts.some(a => !a.acknowledged && a.cameraId === camera.id)
          camera.hasAlert = hasPendingAlerts
        }
      } else {
        const errorText = await response.text()
        console.error('[Monitor] 确认告警失败:', errorText)
        ElMessage.error(`确认告警失败: ${errorText}`)
      }
    } catch (error) {
      console.error('[Monitor] 确认告警失败:', error)
      // 本地标记失败，提示用户
      alertStore.updateAlertStatus(alertId, { acknowledged: true })
      ElMessage.success('告警已确认处理（本地）')
    }
  }
  
  const deleteAlert = async (alert) => {
    if (!alert) return
    
    try {
      // 获取 alertId
      const alertId = alert.alertId || String(alert.id) || `${alert.time}-${alert.cameraId}-${alert.area}`
      
      // 使用数字ID调用后端API
      const numericId = alert.id || (alert.alertId ? parseInt(alert.alertId) : null)
      
      if (!numericId) {
        ElMessage.error('告警ID无效')
        return
      }
      
      // 确认删除
      const confirmResult = await ElMessageBox.confirm('确定要删除这条告警吗？', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
      
      if (confirmResult !== 'confirm') {
        return
      }
      
      const result = await apiDelete(`/api/alerts/delete/${numericId}`)
      
      if (result && result.code === 200) {
        // 使用 alertStore 删除告警
        alertStore.deleteAlert(alertId)
        ElMessage.success('告警已删除')
        
        // 更新摄像头的告警状态
        const camera = cameras.value.find(c => c.id === alert.cameraId)
        if (camera) {
          const alerts = alertStore.getAlerts()
          const hasPendingAlerts = alerts.some(a => !a.acknowledged && a.cameraId === camera.id)
          camera.hasAlert = hasPendingAlerts
        }
      } else {
        console.error('[Monitor] 删除告警失败:', result)
        ElMessage.error(`删除告警失败: ${result?.message || '未知错误'}`)
      }
    } catch (error) {
      if (error !== 'cancel') {
        console.error('[Monitor] 删除告警失败:', error)
        ElMessage.error('删除告警失败')
      }
    }
  }
  
  const deleteAllAlerts = async () => {
    try {
      // 确认删除
      const confirmResult = await ElMessageBox.confirm('确定要删除所有告警吗？此操作不可恢复！', '警告', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'error'
      })
      
      if (confirmResult !== 'confirm') {
        return
      }
      
      const response = await fetch(`${API_CONSTANTS.BASE_URL}/alert/delete-all`, {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      })
      
      if (response.ok) {
        const data = await response.json()
        // 使用 alertStore 清空所有告警
        alertStore.clearAll()
        ElMessage.success(data.message || '所有告警已删除')
        
        // 更新摄像头的告警状态
        cameras.value.forEach(camera => {
          camera.hasAlert = false
        })
      } else {
        const errorText = await response.text()
        console.error('[Monitor] 删除所有告警失败:', errorText)
        ElMessage.error(`删除所有告警失败: ${errorText}`)
      }
    } catch (error) {
      if (error !== 'cancel') {
        console.error('[Monitor] 删除所有告警失败:', error)
        ElMessage.error('删除所有告警失败')
      }
    }
  }
  
  const fetchAlertList = async (retryCount = 0) => {
    const MAX_RETRIES = 3
    const RETRY_DELAY = 2000
    
    try {
      const result = await apiGet('/api/alerts/list', { limit: 200 })
      
      if (result && result.code === 200 && result.data && Array.isArray(result.data)) {
        alertStore.setAlerts(result.data)
        
        console.log('[Monitor] 从后端获取告警列表成功，共', alertStore.getAlerts().length, '条')
        
        return alertStore.getAlerts()
      }
      
      return []
    } catch (error) {
      console.error('[Monitor] 获取告警列表失败:', error)
      
      if (retryCount < MAX_RETRIES) {
        console.log(`[Monitor] 网络错误，正在重试 (${retryCount + 1}/${MAX_RETRIES})`)
        await new Promise(resolve => setTimeout(resolve, RETRY_DELAY * (retryCount + 1)))
        return fetchAlertList(retryCount + 1)
      }
      
      return []
    }
  }
  
  const clearAllAlerts = () => {
    ElMessageBox.confirm('确定要清除所有告警吗？', '提示', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    }).then(() => {
      // 使用 alertStore 清除所有告警
      const alerts = alertStore.getAlerts()
      alerts.forEach(alert => {
        alertStore.updateAlertStatus(alert.alertId, { acknowledged: true })
      })
      ElMessage.success('所有告警已确认处理')
    }).catch(() => {})
  }
  
  const goToAdmin = () => {
    // 打开新标签页导航到React管理员页面
    window.open('http://localhost:5173/', '_blank')
  }
  
  const handleLogout = () => {
    ElMessageBox.confirm('确定要退出登录吗？', '提示', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    }).then(() => {
      localStorage.removeItem('token')
      localStorage.removeItem('username')
      localStorage.removeItem('userType')
      router.push('/login')
      ElMessage.success('已退出登录')
    }).catch(() => {})
  }
  
  const playAlertSound = (cameraId = 1) => {
    const audio = new Audio('/alert.mp3')
    audio.play().catch(err => {
      console.warn('播放告警声音失败:', err)
    })
    
    const speakText = `摄像头${cameraId}出现溺水行为，请立即处理`
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(speakText)
      utterance.lang = 'zh-CN'
      utterance.rate = 1
      utterance.pitch = 1
      utterance.volume = 1
      window.speechSynthesis.speak(utterance)
      console.log('[Alert] 语音播报:', speakText)
    } else {
      console.warn('[Alert] 当前浏览器不支持语音播报')
    }
  }
  
  // ========== 初始化视频状态 ==========
  const initVideoStatus = () => {
    // 先注册事件监听器（关键：确保在视频流加载前监听器已就绪）
    window.addEventListener('videoStreamTimeout', handleVideoStreamTimeout)
    window.addEventListener('videoStreamLoaded', handleVideoStreamLoaded)
    console.log('[Monitor] ✅ 视频流事件监听器已注册')
    
    // 再初始化摄像头状态
    cameras.value.forEach(camera => {
      // 对于MJPEG流，URL设置后浏览器会自动开始接收数据
      // 所以我们立即标记为已加载，避免一直显示"加载中"
      camera.videoLoaded = true  // MJPEG流特性：URL设置即开始流式传输
      camera.videoError = false
      camera.retryCount = 0
      camera.maxRetries = 5
      camera.lastErrorTime = null
      
      // 同步初始化useVideoStream的状态
      initVideoStreamState(camera.id)
      
      // 启动心跳检测（监控连接状态）
      startHeartbeatCheck(camera.id)
    })
    
    console.log('[Monitor] ✅ 摄像头视频状态已初始化（MJPEG流模式）')
  }
  
  // ========== 视频流重载（同步摄像头对象状态） ==========
  const reloadVideo = (cameraId) => {
    console.log(`[Monitor] 🔄 重新加载摄像头${cameraId}`)
    
    const camera = cameras.value.find(c => c.id === cameraId)
    if (camera) {
      // 重置摄像头对象的状态
      camera.videoLoaded = false
      camera.videoError = false
      camera.retryCount = 0
    }
    
    // 调用useVideoStream的重载方法（会重新启动超时计时器）
    reloadVideoStream(cameraId)
  }
  
  // ========== 监听视频流超时事件，同步到摄像头对象 ==========
  const handleVideoStreamTimeout = (event) => {
    const { cameraId } = event.detail
    console.warn(`[Monitor] ⏰ 摄像头${cameraId} 视频流超时`)
    
    const camera = cameras.value.find(c => c.id === cameraId)
    if (camera) {
      camera.videoError = true
      camera.videoLoaded = false
    }
  }
  
  // ========== 监听视频流加载成功事件，同步到摄像头对象 ==========
  const handleVideoStreamLoaded = (event) => {
    const { cameraId } = event.detail
    console.log(`[Monitor] ✅ 摄像头${cameraId} 视频流加载成功`)
    
    const camera = cameras.value.find(c => c.id === cameraId)
    if (camera) {
      camera.videoLoaded = true
      camera.videoError = false
      camera.retryCount = 0
    }
  }
  
  // ========== 生命周期 ==========
  onMounted(async () => {
    console.log('[Monitor] 组件已挂载，开始初始化...')
    
    try {
      const token = localStorage.getItem('token')
      console.log('[Monitor] token:', token ? '存在' : '不存在')
      if (!token) {
        console.warn('[Monitor] 未检测到token，跳转到登录页')
        router.push('/login')
        return
      }
      
      initVideoStatus()  // 已经在initVideoStatus中注册了事件监听器
      console.log('[Monitor] 准备连接WebSocket...')
      connectWebSocket()
      console.log('[Monitor] WebSocket连接已调用')
      startHeartbeat()
      startPeriodicRefresh()
      startTimestampPolling()  // 启动视频流时间戳轮询
      startAlertPolling()      // 启动告警轮询备份机制
      
      // 注意：事件监听器已在initVideoStatus中注册，这里不需要重复注册
      
      document.addEventListener('fullscreenchange', handleFullscreenChange)
      document.addEventListener('webkitfullscreenchange', handleFullscreenChange)
      document.addEventListener('mozfullscreenchange', handleFullscreenChange)
      document.addEventListener('MSFullscreenChange', handleFullscreenChange)
      
      console.log('[Monitor] 初始化完成')
    } catch (error) {
      console.error('[Monitor] 初始化失败:', error)
      ElMessage.error('页面初始化失败，请刷新重试')
    }
  })
  
  onUnmounted(() => {
    isMounted.value = false
    
    if (ws) {
      ws.close()
    }
    stopHeartbeat()
    stopWebSocketHeartbeat()
    if (refreshTimer) {
      clearInterval(refreshTimer)
    }
    stopTimestampPolling()
    stopAlertPolling()
    
    cameras.value.forEach(camera => {
      stopHeartbeatCheck(camera.id)
    })
    
    window.removeEventListener('videoStreamTimeout', handleVideoStreamTimeout)
    window.removeEventListener('videoStreamLoaded', handleVideoStreamLoaded)
    
    document.removeEventListener('fullscreenchange', handleFullscreenChange)
    document.removeEventListener('webkitfullscreenchange', handleFullscreenChange)
    document.removeEventListener('mozfullscreenchange', handleFullscreenChange)
    document.removeEventListener('MSFullscreenChange', handleFullscreenChange)
    
    console.log('[Monitor] 组件已卸载，资源已清理')
  })
  
  return {
    // 状态
    username,
    userType,
    activeTab,
    splitScreen,
    isFullscreen,
    activeCameraId,
    currentTime,
    timelineMax,
    isPlaying,
    selectDate,
    alertMarks,
    markerTipVisible,
    markerTipX,
    markerTipY,
    markerTipText,
    markerTipOverflow,
    cameras,
    alertList,
    activeAlert,
    totalPeopleCount,
    areaDistribution,
    displayedCameras,
    todayAlertStats,
    systemUptime,
    wsConnected,  // WebSocket连接状态
    
    // 方法
    connectWebSocket,
    handleAlertEvent,
    startHeartbeat,
    stopHeartbeat,
    startPeriodicRefresh,
    refreshCameraStatus,
    updateSystemUptime,
    toggleFullscreen,
    handleFullscreenChange,
    refreshAll,
    changeSplitScreen,
    setActiveCamera,
    jumpToAlert,
    confirmAlert,
    deleteAlert,
    deleteAllAlerts,
    clearAllAlerts,
    goToAdmin,
    handleLogout,
    playAlertSound,
    initVideoStatus,
    reloadVideo,
    handleImageLoad,
    handleImageError,
    formatSeconds,  // 添加时间格式化函数
    fetchAlertList  // 添加获取告警列表方法
  }
}