import { ref, onUnmounted, watch, nextTick } from 'vue'
import { getWebRtcWsUrl } from '@/config/websocket.js'
import {
  DEFAULT_CONFIG,
  SIGNALING_MESSAGE_TYPES,
  getReconnectDelay,
  validateSDP,
  logConnectionState,
  setLowLatencySDP,
  getIceServers
} from '@/utils/webrtc.js'

export function useWebRTC(cameraId, options = {}) {
  const config = { ...DEFAULT_CONFIG, ...options }

  const pc = ref(null)
  const remoteStream = ref(null)
  const localStream = ref(null)
  const signalingSocket = ref(null)

  const connectionState = ref('new')
  const iceConnectionState = ref('new')
  const iceGatheringState = ref('new')

  const isConnected = ref(false)
  const isConnecting = ref(false)
  const reconnectAttempts = ref(0)
  const maxReconnectAttempts = options.maxReconnectAttempts || 10
  const minReconnectDelay = 1000
  const maxReconnectDelay = 30000
  const reconnectBackoffFactor = 1.5

  const error = ref(null)
  const stats = ref({})

  const reconnectTimer = ref(null)
  const heartbeatTimer = ref(null)
  const statsTimer = ref(null)
  const connectionTimeoutTimer = ref(null)
  const lastHeartbeatTime = ref(Date.now())
  const lastPongTime = ref(Date.now())
  const missedPongs = ref(0)
  const maxMissedPongs = 5
  const pingSentTime = ref(0)
  const waitingForPong = ref(false)
  const reconnectCooldown = ref(0)
  
  const heartbeatInterval = 10000
  const pongTimeout = 15000

  const addedCandidates = ref(new Set())

  const sendSignalingMessage = (type, data = {}) => {
    const socket = signalingSocket.value
    if (!socket) {
      console.warn('[WebRTC] WebSocket不存在，无法发送消息')
      return
    }
    
    // 检查 WebSocket 连接状态
    if (socket.readyState !== WebSocket.OPEN) {
      console.warn(`[WebRTC] WebSocket状态不是OPEN (状态: ${socket.readyState}), 跳过发送消息: ${type}`)
      return
    }
    
    try {
      const message = { type, ...data }
      socket.send(JSON.stringify(message))
      console.log('[WebRTC] 发送信令消息:', type)
    } catch (e) {
      console.error('[WebRTC] 发送消息失败:', e.message)
    }
  }

  const getSignalingUrl = () => {
    return getWebRtcWsUrl(cameraId)
  }

  const handleSignalingMessage = async (event) => {
    try {
      const message = JSON.parse(event.data)
      console.log('[WebRTC] 收到信令消息:', message.type)

      switch (message.type) {
        case SIGNALING_MESSAGE_TYPES.OFFER:
          await handleOffer(message)
          break

        case SIGNALING_MESSAGE_TYPES.ANSWER:
          await handleAnswer(message)
          break

        case SIGNALING_MESSAGE_TYPES.ICE_CANDIDATE:
          await handleIceCandidate(message)
          break

        case SIGNALING_MESSAGE_TYPES.ERROR:
          console.error('[WebRTC] 信令错误:', message.message)
          error.value = message.message
          break

        case SIGNALING_MESSAGE_TYPES.PING:
          console.log('[WebRTC] 收到后端PING，回复PONG')
          sendSignalingMessage(SIGNALING_MESSAGE_TYPES.PONG)
          lastPongTime.value = Date.now()
          break

        case SIGNALING_MESSAGE_TYPES.PONG:
          console.log('[WebRTC] 收到Pong响应')
          lastPongTime.value = Date.now()
          pingSentTime.value = 0
          waitingForPong.value = false
          missedPongs.value = 0
          break

        default:
          console.log('[WebRTC] 未知消息类型:', message.type)
      }
    } catch (e) {
      console.error('[WebRTC] 解析消息失败:', e)
    }
  }

  const handleOffer = async (message) => {
    console.log('[WebRTC] 收到Offer')
    if (!pc.value || !message.sdp) return

    const sdpValidation = validateSDP(message.sdp)
    if (!sdpValidation.valid) {
      console.error('[WebRTC] 无效的SDP:', sdpValidation.error)
      sendSignalingMessage(SIGNALING_MESSAGE_TYPES.ERROR, { message: '无效的SDP' })
      return
    }

    try {
      const desc = new RTCSessionDescription({
        type: 'offer',
        sdp: message.sdp
      })
      await pc.value.setRemoteDescription(desc)

      const answer = await pc.value.createAnswer()
      await pc.value.setLocalDescription(answer)

      sendSignalingMessage(SIGNALING_MESSAGE_TYPES.ANSWER, { sdp: answer.sdp })
      console.log('[WebRTC] Answer已发送')
    } catch (e) {
      console.error('[WebRTC] 处理Offer失败:', e)
      sendSignalingMessage(SIGNALING_MESSAGE_TYPES.ERROR, { message: '处理Offer失败: ' + e.message })
    }
  }

  const handleAnswer = async (message) => {
    console.log('[WebRTC] 收到Answer，设置远程描述')
    if (pc.value) {
      const desc = new RTCSessionDescription({
        type: 'answer',
        sdp: message.sdp
      })
      await pc.value.setRemoteDescription(desc)
      console.log('[WebRTC] 远程描述设置成功')
    }
  }

  const handleIceCandidate = async (message) => {
    console.log('[WebRTC] 收到ICE候选')
    if (message.candidate && pc.value) {
      try {
        const candidateData = message.candidate
        const candidateKey = `${candidateData.candidate || ''}_${candidateData.sdpMid}_${candidateData.sdpMLineIndex}`

        if (addedCandidates.value.has(candidateKey)) {
          console.log('[WebRTC] ICE候选已存在，跳过')
          return
        }

        addedCandidates.value.add(candidateKey)

        // 正确构造 ICE 候选
        const iceCandidateInit = {
          candidate: candidateData.candidate,
          sdpMid: candidateData.sdpMid,
          sdpMLineIndex: candidateData.sdpMLineIndex
        }
        
        const iceCandidate = new RTCIceCandidate(iceCandidateInit)
        await pc.value.addIceCandidate(iceCandidate)
        console.log('[WebRTC] ICE候选添加成功')
      } catch (e) {
        console.error('[WebRTC] 添加ICE候选失败:', e.message)
      }
    }
  }

  const createPeerConnection = () => {
    if (pc.value) {
      try {
        pc.value.close()
      } catch (e) {
        console.warn('[WebRTC] 关闭旧PeerConnection失败:', e)
      }
    }

    console.log('[WebRTC] 创建RTCPeerConnection')
    const iceServers = getIceServers()
    const connectionConfig = { ...config, iceServers }
    pc.value = new RTCPeerConnection(connectionConfig)

    pc.value.oniceconnectionstatechange = () => {
        iceConnectionState.value = pc.value.iceConnectionState
        const state = pc.value.iceConnectionState
        
        console.log('[WebRTC] ICE连接状态变化:', state)
        
        if (state === 'connected' || state === 'completed') {
            reconnectAttempts.value = 0
            missedPongs.value = 0
            isConnected.value = true
            error.value = null
            startStatsMonitor()
            console.log('[WebRTC] ✅ ICE连接成功')
        } else if (state === 'failed') {
            console.error('[WebRTC] ❌ ICE连接失败，尝试重连...')
            isConnected.value = false
            setTimeout(() => {
                if (!isConnecting.value && !isConnected.value) {
                    scheduleReconnect()
                }
            }, 2000)
        } else if (state === 'disconnected') {
            console.warn('[WebRTC] ⚠️ ICE连接断开，等待15秒确认并尝试刷新候选...')
            setTimeout(() => {
                if (pc.value && pc.value.iceConnectionState === 'disconnected') {
                    console.warn('[WebRTC] ⚠️ ICE连接仍断开，尝试刷新ICE候选...')
                    try {
                        pc.value.restartIce()
                        console.log('[WebRTC] 已触发ICE重启')
                    } catch (e) {
                        console.error('[WebRTC] ICE重启失败:', e)
                        console.error('[WebRTC] ❌ ICE连接确认断开，尝试重连')
                        isConnected.value = false
                        scheduleReconnect()
                    }
                }
            }, 15000)
        } else if (state === 'closed') {
            isConnected.value = false
            console.log('[WebRTC] ICE连接已关闭')
        }
    }

    pc.value.onicegatheringstatechange = () => {
      iceGatheringState.value = pc.value.iceGatheringState
      // 减少日志输出
    }

    pc.value.onconnectionstatechange = () => {
      connectionState.value = pc.value.connectionState
      logConnectionState(pc.value)
    }

    pc.value.ontrack = (event) => {
      try {
        if (!event || !event.track) {
          console.warn('[WebRTC] 无效的track事件，跳过')
          return
        }
        console.log('[WebRTC] 收到远程轨道:', event.track.kind, 'readyState:', event.track.readyState)

        if (event.track.kind === 'video') {
          const receivers = pc.value.getReceivers()
          const videoReceiver = receivers.find(r => r.track.kind === 'video')
          if (videoReceiver) {
            try {
              if ('jitterBufferTarget' in videoReceiver) {
                videoReceiver.jitterBufferTarget = 0.015
                console.log('[WebRTC] JitterBuffer目标已设置为15ms')
              }
              if ('jitterBufferMax' in videoReceiver) {
                videoReceiver.jitterBufferMax = 0.05
                console.log('[WebRTC] JitterBuffer最大已设置为50ms')
              }
              if ('jitterBufferFastAccelerate' in videoReceiver) {
                videoReceiver.jitterBufferFastAccelerate = true
                console.log('[WebRTC] JitterBuffer快速加速已启用')
              }
              if ('playoutDelayHint' in videoReceiver) {
                videoReceiver.playoutDelayHint = 0.015
                console.log('[WebRTC] playoutDelayHint已设置为15ms')
              }
              if ('minPlayoutDelay' in videoReceiver) {
                videoReceiver.minPlayoutDelay = 0
                console.log('[WebRTC] minPlayoutDelay已设置为0ms')
              }
              if ('enableLowLatency' in videoReceiver) {
                videoReceiver.enableLowLatency = true
                console.log('[WebRTC] 低延迟模式已启用')
              }
            } catch (e) {
              console.warn('[WebRTC] 设置jitterBuffer失败:', e.message)
            }
          }
        }

        let newStream = null
        
        if (event.streams && event.streams.length > 0 && event.streams[0]) {
          newStream = event.streams[0]
          console.log('[WebRTC] 从事件中获取到流')
        } else {
          console.log('[WebRTC] 创建新流并添加轨道')
          newStream = new MediaStream()
          if (event.track && typeof event.track.stop === 'function') {
            newStream.addTrack(event.track)
          }
        }
        
        if (newStream) {
          try {
            const tracks = newStream.getTracks()
            if (tracks && tracks.length > 0) {
              console.log('[WebRTC] 更新远程流, 轨道数量:', tracks.length)
              remoteStream.value = newStream
              isConnected.value = true
              isConnecting.value = false
              reconnectAttempts.value = 0
              console.log('[WebRTC] ✅ 视频流已更新，readyState:', tracks[0].readyState)
              
              startStatsMonitor()
            } else {
              console.warn('[WebRTC] 流中没有有效轨道，跳过')
            }
          } catch (streamErr) {
            console.error('[WebRTC] 验证流失败:', streamErr)
          }
        }
      } catch (e) {
        console.error('[WebRTC] 处理track事件失败:', e)
      }
    }

    pc.value.onicecandidate = (event) => {
      if (event.candidate) {
        console.log('[WebRTC] 生成ICE候选')
        sendSignalingMessage(SIGNALING_MESSAGE_TYPES.ICE_CANDIDATE, {
          candidate: {
            candidate: event.candidate.candidate,
            sdpMid: event.candidate.sdpMid,
            sdpMLineIndex: event.candidate.sdpMLineIndex
          }
        })
      } else {
        console.log('[WebRTC] ICE候选收集完成')
      }
    }
  }

  const startHeartbeat = () => {
    if (heartbeatTimer.value) {
      clearInterval(heartbeatTimer.value)
    }

    lastHeartbeatTime.value = Date.now()
    lastPongTime.value = Date.now()
    missedPongs.value = 0

    heartbeatTimer.value = setInterval(() => {
      const now = Date.now()

      if (signalingSocket.value && signalingSocket.value.readyState === WebSocket.OPEN) {
        if (now - lastHeartbeatTime.value >= heartbeatInterval) {
          try {
            sendSignalingMessage(SIGNALING_MESSAGE_TYPES.PING)
            lastHeartbeatTime.value = now
            pingSentTime.value = now
            waitingForPong.value = true
            console.log('[WebRTC] 发送PING，等待PONG响应')
          } catch (e) {
            console.error('[WebRTC] 发送心跳失败:', e)
          }
        }

        if (waitingForPong.value && now - pingSentTime.value >= pongTimeout) {
          missedPongs.value++
          waitingForPong.value = false
          console.warn(`[WebRTC] PONG响应超时 (${missedPongs.value}/${maxMissedPongs})`)
          
          if (missedPongs.value >= maxMissedPongs) {
            console.error('[WebRTC] PONG响应超时次数过多，断开连接并重新连接')
            error.value = 'PONG响应超时，WebRTC连接失败'
            stopHeartbeat()
            disconnect()
            setTimeout(() => {
              if (!isConnected.value && now > reconnectCooldown.value) {
                reconnectCooldown.value = now + 3000
                connect()
              }
            }, 3000)
          }
        }
      } else if (signalingSocket.value && signalingSocket.value.readyState !== WebSocket.CONNECTING) {
        stopHeartbeat()
        if (now > reconnectCooldown.value) {
          reconnectCooldown.value = now + 2000
          scheduleReconnect()
        }
      } else if (!signalingSocket.value) {
        stopHeartbeat()
      }
    }, 3000)
  }

  const stopHeartbeat = () => {
    if (heartbeatTimer.value) {
      clearInterval(heartbeatTimer.value)
      heartbeatTimer.value = null
    }
  }

  const startStatsMonitor = () => {
    if (statsTimer.value) {
      clearInterval(statsTimer.value)
    }

    statsTimer.value = setInterval(async () => {
      if (pc.value && pc.value.connectionState === 'connected') {
        try {
          const statsReport = await pc.value.getStats()
          const formatted = formatStats(statsReport)
          stats.value = formatted
        } catch (e) {
          console.error('[WebRTC] 获取统计信息失败:', e)
        }
      }
    }, 5000)
  }

  const stopStatsMonitor = () => {
    if (statsTimer.value) {
      clearInterval(statsTimer.value)
      statsTimer.value = null
    }
  }

  const formatStats = (statsReport) => {
    const result = {
      video: { fps: 0, bitrate: 0, packetsLost: 0, bytesReceived: 0, jitter: 0, delay: 0 },
      audio: { bitrate: 0, packetsLost: 0, bytesReceived: 0 },
      roundTripTime: 0,
      decodeLatency: 0
    }

    statsReport.forEach((report) => {
      if (report.type === 'inbound-rtp' && report.kind === 'video') {
        result.video.fps = Math.round(report.framesPerSecond || 0)
        result.video.bitrate = report.bytesReceived ? Math.round((report.bytesReceived * 8) / 1000) : 0
        result.video.packetsLost = report.packetsLost || 0
        result.video.bytesReceived = report.bytesReceived || 0
        result.video.jitter = report.jitter ? Math.round(report.jitter * 1000) : 0
        result.video.delay = report.totalReceiveDelay ? Math.round(report.totalReceiveDelay * 1000) : 0
      } else if (report.type === 'inbound-rtp' && report.kind === 'audio') {
        result.audio.bitrate = report.bytesReceived ? Math.round((report.bytesReceived * 8) / 1000) : 0
        result.audio.packetsLost = report.packetsLost || 0
        result.audio.bytesReceived = report.bytesReceived || 0
      } else if (report.type === 'transport') {
        result.roundTripTime = Math.round((report.roundTripTime || 0) * 1000)
      } else if (report.type === 'decoder' && report.kind === 'video') {
        result.decodeLatency = report.totalDecodeTime ? Math.round((report.totalDecodeTime / (report.framesDecoded || 1)) * 1000) : 0
      }
    })

    return result
  }

  const createSignalingConnection = () => {
    if (signalingSocket.value) {
      signalingSocket.value.close()
      signalingSocket.value = null
    }

    const wsUrl = getSignalingUrl()
    console.log('[WebRTC] 重建信令连接:', wsUrl)

    signalingSocket.value = new WebSocket(wsUrl)

    signalingSocket.value.onopen = () => {
      console.log('[WebRTC] 信令连接已重建')
      startHeartbeat()
    }

    signalingSocket.value.onmessage = handleSignalingMessage

    signalingSocket.value.onerror = (e) => {
      console.error('[WebRTC] 信令重建错误:', e)
      scheduleReconnect()
    }

    signalingSocket.value.onclose = (event) => {
      console.log('[WebRTC] 信令重建连接关闭', {
        code: event.code,
        reason: event.reason,
        wasClean: event.wasClean
      })
      stopHeartbeat()
      if (!event.wasClean) {
        scheduleReconnect()
      }
    }
  }

  const scheduleReconnect = (force = false) => {
    const now = Date.now()
    
    if (!force && reconnectAttempts.value >= maxReconnectAttempts) {
      console.error('[WebRTC] 达到最大重连次数，停止重连')
      error.value = '无法连接到服务器，请检查网络连接'
      return
    }

    if (now < reconnectCooldown.value && !force) {
      const remaining = reconnectCooldown.value - now
      console.log(`[WebRTC] 重连冷却中，${remaining}ms后再尝试`)
      if (reconnectTimer.value) {
        clearTimeout(reconnectTimer.value)
      }
      reconnectTimer.value = setTimeout(() => {
        scheduleReconnect(force)
      }, remaining)
      return
    }

    if (!force) {
      reconnectAttempts.value++
    }
    
    const baseDelay = minReconnectDelay
    const maxDelay = maxReconnectDelay
    const delay = Math.min(baseDelay * Math.pow(reconnectBackoffFactor, reconnectAttempts.value - 1), maxDelay)
    const jitter = delay * 0.1
    const actualDelay = delay + jitter * (Math.random() * 2 - 1)

    console.log(`[WebRTC] ${Math.round(actualDelay)}ms后进行第${reconnectAttempts.value}次重连`)

    if (reconnectTimer.value) {
      clearTimeout(reconnectTimer.value)
    }

    reconnectCooldown.value = now + actualDelay + 1000

    reconnectTimer.value = setTimeout(() => {
      console.log('[WebRTC] 开始重连...')
      isConnecting.value = false
      connect()
    }, actualDelay)
  }

  const resetReconnectAttempts = () => {
    reconnectAttempts.value = 0
    error.value = null
    if (reconnectTimer.value) {
      clearTimeout(reconnectTimer.value)
      reconnectTimer.value = null
    }
    console.log('[WebRTC] 重连次数已重置')
  }

  const connect = async () => {
    if (isConnecting.value) {
      console.log('[WebRTC] 已在连接中')
      return
    }
    
    if (isConnected.value || pc.value || signalingSocket.value) {
      console.log('[WebRTC] 清理旧连接...')
      disconnect()
      await new Promise(resolve => setTimeout(resolve, 300))
    }

    isConnecting.value = true
    error.value = null

    if (connectionTimeoutTimer.value) {
      clearTimeout(connectionTimeoutTimer.value)
    }

    connectionTimeoutTimer.value = setTimeout(() => {
      if (isConnecting.value && !isConnected.value) {
        console.error('[WebRTC] 连接超时，强制断开并重连')
        disconnect()
        scheduleReconnect()
      }
    }, 25000)

    try {
      console.log('[WebRTC] === 开始连接流程 ===')
      createPeerConnection()

      const wsUrl = getSignalingUrl()
      console.log('[WebRTC] 连接信令服务器:', wsUrl)

      signalingSocket.value = new WebSocket(wsUrl)

      signalingSocket.value.onopen = async () => {
        if (connectionTimeoutTimer.value) {
          clearTimeout(connectionTimeoutTimer.value)
        }
        console.log('[WebRTC] 信令连接已建立')
        startHeartbeat()

        try {
          if (!pc.value) {
            console.error('[WebRTC] PeerConnection不存在，重新创建')
            createPeerConnection()
          }

          console.log('[WebRTC] 添加接收轨道以生成正确的SDP...')
          
          pc.value.addTransceiver('video', { 
            direction: 'recvonly',
            streams: []
          })
          
          console.log('[WebRTC] 添加视频接收轨道成功')

          console.log('[WebRTC] 创建Offer...')
          const offer = await pc.value.createOffer({
            offerToReceiveAudio: false,
            offerToReceiveVideo: true,
            voiceActivityDetection: false
          })
          
          offer.sdp = setLowLatencySDP(offer.sdp)
          
          console.log('[WebRTC] Offer创建成功，长度:', offer.sdp.length)

          const sdpValidation = validateSDP(offer.sdp)
          if (!sdpValidation.hasVideo) {
            console.log('[WebRTC] 警告: SDP中没有视频轨道')
          }

          await pc.value.setLocalDescription(offer)
          console.log('[WebRTC] 本地描述设置成功')

          sendSignalingMessage(SIGNALING_MESSAGE_TYPES.OFFER, { sdp: offer.sdp })
          console.log('[WebRTC] Offer已发送')
        } catch (e) {
          console.error('[WebRTC] 创建或发送Offer失败:', e.message, e.stack)
          error.value = '创建Offer失败: ' + e.message
          isConnecting.value = false
          if (connectionTimeoutTimer.value) {
            clearTimeout(connectionTimeoutTimer.value)
          }
          scheduleReconnect()
        }
      }

      signalingSocket.value.onmessage = handleSignalingMessage

      signalingSocket.value.onerror = (e) => {
        if (signalingSocket.value?.readyState === WebSocket.OPEN) {
          console.log('[WebRTC] WebSocket错误事件但连接正常')
          return
        }
        console.error('[WebRTC] 信令WebSocket错误:', e)
        error.value = '信令服务器连接错误'
        isConnecting.value = false
        if (connectionTimeoutTimer.value) {
          clearTimeout(connectionTimeoutTimer.value)
        }
        scheduleReconnect()
      }

      signalingSocket.value.onclose = (event) => {
        console.log('[WebRTC] 信令连接已关闭', {
          code: event.code,
          reason: event.reason,
          wasClean: event.wasClean
        })
        stopHeartbeat()
        isConnecting.value = false
        if (connectionTimeoutTimer.value) {
          clearTimeout(connectionTimeoutTimer.value)
        }

        const wasMediaConnected = isConnected.value

        if (!event.wasClean && reconnectAttempts.value < maxReconnectAttempts) {
          if (wasMediaConnected && pc.value && pc.value.connectionState === 'connected') {
            console.log('[WebRTC] 信令连接异常关闭，但媒体连接仍正常，延迟5秒后尝试重建信令...')
            setTimeout(() => {
              if (isConnected.value && pc.value && pc.value.connectionState === 'connected') {
                console.log('[WebRTC] 媒体连接仍正常，尝试重建信令连接')
                createSignalingConnection()
              } else {
                console.log('[WebRTC] 媒体连接已断开，启动完整重连')
                scheduleReconnect()
              }
            }, 5000)
          } else {
            console.log('[WebRTC] 信令连接异常关闭，准备重连...')
            setTimeout(() => {
              if (!isConnected.value && !isConnecting.value) {
                scheduleReconnect()
              }
            }, 3000)
          }
        } else if (reconnectAttempts.value >= maxReconnectAttempts) {
          if (!wasMediaConnected) {
            isConnected.value = false
            error.value = '无法连接到服务器，请检查网络连接'
            console.error('[WebRTC] 达到最大重连次数，停止重连')
          } else {
            console.log('[WebRTC] 媒体连接仍正常，信令连接关闭不影响视频流')
          }
        } else {
          if (!wasMediaConnected) {
            isConnected.value = false
          }
        }
      }

    } catch (e) {
      console.error('[WebRTC] 连接失败:', e)
      error.value = e.message
      isConnecting.value = false
      if (connectionTimeoutTimer.value) {
        clearTimeout(connectionTimeoutTimer.value)
      }
      scheduleReconnect()
    }
  }

  const disconnect = () => {
    console.log('[WebRTC] 断开连接...')

    isConnected.value = false
    isConnecting.value = false

    stopHeartbeat()
    stopStatsMonitor()

    if (reconnectTimer.value) {
      clearTimeout(reconnectTimer.value)
      reconnectTimer.value = null
    }

    if (connectionTimeoutTimer.value) {
      clearTimeout(connectionTimeoutTimer.value)
      connectionTimeoutTimer.value = null
    }

    if (signalingSocket.value) {
      try {
        sendSignalingMessage(SIGNALING_MESSAGE_TYPES.CLOSE)
        signalingSocket.value.close(1000, '正常关闭')
      } catch (e) {
        console.error('[WebRTC] 关闭WebSocket失败:', e)
      }
      signalingSocket.value = null
    }

    if (pc.value) {
      try {
        const receivers = pc.value.getReceivers()
        receivers.forEach(receiver => {
          try {
            receiver.stop()
          } catch (e) {
            console.warn('[WebRTC] 停止receiver失败:', e)
          }
        })
        
        const senders = pc.value.getSenders()
        senders.forEach(sender => {
          try {
            pc.value.removeTrack(sender)
          } catch (e) {
            console.warn('[WebRTC] 移除track失败:', e)
          }
        })
        
        pc.value.close()
      } catch (e) {
        console.error('[WebRTC] 关闭PeerConnection失败:', e)
      }
      pc.value = null
    }

    addedCandidates.value.clear()
    missedPongs.value = 0

    console.log('[WebRTC] 已断开连接（保持最后一帧）')
  }

  const toggleConnection = () => {
    if (isConnected.value) {
      disconnect()
    } else {
      connect()
    }
  }

  const restart = () => {
    disconnect()
    setTimeout(() => {
      connect()
    }, 500)
  }

  onUnmounted(() => {
    console.log('[WebRTC] 组件卸载，清理资源')
    disconnect()
  })

  return {
    pc,
    remoteStream,
    localStream,
    connectionState,
    iceConnectionState,
    iceGatheringState,
    isConnected,
    isConnecting,
    reconnectAttempts,
    maxReconnectAttempts,
    error,
    stats,
    connect,
    disconnect,
    toggleConnection,
    restart,
    resetReconnectAttempts
  }
}