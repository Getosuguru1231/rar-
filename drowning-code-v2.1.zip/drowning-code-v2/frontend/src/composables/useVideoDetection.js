/**
 * 视频上传检测 Composable
 * 管理视频上传、检测结果轮询、实时帧获取等功能
 */
import { ref, onMounted, onUnmounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { apiGet, apiPost, apiDelete, createSafeInterval, clearAllTimers, preloadImage, safeExecute, isValidBase64 } from '../utils/api.js'
import { showSuccess, showError } from '../utils/index.js'
import { useVideoStream } from './useVideoStream.js'

export function useVideoDetection() {
  // ========== 视频流处理(已移至useVideoStream) ==========
  // 这些函数现在由 useVideoStream Composable 统一管理
  // 以下是包装函数,保持向后兼容
  
  const {
    handleVideoError: handleVideoErrorBase,
    handleImageLoad: handleImageLoadBase,
    handleImageError: handleImageErrorBase,
    reloadVideo: reloadVideoBase
  } = useVideoStream()
  
  const handleVideoError = (cameraId) => {
    handleVideoErrorBase(cameraId)
  }
  
  const handleImageLoad = (cameraId, event) => {
    handleImageLoadBase(cameraId, event)
  }
  
  const handleImageError = (cameraId, event) => {
    handleImageErrorBase(cameraId, event)
  }
  
  const handleFrameError = (event) => {
    console.warn('[LiveFrame] ⚠️ 视频帧加载失败')
    liveFrameData.value.frameLoaded = false
  }
  
  const reloadVideo = (cameraId) => {
    reloadVideoBase(cameraId)
  }
  
  // ========== 状态 ==========
  const showUploadDialog = ref(false)
  const showResultDialog = ref(false)
  const showTasksDialog = ref(false)
  const showCleanupDialog = ref(false)
  const uploadRef = ref(null)
  const selectedFile = ref(null)
  const isUploading = ref(false)
  const uploadProgress = ref(0)
  const uploadStatus = ref('')
  const currentTaskId = ref('')
  const detectionResult = ref(null)
  const taskList = ref([])
  const pollingTimer = ref(null)
  const liveFrameData = ref({
    frame: null,
    detected_persons: [],
    timestamp: 0,
    progress: 0,
    status: '',
    frameLoaded: false
  })
  const liveFrameTimer = ref(null)

  // 视频清理相关状态
  const videoList = ref([])
  const videoStats = ref({
    total_count: 0,
    total_size: 0
  })
  const cleanupDays = ref(7)
  const isCleaningUp = ref(false)
  const videoFolders = ref([])
  
  let consecutiveFailures = 0
  const MAX_RETRIES = 3
  const SILENT_RETRY_THRESHOLD = 2
  let isCompletedNotified = false
  let lastErrorShownTime = 0
  const ERROR_SHOW_INTERVAL = 30000 // 增加到30秒

  // 稳定性优化配置
  const MAX_CONSECUTIVE_ERRORS = 5 // 最大连续错误次数
  const LIVE_FRAME_RETRY_DELAY = 2000 // 实时帧重试延迟
  
  // 动态轮询配置
  const POLLING_INTERVALS = {
    processing: 2000,      // 处理中：2秒轮询一次检测结果
    idle: 5000,            // 空闲：5秒轮询一次
    completed: 10000,      // 完成后：10秒轮询一次（用于确认状态）
    liveFrame: {
      normal: 150,         // 正常：150ms轮询一次，约6-7fps
      slow: 300,           // 慢速：300ms轮询一次，约3fps
      fast: 100            // 快速：100ms轮询一次，约10fps
    }
  }
  
  // ========== 文件处理 ==========
  const handleFileSelect = (file, fileList) => {
    console.log('[Upload] handleFileSelect called')
    console.log('[Upload] file type:', typeof file)
    console.log('[Upload] file:', file)
    console.log('[Upload] file.raw:', file.raw)
    console.log('[Upload] fileList:', fileList)
    
    const actualFile = file.raw || file
    console.log('[Upload] actualFile:', actualFile)
    const fileName = actualFile.name.toLowerCase()
    const isValidType = /\.(mp4|avi|mov|jpeg|jpg|png|bmp)$/i.test(fileName)
    
    if (!isValidType) {
      ElMessage.error('不支持的文件格式，仅支持MP4/AVI/MOV视频或JPEG/PNG/BMP图片')
      if (uploadRef.value) {
        uploadRef.value.clearFiles()
      }
      return
    }
    
    const isVideo = ['.mp4', '.avi', '.mov'].some(ext => fileName.endsWith(ext))
    const maxSize = isVideo ? 500 * 1024 * 1024 : 50 * 1024 * 1024
    const sizeLimitMB = isVideo ? 500 : 50
    
    if (actualFile.size > maxSize) {
      ElMessage.error(`文件大小超过${sizeLimitMB}MB限制`)
      if (uploadRef.value) {
        uploadRef.value.clearFiles()
      }
      return
    }
    
    selectedFile.value = actualFile
    uploadProgress.value = 0
    uploadStatus.value = ''
  }
  
  const cancelUpload = () => {
    showUploadDialog.value = false
    selectedFile.value = null
    uploadProgress.value = 0
    uploadStatus.value = ''
    if (uploadRef.value) {
      uploadRef.value.clearFiles()
    }
  }
  
  // ========== 上传检测 ==========
  const startUpload = async () => {
    console.log('[Upload] === startUpload 被调用 ===')
    console.log('[Upload] selectedFile:', selectedFile.value)
    console.log('[Upload] selectedFile 存在吗?', !!selectedFile.value)
    console.log('[Upload] selectedFile 类型:', selectedFile.value instanceof File ? 'File' : typeof selectedFile.value)
    console.log('[Upload] showResultDialog:', showResultDialog.value)
    
    if (!selectedFile.value) {
      console.log('[Upload] ❌ 没有选择文件，返回警告')
      ElMessage.warning('请先选择视频文件')
      return
    }

    console.log('[Upload] ✅ 开始上传流程')
    isUploading.value = true
    uploadProgress.value = 0
    uploadStatus.value = ''

    try {
      console.log('[Upload] 准备 FormData...')
      const formData = new FormData()
      formData.append('file', selectedFile.value)
      
      console.log('[Upload] FormData entries:', [...formData.entries()])
      console.log('[Upload] FormData 包含 file 字段吗:', formData.has('file'))

      console.log('[Upload] 🚀 开始上传文件:', selectedFile.value.name)
      
      console.log('[Upload] 调用 apiPost("/detection/upload", formData)...')
      const result = await apiPost('/api/detection/upload', formData, {
        onUploadProgress: (progressEvent) => {
          uploadProgress.value = Math.round((progressEvent.loaded * 100) / progressEvent.total)
          console.log('[Upload] 上传进度:', uploadProgress.value + '%')
        },
        timeout: 60000,
        retry: 3,
        retryDelay: 2000
      })

      console.log('[Upload] ✅ 上传成功, result:', result)
      uploadStatus.value = 'success'
      
      if (!result) {
        showError('上传响应为空，请检查后端服务')
        isUploading.value = false
        return
      }
      
      showSuccess(result.message || result.msg || '视频上传成功,开始检测...')
      currentTaskId.value = result.task_id || result.taskId
      console.log('[Upload] currentTaskId:', currentTaskId.value)
      
      // 先关闭上传对话框，打开结果对话框
      console.log('[Upload] 关闭上传对话框，打开结果对话框...')
      showUploadDialog.value = false
      showResultDialog.value = true
      console.log('[Upload] 📺 已设置 showResultDialog.value =', showResultDialog.value)
      
      // 延迟启动轮询,确保对话框已渲染
      setTimeout(() => {
        console.log('[Upload] ⏱️  延迟启动检测结果轮询...')
        // 重置检测完成通知标志
        isCompletedNotified = false
        pollDetectionResult(currentTaskId.value)
      }, 100)
      
    } catch (error) {
      uploadStatus.value = 'exception'
      console.error('[Upload] ❌ 上传失败:', error)
      if (!error) {
        showError('上传失败,请重试')
      } else if (error.code === 'ECONNABORTED' || (error.message && error.message.includes('timeout'))) {
        showError('上传超时，请检查网络连接和后端服务状态，或尝试上传更小的文件')
      } else {
        showError(error.response?.data?.detail || error.response?.data?.message || error.message || '上传失败,请重试')
      }
    } finally {
      isUploading.value = false
    }
  }
  
  // ========== 轮询检测结果 ==========
  const pollDetectionResult = (taskId) => {
    clearAllTimers(pollingTimer, liveFrameTimer)
    
    let currentInterval = POLLING_INTERVALS.processing
    
    const poll = async () => {
      try {
        const response = await apiGet(`/api/detection/result/${taskId}`, {}, {}, false)
        
        const result = response.data || response
        const taskData = result.data || result
        detectionResult.value = taskData
        
        const status = taskData.status || (response.status || '')
        
        if (status === 'completed' && !isCompletedNotified) {
          showSuccess('检测完成!')
          isCompletedNotified = true
          await loadSavedImages(taskId)
          currentInterval = POLLING_INTERVALS.completed
        } else if (status === 'failed') {
          showError(`检测失败: ${result.error_message || result.message || '未知错误'}`)
          currentInterval = POLLING_INTERVALS.idle
        } else if (status === 'processing') {
          currentInterval = POLLING_INTERVALS.processing
        }
        
        if (status === 'completed') {
          stopLiveFramePolling()
        }
      } catch (error) {
        console.error('查询检测结果失败:', error)
        if (error.response && error.response.status === 404) {
          showError('任务不存在或已过期，请重新上传视频')
          showResultDialog.value = false
          clearAllTimers(pollingTimer, liveFrameTimer)
          return
        }
        if (error.response && error.response.status >= 500) {
          console.error(`[DetectionResult] 服务器错误 ${error.response.status}，停止轮询`)
          showResultDialog.value = false
          clearAllTimers(pollingTimer, liveFrameTimer)
          return
        }
      }
    }
    
    createSafeInterval(poll, currentInterval, pollingTimer, () => {
      return currentInterval
    })
    
    startLiveFramePolling(taskId)
  }
  
  // ========== 实时帧获取 ==========
  const startLiveFramePolling = (taskId) => {
    console.log('[LiveFrame] 开始实时帧轮询, taskId:', taskId)
    
    let currentInterval = POLLING_INTERVALS.liveFrame.normal
    
    fetchLiveFrame(taskId)
    
    createSafeInterval(async () => {
      await fetchLiveFrame(taskId)
      
      const progress = liveFrameData.value.progress || 0
      if (progress < 10) {
        currentInterval = POLLING_INTERVALS.liveFrame.fast
      } else if (progress > 90) {
        currentInterval = POLLING_INTERVALS.liveFrame.slow
      } else {
        currentInterval = POLLING_INTERVALS.liveFrame.normal
      }
    }, currentInterval, liveFrameTimer, () => {
      return currentInterval
    })
  }
  
  // 帧缓存，用于避免重复处理相同的帧
  let frameCache = {}
  
  // 帧预加载队列，用于平滑视频流
  let framePreloadQueue = {}
  
  // 帧时间戳管理，确保按顺序处理帧
  let frameTimestamps = {}
  
  // 帧加载状态管理
  let frameLoadStatus = {}
  
  // 添加错误统计
  let apiErrorStats = {
    network: 0,
    timeout: 0,
    server: 0,
    other: 0,
    lastErrorType: null
  }
  
  const fetchLiveFrame = async (taskId) => {
    try {
      // 避免并发请求
      if (frameLoadStatus[taskId]) {
        return
      }
      
      frameLoadStatus[taskId] = true
      
      const response = await apiGet(`/api/detection/live-frame/${taskId}`, {}, {'Cache-Control': 'no-cache'}, false)
      
      consecutiveFailures = 0
      apiErrorStats.network = 0
      apiErrorStats.timeout = 0
      apiErrorStats.server = 0
      
      const result = response.data || response
      const newData = result.data || result
      
      if (newData.frame && isValidBase64(newData.frame) && newData.frame !== frameCache[taskId]) {
        const currentTimestamp = newData.timestamp || 0
        const lastTimestamp = frameTimestamps[taskId] || 0
        
        if (currentTimestamp >= lastTimestamp) {
          const loaded = await preloadImage(newData.frame)
          
          if (loaded) {
            const frameDataUrl = `data:image/jpeg;base64,${newData.frame}`
            
            requestAnimationFrame(() => {
              liveFrameData.value = {
                ...newData,
                frame: frameDataUrl,
                frameLoaded: true,
                timestamp: currentTimestamp,
                localTimestamp: Date.now()
              }
              
              frameCache[taskId] = newData.frame
              frameTimestamps[taskId] = currentTimestamp
            })
          }
        }
      }
      
      const taskStatus = newData.status || (response.status || '')
      if (taskStatus === 'completed' || taskStatus === 'failed') {
        delete frameCache[taskId]
        delete framePreloadQueue[taskId]
        delete frameTimestamps[taskId]
        delete frameLoadStatus[taskId]
        stopLiveFramePolling()
      }
    } catch (error) {
      consecutiveFailures++
      const now = Date.now()
      const isNetworkError = !error.response || error.code === 'ECONNABORTED' || error.message.includes('timeout') || error.message.includes('Network')
      
      // 分类记录错误
      if (isNetworkError) {
        if (error.message.includes('timeout')) {
          apiErrorStats.timeout++
        } else {
          apiErrorStats.network++
        }
      } else if (error.response?.status >= 500) {
        apiErrorStats.server++
      } else {
        apiErrorStats.other++
      }
      apiErrorStats.lastErrorType = isNetworkError ? 'network' : 'server'
      
      // 静默重试，不显示弹窗
      if (consecutiveFailures <= MAX_CONSECUTIVE_ERRORS) {
        console.warn(`[LiveFrame] ⚠️ 获取实时帧失败 (${consecutiveFailures}/${MAX_CONSECUTIVE_ERRORS}):`, error.message)
      }
      
      if (error.response && error.response.status === 404) {
        if (now - lastErrorShownTime > ERROR_SHOW_INTERVAL) {
          showError('任务不存在或已过期，请重新上传视频')
          lastErrorShownTime = now
        }
        showResultDialog.value = false
        clearAllTimers(pollingTimer, liveFrameTimer)
        delete frameLoadStatus[taskId]
        delete frameCache[taskId]
        return
      }

      // 500错误也需要停止轮询，避免无限重试
      if (error.response && error.response.status >= 500) {
        console.error(`[LiveFrame] 服务器错误 ${error.response.status}，停止轮询`)
        showResultDialog.value = false
        clearAllTimers(pollingTimer, liveFrameTimer)
        delete frameLoadStatus[taskId]
        delete frameCache[taskId]
        return
      }
      
      // 指数退避重试
      if (consecutiveFailures >= MAX_CONSECUTIVE_ERRORS && isNetworkError) {
        const retryDelay = Math.min(LIVE_FRAME_RETRY_DELAY * Math.pow(1.5, consecutiveFailures - MAX_CONSECUTIVE_ERRORS), 30000)
        console.warn(`[LiveFrame] ⚠️ 连续失败次数过多, ${retryDelay/1000}秒后恢复...`)
        
        setTimeout(() => {
          if (liveFrameTimer.value) {
            console.log('[LiveFrame] 🔄 重新连接...')
            consecutiveFailures = 0
            fetchLiveFrame(taskId)
          }
        }, retryDelay)
      }
    } finally {
      delete frameLoadStatus[taskId]
    }
  }
  
  const stopLiveFramePolling = () => {
    if (liveFrameTimer.value) {
      clearInterval(liveFrameTimer.value)
      liveFrameTimer.value = null
      console.log('[LiveFrame] 已停止实时帧轮询')
    }
  }
  
  // ========== 任务管理 ==========
  const showHistoryDialog = async () => {
    await loadTaskList()
    showTasksDialog.value = true
  }
  
  const loadTaskList = async () => {
    await safeExecute(
      async () => {
        const response = await apiGet('/api/detection/tasks', {}, {}, false)
        const result = response.data || response
        const data = result.data || result
        taskList.value = data
      },
      {
        errorMessage: '加载任务列表失败',
        showError: false
      }
    )
  }
  
  const viewTaskResult = async (taskId) => {
    await safeExecute(
      async () => {
        const response = await apiGet(`/api/detection/result/${taskId}`, {}, {}, false)
        const result = response.data || response
        const taskData = result.data || result
        detectionResult.value = taskData
        showResultDialog.value = true
        showTasksDialog.value = false
      },
      {
        errorMessage: '获取检测结果失败'
      }
    )
  }
  
  const deleteTask = async (taskId) => {
    try {
      await ElMessageBox.confirm('确定要删除此任务吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })

      await safeExecute(
        async () => {
          await apiDelete(`/api/detection/task/${taskId}`)
          showSuccess('任务已删除')
          loadTaskList()
        },
        {
          errorMessage: '删除任务失败',
          showError: false
        }
      )
    } catch (error) {
      if (error !== 'cancel') {
        console.error('删除任务失败:', error)
      }
    }
  }

  // ========== 视频清理 ==========
  const loadVideoList = async () => {
    try {
      const data = await apiGet('/api/video/status', {}, {}, false)
      videoList.value = []
      videoStats.value = {
        total_count: data.total_files || 0,
        total_size: data.total_size_gb || 0
      }
    } catch (error) {
      console.error('[VideoCleanup] 加载视频列表失败:', error)
      videoList.value = []
      videoStats.value = { total_count: 0, total_size: 0 }
    }
  }

  const showCleanupHandler = async () => {
    await loadVideoList()
    showCleanupDialog.value = true
  }

  const cleanupOldVideos = async () => {
    if (isCleaningUp.value) return

    isCleaningUp.value = true
    try {
      const result = await apiPost('/api/video/cleanup', { retention_days: cleanupDays.value })
      const deletedCount = result.total_files_deleted || result.deleted || 0
      showSuccess(result.message || `已删除 ${deletedCount} 个视频`)
      await loadVideoList()
    } catch (error) {
      console.error('[VideoCleanup] 清理视频失败:', error)
      showError('清理失败')
    } finally {
      isCleaningUp.value = false
    }
  }

  const deleteAllVideos = async () => {
    if (isCleaningUp.value) return
    
    try {
      const confirmResult = await ElMessageBox.confirm(
        '确定要删除全部视频吗？此操作无法撤销！',
        '警告',
        {
          confirmButtonText: '确定删除',
          cancelButtonText: '取消',
          type: 'danger'
        }
      )
      
      if (confirmResult === 'confirm') {
        isCleaningUp.value = true
        const result = await apiPost('/api/video/cleanup', { retention_days: 0 })
        showSuccess(result.message || `已删除 ${result.deleted} 个视频`)
        await loadVideoList()
      }
    } catch (error) {
      if (error !== 'cancel') {
        console.error('[VideoCleanup] 删除全部视频失败:', error)
        showError('删除失败')
      }
    } finally {
      isCleaningUp.value = false
    }
  }

  const loadVideoFolders = async () => {
    try {
      const response = await apiGet('/api/video/folders', {}, {}, false)
      if (response.code === 200 && response.data) {
        videoFolders.value = response.data.folders || []
      } else {
        videoFolders.value = []
      }
    } catch (error) {
      console.error('[VideoCleanup] 加载视频文件夹失败:', error)
      videoFolders.value = []
    }
  }

  const deleteVideoFolder = async (folderName) => {
    if (isCleaningUp.value) return
    
    try {
      const confirmResult = await ElMessageBox.confirm(
        `确定要删除文件夹 "${folderName}" 吗？此操作无法撤销！`,
        '警告',
        {
          confirmButtonText: '确定删除',
          cancelButtonText: '取消',
          type: 'danger'
        }
      )
      
      if (confirmResult === 'confirm') {
        isCleaningUp.value = true
        const result = await apiDelete(`/api/video/folder/${encodeURIComponent(folderName)}`)
        if (result.code === 200) {
          showSuccess(result.message || `已删除文件夹: ${folderName}`)
          await loadVideoFolders()
          await loadVideoList()
        } else {
          showError(result.message || '删除失败')
        }
      }
    } catch (error) {
      if (error !== 'cancel') {
        console.error('[VideoCleanup] 删除文件夹失败:', error)
        showError('删除失败')
      }
    } finally {
      isCleaningUp.value = false
    }
  }

  const loadSavedImages = async (taskId) => {
    try {
      const response = await apiGet(`/api/detection/results/images/${taskId}`)
      if (response.code === 200 && response.data) {
        console.log('[VideoDetection] 加载保存的图片成功:', response.data.total_images)
      }
    } catch (error) {
      console.error('[VideoDetection] 加载保存的图片失败:', error)
    }
  }

  const closeResultDialog = () => {
    showResultDialog.value = false
    
    clearAllTimers(pollingTimer, liveFrameTimer)
    
    liveFrameData.value = {
      frame: null,
      detected_persons: [],
      timestamp: 0,
      progress: 0,
      status: '',
      frameLoaded: false
    }
  }
  

  
  // 组件挂载时初始化
  onMounted(() => {
    console.log('[VideoDetection] 组件挂载，初始化状态')
    // 确保组件挂载时重置任务ID，避免页面刷新后使用旧的任务ID
    currentTaskId.value = ''
    // 清理可能存在的定时器
    clearAllTimers(pollingTimer, liveFrameTimer)
  })

  // 组件卸载时清理定时器
  onUnmounted(() => {
    console.log('[VideoDetection] 组件卸载，清理所有定时器')
    clearAllTimers(pollingTimer, liveFrameTimer)
  })

  return {
    // 状态
    showUploadDialog,
    showResultDialog,
    showTasksDialog,
    showCleanupDialog,
    uploadRef,
    selectedFile,
    isUploading,
    uploadProgress,
    uploadStatus,
    currentTaskId,
    detectionResult,
    taskList,
    liveFrameData,
    videoList,
    videoStats,
    videoFolders,
    cleanupDays,
    isCleaningUp,

    // 方法
    handleFileSelect,
    cancelUpload,
    startUpload,
    pollDetectionResult,
    startLiveFramePolling,
    fetchLiveFrame,
    stopLiveFramePolling,
    showHistoryDialog,
    loadTaskList,
    viewTaskResult,
    deleteTask,
    closeResultDialog,
    showCleanupHandler,
    loadVideoList,
    loadVideoFolders,
    cleanupOldVideos,
    deleteAllVideos,
    deleteVideoFolder,
    handleVideoError,
    handleImageLoad,
    handleImageError,
    handleFrameError,
    reloadVideo
  }
}
