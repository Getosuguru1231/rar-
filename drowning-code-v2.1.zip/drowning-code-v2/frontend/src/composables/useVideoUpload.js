    uploadStatus.value = 'success'
    showSuccess(result.message || '视频上传成功,开始检测...')
    currentTaskId.value = result.task_id
    
    // 关闭上传对话框
    showUploadDialog.value = false
    
    // 立即打开结果对话框，显示实时监测
    showResultDialog.value = true
    
    // 延迟启动轮询，给后端加载模型和处理第一帧的时间
    console.log('[Upload] ⏱️ 等待后端初始化...')
    setTimeout(() => {
      console.log('[Upload] 🚀 开始轮询检测结果和实时帧')
      pollDetectionResult(currentTaskId.value)
    }, 500)  // 500ms延迟，确保后端已加载模型并处理了第一帧