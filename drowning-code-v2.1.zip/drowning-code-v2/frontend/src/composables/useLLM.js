// frontend/src/composables/useLLM.js
/**
 * LLM大模型功能Composable
 * 提供LLM连接测试、配置加载、智能问答等共享逻辑
 * 
 * 使用示例:
 * ```javascript
 * import { useLLM } from '@/composables/useLLM'
 * 
 * const {
 *   showLLMDdialog,
 *   llmStatus,
 *   llmStatusText,
 *   testLLMConnection,
 *   loadLLMConfig,
 *   chatMessages,
 *   sendChatMessage
 * } = useLLM()
 * ```
 */
import { ref, reactive, computed, nextTick, onUnmounted } from 'vue'
import { 
  testLLMConnection as testLLMAPI, 
  getLLMConfig as fetchLLMConfig,
  askLLMQuestion
} from '../utils/index.js'
import { ElMessage } from 'element-plus'

const quickQuestions = [
  { question: '当前游泳池内有多少人？', category: '实时监测' },
  { question: '有没有实时告警？', category: '实时监测' },
  { question: '当前监测状态如何？', category: '实时监测' },
  { question: '溺水检测是如何工作的？', category: '溺水检测' },
  { question: '如何调整检测灵敏度？', category: '溺水检测' },
  { question: '检测到溺水会发生什么？', category: '溺水检测' },
  { question: '当前有多少摄像头在线？', category: '系统管理' },
  { question: '系统运行状态怎么样？', category: '系统管理' },
  { question: '如何上传视频进行检测？', category: '系统管理' },
  { question: '今天的监测结果如何？', category: '历史分析' },
  { question: '最近一周溺水事件统计？', category: '历史分析' },
  { question: '历史告警记录有哪些？', category: '历史分析' }
]

export function useLLM() {
  // ========== 基础状态管理 ==========
  const showLLMDialog = ref(false)
  const llmStatus = ref('idle') // idle, testing, connected, error
  const llmConfig = reactive({
    provider: '',
    model: '',
    api_key_configured: false,
    fallback_enabled: false
  })
  const llmTestResult = ref(null)

  // ========== 聊天相关状态 ==========
  const showLLMChatDialog = ref(false)
  const chatMessages = ref([])
  const chatInput = ref('')
  const isChatLoading = ref(false)
  const chatMessagesRef = ref(null)

  // 计算属性：LLM状态文本
  const llmStatusText = computed(() => {
    switch (llmStatus.value) {
      case 'idle': return '启动大模型'
      case 'testing': return '测试中...'
      case 'connected': return '大模型已连接'
      case 'error': return '大模型未连接'
      default: return '启动大模型'
    }
  })

  /**
   * 测试LLM连接状态
   */
  const testLLMConnection = async () => {
    llmStatus.value = 'testing'
    llmTestResult.value = null
    
    try {
      const config = await fetchLLMConfig()
      const configData = config.data || config
      Object.assign(llmConfig, configData)
      
      const testResult = await testLLMAPI()
      
      llmStatus.value = 'connected'
      llmTestResult.value = testResult
      ElMessage.success({ message: '大模型连接成功！', duration: 2000 })
      
      showLLMDialog.value = true
      
    } catch (error) {
      console.error('LLM连接测试失败:', error)
      llmStatus.value = 'error'
      llmTestResult.value = {
        success: false,
        message: error.response?.data?.detail || error.message || '连接测试异常'
      }
      ElMessage.error('大模型连接测试失败')
      showLLMDialog.value = true
    }
  }

  /**
   * 加载LLM初始配置
   */
  const loadLLMConfig = async () => {
    try {
      const config = await fetchLLMConfig()
      const configData = config.data || config
      Object.assign(llmConfig, configData)
      
      if (configData.api_key_configured) {
        await testLLMConnection()
      } else {
        llmStatus.value = 'idle'
      }
    } catch (error) {
      console.error('加载LLM配置失败:', error)
      llmStatus.value = 'error'
    }
  }

  const typewriterTimer = ref(null)

  const stopTypewriter = () => {
    if (typewriterTimer.value) {
      clearInterval(typewriterTimer.value)
      typewriterTimer.value = null
    }
  }

  const typewriterEffect = async (messageIndex, fullContent) => {
    stopTypewriter()
    const msg = chatMessages.value[messageIndex]
    if (!msg) return

    msg.content = ''
    let charIndex = 0
    const speed = 20

    return new Promise((resolve) => {
      typewriterTimer.value = setInterval(() => {
        if (charIndex < fullContent.length) {
          msg.content += fullContent[charIndex]
          charIndex++
          nextTick(() => scrollToBottom())
        } else {
          stopTypewriter()
          resolve()
        }
      }, speed)
    })
  }

  const sendChatMessage = async () => {
    if (!chatInput.value.trim()) {
      ElMessage.warning('请输入问题内容')
      return
    }

    const userMessage = chatInput.value.trim()
    
    chatMessages.value.push({
      role: 'user',
      content: userMessage,
      time: new Date().toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' })
    })
    
    chatInput.value = ''
    isChatLoading.value = true
    
    await nextTick()
    scrollToBottom()
    
    try {
      const response = await askLLMQuestion(userMessage)
      
      if (response.code === 200) {
        const answer = response.data.answer
        
        const assistantMsgIndex = chatMessages.value.push({
          role: 'assistant',
          content: '',
          time: new Date().toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' })
        }) - 1
        
        await typewriterEffect(assistantMsgIndex, answer)
      } else {
        chatMessages.value.push({
          role: 'assistant',
          content: `抱歉，我遇到了一些问题：${response.message || '请稍后重试'}`,
          time: new Date().toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' })
        })
        ElMessage.warning(response.message || '回答失败')
      }
    } catch (error) {
      console.error('发送消息失败:', error)
      chatMessages.value.push({
        role: 'assistant',
        content: '网络连接异常，请检查网络后重试',
        time: new Date().toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' })
      })
      ElMessage.error('发送消息失败')
    } finally {
      isChatLoading.value = false
      await nextTick()
      scrollToBottom()
    }
  }

  const clearChatHistory = () => {
    stopTypewriter()
    chatMessages.value = []
    ElMessage.success('聊天记录已清空')
  }

  onUnmounted(() => {
    stopTypewriter()
  })

  /**
   * 滚动到聊天底部
   */
  const scrollToBottom = () => {
    if (chatMessagesRef.value) {
      chatMessagesRef.value.scrollTop = chatMessagesRef.value.scrollHeight
    }
  }

  /**
   * 打开聊天对话框
   */
  const openChatDialog = () => {
    showLLMChatDialog.value = true
    // 如果是首次打开，添加欢迎消息
    if (chatMessages.value.length === 0) {
      chatMessages.value.push({
        role: 'assistant',
        content: '你好！我是溺水监测智能助手，可以回答关于监测系统的问题。\n\n你可以尝试以下问题：\n\n• 今天的监测结果如何？\n• 有哪些高风险事件？\n• 如何解读检测结果？\n• 系统运行状态怎么样？',
        time: new Date().toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' })
      })
    }
  }

  /**
   * 使用快捷问题
   */
  const useQuickQuestion = async (question) => {
    chatInput.value = question
    await sendChatMessage()
  }

  /**
   * 获取快捷问题分类
   */
  const getQuickQuestionCategories = () => {
    const categories = [...new Set(quickQuestions.map(q => q.category))]
    return categories
  }

  /**
   * 根据分类获取快捷问题
   */
  const getQuickQuestionsByCategory = (category) => {
    if (!category || category === '全部') {
      return quickQuestions
    }
    return quickQuestions.filter(q => q.category === category)
  }

  // 返回所有需要的状态和方法
  return {
    // 基础状态
    showLLMDialog,
    llmStatus,
    llmConfig,
    llmTestResult,
    llmStatusText,
    
    // 基础方法
    testLLMConnection,
    loadLLMConfig,
    
    // 聊天状态
    showLLMChatDialog,
    chatMessages,
    chatInput,
    isChatLoading,
    chatMessagesRef,
    
    // 聊天方法
    sendChatMessage,
    clearChatHistory,
    openChatDialog,
    scrollToBottom,
    
    // 快捷问题相关
    quickQuestions,
    getQuickQuestionCategories,
    getQuickQuestionsByCategory,
    useQuickQuestion
  }
}
