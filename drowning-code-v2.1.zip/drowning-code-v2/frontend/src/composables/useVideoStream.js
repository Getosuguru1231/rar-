/**
 * 视频流处理工具 Composable
 * 统一管理摄像头视频流的加载、错误处理和重试机制
 * 优化版本：提升稳定性和流畅度
 */
import { ref, shallowRef } from 'vue'
import { ElMessage } from 'element-plus'
import { API_CONSTANTS } from '../utils/index.js'

// 视频流配置常量 - 稳定性优化版
const VIDEO_STREAM_TIMEOUT = 8000 // 8秒超时（更快的失败检测）
const VIDEO_STREAM_RETRY_INTERVAL = 200 // 0.2秒后重试（更快的响应）
const VIDEO_STREAM_MAX_RETRIES = 8 // 增加重试次数，提高连接稳定性
const VIDEO_STREAM_BACKOFF_MULTIPLIER = 1.2 // 指数退避倍数
const HEARTBEAT_CHECK_INTERVAL = 3000 // 心跳检查间隔（3秒，更及时的检测）
const VIDEO_STREAM_STALE_THRESHOLD = 6000 // 帧过期阈值：6秒未更新视为 stale

// 视频流缓存配置 - 增强稳定性
const VIDEO_STREAM_CACHE_SIZE = 15 // 缓存帧数（增加缓存，提高稳定性）
const VIDEO_STREAM_CACHE_EXPIRE = 15000 // 缓存过期时间（毫秒）

// 网络连接检测配置
const NETWORK_CHECK_INTERVAL = 30000 // 网络连接检查间隔（30秒）
const NETWORK_TIMEOUT = 15000 // 网络连接测试超时（15秒）

// 错误提示限制配置
const ERROR_MESSAGE_INTERVAL = 15000 // 错误提示间隔：15秒
let lastErrorMessageTime = 0

// 性能指标收集配置
const PERFORMANCE_SAMPLE_SIZE = 30 // 样本大小：保留最近30个样本（减少内存占用）
const PERFORMANCE_CHECK_INTERVAL = 3000 // 性能检查间隔：3秒

// 自适应码率配置 - 优化阈值
const QUALITY_LEVELS = ['low', 'medium', 'high', 'ultra']
const MIN_QUALITY_CHANGE_INTERVAL = 30000 // 最小质量切换间隔：30秒（防止频繁切换）
const QUALITY_THRESHOLDS = {
  // 降级阈值（需要降低质量的指标）
  downgrade: {
    avgFrameTime: 200, // 平均帧加载时间超过200ms，降低质量（提高阈值，减少误触发）
    errorRate: 0.5, // 错误率超过50%，降低质量
    dropRate: 0.4 // 丢帧率超过40%，降低质量
  },
  // 升级阈值（可以提升质量的指标）
  upgrade: {
    avgFrameTime: 60, // 平均帧加载时间低于60ms，可以提升质量
    errorRate: 0.05, // 错误率低于5%，可以提升质量（更严格，避免频繁升级）
    dropRate: 0.05 // 丢帧率低于5%，可以提升质量
  }
}

// 全局缓存：存储常用的计算结果和配置
const globalCache = {
  videoStreamUrls: new Map(),
  computedValues: new Map(),
  timestamps: new Map()
}

// 使用 shallowRef 优化性能
const networkStatus = shallowRef({
  isOnline: navigator.onLine,
  lastCheck: Date.now(),
  isChecking: false
})

// 性能指标收集器
class PerformanceMonitor {
  constructor() {
    this.metrics = new Map()
    this.checkTimers = new Map()
  }

  // 初始化摄像头性能指标
  initMetrics(cameraId) {
    if (!this.metrics.has(cameraId)) {
      this.metrics.set(cameraId, {
        frameTimes: [],
        errorCount: 0,
        totalFrames: 0,
        dropCount: 0,
        lastQualityCheck: 0,
        currentQuality: 'high',
        consecutiveErrors: 0, // 连续错误计数
        lastSuccessTime: Date.now() // 上次成功时间
      })
    }
  }

  // 记录帧加载时间
  recordFrameTime(cameraId, frameTime) {
    const metrics = this.getMetrics(cameraId)
    if (!metrics) return

    metrics.frameTimes.push(frameTime)
    metrics.totalFrames++
    metrics.consecutiveErrors = 0 // 重置连续错误计数
    metrics.lastSuccessTime = Date.now()

    // 保持样本大小
    if (metrics.frameTimes.length > PERFORMANCE_SAMPLE_SIZE) {
      metrics.frameTimes.shift()
    }
  }

  // 记录错误
  recordError(cameraId) {
    const metrics = this.getMetrics(cameraId)
    if (!metrics) return
    metrics.errorCount++
    metrics.consecutiveErrors++
  }

  // 记录丢帧
  recordDrop(cameraId) {
    const metrics = this.getMetrics(cameraId)
    if (!metrics) return
    metrics.dropCount++
  }

  // 获取性能指标
  getMetrics(cameraId) {
    if (!this.metrics.has(cameraId)) {
      this.initMetrics(cameraId)
    }
    return this.metrics.get(cameraId)
  }

  // 计算平均帧加载时间
  getAvgFrameTime(cameraId) {
    const metrics = this.getMetrics(cameraId)
    if (!metrics || metrics.frameTimes.length === 0) return 0
    const sum = metrics.frameTimes.reduce((a, b) => a + b, 0)
    return sum / metrics.frameTimes.length
  }

  // 计算错误率
  getErrorRate(cameraId) {
    const metrics = this.getMetrics(cameraId)
    if (!metrics || metrics.totalFrames === 0) return 0
    return metrics.errorCount / metrics.totalFrames
  }

  // 计算丢帧率
  getDropRate(cameraId) {
    const metrics = this.getMetrics(cameraId)
    if (!metrics || metrics.totalFrames === 0) return 0
    return metrics.dropCount / metrics.totalFrames
  }

  // 获取连续错误计数
  getConsecutiveErrors(cameraId) {
    const metrics = this.getMetrics(cameraId)
    return metrics ? metrics.consecutiveErrors : 0
  }

  // 重置性能指标
  resetMetrics(cameraId) {
    const metrics = this.getMetrics(cameraId)
    if (metrics) {
      metrics.frameTimes = []
      metrics.errorCount = 0
      metrics.totalFrames = 0
      metrics.dropCount = 0
      metrics.consecutiveErrors = 0
    }
  }

  // 获取性能统计摘要
  getStatsSummary(cameraId) {
    const metrics = this.getMetrics(cameraId)
    if (!metrics) return null

    return {
      avgFrameTime: this.getAvgFrameTime(cameraId),
      errorRate: this.getErrorRate(cameraId),
      dropRate: this.getDropRate(cameraId),
      totalFrames: metrics.totalFrames,
      errorCount: metrics.errorCount,
      dropCount: metrics.dropCount,
      currentQuality: metrics.currentQuality,
      consecutiveErrors: metrics.consecutiveErrors,
      lastSuccessTime: metrics.lastSuccessTime
    }
  }
}

// 自适应质量调整器
class AdaptiveQualityController {
  constructor(performanceMonitor) {
    this.performanceMonitor = performanceMonitor
    this.qualityRecommendations = new Map()
    this.lastRecommendation = new Map()
    this.qualityChangeTimers = new Map() // 质量切换定时器
    this.lastQualityChangeTime = new Map() // 记录上次质量切换时间
  }

  // 检查是否可以进行质量切换（基于最小间隔）
  canChangeQuality(cameraId) {
    const lastChange = this.lastQualityChangeTime.get(cameraId)
    if (!lastChange) return true
    return Date.now() - lastChange >= MIN_QUALITY_CHANGE_INTERVAL
  }

  // 记录质量切换时间
  recordQualityChange(cameraId) {
    this.lastQualityChangeTime.set(cameraId, Date.now())
  }

  // 评估当前性能并给出质量建议
  evaluateAndRecommend(cameraId) {
    const stats = this.performanceMonitor.getStatsSummary(cameraId)
    if (!stats) return 'high'

    const metrics = this.performanceMonitor.getMetrics(cameraId)
    const currentQuality = metrics.currentQuality
    const currentIndex = QUALITY_LEVELS.indexOf(currentQuality)

    // 检查是否需要降级
    if (this.shouldDowngrade(stats)) {
      if (currentIndex < QUALITY_LEVELS.length - 1) {
        const newQuality = QUALITY_LEVELS[currentIndex + 1]
        // 降级可以立即执行，不需要等待间隔（紧急情况）
        this.qualityRecommendations.set(cameraId, {
          action: 'downgrade',
          from: currentQuality,
          to: newQuality,
          reason: this.getDowngradeReason(stats)
        })
        this.recordQualityChange(cameraId)
        return newQuality
      }
    }

    // 检查是否可以升级（需要满足最小间隔要求）
    if (this.shouldUpgrade(stats) && this.canChangeQuality(cameraId)) {
      if (currentIndex > 0) {
        const newQuality = QUALITY_LEVELS[currentIndex - 1]
        this.qualityRecommendations.set(cameraId, {
          action: 'upgrade',
          from: currentQuality,
          to: newQuality,
          reason: 'Performance is good, can upgrade quality'
        })
        this.recordQualityChange(cameraId)
        return newQuality
      }
    }

    return currentQuality
  }

  // 判断是否需要降级
  shouldDowngrade(stats) {
    return (
      stats.avgFrameTime > QUALITY_THRESHOLDS.downgrade.avgFrameTime ||
      stats.errorRate > QUALITY_THRESHOLDS.downgrade.errorRate ||
      stats.dropRate > QUALITY_THRESHOLDS.downgrade.dropRate
    )
  }

  // 判断是否可以升级
  shouldUpgrade(stats) {
    return (
      stats.avgFrameTime < QUALITY_THRESHOLDS.upgrade.avgFrameTime &&
      stats.errorRate < QUALITY_THRESHOLDS.upgrade.errorRate &&
      stats.dropRate < QUALITY_THRESHOLDS.upgrade.dropRate
    )
  }

  // 获取降级原因
  getDowngradeReason(stats) {
    const reasons = []
    if (stats.avgFrameTime > QUALITY_THRESHOLDS.downgrade.avgFrameTime) {
      reasons.push(`帧加载时间过长 (${stats.avgFrameTime.toFixed(1)}ms)`)
    }
    if (stats.errorRate > QUALITY_THRESHOLDS.downgrade.errorRate) {
      reasons.push(`错误率过高 (${(stats.errorRate * 100).toFixed(1)}%)`)
    }
    if (stats.dropRate > QUALITY_THRESHOLDS.downgrade.dropRate) {
      reasons.push(`丢帧率过高 (${(stats.dropRate * 100).toFixed(1)}%)`)
    }
    return reasons.join(', ')
  }

  // 获取质量建议
  getRecommendation(cameraId) {
    return this.qualityRecommendations.get(cameraId)
  }

  // 检查是否应该通知用户
  shouldNotifyUser(cameraId) {
    const recommendation = this.getRecommendation(cameraId)
    if (!recommendation) return false

    const last = this.lastRecommendation.get(cameraId)
    if (!last) return true

    return (
      recommendation.action !== last.action ||
      recommendation.to !== last.to
    )
  }

  // 更新最后通知
  updateLastNotification(cameraId) {
    const recommendation = this.getRecommendation(cameraId)
    if (recommendation) {
      this.lastRecommendation.set(cameraId, { ...recommendation })
    }
  }

  // 应用质量建议
  applyQualityRecommendation(cameraId, callback) {
    if (!this.shouldNotifyUser(cameraId)) return false

    const recommendation = this.getRecommendation(cameraId)
    if (!recommendation) return false

    if (callback) {
      callback(recommendation)
    }

    this.updateLastNotification(cameraId)
    return true
  }
}

// 创建性能监控器和自适应质量控制器实例
const performanceMonitor = new PerformanceMonitor()
const adaptiveQualityController = new AdaptiveQualityController(performanceMonitor)

// 本地缓存管理器
class LocalCacheManager {
  constructor() {
    this.cacheKeyPrefix = 'video_stream_cache_'
    this.maxCacheSize = 8
    this.cacheExpiry = 20000
  }

  getCacheKey(cameraId) {
    return `${this.cacheKeyPrefix}${cameraId}`
  }

  saveFrame(cameraId, frameData) {
    try {
      const cacheKey = this.getCacheKey(cameraId)
      const cache = JSON.parse(localStorage.getItem(cacheKey) || '[]')
      
      cache.push({
        data: frameData,
        timestamp: Date.now()
      })
      
      if (cache.length > this.maxCacheSize) {
        cache.shift()
      }
      
      localStorage.setItem(cacheKey, JSON.stringify(cache))
    } catch (error) {
      console.error('[VideoStream] 保存帧到本地缓存失败:', error)
    }
  }

  getFrame(cameraId) {
    try {
      const cacheKey = this.getCacheKey(cameraId)
      const cache = JSON.parse(localStorage.getItem(cacheKey) || '[]')
      
      const now = Date.now()
      const validFrames = cache.filter(frame => now - frame.timestamp < this.cacheExpiry)
      
      if (validFrames.length !== cache.length) {
        localStorage.setItem(cacheKey, JSON.stringify(validFrames))
      }
      
      return validFrames.length > 0 ? validFrames[validFrames.length - 1] : null
    } catch (error) {
      console.error('[VideoStream] 从本地缓存获取帧失败:', error)
      return null
    }
  }

  clearCache(cameraId) {
    try {
      const cacheKey = this.getCacheKey(cameraId)
      localStorage.removeItem(cacheKey)
    } catch (error) {
      console.error('[VideoStream] 清空本地缓存失败:', error)
    }
  }

  clearAllCache() {
    try {
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i)
        if (key && key.startsWith(this.cacheKeyPrefix)) {
          localStorage.removeItem(key)
        }
      }
    } catch (error) {
      console.error('[VideoStream] 清空所有本地缓存失败:', error)
    }
  }
}

// 网络连接检测函数（增强稳定性检测）
const checkNetworkStatus = async () => {
  if (networkStatus.value.isChecking) return
  
  networkStatus.value.isChecking = true
  
  try {
    const controller = new AbortController()
    const timeoutId = setTimeout(() => controller.abort(), NETWORK_TIMEOUT)
    
    // 尝试多个端点以确保连接可靠性
    const endpoints = ['/api/health', '/api/video_feed/stats']
    let success = false
    
    for (const endpoint of endpoints) {
      try {
        const response = await fetch(endpoint, {
          method: 'GET',
          signal: controller.signal,
          headers: {
            'Content-Type': 'application/json'
          }
        })
        
        if (response.ok) {
          success = true
          break
        }
      } catch (e) {
        continue
      }
    }
    
    clearTimeout(timeoutId)
    networkStatus.value = {
      ...networkStatus.value,
      isOnline: success,
      lastCheck: Date.now(),
      isChecking: false
    }
  } catch (error) {
    console.warn('[Network] 网络连接检测失败:', error.message)
    networkStatus.value = {
      ...networkStatus.value,
      isOnline: false,
      lastCheck: Date.now(),
      isChecking: false
    }
  }
}

// 启动网络连接检测
let networkCheckTimer = null
const startNetworkCheck = () => {
  if (networkCheckTimer) {
    clearInterval(networkCheckTimer)
  }
  
  checkNetworkStatus()
  networkCheckTimer = setInterval(checkNetworkStatus, NETWORK_CHECK_INTERVAL)
}

// 停止网络连接检测
const stopNetworkCheck = () => {
  if (networkCheckTimer) {
    clearInterval(networkCheckTimer)
    networkCheckTimer = null
  }
}

// 创建本地缓存管理器实例
const localCacheManager = new LocalCacheManager()

/**
 * 缓存管理工具函数
 */
const cacheUtils = {
  /**
   * 获取缓存值
   * @param {string} key - 缓存键
   * @param {number} maxAge - 最大缓存年龄（毫秒）
   * @returns {any} 缓存值或null
   */
  get: (key, maxAge = 30000) => {
    const cached = globalCache.computedValues.get(key)
    const timestamp = globalCache.timestamps.get(key)
    if (cached && timestamp && (Date.now() - timestamp) < maxAge) {
      return cached
    }
    return null
  },
  
  /**
   * 设置缓存值
   * @param {string} key - 缓存键
   * @param {any} value - 缓存值
   */
  set: (key, value) => {
    globalCache.computedValues.set(key, value)
    globalCache.timestamps.set(key, Date.now())
  },
  
  /**
   * 清除缓存
   * @param {string} key - 缓存键（可选）
   */
  clear: (key) => {
    if (key) {
      globalCache.computedValues.delete(key)
      globalCache.timestamps.delete(key)
    } else {
      globalCache.computedValues.clear()
      globalCache.timestamps.clear()
    }
  }
}

export function useVideoStream() {
  // ========== 视频流状态管理 ==========
  const videoStreamStates = ref(new Map())
  
  // 超时定时器管理
  const timeoutTimers = ref(new Map())
  
  // 心跳检查定时器
  const heartbeatTimers = ref(new Map())
  
  // 重试延迟记录（用于指数退避）
  const retryDelays = ref(new Map())
  
  // 视频流缓存管理 - 优化版
  const videoStreamCache = ref(new Map())
  
  /**
   * 初始化摄像头视频流状态
   * @param {number} cameraId - 摄像头ID
   */
  const initVideoStreamState = (cameraId) => {
    if (!videoStreamStates.value.has(cameraId)) {
      videoStreamStates.value.set(cameraId, {
        videoLoaded: false,
        videoError: false,
        retryCount: 0,
        maxRetries: VIDEO_STREAM_MAX_RETRIES,
        lastErrorTime: null,
        timeoutStarted: false,  // 标记是否已启动超时计时器
        initTime: Date.now(),   // 记录初始化时间（用于心跳检测）
        lastFrameTime: null,    // 记录最后一帧加载时间
        frameCount: 0,          // 记录已加载的帧数
        avgFrameTime: 0         // 平均帧加载时间
      })
    } else {
      // 如果已存在，更新initTime
      const state = videoStreamStates.value.get(cameraId)
      state.initTime = Date.now()
    }
  }
  
  /**
   * 获取摄像头视频流状态
   * @param {number} cameraId - 摄像头ID
   * @returns {Object} 视频流状态对象
   */
  const getVideoStreamState = (cameraId) => {
    initVideoStreamState(cameraId)
    
    const state = videoStreamStates.value.get(cameraId)
    
    // 如果还没有启动超时计时器，则启动
    if (!state.timeoutStarted && !state.videoLoaded && !state.videoError) {
      state.timeoutStarted = true
      startTimeoutTimer(cameraId)
    }
    
    return state
  }
  
  /**
   * 启动超时计时器
   * @param {number} cameraId - 摄像头ID
   */
  const startTimeoutTimer = (cameraId) => {
    // 清除已存在的定时器
    clearTimeoutTimer(cameraId)
    
    const timer = setTimeout(() => {
      const state = videoStreamStates.value.get(cameraId)
      if (state && !state.videoLoaded && !state.videoError) {
        console.warn(`[VideoStream] ⏰ 摄像头${cameraId} 加载超时（${VIDEO_STREAM_TIMEOUT}ms）`)
        state.videoError = true
        state.videoLoaded = false
        
        // 触发自定义事件通知组件显示错误
        window.dispatchEvent(new CustomEvent('videoStreamTimeout', { 
          detail: { cameraId, timeout: VIDEO_STREAM_TIMEOUT } 
        }))
      }
    }, VIDEO_STREAM_TIMEOUT)
    
    timeoutTimers.value.set(cameraId, timer)
  }
  
  /**
   * 清除超时计时器
   * @param {number} cameraId - 摄像头ID
   */
  const clearTimeoutTimer = (cameraId) => {
    if (timeoutTimers.value.has(cameraId)) {
      clearTimeout(timeoutTimers.value.get(cameraId))
      timeoutTimers.value.delete(cameraId)
    }
  }
  
  /**
   * 重置摄像头视频流状态
   * @param {number} cameraId - 摄像头ID
   */
  const resetVideoStreamState = (cameraId) => {
    const state = getVideoStreamState(cameraId)
    state.videoLoaded = false
    state.videoError = false
    state.retryCount = 0
    state.lastErrorTime = null
    state.timeoutStarted = false
    
    // 重新启动超时计时器
    startTimeoutTimer(cameraId)
  }
  
  /**
   * 从缓存获取视频帧
   * @param {number} cameraId - 摄像头ID
   * @returns {string|null} 缓存的视频帧数据URL
   */
  const getCachedVideoFrame = (cameraId) => {
    if (!videoStreamCache.value.has(cameraId)) {
      return null
    }
    
    const cache = videoStreamCache.value.get(cameraId)
    const now = Date.now()
    
    // 检查缓存是否过期
    if (now - cache.timestamp > VIDEO_STREAM_CACHE_EXPIRE) {
      videoStreamCache.value.delete(cameraId)
      return null
    }
    
    return cache.frame
  }
  
  /**
   * 缓存视频帧 - 优化版
   * @param {number} cameraId - 摄像头ID
   * @param {string} frame - 视频帧数据URL
   */
  const cacheVideoFrame = (cameraId, frame) => {
    // 检查是否已存在缓存，避免缓存相同的帧
    if (videoStreamCache.value.has(cameraId)) {
      const existingCache = videoStreamCache.value.get(cameraId)
      if (existingCache.frame === frame) {
        return
      }
    }
    
    const now = Date.now()
    
    // 只在必要时更新帧统计
    const state = getVideoStreamState(cameraId)
    if (state.lastFrameTime > 0) {
      const frameTime = now - state.lastFrameTime
      // 每10帧更新一次统计，减少计算
      if (frameTime > 0) {
        state.frameCount++
        if (state.frameCount % 10 === 0) {
          state.avgFrameTime = frameTime
        }
      }
    }
    state.lastFrameTime = now
    
    // 缓存视频帧
    videoStreamCache.value.set(cameraId, {
      frame,
      timestamp: now
    })
  }
  
  /**
   * 预加载视频帧
   * @param {number} cameraId - 摄像头ID
   * @param {string} frame - 视频帧数据URL
   */
  const preloadVideoFrame = (cameraId, frame) => {
    // 创建Image对象预加载
    const img = new Image()
    img.src = frame
    img.onload = () => {
      // 预加载完成后缓存
      cacheVideoFrame(cameraId, frame)
    }
  }
  
  /**
   * 清除视频流缓存
   * @param {number} cameraId - 摄像头ID
   */
  const clearVideoStreamCache = (cameraId) => {
    videoStreamCache.value.delete(cameraId)
  }
  
  /**
   * 清除所有视频流缓存
   */
  const clearAllVideoStreamCache = () => {
    videoStreamCache.value.clear()
  }
  
  // ========== 视频流事件处理 ==========
  
  /**
   * 视频帧加载成功处理
   * @param {number} cameraId - 摄像头ID
   * @param {Event} event - 加载事件
   */
  const handleImageLoad = (cameraId, event) => {
    const state = getVideoStreamState(cameraId)
    
    // 只在状态确实改变时才更新，避免不必要的重渲染
    if (state.videoLoaded && !state.videoError) {
      return // 状态已经是加载成功，无需重复处理
    }
    
    console.log(`[VideoStream] ✅ 摄像头${cameraId} 视频帧加载成功`)
    
    state.videoLoaded = true
    state.videoError = false
    state.retryCount = 0
    state.timeoutStarted = false
    
    // 清除超时定时器
    clearTimeoutTimer(cameraId)
    
    // 触发自定义事件通知Monitor组件
    window.dispatchEvent(new CustomEvent('videoStreamLoaded', { 
      detail: { cameraId } 
    }))
    
    // 缓存视频帧（使用 requestIdleCallback 延迟处理）
    if (event?.target?.tagName === 'IMG' && event.target.src) {
      const src = event.target.src
      if ('requestIdleCallback' in window) {
        requestIdleCallback(() => {
          cacheVideoFrame(cameraId, src)
        }, { timeout: 100 })
      } else {
        cacheVideoFrame(cameraId, src)
      }
    }
  }

  /**
   * 保存视频帧到本地缓存（已移除，使用内存缓存）
   * @param {number} cameraId - 摄像头ID
   * @param {string} frameData - 帧数据（base64格式）
   */
  const saveFrameToCache = (cameraId, frameData) => {
    // 已移除本地缓存，使用内存缓存
  }

  /**
   * 从本地缓存获取视频帧（已移除，使用内存缓存）
   * @param {number} cameraId - 摄像头ID
   * @returns {string|null} 帧数据（base64格式）或null
   */
  const getFrameFromCache = (cameraId) => {
    // 已移除本地缓存，使用内存缓存
    return null
  }

  /**
   * 清空指定摄像头的本地缓存（已移除）
   * @param {number} cameraId - 摄像头ID
   */
  const clearCameraCache = (cameraId) => {
    // 已移除本地缓存
  }

  /**
   * 清空所有摄像头的本地缓存（已移除）
   */
  const clearAllCameraCache = () => {
    // 已移除本地缓存
  }
  
  /**
   * 视频帧加载失败处理(带自动重试和指数退避) - 高清晰度和灵活度优化版 v5.0
   * @param {number} cameraId - 摄像头ID
   * @param {Event} event - 错误事件
   */
  const handleImageError = (cameraId, event) => {
    const state = getVideoStreamState(cameraId)
    state.videoError = true
    state.videoLoaded = false
    state.lastErrorTime = Date.now()
    
    // 尝试使用缓存的视频帧
    let cachedFrame = getCachedVideoFrame(cameraId)
    
    if (cachedFrame) {
      const img = event?.target
      if (img && img.tagName === 'IMG') {
        // 立即显示缓存帧，减少卡顿
        img.src = cachedFrame
        state.videoError = false
        state.videoLoaded = true
        return
      }
    }
    
    // 自动重试机制（带指数退避）
    if (state.retryCount < state.maxRetries) {
      state.retryCount++
      
      // 优化：缓存重试延迟计算，减少重复计算
      const cacheKey = `retry_delay_${cameraId}_${state.retryCount}`
      let delay = cacheUtils.get(cacheKey)
      
      if (!delay) {
        // 计算重试延迟（指数退避）
        const baseDelay = VIDEO_STREAM_RETRY_INTERVAL
        delay = Math.min(
          baseDelay * Math.pow(VIDEO_STREAM_BACKOFF_MULTIPLIER, state.retryCount - 1),
          500  // 最大延迟0.5秒（增加最大延迟时间，避免过于频繁的重试）
        )
        // 缓存计算结果
        cacheUtils.set(cacheKey, delay)
      }
      
      setTimeout(() => {
        state.videoError = false
        
        // 重新加载MJPEG视频流（添加时间戳参数，避免浏览器缓存）
        const img = event?.target
        if (img && img.tagName === 'IMG') {
          // 方案：添加时间戳参数强制刷新，避免浏览器缓存
          const baseUrl = img.src.split('?')[0]
          const timestamp = Date.now()
          img.src = `${baseUrl}?t=${timestamp}`
        }
      }, delay)
    } else {
      ElMessage.warning({
        message: `摄像头${cameraId} 连接失败，已重试${state.maxRetries}次。请检查网络连接或点击刷新按钮重试。`,
        duration: 2000, // 增加提示时间，确保用户能看到
        showClose: true
      })
      
      // 触发自定义事件
      window.dispatchEvent(new CustomEvent('videoStreamFailed', { 
        detail: { cameraId, retryCount: state.retryCount } 
      }))
    }
  }
  
  /**
   * 通用视频错误处理(用于video标签)
   * @param {number} cameraId - 摄像头ID
   */
  const handleVideoError = (cameraId) => {
    console.error(`[VideoStream] ❌ 摄像头${cameraId} 视频加载失败`)
    
    const state = getVideoStreamState(cameraId)
    state.videoError = true
    state.videoLoaded = false
    
    // 清除超时定时器
    clearTimeoutTimer(cameraId)
    
    ElMessage.error(`摄像头${cameraId} 视频流异常`)
  }
  
  /**
   * 手动刷新视频流（增强自动重连机制）
   * @param {number} cameraId - 摄像头ID
   */
  const reloadVideo = (cameraId) => {
    console.log(`[VideoStream] 🔄 手动刷新摄像头${cameraId}`)
    
    // 重置状态（会重新启动超时计时器）
    resetVideoStreamState(cameraId)
    
    ElMessage.info(`正在重新加载摄像头${cameraId}...`)
    
    // 触发自定义事件,通知组件重新加载
    window.dispatchEvent(new CustomEvent('reloadVideoStream', { 
      detail: { cameraId } 
    }))
  }
  
  /**
   * 智能重连（根据错误情况自动选择重连策略）
   * @param {number} cameraId - 摄像头ID
   * @param {string} reason - 重连原因
   */
  const smartReconnect = (cameraId, reason = 'auto') => {
    console.log(`[VideoStream] 🔧 智能重连摄像头${cameraId}，原因: ${reason}`)
    
    // 获取当前状态
    const state = getVideoStreamState(cameraId)
    
    // 策略1：如果连续错误过多，降低重连频率
    if (state.retryCount > 5) {
      console.log(`[VideoStream] ⚠️ 摄像头${cameraId} 连续错误过多，使用延迟重连`)
      setTimeout(() => {
        reloadVideo(cameraId)
      }, 3000)
      return
    }
    
    // 策略2：正常情况立即重连
    reloadVideo(cameraId)
  }
  
  /**
   * 实时帧加载失败处理(用于上传视频的实时监测)
   * @param {Event} event - 错误事件
   */
  const handleFrameError = (event) => {
    console.warn('[LiveFrame] ⚠️ 视频帧加载失败')
    // 这个函数主要用于useVideoDetection中的liveFrameData
    return {
      frameLoaded: false
    }
  }
  
  /**
   * 启动心跳检测（监控视频流连接状态）- 优化版
   * @param {number} cameraId - 摄像头ID
   */
  const startHeartbeatCheck = (cameraId) => {
    // 清除已存在的心跳定时器
    stopHeartbeatCheck(cameraId)
    
    const timer = setInterval(() => {
      const state = videoStreamStates.value.get(cameraId)
      if (!state) return
      
      const now = Date.now()
      
      // 情况1：视频流从未加载成功（超时后）
      if (!state.videoLoaded && !state.videoError && state.timeoutStarted) {
        // 检查是否已经超时（由超时计时器处理，这里只是额外保险）
        const timeSinceInit = now - (state.initTime || now)
        if (timeSinceInit > VIDEO_STREAM_TIMEOUT + 5000) {
          console.warn(`[VideoStream] ⚠️ 摄像头${cameraId} 初始化后长时间无响应`)
          state.videoError = true
          window.dispatchEvent(new CustomEvent('videoStreamTimeout', { 
            detail: { cameraId, timeout: VIDEO_STREAM_TIMEOUT } 
          }))
        }
        return
      }
      
      // 情况2：视频流加载成功后断开（有错误记录）
      if (state.lastErrorTime) {
        const timeSinceLastError = now - state.lastErrorTime
        // 如果超过20秒没有成功加载，且不在重试中，触发重新连接
        if (timeSinceLastError > 20000 && !state.videoLoaded && state.retryCount < state.maxRetries) {
          console.warn(`[VideoStream] ⚠️ 摄像头${cameraId} 长时间无响应（${(timeSinceLastError/1000).toFixed(1)}s），尝试恢复连接`)
          resetVideoStreamState(cameraId)
        }
      }
      
      // 情况3：视频流正在加载但长时间没有成功
      if (!state.videoLoaded && !state.videoError && state.retryCount === 0) {
        // 这种情况应该由超时计时器处理，这里只做日志记录
      }
    }, HEARTBEAT_CHECK_INTERVAL)
    
    heartbeatTimers.value.set(cameraId, timer)
  }
  
  /**
   * 停止心跳检测
   * @param {number} cameraId - 摄像头ID
   */
  const stopHeartbeatCheck = (cameraId) => {
    if (heartbeatTimers.value.has(cameraId)) {
      clearInterval(heartbeatTimers.value.get(cameraId))
      heartbeatTimers.value.delete(cameraId)
    }
  }
  
  /**
   * 清理所有视频流状态
   */
  const cleanupAllVideoStreams = () => {
    console.log('[VideoStream] 🧹 清理所有视频流状态')
    videoStreamStates.value.clear()
    
    // 清除所有超时定时器
    timeoutTimers.value.forEach((timer, cameraId) => {
      clearTimeout(timer)
    })
    timeoutTimers.value.clear()
    
    // 清除所有心跳定时器
    heartbeatTimers.value.forEach((timer, cameraId) => {
      clearInterval(timer)
    })
    heartbeatTimers.value.clear()
    
    // 清除所有视频流缓存
    clearAllVideoStreamCache()
  }
  
  /**
   * 获取所有摄像头的视频流状态统计
   * @returns {Object} 统计信息
   */
  const getVideoStreamStats = () => {
    const stats = {
      total: videoStreamStates.value.size,
      loaded: 0,
      error: 0,
      loading: 0
    }
    
    videoStreamStates.value.forEach((state) => {
      if (state.videoLoaded) stats.loaded++
      else if (state.videoError) stats.error++
      else stats.loading++
    })
    
    return stats
  }
  
  return {
    // 状态管理
    videoStreamStates,
    initVideoStreamState,
    getVideoStreamState,
    resetVideoStreamState,
    
    // 事件处理
    handleImageLoad,
    handleImageError,
    handleVideoError,
    handleFrameError,
    reloadVideo,
    smartReconnect,
    
    // 心跳检测
    startHeartbeatCheck,
    stopHeartbeatCheck,
    
    // 网络连接检测
    networkStatus,
    checkNetworkStatus,
    startNetworkCheck,
    stopNetworkCheck,
    
    // 缓存管理
    getCachedVideoFrame,
    cacheVideoFrame,
    preloadVideoFrame,
    clearVideoStreamCache,
    clearAllVideoStreamCache,
    
    // 性能监控
    performanceMonitor,
    adaptiveQualityController,
    
    // 工具函数
    cleanupAllVideoStreams,
    getVideoStreamStats
  }
}
