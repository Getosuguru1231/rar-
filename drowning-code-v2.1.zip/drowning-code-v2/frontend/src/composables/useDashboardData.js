import { ref, computed } from 'vue'

export function useDashboardData() {
  const hazardPoints = ref([
    { id: 1, name: '南流江大桥水域', type: '河流', risk: 'high', lat: 22.645, lng: 110.19, radius: 800, detail: '水域面积大，流速较快，汛期水位上涨明显' },
    { id: 2, name: '玉林体育馆泳池', type: '泳池', risk: 'high', lat: 22.632, lng: 110.205, radius: 600, detail: '夏季人流量大，深水区无安全护栏' },
    { id: 3, name: '龟山公园水库', type: '水库', risk: 'high', lat: 22.618, lng: 110.165, radius: 1000, detail: '岸边陡峭，水下有暗流，常有游客戏水' },
    { id: 4, name: '清湾江支流', type: '河流', risk: 'high', lat: 22.625, lng: 110.182, radius: 700, detail: '河道弯曲，水流湍急，夏季溺水事故频发' },
    { id: 5, name: '石南镇池塘群', type: '池塘', risk: 'high', lat: 22.605, lng: 110.148, radius: 500, detail: '养殖池塘密集，水深2-4米，周边有村庄' },
    { id: 6, name: '福绵区游泳场', type: '泳池', risk: 'high', lat: 22.658, lng: 110.175, radius: 400, detail: '露天泳池，无救生员值班时段风险较高' },
    { id: 7, name: '兴业县水库', type: '水库', risk: 'high', lat: 22.592, lng: 110.132, radius: 900, detail: '库容较大，岸边无防护设施，野泳现象严重' },
    { id: 8, name: '博白江段', type: '河流', risk: 'high', lat: 22.675, lng: 110.215, radius: 850, detail: '江面宽阔，汛期水流急促，事故多发' },
    { id: 9, name: '玉州区人工湖', type: '湖泊', risk: 'mid', lat: 22.638, lng: 110.195, radius: 300, detail: '湖边有护栏，但仍有儿童靠近玩耍' },
    { id: 10, name: '仁东镇溪流', type: '溪流', risk: 'mid', lat: 22.608, lng: 110.155, radius: 450, detail: '溪水较浅但水流急，夏季儿童戏水较多' },
    { id: 11, name: '城北公园喷泉池', type: '水池', risk: 'mid', lat: 22.648, lng: 110.188, radius: 200, detail: '水深1.5米，周边有儿童游乐设施' },
    { id: 12, name: '城西工业区水塘', type: '池塘', risk: 'mid', lat: 22.662, lng: 110.172, radius: 350, detail: '工业用水塘，水质较差，周边有工地' },
    { id: 13, name: '名山街道鱼塘', type: '池塘', risk: 'mid', lat: 22.622, lng: 110.212, radius: 280, detail: '养殖鱼塘，水深2-3米，周边有居民区' },
    { id: 14, name: '新桥镇水库', type: '水库', risk: 'mid', lat: 22.585, lng: 110.145, radius: 600, detail: '小型水库，有防护网但部分区域破损' },
    { id: 15, name: '大平山镇溪流', type: '溪流', risk: 'mid', lat: 22.578, lng: 110.162, radius: 320, detail: '山区溪流，雨季水量变化大' },
    { id: 16, name: '樟木镇河流', type: '河流', risk: 'mid', lat: 22.685, lng: 110.198, radius: 500, detail: '河流水位季节变化明显' },
    { id: 17, name: '沙田镇池塘', type: '池塘', risk: 'mid', lat: 22.692, lng: 110.185, radius: 250, detail: '村内池塘，有警示标志' },
    { id: 18, name: '茂林镇小溪', type: '溪流', risk: 'low', lat: 22.615, lng: 110.222, radius: 150, detail: '溪水浅，流速慢，周边有农田' },
    { id: 19, name: '成均镇蓄水池', type: '水池', risk: 'low', lat: 22.678, lng: 110.152, radius: 120, detail: '小型蓄水池，有围栏保护' },
    { id: 20, name: '樟木镇山泉', type: '水池', risk: 'low', lat: 22.698, lng: 110.202, radius: 80, detail: '山间泉水池，位置偏僻' },
    { id: 21, name: '福绵街道水坑', type: '水坑', risk: 'low', lat: 22.655, lng: 110.168, radius: 100, detail: '路边水坑，雨季积水' },
    { id: 22, name: '石和镇鱼塘', type: '池塘', risk: 'low', lat: 22.568, lng: 110.158, radius: 180, detail: '小型鱼塘，周边无人居住' },
    { id: 23, name: '仁厚镇溪流', type: '溪流', risk: 'low', lat: 22.628, lng: 110.142, radius: 160, detail: '小溪流，水深不足1米' },
    { id: 24, name: '城北工业区水池', type: '水池', risk: 'low', lat: 22.652, lng: 110.192, radius: 90, detail: '工业蓄水池，有防护设施' },
    { id: 25, name: '南江街道喷泉', type: '喷泉', risk: 'low', lat: 22.642, lng: 110.202, radius: 60, detail: '广场喷泉，水深较浅' },
  ])

  const cameraPoints = ref([
    { id: 1, name: '南流江监控点A', lat: 22.645, lng: 110.19, status: 'online' },
    { id: 2, name: '体育馆泳池A', lat: 22.632, lng: 110.205, status: 'online' },
    { id: 3, name: '龟山公园A', lat: 22.618, lng: 110.165, status: 'alert' },
    { id: 4, name: '清湾江监控点', lat: 22.625, lng: 110.182, status: 'online' },
    { id: 5, name: '石南镇监控点', lat: 22.605, lng: 110.148, status: 'online' },
    { id: 6, name: '福绵游泳场', lat: 22.658, lng: 110.175, status: 'online' },
    { id: 7, name: '兴业水库A', lat: 22.592, lng: 110.132, status: 'offline' },
    { id: 8, name: '博白江段A', lat: 22.675, lng: 110.215, status: 'online' },
    { id: 9, name: '玉州人工湖', lat: 22.638, lng: 110.195, status: 'online' },
    { id: 10, name: '仁东镇溪流', lat: 22.608, lng: 110.155, status: 'online' },
  ])

  const warnings = ref([
    { time: '14:23', location: '南流江大桥水域', detail: '检测到可疑落水人员，正在核实', level: 'high', ai: true },
    { time: '14:18', location: '龟山公园水库', detail: '有儿童靠近危险水域，已提醒', level: 'mid', ai: true },
    { time: '14:12', location: '玉林体育馆泳池', detail: '深水区有人停留超过10分钟', level: 'low', ai: true },
    { time: '14:05', location: '清湾江支流', detail: '发现不明漂浮物', level: 'mid', ai: true },
    { time: '13:58', location: '石南镇池塘群', detail: '有人员在池塘边垂钓', level: 'low', ai: false },
  ])

  const highRiskCount = computed(() => hazardPoints.value.filter(p => p.risk === 'high').length)
  const midRiskCount = computed(() => hazardPoints.value.filter(p => p.risk === 'mid').length)
  const lowRiskCount = computed(() => hazardPoints.value.filter(p => p.risk === 'low').length)
  const safeCount = computed(() => Math.max(0, 50 - hazardPoints.value.length))
  const cameraCount = computed(() => cameraPoints.value.length)

  const topSpots = computed(() => {
    const highSpots = hazardPoints.value
      .filter(p => p.risk === 'high')
      .map((p, i) => ({ rank: i + 1, name: p.name, score: Math.floor(Math.random() * 30) + 70 }))
      .sort((a, b) => b.score - a.score)
      .slice(0, 5)
    return highSpots
  })

  return {
    hazardPoints,
    cameraPoints,
    warnings,
    highRiskCount,
    midRiskCount,
    lowRiskCount,
    safeCount,
    cameraCount,
    topSpots
  }
}