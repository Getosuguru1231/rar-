import { ref, onUnmounted } from 'vue'

export function useWebSocket(urlGetter, options = {}) {
  const {
    maxReconnectAttempts = 10,
    reconnectDelayBase = 3000,
    heartbeatInterval = 10000,
    connectionTimeout = 10000,
    onMessage = () => {},
    onOpen = () => {},
    onClose = () => {},
    onError = () => {}
  } = options

  const ws = ref(null)
  const connected = ref(false)
  const reconnectAttempts = ref(0)
  const wsInstance = ref(null)

  let heartbeatTimer = null
  let connectionTimeoutTimer = null

  const sendMessage = (message) => {
    if (!wsInstance.value || wsInstance.value.readyState !== WebSocket.OPEN) {
      console.warn('[WebSocket] 连接未建立，无法发送消息')
      return false
    }
    try {
      if (typeof message === 'object') {
        wsInstance.value.send(JSON.stringify(message))
      } else {
        wsInstance.value.send(message)
      }
      return true
    } catch (error) {
      console.error('[WebSocket] 发送消息失败:', error)
      return false
    }
  }

  const startHeartbeat = () => {
    stopHeartbeat()
    heartbeatTimer = setInterval(() => {
      if (wsInstance.value && wsInstance.value.readyState === WebSocket.OPEN) {
        sendMessage({ type: 'ping', timestamp: Date.now() })
      }
    }, heartbeatInterval)
  }

  const stopHeartbeat = () => {
    if (heartbeatTimer) {
      clearInterval(heartbeatTimer)
      heartbeatTimer = null
    }
  }

  const clearConnectionTimeout = () => {
    if (connectionTimeoutTimer) {
      clearTimeout(connectionTimeoutTimer)
      connectionTimeoutTimer = null
    }
  }

  const connect = () => {
    try {
      connected.value = false

      const url = typeof urlGetter === 'function' ? urlGetter() : urlGetter
      console.log('[WebSocket] 尝试连接:', url)

      if (wsInstance.value) {
        wsInstance.value.close()
        wsInstance.value = null
      }

      wsInstance.value = new WebSocket(url)

      connectionTimeoutTimer = setTimeout(() => {
        if (wsInstance.value && wsInstance.value.readyState !== WebSocket.OPEN) {
          console.warn('[WebSocket] 连接超时')
          wsInstance.value.close()
        }
      }, connectionTimeout)

      wsInstance.value.onopen = () => {
        clearConnectionTimeout()
        console.log('[WebSocket] 连接成功')
        connected.value = true
        reconnectAttempts.value = 0
        startHeartbeat()
        onOpen()
      }

      wsInstance.value.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data)
          onMessage(data)
        } catch (error) {
          console.error('[WebSocket] 解析消息失败:', error)
        }
      }

      wsInstance.value.onerror = (error) => {
        clearConnectionTimeout()
        console.error('[WebSocket] 连接错误:', error)
        connected.value = false
        onError(error)
      }

      wsInstance.value.onclose = (event) => {
        clearConnectionTimeout()
        stopHeartbeat()
        console.log('[WebSocket] 连接关闭:', event.code, event.reason)
        connected.value = false
        onClose(event)

        if (event.code !== 1000 && reconnectAttempts.value < maxReconnectAttempts) {
          const delay = Math.min(reconnectDelayBase * Math.pow(2, reconnectAttempts.value), 30000)
          reconnectAttempts.value++
          console.log(`[WebSocket] 尝试重新连接 (${reconnectAttempts.value}/${maxReconnectAttempts})，延迟 ${delay}ms`)
          setTimeout(() => {
            if (!wsInstance.value || wsInstance.value.readyState === WebSocket.CLOSED) {
              connect()
            }
          }, delay)
        } else if (event.code !== 1000) {
          console.error('[WebSocket] 已达到最大重连次数')
        }
      }
    } catch (error) {
      console.error('[WebSocket] 初始化失败:', error)
    }
  }

  const disconnect = () => {
    stopHeartbeat()
    clearConnectionTimeout()
    if (wsInstance.value) {
      wsInstance.value.close()
      wsInstance.value = null
    }
    connected.value = false
  }

  onUnmounted(() => {
    disconnect()
  })

  return {
    ws: wsInstance,
    connected,
    reconnectAttempts,
    connect,
    disconnect,
    sendMessage,
    startHeartbeat,
    stopHeartbeat
  }
}