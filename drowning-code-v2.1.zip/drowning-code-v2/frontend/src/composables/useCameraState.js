import { ref, reactive, computed } from 'vue'
import { apiGet } from '../utils/api.js'

const DEFAULT_CAMERA_CONFIG = {
  id: 0,
  area: '',
  peopleCount: 0,
  inWaterCount: 0,
  outOfWaterCount: 0,
  hasAlert: false,
  videoLoaded: false,
  videoError: false,
  retryCount: 0,
  connectionState: 'disconnected',
  useWebRTC: false,
  fps: 0,
  packetsLost: 0,
  isConfigured: false,
  cameraType: ''
}

export function useCameraState(camerasConfig = []) {
  const cameras = reactive(
    camerasConfig.map(config => ({ ...DEFAULT_CAMERA_CONFIG, ...config }))
  )

  const activeCameraId = ref(1)
  const splitScreen = ref(1)

  const totalPeopleCount = computed(() =>
    cameras.reduce((sum, c) => sum + (c.peopleCount || 0), 0)
  )

  const areaDistribution = computed(() =>
    cameras.map(c => ({ name: c.area, count: c.peopleCount || 0 }))
  )

  const displayedCameras = computed(() => {
    if (splitScreen.value === 1) {
      const active = cameras.find(c => c.id === activeCameraId.value)
      return active ? [active] : []
    }
    return cameras.filter(c => c.isConfigured).slice(0, splitScreen.value)
  })

  const setActiveCamera = (cameraId) => {
    activeCameraId.value = cameraId
  }

  const setSplitScreen = (value) => {
    splitScreen.value = value
  }

  const updateCameraPeopleCount = (cameraId, count) => {
    const camera = cameras.find(c => c.id === cameraId)
    if (camera) {
      camera.peopleCount = count
    }
  }

  const updateCameraStatus = (cameraId, status) => {
    const camera = cameras.find(c => c.id === cameraId)
    if (camera) {
      Object.assign(camera, status)
    }
  }

  const updateCameraAlertStatus = (alertStore) => {
    const alerts = alertStore.getAlerts()
    cameras.forEach(camera => {
      camera.hasAlert = alerts.some(a => !a.acknowledged && a.cameraId === camera.id)
    })
  }

  const refreshCameraStats = async () => {
    try {
      const data = await apiGet('/api/video/people-count')
      const peopleCount = data.people_count || data.total_people || 0

      cameras.forEach(camera => {
        camera.peopleCount = 0
        camera.inWaterCount = 0
        camera.outOfWaterCount = 0
      })

      if (data.cameras && typeof data.cameras === 'object') {
        cameras.forEach(camera => {
          const camData = data.cameras[camera.id.toString()]
          if (camData) {
            camera.peopleCount = camData.people_count || camData.total_people || 0
            camera.inWaterCount = camData.in_water_count || 0
            camera.outOfWaterCount = camData.out_water_count || 0
          }
        })
      }
    } catch (error) {
      console.error('[CameraState] 获取摄像头统计失败:', error)
    }
  }

  const updateCamerasFromWebSocket = (data) => {
    if (!data || !data.cameras) return

    cameras.forEach(camera => {
      const camData = data.cameras[camera.id.toString()]
      if (camData) {
        camera.peopleCount = typeof camData.people_count === 'number' && !isNaN(camData.people_count) ? camData.people_count : 0
      } else {
        camera.peopleCount = 0
      }
    })
  }

  return {
    cameras,
    activeCameraId,
    splitScreen,
    totalPeopleCount,
    areaDistribution,
    displayedCameras,
    setActiveCamera,
    setSplitScreen,
    updateCameraPeopleCount,
    updateCameraStatus,
    updateCameraAlertStatus,
    refreshCameraStats,
    updateCamerasFromWebSocket
  }
}