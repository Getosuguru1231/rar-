import { ref, onUnmounted } from 'vue'

export function useTimer() {
  const timers = ref(new Map())

  const setInterval = (callback, interval, key = null) => {
    if (key && timers.value.has(key)) {
      clearInterval(key)
    }

    const timerId = window.setInterval(async () => {
      try {
        await callback()
      } catch (error) {
        console.error('[Timer] 定时器回调执行失败:', error)
      }
    }, interval)

    if (key) {
      timers.value.set(key, timerId)
    }

    return timerId
  }

  const clearInterval = (keyOrTimerId) => {
    let timerId
    if (typeof keyOrTimerId === 'string') {
      timerId = timers.value.get(keyOrTimerId)
      timers.value.delete(keyOrTimerId)
    } else {
      timerId = keyOrTimerId
    }

    if (timerId) {
      window.clearInterval(timerId)
    }
  }

  const setTimeout = (callback, delay, key = null) => {
    if (key && timers.value.has(key)) {
      clearTimeout(key)
    }

    const timerId = window.setTimeout(async () => {
      try {
        await callback()
      } catch (error) {
        console.error('[Timer] 延时器回调执行失败:', error)
      }
    }, delay)

    if (key) {
      timers.value.set(key, timerId)
    }

    return timerId
  }

  const clearTimeout = (keyOrTimerId) => {
    let timerId
    if (typeof keyOrTimerId === 'string') {
      timerId = timers.value.get(keyOrTimerId)
      timers.value.delete(keyOrTimerId)
    } else {
      timerId = keyOrTimerId
    }

    if (timerId) {
      window.clearTimeout(timerId)
    }
  }

  const clearAll = () => {
    timers.value.forEach((timerId) => {
      window.clearInterval(timerId)
      window.clearTimeout(timerId)
    })
    timers.value.clear()
  }

  onUnmounted(() => {
    clearAll()
  })

  return {
    setInterval,
    clearInterval,
    setTimeout,
    clearTimeout,
    clearAll
  }
}

export function useSafeInterval(callback, interval, dependencies = []) {
  const timer = ref(null)
  const isRunning = ref(false)

  const start = () => {
    if (timer.value) {
      clearInterval(timer.value)
    }

    isRunning.value = true

    const run = async () => {
      try {
        await callback()
      } catch (error) {
        console.error('[SafeInterval] 执行失败:', error)
      }
    }

    run()
    timer.value = setInterval(run, interval)
  }

  const stop = () => {
    if (timer.value) {
      clearInterval(timer.value)
      timer.value = null
    }
    isRunning.value = false
  }

  onUnmounted(() => {
    stop()
  })

  return {
    timer,
    isRunning,
    start,
    stop
  }
}