import { createRouter, createWebHistory } from 'vue-router'

const routes = [
  {
    path: '/',
    redirect: '/login'
  },
  {
    path: '/login',
    name: 'Login',
    component: () => import('@/components/common/Login.vue'),
    meta: { requiresGuest: true }
  },
  {
    path: '/monitor',
    name: 'Monitor',
    component: () => import('@/views/Monitor.vue'),
    meta: { requiresAuth: true }
  },
  {
    path: '/dashboard',
    name: 'Dashboard',
    component: () => import('@/views/DrowningDashboard.vue'),
    meta: { requiresAuth: true }
  },
  {
    path: '/admin',
    name: 'AdminPanel',
    component: () => import('@/views/AdminPanel.vue'),
    meta: { requiresAuth: true, role: 'admin' }
  },
  {
    path: '/alerts',
    name: 'AlertManagement',
    component: () => import('@/views/AlertManagement.vue'),
    meta: { requiresAuth: true }
  },
  {
    path: '/video-test',
    name: 'VideoTest',
    component: () => import('@/views/VideoTest.vue'),
    meta: { requiresAuth: true }
  },
  {
    path: '/test-webrtc',
    name: 'TestWebRTC',
    component: () => import('@/views/TestWebRTC.vue'),
    meta: { requiresAuth: false }
  },
  {
    path: '/history',
    name: 'DetectionHistory',
    component: () => import('@/views/DetectionHistory.vue'),
    meta: { requiresAuth: true }
  },

]

const router = createRouter({
  history: createWebHistory(),
  routes
})

// 路由守卫
router.beforeEach((to, from, next) => {
  const token = localStorage.getItem('token')
  const userType = localStorage.getItem('userType')
  
  console.log(`[路由守卫] 从 ${from.path} 跳转到 ${to.path}`, { token: !!token, userType })
  
  // 检查是否需要认证
  if (to.meta.requiresAuth) {
    if (!token) {
      console.warn('[路由守卫] 未登录，重定向到登录页')
      next('/login')
    } else {
      // 检查用户角色是否符合要求
      if (to.meta.role && userType !== to.meta.role) {
        console.warn(`[路由守卫] 权限不足: ${userType} 无法访问 ${to.meta.role} 页面`)
        // 如果用户尝试访问其他角色的页面，则重定向
        if (userType === 'admin') {
          next('/admin')
        } else {
          next('/monitor')
        }
      } else {
        console.log('[路由守卫] 验证通过，允许访问')
        next()
      }
    }
  } 
  // 检查是否仅允许未登录用户访问
  else if (to.meta.requiresGuest) {
    if (token) {
      console.log('[路由守卫] 已登录用户访问登录页，重定向到对应页面')
      // 如果已登录，根据用户类型重定向
      if (userType === 'admin') {
        next('/admin')
      } else {
        next('/monitor')
      }
    } else {
      console.log('[路由守卫] 未登录用户访问登录页，允许')
      next()
    }
  } 
  else {
    next()
  }
})

// 路由错误处理
router.onError((error) => {
  console.error('[路由错误]', error)
  // 避免无限循环
  if (error.message.includes('Redirected when going from')) {
    console.warn('[路由错误] 检测到重定向循环，跳转到登录页')
    localStorage.clear()
    window.location.href = '/login'
  }
})

export default router
