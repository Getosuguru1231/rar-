// frontend/src/utils/icons.js
/**
 * 统一图标管理模块
 * 
 * 解决Element Plus图标版本兼容性问题，集中管理图标引用
 * 
 * 使用示例：
 * import { iconMap } from '@/utils/icons.js'
 * 
 * <el-icon><component :is="iconMap.Lightbulb" /></el-icon>
 */

import { 
  ArrowDown, Bell, VideoCamera, User, Refresh, Loading, 
  UploadFilled, Clock, ChatDotRound, ChatLineSquare, Promotion,
  DataAnalysis, Picture, Download, Warning, CircleCheck, Timer, 
  Sunny, MessageSquare, Send, Delete, Operation, Top, Comment
} from '@element-plus/icons-vue'

// 导出原始图标
export { 
  ArrowDown, Bell, VideoCamera, User, Refresh, Loading, 
  UploadFilled, Clock, ChatDotRound, ChatLineSquare, Promotion,
  DataAnalysis, Picture, Download, Warning, CircleCheck, Timer, 
  Sunny, MessageSquare, Send, Delete, Operation, Top, Comment
}

/**
 * 图标兼容性映射表
 * 
 * 当新版本Element Plus移除某些图标时，使用此映射表进行替换
 * 键：旧图标名称（可能不存在）
 * 值：新图标名称（确保存在）
 */
export const iconMap = {
  // 旧图标 -> 新图标（兼容性映射）
  Lightbulb: Sunny,           // 灯泡图标替换为太阳图标
  Keyboard: Top,              // 键盘图标替换为顶部图标
  MessageCircle: MessageSquare, // 消息圆圈图标替换为消息方块图标
  Send: Send,                 // 发送图标（确保存在）
  Comment: Comment,           // 评论图标
  Operation: Operation,       // 操作图标
  Top: Top,                   // 顶部图标
  
  // 直接导出的图标（保持一致性）
  ArrowDown, 
  Bell, 
  VideoCamera, 
  User, 
  Refresh, 
  Loading, 
  UploadFilled, 
  Clock, 
  ChatDotRound, 
  ChatLineSquare, 
  Promotion,
  DataAnalysis, 
  Picture, 
  Download, 
  Warning, 
  CircleCheck, 
  Timer, 
  Sunny, 
  Delete
}

/**
 * 获取图标组件
 * 
 * @param {string} iconName - 图标名称
 * @returns {Component} 图标组件，如果不存在返回默认图标
 */
export const getIcon = (iconName) => {
  const icon = iconMap[iconName]
  if (icon) {
    return icon
  }
  console.warn(`[IconManager] 图标 ${iconName} 不存在，使用默认图标`)
  return MessageSquare // 默认图标
}

/**
 * 图标分类常量
 * 
 * 用于组织和管理不同用途的图标
 */
export const IconCategories = {
  SYSTEM: ['Refresh', 'Loading', 'Settings', 'Help'],
  MEDIA: ['VideoCamera', 'Picture', 'UploadFilled', 'Download'],
  COMMUNICATION: ['MessageSquare', 'ChatDotRound', 'ChatLineSquare', 'Send'],
  ALERT: ['Bell', 'Warning', 'CircleCheck'],
  USER: ['User'],
  DATA: ['DataAnalysis', 'Timer', 'Clock'],
  ACTION: ['ArrowDown', 'Delete', 'Operation']
}

/**
 * 图标工厂函数
 * 
 * @param {string} category - 图标分类
 * @returns {Object} 指定分类的图标对象
 */
export const getIconsByCategory = (category) => {
  const categoryIcons = IconCategories[category]
  if (!categoryIcons) {
    console.warn(`[IconManager] 图标分类 ${category} 不存在`)
    return {}
  }
  
  const result = {}
  categoryIcons.forEach(iconName => {
    result[iconName] = iconMap[iconName] || MessageSquare
  })
  
  return result
}