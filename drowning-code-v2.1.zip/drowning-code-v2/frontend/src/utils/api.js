import { axios, API_CONSTANTS, showError } from './index.js'

const apiCache = new Map()
const CACHE_EXPIRY = 10000
const MAX_CACHE_SIZE = 50

const generateCacheKey = (url, params) => {
  const queryString = Object.keys(params).length > 0 
    ? '?' + new URLSearchParams(params).toString() 
    : '';
  return `${url}${queryString}`;
};

export const apiGet = async (url, params = {}, headers = {}, useCache = true) => {
  try {
    const cacheKey = generateCacheKey(url, params);
    
    if (useCache) {
      const cached = apiCache.get(cacheKey);
      if (cached && (Date.now() - cached.timestamp) < CACHE_EXPIRY) {
        return cached.data;
      }
    }
    
    const cleanUrl = url.startsWith('/api') ? url.substring(4) : url;
    
    let timeout = API_CONSTANTS.DEFAULT_TIMEOUT;
    if (cleanUrl.includes('/video_feed') || cleanUrl.includes('/stream')) {
      timeout = 60000;
    } else if (cleanUrl.includes('/upload') || cleanUrl.includes('/detect')) {
      timeout = 120000;
    }
    
    const response = await axios.get(cleanUrl, {
      params: params,
      headers: {
        'Content-Type': API_CONSTANTS.DEFAULT_CONTENT_TYPE,
        ...headers
      },
      timeout: timeout,
      timeoutErrorMessage: `请求超时(${timeout/1000}秒)，请检查网络连接`,
      retry: 3,
      retryDelay: 1000
    });
    
    const data = response.data;
    
    if (data.code === 200 || data.success === true || data.success === "true") {
      const result = data.data;
      
      if (useCache) {
        if (apiCache.size >= MAX_CACHE_SIZE) {
          const firstKey = apiCache.keys().next().value;
          apiCache.delete(firstKey);
        }
        apiCache.set(cacheKey, {
          data: result,
          timestamp: Date.now()
        });
      }
      
      return result;
    } else {
      console.warn('[apiGet] 非成功响应:', data);
      return data;
    }
  } catch (error) {
    console.error('[apiGet] 请求失败:', error);
    throw error;
  }
};

export const apiPost = async (url, data = {}, config = {}) => {
  try {
    const cleanUrl = url.startsWith('/api') ? url.substring(4) : url;
    const { headers = {}, onUploadProgress, timeout: customTimeout, retry, retryDelay, ...axiosConfig } = config;
    
    let timeout = customTimeout || API_CONSTANTS.DEFAULT_TIMEOUT;
    if (cleanUrl.includes('/upload') || cleanUrl.includes('/detect')) {
      timeout = customTimeout || 120000;
    }
    
    const isFormData = data instanceof FormData;
    
    const response = await axios.post(cleanUrl, data, {
      headers: {
        ...(!isFormData && { 'Content-Type': API_CONSTANTS.DEFAULT_CONTENT_TYPE }),
        ...headers
      },
      timeout: timeout,
      timeoutErrorMessage: `请求超时(${timeout/1000}秒)，请检查网络连接`,
      retry: retry || 3,
      retryDelay: retryDelay || 1000,
      onUploadProgress: onUploadProgress,
      ...axiosConfig
    });
    
    const responseData = response.data;
    
    if (responseData.code === 200 || responseData.success === true || responseData.success === "true") {
      // 如果有 data 字段，返回 data；否则返回整个响应对象
      return responseData.data !== undefined ? responseData.data : responseData;
    } else {
      console.warn('[apiPost] 非成功响应:', responseData);
      return responseData;
    }
  } catch (error) {
    console.error('[apiPost] 请求失败:', error);
    throw error;
  }
};

export const apiDelete = async (url, headers = {}) => {
  try {
    const cleanUrl = url.startsWith('/api') ? url.substring(4) : url;
    
    const response = await axios.delete(cleanUrl, {
      headers: {
        'Content-Type': API_CONSTANTS.DEFAULT_CONTENT_TYPE,
        ...headers
      },
      timeout: API_CONSTANTS.DEFAULT_TIMEOUT,
      retry: 3,
      retryDelay: 1000
    });
    
    const data = response.data;
    
    if (data.code === 200 || data.success === true || data.success === "true") {
      return data.data || data;
    } else {
      console.warn('[apiDelete] 非成功响应:', data);
      return data;
    }
  } catch (error) {
    console.error('[apiDelete] 请求失败:', error);
    throw error;
  }
};

export const executeWithRetry = async (fn, maxRetries = 3, delay = 1000) => {
  let lastError = null;
  
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      return await fn();
    } catch (error) {
      lastError = error;
      console.warn(`[executeWithRetry] 第 ${attempt} 次尝试失败:`, error.message);
      
      if (attempt < maxRetries) {
        const backoffDelay = delay * Math.pow(2, attempt - 1);
        await new Promise(resolve => setTimeout(resolve, backoffDelay));
      }
    }
  }
  
  throw lastError;
};

export const createSafeInterval = (fn, interval, timerRef, getIntervalFn) => {
  if (timerRef.value) {
    clearInterval(timerRef.value);
  }
  
  const run = async () => {
    try {
      await fn();
    } catch (error) {
      console.error('[createSafeInterval] 执行失败:', error);
    }
  };
  
  const startInterval = () => {
    timerRef.value = setInterval(run, interval);
  };
  
  startInterval();
  
  return () => {
    if (timerRef.value) {
      clearInterval(timerRef.value);
      timerRef.value = null;
    }
  };
};

export const clearAllTimers = (...timerRefs) => {
  timerRefs.forEach(timerRef => {
    if (timerRef.value) {
      clearInterval(timerRef.value);
      timerRef.value = null;
    }
  });
};

export const safeExecute = async (fn, options = {}) => {
  const {
    errorMessage = '操作失败',
    showError: shouldShowError = true,
    onError
  } = options;
  
  try {
    return await fn();
  } catch (error) {
    console.error('[safeExecute] 执行失败:', error);
    
    if (shouldShowError) {
      const message = error.response?.data?.detail || error.response?.data?.message || error.message || errorMessage;
      showError(message);
    }
    
    if (onError) {
      onError(error);
    }
    
    throw error;
  }
};

/**
 * 验证数据是否为有效的base64字符串
 * @param {*} data - 待验证的数据
 * @returns {boolean} 是否为有效的base64字符串
 */
export const isValidBase64 = (data) => {
  if (typeof data !== 'string') {
    return false;
  }
  const trimmed = data.trim();
  if (!trimmed) {
    return false;
  }
  const base64Regex = /^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/;
  return base64Regex.test(trimmed);
};

/**
 * 预加载图片（用于优化图片显示性能）
 * @param {string} base64Data - base64编码的图片数据
 * @returns {Promise<boolean>} 图片是否预加载成功
 */
export const preloadImage = (base64Data) => {
  return new Promise((resolve) => {
    if (!base64Data || !isValidBase64(base64Data)) {
      resolve(false);
      return;
    }
    
    const img = new Image();
    img.onload = () => resolve(true);
    img.onerror = () => {
      console.warn('[PreloadImage] 图片加载失败');
      resolve(false);
    };
    img.src = 'data:image/jpeg;base64,' + base64Data;
  });
};