// frontend/src/utils/index.js
/**
 * 前端通用工具函数模块
 * 提取重复代码，提供统一的工具方法
 * 优化说明：CSP合规加固、边界异常修复、内存泄漏优化、兼容性增强、类型安全提升
 */
import { ElMessage, ElMessageBox } from 'element-plus'
import axios from 'axios'

// ==================== 常量抽离（消除魔法值，便于统一维护与CSP适配）====================
/** 时间格式化常量 */
export const TIME_FORMAT_CONSTANTS = {
  DEFAULT_DATE_FORMAT: 'YYYY-MM-DD HH:mm:ss',
  DEFAULT_TIME_PAD_LENGTH: 2,
  DEFAULT_PAD_STRING: '0',
  SECONDS_PER_HOUR: 3600,
  SECONDS_PER_MINUTE: 60
}

/** 标注框颜色常量 - 适配AI检测/溺水监控场景 */
export const BOX_COLORS = {
  normal: '#00ff00', // 正常
  warning: '#ffff00', // 疑似风险
  alert: '#ff0000',   // 告警/溺水
  default: '#00ff00'
}

/** 风险等级常量 - 匹配监控系统高/中/低风险分级 */
export const RISK_LEVEL_CONFIG = {
  high: { tagType: 'danger', text: '高风险' },
  medium: { tagType: 'warning', text: '中风险' },
  low: { tagType: 'info', text: '低风险' },
  default: { tagType: 'info', text: '未知风险' }
}

/** 消息弹窗常量 - 全局统一弹窗样式 */
export const MESSAGE_BOX_CONFIG = {
  confirmButtonText: '确认',
  cancelButtonText: '取消',
  type: 'warning',
  closeOnClickModal: false, // 新增：点击遮罩不关闭，适配告警确认场景
  closeOnPressEscape: false // 新增：按ESC不关闭，适配告警确认场景
}

/** 网络请求常量 - 适配多环境，对接后端API */
export const API_CONSTANTS = {
  BASE_URL: import.meta.env.VITE_API_BASE_URL !== undefined ? import.meta.env.VITE_API_BASE_URL : '/api',
  DEFAULT_TIMEOUT: 30000,
  DEFAULT_CONTENT_TYPE: 'application/json;charset=utf-8'
}

/** 音频常量 - 告警音频配置 */
export const ALERT_AUDIO_CONFIG = {
  DEFAULT_PATH: '/alert.mp3',
  VOLUME: 0.8 // 新增：默认音量，避免音量过大
}

/** 防抖节流默认配置 - 全局统一防抖节流时间 */
export const DEBOUNCE_THROTTLE_CONFIG = {
  DEFAULT_WAIT: 300,
  DEFAULT_DELAY: 300
}

// ==================== Axios实例配置与拦截器 ====================
// 错误弹窗限制配置
const GLOBAL_ERROR_COOLDOWN = 30000 // 30秒内不重复显示相同错误
const globalErrorTracker = new Map() // 追踪全局错误
const GLOBAL_MAX_ERRORS = 3 // 最多显示3次全局错误弹窗

// 检查是否应该显示全局错误弹窗
const shouldShowGlobalError = (errorKey) => {
  const now = Date.now()
  const lastShown = globalErrorTracker.get(errorKey) || 0
  const count = globalErrorTracker.get(`${errorKey}_count`) || 0

  // 如果在冷却期内，不显示错误
  if (now - lastShown < GLOBAL_ERROR_COOLDOWN) {
    return false
  }

  // 如果错误次数超过上限，不显示错误
  if (count >= GLOBAL_MAX_ERRORS) {
    return false
  }

  // 更新追踪数据
  globalErrorTracker.set(errorKey, now)
  globalErrorTracker.set(`${errorKey}_count`, count + 1)
  return true
}

/**
 * 创建axios实例，配置基础URL和超时时间
 */
const apiClient = axios.create({
  baseURL: API_CONSTANTS.BASE_URL,
  timeout: API_CONSTANTS.DEFAULT_TIMEOUT,
  headers: {},
  // 启用withCredentials以支持跨域cookie
  withCredentials: false
})

/**
 * 请求重试配置
 */
const RETRY_CONFIG = {
  maxRetries: 3,              // 最大重试次数
  retryDelay: 1000,           // 初始重试延迟(ms)
  retryBackoff: 2,            // 退避倍数(指数退避)
  retryableStatuses: [408, 429, 500, 502, 503, 504],  // 可重试的状态码
  retryableErrors: ['ECONNABORTED', 'ETIMEDOUT', 'ECONNRESET']  // 可重试的错误
}

/**
 * 检查是否应该重试
 */
const shouldRetry = (error, retryCount) => {
  if (retryCount >= RETRY_CONFIG.maxRetries) return false
  
  // 检查状态码
  if (error.response && RETRY_CONFIG.retryableStatuses.includes(error.response.status)) {
    return true
  }
  
  // 检查网络错误
  if (error.code && RETRY_CONFIG.retryableErrors.includes(error.code)) {
    return true
  }
  
  // 检查是否是超时错误
  if (error.message && (error.message.includes('timeout') || error.message.includes('Timeout'))) {
    return true
  }
  
  return false
}

/**
 * 计算重试延迟(指数退避)
 */
const getRetryDelay = (retryCount) => {
  return RETRY_CONFIG.retryDelay * Math.pow(RETRY_CONFIG.retryBackoff, retryCount)
}

/**
 * 请求拦截器：自动添加token和请求ID
 */
apiClient.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token')
    if (token) {
      config.headers.Authorization = `Bearer ${token}`
    }
    
    // 添加请求ID用于追踪
    if (!config.headers['X-Request-ID']) {
      config.headers['X-Request-ID'] = `req_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
    }
    
    // 初始化重试计数
    if (config.__retryCount === undefined) {
      config.__retryCount = 0
    }
    
    return config
  },
  (error) => {
    console.error('请求拦截器错误:', error)
    return Promise.reject(error)
  }
)

/**
 * 响应拦截器：处理401未授权错误和自动重试
 */
apiClient.interceptors.response.use(
  (response) => {
    return response
  },
  async (error) => {
    const config = error.config
    
    // 检查是否应该重试
    if (config && shouldRetry(error, config.__retryCount || 0)) {
      config.__retryCount = (config.__retryCount || 0) + 1
      
      const retryDelay = getRetryDelay(config.__retryCount - 1)
      
      console.warn(`[API Retry] 第${config.__retryCount}次重试: ${config.url} (延迟${retryDelay}ms)`)
      
      // 等待后重试
      await new Promise(resolve => setTimeout(resolve, retryDelay))
      
      return apiClient(config)
    }
    
    // 处理401未授权错误
    if (error.response && error.response.status === 401) {
      if (shouldShowGlobalError('401_error')) {
        console.warn('Token已过期或无效，跳转到登录页')
        localStorage.removeItem('token')
        localStorage.removeItem('username')
        localStorage.removeItem('userType')

        // 避免在登录页重复跳转
        if (window.location.pathname !== '/login') {
          ElMessage.error('登录已过期，请重新登录')
          window.location.href = '/login'
        }
      }
      return Promise.reject(error)
    }

    // 处理其他错误 - 使用错误限制器避免频繁弹窗
    if (error.response) {
      const status = error.response.status
      const errorKey = `http_${status}`

      if (shouldShowGlobalError(errorKey)) {
        const message = error.response.data?.detail || error.response.data?.message || '请求失败'
        ElMessage.error(message)
      }
    } else if (error.request) {
      // 网络错误，只在控制台输出，避免频繁弹窗
      const errorKey = 'network_error'
      if (shouldShowGlobalError(errorKey)) {
        ElMessage.warning('网络连接不稳定，正在重试...')
        console.warn('[Network] 网络错误:', error.message)
      }
    } else {
      const errorKey = 'config_error'
      if (shouldShowGlobalError(errorKey)) {
        ElMessage.error('请求配置错误')
      }
    }

    return Promise.reject(error)
  }
)

// 导出配置好的axios实例
export { apiClient as axios }

/**
 * 快速连接测试
 * 用于检测后端服务是否可用
 * @returns {Promise<boolean>} 连接是否正常
 */
export const testConnection = async () => {
  try {
    const response = await apiClient.get('/ping', {
      timeout: 5000,  // 5秒超时
      retry: false     // 不重试，快速失败
    })
    return response.data?.pong === true
  } catch (error) {
    console.warn('[Connection Test] 后端连接测试失败:', error.message)
    return false
  }
}

/**
 * 健康检查
 * 获取后端服务详细状态
 * @returns {Promise<Object>} 健康状态信息
 */
export const checkHealth = async () => {
  try {
    const response = await apiClient.get('/health', {
      timeout: 10000  // 10秒超时
    })
    return {
      healthy: response.data?.status === 'healthy',
      data: response.data
    }
  } catch (error) {
    console.error('[Health Check] 健康检查失败:', error.message)
    return {
      healthy: false,
      error: error.message
    }
  }
}

// ==================== 全局实例复用（解决内存泄漏问题）====================
/** 告警音频复用实例，避免重复创建导致内存泄漏 */
let alertAudioInstance = null

// ==================== 时间格式化工具函数 ====================
/**
 * 格式化时间为字符串
 * @param {Date|number|string} date - Date 对象、时间戳、合法时间字符串
 * @param {string} format - 格式化模板，默认 YYYY-MM-DD HH:mm:ss
 * @returns {string} 格式化的时间字符串，入参无效时返回空字符串
 */
export const formatTime = (date, format = TIME_FORMAT_CONSTANTS.DEFAULT_DATE_FORMAT) => {
  // 入参非空+类型校验
  if (date === null || date === undefined || date === '' || (typeof date !== 'number' && typeof date !== 'string' && !(date instanceof Date))) {
    console.warn('formatTime: 无效的时间入参，仅支持Date/数字时间戳/合法时间字符串', date)
    return ''
  }

  // 日期对象转换与合法性校验
  const d = date instanceof Date ? date : new Date(date)
  if (Number.isNaN(d.getTime())) {
    console.warn('formatTime: 无法转换为合法日期', date)
    return ''
  }

  // 时间字段提取
  const year = d.getFullYear()
  const month = String(d.getMonth() + 1).padStart(TIME_FORMAT_CONSTANTS.DEFAULT_TIME_PAD_LENGTH, TIME_FORMAT_CONSTANTS.DEFAULT_PAD_STRING)
  const day = String(d.getDate()).padStart(TIME_FORMAT_CONSTANTS.DEFAULT_TIME_PAD_LENGTH, TIME_FORMAT_CONSTANTS.DEFAULT_PAD_STRING)
  const hours = String(d.getHours()).padStart(TIME_FORMAT_CONSTANTS.DEFAULT_TIME_PAD_LENGTH, TIME_FORMAT_CONSTANTS.DEFAULT_PAD_STRING)
  const minutes = String(d.getMinutes()).padStart(TIME_FORMAT_CONSTANTS.DEFAULT_TIME_PAD_LENGTH, TIME_FORMAT_CONSTANTS.DEFAULT_PAD_STRING)
  const seconds = String(d.getSeconds()).padStart(TIME_FORMAT_CONSTANTS.DEFAULT_TIME_PAD_LENGTH, TIME_FORMAT_CONSTANTS.DEFAULT_PAD_STRING)

  // 模板替换（支持扩展）
  return format
    .replace('YYYY', year)
    .replace('MM', month)
    .replace('DD', day)
    .replace('HH', hours)
    .replace('mm', minutes)
    .replace('ss', seconds)
}

/**
 * 格式化秒数为 HH:MM:SS 格式（适配监控录像时间轴）
 * @param {number|string} seconds - 非负整数秒数/数字字符串
 * @returns {string} 格式化的时间字符串，入参无效时返回 00:00:00
 */
export const formatSeconds = (seconds) => {
  // 入参类型与合法性校验：支持数字/数字字符串，过滤非数字
  let numSeconds = Number(seconds)
  if (Number.isNaN(numSeconds) || numSeconds < 0 || !isFinite(numSeconds)) {
    console.warn('formatSeconds: 无效的秒数入参，仅支持非负数字', seconds)
    return '00:00:00'
  }

  // 取整处理，避免小数导致格式异常
  const totalSeconds = Math.floor(numSeconds)
  const h = Math.floor(totalSeconds / TIME_FORMAT_CONSTANTS.SECONDS_PER_HOUR)
    .toString()
    .padStart(TIME_FORMAT_CONSTANTS.DEFAULT_TIME_PAD_LENGTH, TIME_FORMAT_CONSTANTS.DEFAULT_PAD_STRING)
  const m = Math.floor((totalSeconds % TIME_FORMAT_CONSTANTS.SECONDS_PER_HOUR) / TIME_FORMAT_CONSTANTS.SECONDS_PER_MINUTE)
    .toString()
    .padStart(TIME_FORMAT_CONSTANTS.DEFAULT_TIME_PAD_LENGTH, TIME_FORMAT_CONSTANTS.DEFAULT_PAD_STRING)
  const s = (totalSeconds % TIME_FORMAT_CONSTANTS.SECONDS_PER_MINUTE)
    .toString()
    .padStart(TIME_FORMAT_CONSTANTS.DEFAULT_TIME_PAD_LENGTH, TIME_FORMAT_CONSTANTS.DEFAULT_PAD_STRING)

  return `${h}:${m}:${s}`
}

// ==================== 业务状态工具函数（适配监控场景）====================
/**
 * 获取 AI 标注框颜色（匹配溺水监控人员状态）
 * @param {string} status - 状态（normal/warning/alert）
 * @returns {string} 颜色值，入参无效返回默认色
 */
export const getBoxColor = (status) => {
  // 入参非空校验
  if (!status || typeof status !== 'string') {
    return BOX_COLORS.default
  }
  return BOX_COLORS[status] || BOX_COLORS.default
}

/**
 * 获取风险等级标签类型（Element Plus Tag组件）
 * @param {string} level - 风险等级（high/medium/low）
 * @returns {string} Element Plus tag 类型，入参无效返回默认值
 */
export const getRiskTagType = (level) => {
  if (!level || typeof level !== 'string') {
    return RISK_LEVEL_CONFIG.default.tagType
  }
  return RISK_LEVEL_CONFIG[level]?.tagType || RISK_LEVEL_CONFIG.default.tagType
}

/**
 * 获取风险等级文本（适配监控系统告警展示）
 * @param {string} level - 风险等级（high/medium/low）
 * @returns {string} 风险等级文本，入参无效返回默认值
 */
export const getRiskText = (level) => {
  if (!level || typeof level !== 'string') {
    return RISK_LEVEL_CONFIG.default.text
  }
  return RISK_LEVEL_CONFIG[level]?.text || RISK_LEVEL_CONFIG.default.text
}

// ==================== 统一消息提示函数组（全局统一，避免重复代码）====================
/**
 * 显示确认对话框（适配告警确认/操作确认场景）
 * @param {string} message - 确认信息
 * @param {string} title - 标题，默认「提示」
 * @param {object} customConfig - 自定义弹窗配置，覆盖默认配置
 * @returns {Promise} 确认/取消的Promise
 */
export const showConfirm = (message, title = '提示', customConfig = {}) => {
  // 入参非空校验
  if (!message || typeof message !== 'string') {
    console.warn('showConfirm: 确认信息不能为空，且必须为字符串')
    return Promise.reject(new Error('确认信息不能为空'))
  }
  // 过滤非对象配置
  const validConfig = typeof customConfig === 'object' && customConfig !== null ? customConfig : {}
  return ElMessageBox.confirm(message, title, {
    ...MESSAGE_BOX_CONFIG,
    ...validConfig
  })
}

/**
 * 显示成功消息
 * @param {string} message - 消息内容
 * @param {number} duration - 显示时长，默认3000ms
 */
export const showSuccess = (message, duration = 3000) => {
  if (!message || typeof message !== 'string') return
  ElMessage.success({ message, duration, showClose: true })
}

/**
 * 显示错误消息
 * @param {string} message - 消息内容
 * @param {number} duration - 显示时长，默认5000ms（告警类错误显示更久）
 */
export const showError = (message, duration = 5000) => {
  if (!message || typeof message !== 'string') return
  ElMessage.error({ message, duration, showClose: true })
}

/**
 * 显示警告消息
 * @param {string} message - 消息内容
 * @param {number} duration - 显示时长，默认4000ms
 */
export const showWarning = (message, duration = 4000) => {
  if (!message || typeof message !== 'string') return
  ElMessage.warning({ message, duration, showClose: true })
}

/**
 * 显示信息消息
 * @param {string} message - 消息内容
 * @param {number} duration - 显示时长，默认3000ms
 */
export const showInfo = (message, duration = 3000) => {
  if (!message || typeof message !== 'string') return
  ElMessage.info({ message, duration, showClose: true })
}

// ==================== 网络请求封装（适配后端API，统一错误处理）====================
/**
 * 基础API请求封装（基于Axios）
 * @param {string} url - 请求 URL（相对路径，自动拼接BASE_URL）
 * @param {Object} options - Axios 配置（method/params/data/headers等）
 * @returns {Promise} 请求结果Promise，返回res.data
 */
export const apiRequest = async (url, options = {}) => {
  if (!url || typeof url !== 'string') {
    const error = new Error('请求URL不能为空，且必须为字符串')
    console.error('API 请求失败:', error)
    return Promise.reject(error)
  }
  const validOptions = typeof options === 'object' && options !== null ? options : {}

  try {
    const cleanUrl = url.startsWith('/api') ? url.substring(4) : url;
    const response = await apiClient({
      url: cleanUrl,
      timeout: API_CONSTANTS.DEFAULT_TIMEOUT,
      headers: {
        'Content-Type': API_CONSTANTS.DEFAULT_CONTENT_TYPE,
        ...validOptions.headers
      },
      ...validOptions
    })
    return response.data
  } catch (error) {
    console.warn('API 请求失败:', error.message)
    throw error
  }
}

/**
 * GET 请求封装（快捷方法）
 * @param {string} url - 请求 URL
 * @param {Object} params - 查询参数
 * @param {Object} headers - 自定义请求头
 * @returns {Promise} 请求结果Promise
 */
export const apiGet = (url, params = {}, headers = {}) => {
  const validParams = typeof params === 'object' && params !== null ? params : {}
  const validHeaders = typeof headers === 'object' && headers !== null ? headers : {}
  return apiRequest(url, { method: 'get', params: validParams, headers: validHeaders })
}

/**
 * POST 请求封装（快捷方法，适配JSON提交）
 * @param {string} url - 请求 URL
 * @param {Object} data - 请求体数据
 * @param {Object} headers - 自定义请求头
 * @returns {Promise} 请求结果Promise
 */
export const apiPost = (url, data = {}, headers = {}) => {
  const validData = typeof data === 'object' && data !== null ? data : {}
  const validHeaders = typeof headers === 'object' && headers !== null ? headers : {}
  return apiRequest(url, { method: 'post', data: validData, headers: validHeaders })
}

// ==================== 业务工具函数（适配监控/告警/视频场景）====================
/**
 * 播放告警声音（全局单例，避免重复创建，适配监控告警）
 * @param {string} audioPath - 音频文件路径，默认/alert.mp3
 * @param {boolean} forceRestart - 是否强制重新播放（中断当前播放），默认true
 * @param {number} volume - 音量，0-1，默认0.8
 */
export const playAlertSound = (audioPath = ALERT_AUDIO_CONFIG.DEFAULT_PATH, forceRestart = true, volume = ALERT_AUDIO_CONFIG.VOLUME) => {
  try {
    // 入参校验
    if (typeof audioPath !== 'string') audioPath = ALERT_AUDIO_CONFIG.DEFAULT_PATH
    if (typeof forceRestart !== 'boolean') forceRestart = true
    if (typeof volume !== 'number' || volume < 0 || volume > 1) volume = ALERT_AUDIO_CONFIG.VOLUME

    // 处理音频路径：避免绝对路径重复拼接origin
    let audioFullPath = audioPath
    if (!audioPath.startsWith('http') && !audioPath.startsWith('blob')) {
      audioFullPath = new URL(audioPath, window.location.origin).href
    }

    // 复用实例，避免重复创建导致内存泄漏
    if (!alertAudioInstance || alertAudioInstance.src !== audioFullPath) {
      // 销毁旧实例，彻底释放内存
      if (alertAudioInstance) {
        alertAudioInstance.pause()
        alertAudioInstance = null
      }
      alertAudioInstance = new Audio(audioFullPath)
      alertAudioInstance.preload = 'auto' // 预加载音频
      alertAudioInstance.volume = volume // 设置音量
    }

    // 强制重新播放：中断当前播放，重置进度
    if (forceRestart) {
      alertAudioInstance.pause()
      alertAudioInstance.currentTime = 0
    }

    // 播放音频，捕获浏览器自动播放策略限制（需用户交互）
    alertAudioInstance.play().catch(err => {
      console.warn("播放告警声音失败：浏览器自动播放策略限制，需用户交互后播放", err)
      showWarning('告警声音播放失败，请先点击页面任意位置')
    })
  } catch (err) {
    console.warn("播放告警声音初始化失败：", err)
    showError('告警声音初始化失败')
  }
}

/**
 * 停止告警声音播放
 * @param {boolean} destroy - 是否销毁音频实例（彻底释放内存），默认false
 */
export const stopAlertSound = (destroy = false) => {
  try {
    if (alertAudioInstance) {
      alertAudioInstance.pause()
      alertAudioInstance.currentTime = 0
      // 销毁实例，彻底释放内存（如页面卸载/退出监控场景）
      if (destroy) {
        alertAudioInstance = null
      }
    }
  } catch (err) {
    console.warn("停止告警声音失败：", err)
  }
}

/**
 * 全屏切换（适配视频监控全屏展示，兼容所有浏览器）
 * @param {HTMLElement} element - 目标元素，默认 document.documentElement
 * @returns {Promise<boolean>} 是否进入全屏：true=进入，false=退出，异常返回false
 */
export const toggleFullscreen = async (element = document.documentElement) => {
  try {
    // 入参校验：确保是DOM元素
    if (!(element instanceof HTMLElement)) {
      console.warn('toggleFullscreen: 目标元素必须是HTMLElement，使用默认根元素')
      element = document.documentElement
    }

    // 浏览器兼容性前缀适配
    const requestFullscreen = element.requestFullscreen || element.webkitRequestFullscreen || element.mozRequestFullScreen || element.msRequestFullscreen
    const exitFullscreen = document.exitFullscreen || document.webkitExitFullscreen || document.mozCancelFullScreen || document.msExitFullscreen
    const fullscreenElement = document.fullscreenElement || document.webkitFullscreenElement || document.mozFullScreenElement || document.msFullscreenElement

    if (!fullscreenElement) {
      if (!requestFullscreen) {
        throw new Error('当前浏览器不支持全屏API')
      }
      await requestFullscreen.call(element)
      showSuccess("已切换至全屏模式")
      return true
    } else {
      if (!exitFullscreen) {
        throw new Error('当前浏览器不支持退出全屏API')
      }
      await exitFullscreen.call(document)
      showInfo("已退出全屏模式")
      return false
    }
  } catch (err) {
    console.error("全屏切换失败：", err)
    showError("全屏切换失败：" + err.message)
    return false
  }
}

// ==================== 性能优化工具函数（防抖节流，适配高频操作）====================
/**
 * 防抖函数（适配搜索/按钮点击等高频操作）
 * @param {Function} func - 需要防抖的函数
 * @param {number} wait - 等待时间（毫秒），默认300ms
 * @param {boolean} immediate - 是否立即执行（首次触发立即执行），默认false
 * @returns {Function} 防抖后的函数，附带cancel取消方法
 * @throws {TypeError} 当func不是函数时抛出错误
 */
export const debounce = function (func, wait = DEBOUNCE_THROTTLE_CONFIG.DEFAULT_WAIT, immediate = false) {
  // 入参严格校验
  if (typeof func !== 'function') {
    throw new TypeError('debounce: 第一个参数必须是函数')
  }
  if (typeof wait !== 'number' || wait < 0 || !isFinite(wait)) {
    console.warn('debounce: 无效的等待时间，使用默认值300ms', wait)
    wait = DEBOUNCE_THROTTLE_CONFIG.DEFAULT_WAIT
  }
  if (typeof immediate !== 'boolean') immediate = false

  let timeout = null
  let isExecuted = false

  // 防抖核心逻辑，保留this和参数
  const debounced = function (...args) {
    const context = this
    // 清除已有定时器
    if (timeout) clearTimeout(timeout)

    // 立即执行模式
    if (immediate && !isExecuted) {
      func.apply(context, args)
      isExecuted = true
      return
    }

    // 延迟执行模式
    timeout = setTimeout(() => {
      func.apply(context, args)
      isExecuted = false
      timeout = null
    }, wait)
  }

  // 新增取消方法，清除定时器，避免内存泄漏
  debounced.cancel = function () {
    if (timeout) {
      clearTimeout(timeout)
      timeout = null
      isExecuted = false
    }
  }

  return debounced
}

/**
 * 节流函数（适配滚动/resize/视频帧刷新等高频操作）
 * @param {Function} func - 需要节流的函数
 * @param {number} delay - 延迟时间（毫秒），默认300ms
 * @param {object} options - 配置项 { leading: 首次是否执行, trailing: 结束后是否执行 }，默认{leading: true, trailing: false}
 * @returns {Function} 节流后的函数，附带cancel取消方法
 * @throws {TypeError} 当func不是函数时抛出错误
 */
export const throttle = function (func, delay = DEBOUNCE_THROTTLE_CONFIG.DEFAULT_DELAY, options = { leading: true, trailing: false }) {
  // 入参严格校验
  if (typeof func !== 'function') {
    throw new TypeError('throttle: 第一个参数必须是函数')
  }
  if (typeof delay !== 'number' || delay < 0 || !isFinite(delay)) {
    console.warn('throttle: 无效的延迟时间，使用默认值300ms', delay)
    delay = DEBOUNCE_THROTTLE_CONFIG.DEFAULT_DELAY
  }
  const validOptions = typeof options === 'object' && options !== null ? options : {}
  const leading = typeof validOptions.leading === 'boolean' ? validOptions.leading : true
  const trailing = typeof validOptions.trailing === 'boolean' ? validOptions.trailing : false

  let lastTime = 0
  let timeout = null

  // 节流核心逻辑，保留this和参数
  const throttled = function (...args) {
    const context = this
    const now = Date.now()

    // 首次执行控制
    if (!leading && lastTime === 0) {
      lastTime = now
    }

    const remaining = delay - (now - lastTime)
    // 到达执行时间
    if (remaining <= 0) {
      if (timeout) {
        clearTimeout(timeout)
        timeout = null
      }
      func.apply(context, args)
      lastTime = now
    }
    // 尾部执行控制
    else if (trailing && !timeout) {
      timeout = setTimeout(() => {
        func.apply(context, args)
        lastTime = Date.now()
        timeout = null
      }, remaining)
    }
  }

  // 新增取消方法，清除定时器，避免内存泄漏
  throttled.cancel = function () {
    if (timeout) {
      clearTimeout(timeout)
      timeout = null
    }
    lastTime = 0
  }

  return throttled
}

// ==================== 工具函数复用组件化改造（工厂类，按需导入）====================
/**
 * 工具函数工厂类 - 提取常用工具函数为独立模块，便于按需导入和维护
 * 适配Vue3组件按需使用，减少全局导入体积
 */
export class UtilsFactory {
  /**
   * 创建防抖函数实例
   * @param {Function} func - 需要防抖的函数
   * @param {number} wait - 等待时间（毫秒）
   * @param {boolean} immediate - 是否立即执行
   * @returns {Function} 防抖后的函数实例
   */
  static createDebounce(func, wait = DEBOUNCE_THROTTLE_CONFIG.DEFAULT_WAIT, immediate = false) {
    return debounce(func, wait, immediate)
  }

  /**
   * 创建节流函数实例
   * @param {Function} func - 需要节流的函数
   * @param {number} delay - 延迟时间（毫秒）
   * @param {object} options - 配置项 { leading: 首次是否执行, trailing: 结束后是否执行 }
   * @returns {Function} 节流后的函数实例
   */
  static createThrottle(func, delay = DEBOUNCE_THROTTLE_CONFIG.DEFAULT_DELAY, options = { leading: true, trailing: false }) {
    return throttle(func, delay, options)
  }

  /**
   * 创建消息提示工具实例（仅包含消息提示方法）
   * @returns {Object} 包含success/error/warning/info的消息提示对象
   */
  static createMessageUtils() {
    return {
      success: showSuccess,
      error: showError,
      warning: showWarning,
      info: showInfo
    }
  }

  /**
   * 创建API请求工具实例（仅包含网络请求方法）
   * @returns {Object} 包含get/post/request的API请求对象
   */
  static createApiUtils() {
    return {
      get: apiGet,
      post: apiPost,
      request: apiRequest
    }
  }

  /**
   * 创建监控业务工具实例（仅包含监控/告警相关方法）
   * @returns {Object} 包含播放/停止告警、全屏、获取颜色/风险的业务工具对象
   */
  static createMonitorUtils() {
    return {
      playAlertSound,
      stopAlertSound,
      toggleFullscreen,
      getBoxColor,
      getRiskTagType,
      getRiskText
    }
  }

  /**
   * 创建时间格式化工具实例（仅包含时间处理方法）
   * @returns {Object} 包含formatTime/formatSeconds的时间工具对象
   */
  static createTimeUtils() {
    return {
      formatTime,
      formatSeconds
    }
  }
}

// ==================== LLM大模型相关API封装 ====================
/**
 * 测试LLM连接状态
 * @returns {Promise} LLM连接测试结果
 */
export const testLLMConnection = () => {
  return apiGet('/api/llm/test')
}

/**
 * 获取LLM配置信息
 * @returns {Promise} LLM配置信息
 */
export const getLLMConfig = () => {
  return apiGet('/api/llm/config')
}

/**
 * 分析溺水事件
 * @param {Object} eventData - 事件数据
 * @returns {Promise} 分析结果
 */
export const analyzeDrowningEvent = (eventData) => {
  return apiPost('/api/llm/analyze', eventData)
}

/**
 * 生成预警消息
 * @param {Object} eventData - 事件数据
 * @returns {Promise} 预警消息
 */
export const generateAlertMessage = (eventData) => {
  return apiPost('/api/llm/generate-alert', eventData)
}

/**
 * 智能问答
 * @param {string} question - 用户问题
 * @param {string} context - 上下文信息（可选）
 * @returns {Promise} 回答结果
 */
export const askQuestion = (question, context = {}) => {
  return apiPost('/api/llm/ask', { question, context })
}

/**
 * LLM聊天问答（askQuestion的别名，用于统一命名）
 * @param {string} question - 用户问题
 * @param {string} context - 上下文信息（可选）
 * @returns {Promise} 回答结果
 */
export const askLLMQuestion = askQuestion

// 导出apiClient实例，供其他模块使用
export { apiClient }
