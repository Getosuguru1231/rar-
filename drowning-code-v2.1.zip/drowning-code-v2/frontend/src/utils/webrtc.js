export const ICE_SERVERS = [
  { urls: 'stun:stun.l.google.com:19302' },
  { urls: 'stun:stun1.l.google.com:19302' },
  { urls: 'stun:stun2.l.google.com:19302' },
  { urls: 'stun:stun3.l.google.com:19302' },
  { urls: 'stun:stun4.l.google.com:19302' },
  { urls: 'stun:stun.services.mozilla.com:3478' },
  { urls: 'stun:stunserver.org:3478' },
  { urls: 'stun:stun.ekiga.net:3478' },
  { urls: 'stun:stun.ideasip.com:3478' },
  { urls: 'stun:stun.stunprotocol.org:3478' },
  { urls: 'stun:stun.voxgratia.org:3478' }
]

export const TURN_SERVERS = [
  {
    urls: 'turn:turn.openrelay.metered.ca:80',
    username: 'openrelayproject',
    credential: 'openrelayproject'
  },
  {
    urls: 'turn:turn.openrelay.metered.ca:443',
    username: 'openrelayproject',
    credential: 'openrelayproject'
  }
]

export const getIceServers = () => {
  const servers = [...ICE_SERVERS]
  
  const turnUrl = import.meta.env.VITE_WEBRTC_TURN_URL
  const turnUsername = import.meta.env.VITE_WEBRTC_TURN_USERNAME
  const turnCredential = import.meta.env.VITE_WEBRTC_TURN_CREDENTIAL
  
  if (turnUrl) {
    servers.push({
      urls: turnUrl,
      username: turnUsername || 'webrtc',
      credential: turnCredential || 'webrtc123'
    })
    console.log('[WebRTC] TURN服务器已配置:', turnUrl)
  }
  
  return servers
}

export const DEFAULT_CONFIG = {
  iceServers: getIceServers(),
  iceCandidatePoolSize: 3,
  bundlePolicy: 'max-bundle',
  rtcpMuxPolicy: 'require',
  sdpSemantics: 'unified-plan',
  iceTransportPolicy: 'all',
  iceMinPriority: 1,
  iceMaxPriority: 65535,
  rtcpFeedback: [
    { type: 'nack' },
    { type: 'nack', parameter: 'pli' },
    { type: 'transport-cc' }
  ],
  peerIdentity: null
}

export const SIGNALING_MESSAGE_TYPES = {
  OFFER: 'offer',
  ANSWER: 'answer',
  ICE_CANDIDATE: 'ice_candidate',
  ERROR: 'error',
  PING: 'ping',
  PONG: 'pong',
  CLOSE: 'close'
}

export class SignalingMessage {
  constructor(type, data = {}) {
    this.type = type
    this.data = data
  }

  static offer(sdp, sdpSemantics = 'unified-plan') {
    return new SignalingMessage(SIGNALING_MESSAGE_TYPES.OFFER, {
      sdp,
      sdp_semantics: sdpSemantics
    })
  }

  static answer(sdp) {
    return new SignalingMessage(SIGNALING_MESSAGE_TYPES.ANSWER, { sdp })
  }

  static iceCandidate(candidate) {
    return new SignalingMessage(SIGNALING_MESSAGE_TYPES.ICE_CANDIDATE, { candidate })
  }

  static error(message) {
    return new SignalingMessage(SIGNALING_MESSAGE_TYPES.ERROR, { message })
  }

  static ping() {
    return new SignalingMessage(SIGNALING_MESSAGE_TYPES.PING)
  }

  static pong() {
    return new SignalingMessage(SIGNALING_MESSAGE_TYPES.PONG)
  }

  static close() {
    return new SignalingMessage(SIGNALING_MESSAGE_TYPES.CLOSE)
  }

  toJSON() {
    return {
      type: this.type,
      ...this.data
    }
  }

  static fromJSON(jsonString) {
    const data = JSON.parse(jsonString)
    return new SignalingMessage(data.type, data)
  }
}

export function createPeerConnection(config = {}) {
  const pcConfig = { ...DEFAULT_CONFIG, ...config }
  return new RTCPeerConnection(pcConfig)
}

export function createVideoElement(options = {}) {
  const video = document.createElement('video')
  video.autoplay = options.autoplay !== undefined ? options.autoplay : true
  video.playsInline = options.playsInline !== undefined ? options.playsInline : true
  video.muted = options.muted !== undefined ? options.muted : true
  video.width = options.width || 640
  video.height = options.height || 480
  
  if (options.objectFit) {
    video.style.objectFit = options.objectFit
  }
  
  return video
}

export async function getDisplayMedia(options = {}) {
  const constraints = {
    video: {
      width: { ideal: 1920 },
      height: { ideal: 1080 },
      frameRate: { ideal: 30 }
    },
    audio: options.audio !== undefined ? options.audio : false,
    ...options
  }
  
  try {
    const stream = await navigator.mediaDevices.getDisplayMedia(constraints)
    return stream
  } catch (error) {
    console.error('[WebRTC] 获取屏幕共享失败:', error)
    throw error
  }
}

export async function getUserMedia(options = {}) {
  const constraints = {
    video: {
      width: { ideal: 640 },
      height: { ideal: 480 },
      frameRate: { ideal: 15 }
    },
    audio: options.audio !== undefined ? options.audio : false,
    ...options
  }
  
  try {
    const stream = await navigator.mediaDevices.getUserMedia(constraints)
    return stream
  } catch (error) {
    console.error('[WebRTC] 获取摄像头失败:', error)
    throw error
  }
}

export function attachStreamToVideo(stream, videoElement) {
  if (!stream || !videoElement) {
    console.warn('[WebRTC] 无法附加流: 流或视频元素为空')
    return
  }
  
  try {
    videoElement.srcObject = stream
    console.log('[WebRTC] 流已附加到视频元素')
  } catch (error) {
    console.error('[WebRTC] 附加流失败:', error)
    throw error
  }
}

export function detachStreamFromVideo(videoElement) {
  if (videoElement) {
    videoElement.srcObject = null
    console.log('[WebRTC] 流已从视频元素分离')
  }
}

export function getConnectionStats(pc) {
  return new Promise((resolve) => {
    if (!pc || pc.connectionState === 'closed') {
      resolve({})
      return
    }
    
    pc.getStats().then((stats) => {
      const result = {}
      stats.forEach((report) => {
        result[report.type] = report
      })
      resolve(result)
    }).catch((error) => {
      console.error('[WebRTC] 获取统计信息失败:', error)
      resolve({})
    })
  })
}

export function formatStats(stats) {
  const formatted = {
    connection: {
      state: 'unknown',
      iceState: 'unknown'
    },
    video: {
      fps: 0,
      bitrate: 0,
      packetsLost: 0
    },
    audio: {
      bitrate: 0,
      packetsLost: 0
    }
  }
  
  for (const [key, value] of Object.entries(stats)) {
    if (value.type === 'inbound-rtp' && value.kind === 'video') {
      formatted.video.fps = Math.round(value.framesPerSecond || 0)
      formatted.video.bitrate = Math.round((value.bytesReceived || 0) * 8 / 1000)
      formatted.video.packetsLost = value.packetsLost || 0
    } else if (value.type === 'inbound-rtp' && value.kind === 'audio') {
      formatted.audio.bitrate = Math.round((value.bytesReceived || 0) * 8 / 1000)
      formatted.audio.packetsLost = value.packetsLost || 0
    }
  }
  
  return formatted
}

export function generatePeerId() {
  return 'peer_' + Math.random().toString(36).substring(2, 15) + Date.now().toString(36)
}

export function getReconnectDelay(attempt, baseDelay = 1000, maxDelay = 30000) {
  return Math.min(baseDelay * Math.pow(2, attempt), maxDelay)
}

export function logConnectionState(pc) {
  if (!pc) return
  
  console.log('[WebRTC] 连接状态:', {
    connectionState: pc.connectionState,
    iceConnectionState: pc.iceConnectionState,
    iceGatheringState: pc.iceGatheringState,
    signalingState: pc.signalingState
  })
}

export function setLowLatencySDP(sdp) {
  let modifiedSDP = sdp
  
  const lines = modifiedSDP.split('\r\n')
  const result = []
  
  let videoLineIndex = -1
  let hasH264 = false
  
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i]
    
    if (line.startsWith('a=rtpmap:') && line.includes('H264')) {
      hasH264 = true
    }
    
    if (line.startsWith('m=video')) {
      videoLineIndex = i
    }
    
    result.push(line)
  }
  
  if (videoLineIndex >= 0) {
    result.splice(videoLineIndex + 1, 0, 'a=rtcp-fb:* nack')
    result.splice(videoLineIndex + 2, 0, 'a=rtcp-fb:* nack pli')
    result.splice(videoLineIndex + 3, 0, 'a=rtcp-fb:* transport-cc')
    // 不硬编码extmap ID，让浏览器自动分配，避免冲突
  }
  
  for (let i = 0; i < result.length; i++) {
    if (result[i].includes('fmtp:') && result[i].includes('H264')) {
      let fmtpLine = result[i]
      if (!fmtpLine.includes('profile-level-id')) {
        fmtpLine += ';profile-level-id=42e01f'
      }
      if (!fmtpLine.includes('packetization-mode')) {
        fmtpLine += ';packetization-mode=1'
      }
      if (!fmtpLine.includes('max-fps')) {
        fmtpLine += ';max-fps=30'
      }
      if (!fmtpLine.includes('min-fps')) {
        fmtpLine += ';min-fps=5'
      }
      result[i] = fmtpLine
    }
  }
  
  modifiedSDP = result.join('\r\n')
  
  return modifiedSDP
}

export function validateSDP(sdp) {
  if (!sdp || typeof sdp !== 'string') {
    return { valid: false, error: 'SDP为空或不是字符串' }
  }
  
  const lines = sdp.trim().split('\n')
  if (lines.length < 3) {
    return { valid: false, error: 'SDP格式无效' }
  }
  
  const hasSession = lines.some(line => line.startsWith('v='))
  const hasOrigin = lines.some(line => line.startsWith('o='))
  const hasMedia = lines.some(line => line.startsWith('m='))
  
  return {
    valid: hasSession && hasOrigin,
    hasVideo: lines.some(line => line.startsWith('m=video')),
    hasAudio: lines.some(line => line.startsWith('m=audio')),
    error: hasSession && hasOrigin ? null : '缺少必需的SDP字段'
  }
}