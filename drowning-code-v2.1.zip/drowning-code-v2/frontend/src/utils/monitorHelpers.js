import { API_CONSTANTS } from './index.js'

/**
 * 监控页面辅助工具函数
 */

/**
 * 获取风险等级文本
 */
export const getRiskText = (level) => {
  const riskMap = {
    high: '高风险',
    medium: '中风险',
    low: '低风险'
  }
  return riskMap[level] || '未知'
}

/**
 * 格式化时间戳或ISO字符串
 */
export const formatTime = (timestamp) => {
  let date
  if (typeof timestamp === 'number') {
    date = new Date(timestamp * 1000)
  } else {
    date = new Date(timestamp)
  }
  return date.toLocaleTimeString('zh-CN', { hour12: false })
}

/**
 * 格式化时长（秒转时分秒）
 */
export const formatDuration = (seconds) => {
  if (!seconds) return '0秒'
  
  const hours = Math.floor(seconds / 3600)
  const minutes = Math.floor((seconds % 3600) / 60)
  const secs = seconds % 60
  
  if (hours > 0) {
    return `${hours}小时${minutes}分${secs}秒`
  } else if (minutes > 0) {
    return `${minutes}分${secs}秒`
  } else {
    return `${secs}秒`
  }
}

/**
 * 格式化秒数为 HH:MM:SS 格式（适配监控录像时间轴）
 */
export const formatSeconds = (seconds) => {
  let numSeconds = Number(seconds)
  if (Number.isNaN(numSeconds) || numSeconds < 0 || !isFinite(numSeconds)) {
    return '00:00:00'
  }

  const totalSeconds = Math.floor(numSeconds)
  const h = Math.floor(totalSeconds / 3600)
    .toString()
    .padStart(2, '0')
  const m = Math.floor((totalSeconds % 3600) / 60)
    .toString()
    .padStart(2, '0')
  const s = (totalSeconds % 60)
    .toString()
    .padStart(2, '0')

  return `${h}:${m}:${s}`
}

/**
 * 获取视频流URL
 * 性能优化版本：平衡清晰度与传输速度
 * 
 * @param {number} cameraId - 摄像头ID
 * @param {string} quality - 视频质量 (ultra/high/medium/low)
 * @returns {string} 视频流URL
 */
export const getVideoStreamUrl = (cameraId, quality = 'high') => {
  const qualityParams = {
    ultra: { quality: 80, fps: 30 },   // 超高清，30fps
    high: { quality: 75, fps: 30 },     // 高清（默认），30fps
    medium: { quality: 70, fps: 25 },   // 标清，25fps
    low: { quality: 60, fps: 20 }       // 低清，20fps
  }
  
  const params = qualityParams[quality] || qualityParams.low
  const timestamp = Date.now()
  return `/api/video_feed?camera=${cameraId}&quality=${params.quality}&fps=${params.fps}&t=${timestamp}`
}

export const buildVideoStreamUrl = (options = {}) => {
  const { quality = 'high', fps = 30, camera = 1 } = options
  
  const qualityParams = {
    ultra: { quality: 80 },
    high: { quality: 75 },
    medium: { quality: 70 },
    low: { quality: 60 }
  }
  
  const params = qualityParams[quality] || qualityParams.low
  const timestamp = Date.now()
  return `/api/video_feed?camera=${camera}&quality=${params.quality}&fps=${fps}&t=${timestamp}`
}

/**
 * 构建溺水监测上下文信息
 */
export const buildDrowningContext = (cameras, alertList, totalPeopleCount) => {
  const alerts = Array.isArray(alertList) ? alertList : []
  const context = {
    current_time: new Date().toLocaleString('zh-CN'),
    total_cameras: cameras.length,
    active_alerts: alerts.filter(a => !a.acknowledged).length,
    total_people: totalPeopleCount,
    recent_alerts: alerts.slice(0, 5).map(alert => ({
      time: alert.time,
      camera: `摄像头${alert.cameraId}`,
      area: alert.area,
      level: alert.level,
      reason: alert.reason
    }))
  }
  
  return JSON.stringify(context, null, 2)
}

/**
 * 获取后端API的基础URL
 */
export const getBackendUrl = () => {
  // 使用相对路径，让Vite代理处理，避免CORS问题
  return ''
}

/**
 * 获取检测结果状态类型
 */
export const getStatusType = (status) => {
  const typeMap = {
    processing: 'warning',
    completed: 'success',
    failed: 'danger',
    pending: 'info'
  }
  return typeMap[status] || 'info'
}

/**
 * 获取检测结果状态文本
 */
export const getStatusText = (status) => {
  const textMap = {
    processing: '处理中',
    completed: '已完成',
    failed: '失败',
    pending: '等待中'
  }
  return textMap[status] || '未知'
}

/**
 * 获取相对时间文本
 */
export const getRelativeTime = (timestamp) => {
  if (!timestamp) return '未知'
  
  let date
  if (typeof timestamp === 'string') {
    date = new Date(timestamp)
  } else if (typeof timestamp === 'number') {
    date = new Date(timestamp * 1000)
  } else {
    date = new Date(timestamp)
  }
  
  const now = new Date()
  const diff = Math.floor((now - date) / 1000)
  
  if (diff < 60) {
    return '刚刚'
  } else if (diff < 3600) {
    const minutes = Math.floor(diff / 60)
    return `${minutes}分钟前`
  } else if (diff < 86400) {
    const hours = Math.floor(diff / 3600)
    return `${hours}小时前`
  } else {
    const days = Math.floor(diff / 86400)
    return `${days}天前`
  }
}
