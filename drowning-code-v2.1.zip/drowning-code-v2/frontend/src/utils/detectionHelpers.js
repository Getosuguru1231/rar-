/**
 * 检测相关的辅助函数
 * 用于处理视频检测、风险等级计算等功能
 */

/**
 * 格式化时间戳
 * @param {number} timestamp - 时间戳（秒）
 * @returns {string} 格式化后的时间字符串 (HH:MM:SS)
 */
export const formatTimestamp = (timestamp) => {
  if (!timestamp) return '00:00:00'
  const seconds = Math.floor(timestamp)
  const hours = Math.floor(seconds / 3600)
  const minutes = Math.floor((seconds % 3600) / 60)
  const secs = seconds % 60
  return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(secs).padStart(2, '0')}`
}

/**
 * 格式化持续时间
 * @param {number} frames - 帧数
 * @param {number} fps - 帧率，默认为30
 * @returns {string} 格式化后的时间字符串 (MM:SS)
 */
export const formatDuration = (frames, fps = 30) => {
  if (!frames || frames === 0) return '00:00'
  const seconds = Math.floor(frames / fps)
  const minutes = Math.floor(seconds / 60)
  const secs = seconds % 60
  return `${String(minutes).padStart(2, '0')}:${String(secs).padStart(2, '0')}`
}

/**
 * 格式化事件时间
 * @param {number} timestamp - 时间戳（秒）
 * @returns {string} 格式化后的时间字符串 (HH:MM:SS)
 */
export const formatEventTime = (timestamp) => {
  if (!timestamp) return ''
  return formatTimestamp(timestamp)
}

/**
 * 获取风险等级
 * @param {Array} detectedPersons - 检测到的人员列表
 * @returns {string} 风险等级 ('safe', 'medium', 'high')
 */
export const getRiskLevel = (detectedPersons) => {
  if (!detectedPersons || detectedPersons.length === 0) {
    return 'safe'
  }
  
  // 检查是否有高风险人员
  const hasHighRisk = detectedPersons.some(p => 
    p.risk_level === 'high' || p.confidence > 0.8
  )
  
  return hasHighRisk ? 'high' : 'medium'
}

/**
 * 获取风险等级文本
 * @param {string} level - 风险等级
 * @returns {string} 风险等级文本
 */
export const getRiskLevelText = (level) => {
  switch(level) {
    case 'high':
      return '高风险警告'
    case 'medium':
      return '中等风险'
    default:
      return '安全'
  }
}
