// frontend/src/utils/performance.js
/**
 * 前端性能优化工具
 * 包含防抖、节流、内存管理、视频流优化等
 */

/**
 * 防抖函数 - 适用于搜索、输入等场景
 * @param {Function} func - 要执行的函数
 * @param {number} delay - 延迟时间(ms)
 * @returns {Function}
 */
export function debounce(func, delay = 300) {
  let timer = null
  return function(...args) {
    if (timer) clearTimeout(timer)
    timer = setTimeout(() => {
      func.apply(this, args)
    }, delay)
  }
}

/**
 * 节流函数 - 适用于滚动、resize等高频事件
 * @param {Function} func - 要执行的函数
 * @param {number} interval - 间隔时间(ms)
 * @returns {Function}
 */
export function throttle(func, interval = 100) {
  let lastTime = 0
  return function(...args) {
    const now = Date.now()
    if (now - lastTime >= interval) {
      lastTime = now
      func.apply(this, args)
    }
  }
}

/**
 * 使用 requestAnimationFrame 的节流 - 适用于渲染相关操作
 * @param {Function} func - 要执行的函数
 * @returns {Function}
 */
export function rafThrottle(func) {
  let ticking = false
  return function(...args) {
    if (!ticking) {
      ticking = true
      requestAnimationFrame(() => {
        func.apply(this, args)
        ticking = false
      })
    }
  }
}

/**
 * 图片懒加载优化
 * @param {HTMLImageElement} img - 图片元素
 * @param {string} src - 图片地址
 */
export function lazyLoadImage(img, src) {
  if ('IntersectionObserver' in window) {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          img.src = src
          observer.unobserve(img)
        }
      })
    })
    observer.observe(img)
  } else {
    img.src = src
  }
}

/**
 * 视频流管理器 - 优化视频流的加载和渲染
 */
export class VideoStreamManager {
  constructor(options = {}) {
    this.maxBufferSize = options.maxBufferSize || 3
    this.targetFps = options.targetFps || 30
    this.frameBuffer = []
    this.isPlaying = false
    this.lastRenderTime = 0
    this.minRenderInterval = 1000 / this.targetFps
    this.stats = {
      totalFrames: 0,
      droppedFrames: 0,
      currentFps: 0
    }
    this.frameCount = 0
    this.lastFpsUpdate = Date.now()
  }

  /**
   * 添加帧到缓冲区
   * @param {string} frameData - 帧数据 (base64 或 URL)
   */
  addFrame(frameData) {
    this.stats.totalFrames++
    
    if (this.frameBuffer.length >= this.maxBufferSize) {
      this.frameBuffer.shift()
      this.stats.droppedFrames++
    }
    
    this.frameBuffer.push(frameData)
    
    if (!this.isPlaying) {
      this.processBuffer()
    }
  }

  /**
   * 处理缓冲区并渲染帧
   * @private
   */
  processBuffer() {
    if (this.frameBuffer.length === 0 || !this.isPlaying) return

    const now = Date.now()
    
    if (now - this.lastRenderTime < this.minRenderInterval) {
      this.stats.droppedFrames++
      requestAnimationFrame(() => this.processBuffer())
      return
    }

    const frameData = this.frameBuffer.shift()
    this.lastRenderTime = now
    this.frameCount++
    
    this.onFrameRender(frameData)
    
    if (now - this.lastFpsUpdate >= 1000) {
      this.stats.currentFps = this.frameCount
      this.frameCount = 0
      this.lastFpsUpdate = now
    }
    
    if (this.frameBuffer.length > 0) {
      requestAnimationFrame(() => this.processBuffer())
    } else {
      this.isPlaying = false
    }
  }

  /**
   * 开始处理视频流
   */
  start() {
    this.isPlaying = true
    if (this.frameBuffer.length > 0) {
      this.processBuffer()
    }
  }

  /**
   * 停止处理视频流
   */
  stop() {
    this.isPlaying = false
  }

  /**
   * 清空缓冲区
   */
  clear() {
    this.frameBuffer = []
  }

  /**
   * 设置目标 FPS
   * @param {number} fps - 目标帧率
   */
  setTargetFps(fps) {
    this.targetFps = fps
    this.minRenderInterval = 1000 / fps
  }

  /**
   * 帧渲染回调 - 需要被重写
   * @param {string} frameData - 帧数据
   */
  onFrameRender(frameData) {
    console.warn('VideoStreamManager: onFrameRender 未实现')
  }

  /**
   * 获取统计信息
   * @returns {Object} 统计信息
   */
  getStats() {
    return { ...this.stats }
  }

  /**
   * 销毁管理器
   */
  destroy() {
    this.stop()
    this.clear()
    this.onFrameRender = () => {}
  }
}

/**
 * 内存清理工具
 */
export class MemoryCleaner {
  constructor() {
    this.timers = []
    this.observers = []
    this.eventListeners = []
  }
  
  /**
   * 注册定时器以便清理
   */
  registerTimer(timerId) {
    this.timers.push(timerId)
    return timerId
  }
  
  /**
   * 注册观察器以便清理
   */
  registerObserver(observer) {
    this.observers.push(observer)
    return observer
  }
  
  /**
   * 注册事件监听器
   */
  registerEventListener(target, type, handler, options) {
    target.addEventListener(type, handler, options)
    this.eventListeners.push({ target, type, handler, options })
  }
  
  /**
   * 执行全面清理
   */
  cleanup() {
    this.timers.forEach(timer => {
      clearInterval(timer)
      clearTimeout(timer)
    })
    this.timers = []
    
    this.observers.forEach(observer => {
      try {
        observer.disconnect()
      } catch (e) {
        console.warn('断开观察器失败:', e)
      }
    })
    this.observers = []
    
    this.eventListeners.forEach(({ target, type, handler, options }) => {
      try {
        target.removeEventListener(type, handler, options)
      } catch (e) {
        console.warn('清理事件监听器失败:', e)
      }
    })
    this.eventListeners = []
    
    console.log('✅ 内存清理完成')
  }
}

/**
 * 数据缓存管理器 - 避免重复请求
 */
export class DataCache {
  constructor(ttl = 5000) {
    this.cache = new Map()
    this.ttl = ttl
  }
  
  get(key) {
    const item = this.cache.get(key)
    if (!item) return null
    
    if (Date.now() - item.timestamp > this.ttl) {
      this.cache.delete(key)
      return null
    }
    
    return item.data
  }
  
  set(key, data) {
    this.cache.set(key, {
      data,
      timestamp: Date.now()
    })
  }
  
  delete(key) {
    this.cache.delete(key)
  }
  
  clear() {
    this.cache.clear()
  }
}

/**
 * FPS 计算器
 */
export class FpsCounter {
  constructor() {
    this.frameCount = 0
    this.lastTime = Date.now()
    this.fps = 0
  }

  tick() {
    this.frameCount++
    const now = Date.now()
    if (now - this.lastTime >= 1000) {
      this.fps = this.frameCount
      this.frameCount = 0
      this.lastTime = now
      return this.fps
    }
    return null
  }

  reset() {
    this.frameCount = 0
    this.lastTime = Date.now()
    this.fps = 0
  }

  getFps() {
    return this.fps
  }
}

/**
 * 安全执行 requestIdleCallback，包含降级方案
 * @param {Function} callback - 回调函数
 * @param {Object} options - 选项
 */
export function safeRequestIdleCallback(callback, options = {}) {
  if ('requestIdleCallback' in window) {
    return requestIdleCallback(callback, options)
  }
  return setTimeout(callback, options.timeout || 50)
}

/**
 * 视频流刷新优化 - 避免频繁DOM操作
 * @param {Ref} videoImgs - 视频img元素ref数组
 * @param {Array} cameras - 摄像头数据
 */
export function optimizeVideoRefresh(videoImgs, cameras) {
  cameras.forEach((camera, index) => {
    const img = videoImgs.value?.[index]
    if (img && !camera.videoError) {
      if (!img.src || img.src === '') {
        img.src = `/api/video_feed?camera=${camera.id}`
        
        img.onload = () => {
          camera.videoLoaded = true
          camera.videoError = false
        }
        
        img.onerror = () => {
          camera.videoError = true
          camera.videoLoaded = false
        }
      }
    }
  })
}

export const apiCache = new DataCache(5000)
export const statsCache = new DataCache(10000)
export const globalMemoryCleaner = new MemoryCleaner()