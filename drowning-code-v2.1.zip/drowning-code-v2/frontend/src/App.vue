<!-- src/App.vue -->
<template>
  <router-view />
</template>

<script setup>
// 无需额外代码，仅渲染路由匹配的页面
</script>

<style>
/* 全局样式重置 */
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}
body {
  font-family: "Helvetica Neue", Helvetica, "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", Arial, sans-serif;
}
</style>