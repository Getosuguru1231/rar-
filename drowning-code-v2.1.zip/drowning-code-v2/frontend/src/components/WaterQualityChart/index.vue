<script setup>
import { ref, onMounted, onBeforeUnmount, computed } from 'vue'
import * as echarts from 'echarts'
import { addDataListener, getChartHistory, getDataByIdentifier, isHistoryLoaded } from '@/stores/deviceData'

const props = defineProps({
  title: { type: String, default: '水质监测' },
  unit: { type: String, default: '' },
  color: { type: String, default: '#64b4ff' },
  dataType: { type: String, default: 'PHValue' },
  yAxisMin: { type: Number, default: undefined },
  yAxisMax: { type: Number, default: undefined }
})

const chartRef = ref(null)
const loading = ref(true)
const latestValue = ref('--')
let myChart = null
let removeListener = null
let isDisposed = false
let resizeHandler = null

const gradientColor = computed(() => {
  const hex = props.color.replace('#', '')
  const r = parseInt(hex.substring(0, 2), 16)
  const g = parseInt(hex.substring(2, 4), 16)
  const b = parseInt(hex.substring(4, 6), 16)
  return {
    start: `rgba(${r}, ${g}, ${b}, 0.5)`,
    end: `rgba(${r}, ${g}, ${b}, 0.05)`
  }
})

const updateLatestValue = () => {
  // 获取 SSE 实时数据，而不是历史数据
  const realtime = getDataByIdentifier(props.dataType)
  if (realtime === null || isNaN(realtime)) {
    latestValue.value = '--'
    return
  }
  latestValue.value = realtime.toFixed(2)
}

const getTimeWindow = () => {
  const now = Date.now()
  // 显示最近 10 分钟，数据更聚焦
  return { min: now - 10 * 60 * 1000, max: now }
}

const computeYAxisRange = (data) => {
  // 如果外部传了固定值，优先使用
  if (props.yAxisMin !== undefined || props.yAxisMax !== undefined) {
    return { min: props.yAxisMin, max: props.yAxisMax }
  }
  if (!data || data.length < 2) return {}
  const values = data.map(d => d[1]).filter(v => typeof v === 'number' && !isNaN(v))
  if (values.length === 0) return {}

  const minVal = Math.min(...values)
  const maxVal = Math.max(...values)
  let padding = (maxVal - minVal) * 0.2
  if (padding === 0) padding = Math.abs(minVal) * 0.1 || 1

  return {
    min: Math.round((minVal - padding) * 100) / 100,
    max: Math.round((maxVal + padding) * 100) / 100
  }
}

onMounted(() => {
  resizeHandler = () => {
    if (myChart && !isDisposed) myChart.resize()
  }
  window.addEventListener('resize', resizeHandler)

  // 等待历史数据加载，最多等 5 秒防止无限阻塞
  const maxWait = 5000
  const startTime = Date.now()
  const timer = setInterval(() => {
    if (isDisposed) {
      clearInterval(timer)
      return
    }
    if (isHistoryLoaded() || Date.now() - startTime > maxWait) {
      clearInterval(timer)
      if (!isDisposed) initChart()
    }
  }, 100)
})

onBeforeUnmount(() => {
  isDisposed = true
  if (removeListener) removeListener()
  window.removeEventListener('resize', resizeHandler)
  if (myChart) {
    myChart.dispose()
    myChart = null
  }
})

const initChart = () => {
  if (!chartRef.value || isDisposed) return

  loading.value = false
  myChart = echarts.init(chartRef.value)

  const historyData = getChartHistory(props.dataType)
  // 判断是否为真实数据（fallback 是 [[Date.now(), 0]]）
  const hasRealData = !(historyData.length === 1 && historyData[0][1] === 0)
  updateLatestValue()

  const { min, max } = getTimeWindow()

  const option = {
    backgroundColor: 'transparent',
    title: {
      text: props.title,
      textStyle: { color: '#a8d5ff', fontSize: 13, fontWeight: 'normal' },
      left: 10,
      top: 8
    },
    grid: {
      left: 45,
      right: 20,
      top: 45,
      bottom: 25
    },
    tooltip: {
      trigger: 'axis',
      backgroundColor: 'rgba(15, 36, 71, 0.9)',
      borderColor: 'rgba(100, 180, 255, 0.3)',
      textStyle: { color: '#c4e3ff', fontSize: 12 },
      formatter: (params) => {
        if (!params?.length) return '暂无数据'
        const date = new Date(params[0].value[0])
        const timeStr = `${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}:${String(date.getSeconds()).padStart(2, '0')}`
        return `<div style="font-weight:bold;margin-bottom:4px">${timeStr}</div>
                <div>${props.title}: <span style="color:${props.color};font-weight:bold">${params[0].value[1]}</span> ${props.unit}</div>`
      },
      axisPointer: {
        type: 'line',
        lineStyle: { color: props.color, type: 'dashed', width: 1 }
      }
    },
    xAxis: {
      type: 'time',
      splitLine: { show: false },
      axisLine: { lineStyle: { color: 'rgba(168, 213, 255, 0.2)' } },
      axisLabel: {
        fontSize: 10,
        color: '#a8d5ff',
        formatter: (value) => {
          const date = new Date(value)
          return `${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`
        }
      },
      min,
      max
    },
    yAxis: {
      type: 'value',
      ...computeYAxisRange(historyData),
      splitLine: {
        show: true,
        lineStyle: { color: 'rgba(168, 213, 255, 0.08)' }
      },
      axisLine: { show: false },
      axisLabel: {
        fontSize: 10,
        color: '#a8d5ff'
      }
    },
    dataZoom: [
      {
        type: 'inside',
        start: 0,
        end: 100,
        minValueSpan: 1000
      }
    ],
    series: [{
      name: props.title,
      type: 'line',
      smooth: true,
      showSymbol: false,
      data: hasRealData ? historyData : [],
      lineStyle: { color: props.color, width: 2 },
      itemStyle: { color: props.color },
      areaStyle: {
        color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
          { offset: 0, color: gradientColor.value.start },
          { offset: 1, color: gradientColor.value.end }
        ])
      }
    }]
  }

  myChart.setOption(option)

  removeListener = addDataListener(() => {
    if (isDisposed || !myChart) return

    const data = getChartHistory(props.dataType)
    const empty = data.length === 1 && data[0][1] === 0
    updateLatestValue()

    const { min, max } = getTimeWindow()

    myChart.setOption({
      xAxis: { min, max },
      yAxis: { ...computeYAxisRange(data) },
      series: [{ data: empty ? [] : data }]
    })
  })
}
</script>

<template>
  <div class="chart-wrapper">
    <div v-if="loading" class="chart-loading">
      <span class="loading-dot"></span>
      加载中...
    </div>
    <div v-else class="current-value" :style="{ color: props.color }">
      {{ latestValue }}<span class="unit">{{ props.unit }}</span>
    </div>
    <div ref="chartRef" class="chart-container"></div>
  </div>
</template>

<style scoped>
.chart-wrapper {
  width: 100%;
  height: 100%;
  border-radius: 8px;
  background: rgba(255, 255, 255, 0.05);
  padding: 10px;
  box-sizing: border-box;
  position: relative;
}

.chart-container {
  width: 100%;
  height: 100%;
}

.chart-loading {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  color: #a8d5ff;
  font-size: 12px;
  z-index: 2;
  display: flex;
  align-items: center;
  gap: 6px;
}

.loading-dot {
  width: 6px;
  height: 6px;
  background: #64b4ff;
  border-radius: 50%;
  animation: pulse 1s infinite;
}

@keyframes pulse {
  0%, 100% { opacity: 1; transform: scale(1); }
  50% { opacity: 0.5; transform: scale(0.8); }
}

.current-value {
  position: absolute;
  top: 8px;
  right: 12px;
  font-size: clamp(16px, 1.3vw, 22px);
  font-weight: bold;
  z-index: 2;
  text-shadow: 0 0 10px rgba(0, 0, 0, 0.4);
  pointer-events: none;
}

.current-value .unit {
  font-size: clamp(10px, 0.85vw, 14px);
  font-weight: normal;
  margin-left: 3px;
  opacity: 0.7;
}
</style>
