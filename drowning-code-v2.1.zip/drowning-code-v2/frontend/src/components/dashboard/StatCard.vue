<template>
  <div class="card">
    <div class="card-header"><span class="card-title ai">AI 监测统计</span></div>
    <div class="stat-grid">
      <StatItem :value="patrols" label="今日AI巡检次数" type="ai" />
      <StatItem :value="warnings" label="今日预警次数" type="danger" />
      <StatItem :value="monitors" label="活跃监测点位" type="warning" />
      <StatItem :value="accuracy + '%'" label="AI识别准确率" type="safe" />
    </div>
    <div class="ai-status-row">
      <div class="ai-dot"></div>
      <span class="ai-status-text">AI模型版本 <strong>v3.2.1</strong> · 最后更新 2h前</span>
    </div>
  </div>
</template>

<script setup>
import StatItem from './StatItem.vue'

defineProps({
  patrols: { type: [String, Number], default: '0' },
  warnings: { type: [String, Number], default: 0 },
  monitors: { type: [String, Number], default: 0 },
  accuracy: { type: [String, Number], default: 0 }
})
</script>

<style scoped>
.card {
  background: linear-gradient(135deg, #FFFFFF 0%, #FAFBFC 100%);
  border-radius: 5px;
  padding: 16px 18px;
  box-shadow: 0 3px 12px rgba(0,0,0,0.06), 0 1px 3px rgba(0,0,0,0.04);
  border: 1px solid #E8ECF0;
  transition: transform 0.2s ease, box-shadow 0.2s ease;
}
.card:hover {
  transform: translateY(-2px);
  box-shadow: 0 6px 20px rgba(0,0,0,0.1), 0 2px 6px rgba(0,0,0,0.06);
}
.card-header {
  display: flex; align-items: center; justify-content: space-between;
  margin-bottom: 12px;
}
.card-title {
  font-size: 15px; font-weight: 700;
  color: #1A1A2E;
  position: relative;
  padding-left: 12px;
}
.card-title::before {
  content: '';
  position: absolute; left: 0; top: 2px; bottom: 2px;
  width: 3px; background: #2D3436;
  border-radius: 2px;
}
.stat-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }

.ai-status-row {
  display: flex; align-items: center; gap: 8px;
  margin-top: 8px; padding-top: 10px;
  border-top: 1px solid #ECF0F1;
}
.ai-dot {
  width: 10px; height: 10px; border-radius: 50%;
  background: linear-gradient(135deg, #00B894 0%, #00CEC9 100%);
  animation: livePulse 2s ease-in-out infinite;
  box-shadow: 0 0 8px rgba(0,184,148,0.4);
}
.ai-status-text { font-size: 12px; color: #636E72; }
.ai-status-text strong { color: #2D3436; }

@keyframes livePulse {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.6; }
}
</style>