<template>
  <div class="map-legend">
    <button 
      v-for="legend in legends" 
      :key="legend.key"
      :class="['map-legend-btn', legend.key, { active: selectedLegend === legend.key }]"
      @click="$emit('toggleLegend', legend.key)"
    >
      <span class="map-legend-dot"></span>
      <span class="map-legend-text">{{ legend.label }}</span>
      <span class="map-legend-count">{{ legend.count }}</span>
    </button>
  </div>
</template>

<script setup>
import { computed } from 'vue'

const props = defineProps({
  selectedLegend: { type: String, default: 'danger' },
  highRiskCount: { type: Number, default: 0 },
  midRiskCount: { type: Number, default: 0 },
  lowRiskCount: { type: Number, default: 0 },
  cameraCount: { type: Number, default: 0 }
})

defineEmits(['toggleLegend'])

const legends = computed(() => [
  { key: 'danger', label: '高危场所', count: props.highRiskCount },
  { key: 'warning', label: '中危场所', count: props.midRiskCount },
  { key: 'caution', label: '低危场所', count: props.lowRiskCount },
  { key: 'ai', label: 'AI摄像头', count: props.cameraCount }
])
</script>

<style scoped>
.map-legend {
  position: absolute; bottom: 20px; left: 24px;
  display: flex; gap: 12px; flex-wrap: wrap;
  background: linear-gradient(135deg, rgba(255,255,255,0.98) 0%, rgba(248,250,252,0.98) 100%);
  padding: 8px 16px; border-radius: 5px;
  box-shadow: 0 4px 16px rgba(0,0,0,0.1), 0 1px 4px rgba(0,0,0,0.06);
  font-size: 13px;
  z-index: 1000;
  border: 1px solid #E8ECF0;
}
.map-legend-btn {
  display: flex; align-items: center; gap: 6px;
  padding: 7px 14px;
  border-radius: 20px;
  border: 1.5px solid transparent;
  background: rgba(241,245,249,0.7);
  cursor: pointer;
  transition: all 0.25s ease;
  font-size: 12px;
  color: #636E72;
}
.map-legend-btn:hover {
  background: rgba(226,232,240,0.9);
  transform: translateY(-1px);
}
.map-legend-btn.danger .map-legend-dot { background: #D63031; }
.map-legend-btn.warning .map-legend-dot { background: #E17055; }
.map-legend-btn.caution .map-legend-dot { background: #FDCB6E; }
.map-legend-btn.ai .map-legend-dot { 
  background: #2D3436; 
  width: 12px; height: 12px;
  border-radius: 2px;
}
.map-legend-btn.danger.active {
  border-color: #D63031;
  background: rgba(214,48,49,0.12);
  color: #D63031;
  font-weight: 600;
}
.map-legend-btn.danger.active .map-legend-count {
  background: #D63031;
  color: #fff;
}
.map-legend-btn.warning.active {
  border-color: #E17055;
  background: rgba(225,112,85,0.12);
  color: #E17055;
  font-weight: 600;
}
.map-legend-btn.warning.active .map-legend-count {
  background: #E17055;
  color: #fff;
}
.map-legend-btn.caution.active {
  border-color: #FDCB6E;
  background: rgba(253,203,110,0.15);
  color: #2D3436;
  font-weight: 600;
}
.map-legend-btn.caution.active .map-legend-count {
  background: #FDCB6E;
  color: #2D3436;
}
.map-legend-btn.ai.active {
  border-color: #2D3436;
  background: rgba(45,52,54,0.12);
  color: #2D3436;
  font-weight: 600;
}
.map-legend-btn.ai.active .map-legend-count {
  background: #2D3436;
  color: #fff;
}
.map-legend-text { white-space: nowrap; }
.map-legend-count {
  min-width: 22px; height: 22px;
  display: flex; align-items: center; justify-content: center;
  background: #F1F5F9;
  border-radius: 50%;
  font-size: 11px;
  font-weight: 600;
  color: #9CA3A8;
}
.map-legend-dot {
  width: 10px; height: 10px; border-radius: 50%;
}
</style>