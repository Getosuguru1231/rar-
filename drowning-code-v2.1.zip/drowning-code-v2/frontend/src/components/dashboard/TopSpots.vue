<template>
  <div class="card">
    <div class="card-header"><span class="card-title">高危场所 TOP 5</span></div>
    <div class="top-spots-list">
      <TopSpotItem 
        v-for="s in spots" 
        :key="s.rank" 
        :rank="s.rank"
        :name="s.name"
        :score="s.score"
      />
    </div>
  </div>
</template>

<script setup>
import TopSpotItem from './TopSpotItem.vue'

defineProps({
  spots: { type: Array, default: () => [] }
})
</script>

<style scoped>
.card {
  background: linear-gradient(135deg, #FFFFFF 0%, #FAFBFC 100%);
  border-radius: 5px;
  padding: 16px 18px;
  box-shadow: 0 3px 12px rgba(0,0,0,0.06), 0 1px 3px rgba(0,0,0,0.04);
  border: 1px solid #E8ECF0;
  transition: transform 0.2s ease, box-shadow 0.2s ease;
}
.card:hover {
  transform: translateY(-2px);
  box-shadow: 0 6px 20px rgba(0,0,0,0.1), 0 2px 6px rgba(0,0,0,0.06);
}
.card-header {
  display: flex; align-items: center; justify-content: space-between;
  margin-bottom: 12px;
}
.card-title {
  font-size: 15px; font-weight: 700;
  color: #1A1A2E;
  position: relative;
  padding-left: 12px;
}
.card-title::before {
  content: '';
  position: absolute; left: 0; top: 2px; bottom: 2px;
  width: 3px; background: #D63031;
  border-radius: 2px;
}

.top-spots-list { font-size: 12px; color: #636E72; line-height: 2; }
</style>