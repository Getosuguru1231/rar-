<template>
  <div class="card">
    <div class="map-container" ref="mapContainerRef"></div>
    <MapLegend 
      :selected-legend="selectedLegend"
      :high-risk-count="highRiskCount"
      :mid-risk-count="midRiskCount"
      :low-risk-count="lowRiskCount"
      :camera-count="cameraCount"
      @toggle-legend="$emit('toggleLegend', $event)"
    />
    <MapInfoOverlay :count="focusCount" />
    <div class="map-zoom-hint" :class="{ visible: showZoomHint }">滚轮缩放查看详细市/镇/村边界</div>
  </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted, watch } from 'vue'
import L from 'leaflet'
import 'leaflet/dist/leaflet.css'
import MapLegend from './MapLegend.vue'
import MapInfoOverlay from './MapInfoOverlay.vue'

const props = defineProps({
  hazardPoints: { type: Array, default: () => [] },
  cameraPoints: { type: Array, default: () => [] },
  selectedLegend: { type: String, default: 'danger' },
  highRiskCount: { type: Number, default: 0 },
  midRiskCount: { type: Number, default: 0 },
  lowRiskCount: { type: Number, default: 0 },
  cameraCount: { type: Number, default: 0 },
  focusCount: { type: Number, default: 0 },
  showZoomHint: { type: Boolean, default: false }
})

defineEmits(['toggleLegend'])

const mapContainerRef = ref(null)
let map = null
let cameraMarkers = []

function initMap() {
  if (!mapContainerRef.value) return

  map = L.map(mapContainerRef.value, {
    center: [22.64, 110.18],
    zoom: 12,
    minZoom: 3,
    maxZoom: 18,
    zoomControl: true,
    attributionControl: false,
  })

  const tileProviders = [
    {
      name: '高德地图',
      url: 'https://webrd0{s}.is.autonavi.com/appmaptile?lang=zh_cn&size=1&scale=1&style=8&x={x}&y={y}&z={z}',
      options: { subdomains: '1234', maxZoom: 18, minZoom: 3 }
    },
    {
      name: 'GeoQ地图',
      url: 'https://map.geoq.cn/ArcGIS/rest/services/ChinaOnlineCommunity/MapServer/tile/{z}/{y}/{x}',
      options: { maxZoom: 18, minZoom: 3 }
    },
    {
      name: 'OpenStreetMap',
      url: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
      options: { maxZoom: 18, minZoom: 3 }
    },
    {
      name: 'CartoDB',
      url: 'https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}.png',
      options: { subdomains: 'abcd', maxZoom: 18, minZoom: 3 }
    },
  ]

  let currentProviderIndex = 0
  let tileLoadTimer = null

  function createOfflineBaseLayer() {
    return L.tileLayer('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI0MCIgaGVpZ2h0PSI0MCI+PHJlY3Qgd2lkdGg9IjQwIiBoZWlnaHQ9IjQwIiBmaWxsPSIjZmZmIiBmaWxsLW9wYWNpdHk9IjAuMDMiLz48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxwYXRoIGQ9Ik00MCAwSDJ2NDBoMzZWMHoiIGZpbGw9IiM4MjlBQ0MiIGZpbGwtb3BhY2l0eT0iMC4zIi8+PHBhdGggZD0iTTAgMzRoMzZWMGgydiMzNHoiIGZpbGw9IiM4MjlBQ0MiIGZpbGwtb3BhY2l0eT0iMC4zIi8+PC9nPjwvc3ZnPg==', {
      maxZoom: 18,
      minZoom: 0,
      attribution: '离线地图'
    })
  }

  function loadTileProvider(index) {
    if (index >= tileProviders.length) {
      console.warn('所有在线地图服务均加载失败，切换到离线地图')
      const offlineLayer = createOfflineBaseLayer()
      offlineLayer.addTo(map)
      return
    }

    const provider = tileProviders[index]
    const layer = L.tileLayer(provider.url, {
      ...provider.options,
      attribution: provider.name,
      className: `tile-layer-${index}`,
    })

    layer.on('tileerror', function () {
      if (tileLoadTimer) clearTimeout(tileLoadTimer)
      if (currentProviderIndex === index) {
        console.warn(`${provider.name} 瓦片加载失败，尝试备用方案 ${index + 1}/${tileProviders.length}`)
        map.removeLayer(layer)
        currentProviderIndex++
        loadTileProvider(currentProviderIndex)
      }
    })

    layer.on('load', function () {
      if (tileLoadTimer) clearTimeout(tileLoadTimer)
      console.log(`${provider.name} 瓦片加载成功`)
    })

    layer.addTo(map)

    tileLoadTimer = setTimeout(function () {
      if (currentProviderIndex === index) {
        console.warn(`${provider.name} 瓦片加载超时，尝试备用方案`)
        map.removeLayer(layer)
        currentProviderIndex++
        loadTileProvider(currentProviderIndex)
      }
    }, 5000)
  }

  loadTileProvider(currentProviderIndex)

  L.control.scale({ position: 'bottomright', metric: true, imperial: false }).addTo(map)
  renderMarkers()

  let focusTimer = setTimeout(() => {
    try {
      if (map && map.getContainer) {
        map.flyTo([22.64, 110.18], 12, { duration: 2.5, easeLinearity: 0.25 })
      }
    } catch (e) {
      console.error('[Map] flyTo 失败:', e)
    }
  }, 2000)

  map.on('zoomend', function () {
    const z = map.getZoom()
    if (z >= 10) {
      setTimeout(() => { }, 3000)
    }
    if (focusTimer) { clearTimeout(focusTimer); focusTimer = null }
  })

  setTimeout(() => map.invalidateSize(), 300)
}

function renderMarkers() {
  if (!map) return

  cameraMarkers.forEach(({ marker }) => {
    map.removeLayer(marker)
  })
  cameraMarkers = []

  const riskColors = { high: '#D63031', mid: '#E17055', low: '#FDCB6E' }

  props.hazardPoints.forEach(p => {
    const color = riskColors[p.risk]
    const marker = L.circleMarker([p.lat, p.lng], {
      radius: p.risk === 'high' ? 13 : p.risk === 'mid' ? 10 : 8,
      fillColor: color,
      color: '#fff',
      weight: 3,
      opacity: 1,
      fillOpacity: 0.95,
    })

    const riskText = p.risk === 'high' ? '高危' : p.risk === 'mid' ? '中危' : '低危'
    marker.bindTooltip(`<strong>${p.name}</strong><br><span style="font-size:11px;color:#636E72">${p.type} · ${riskText}</span>`, {
      direction: 'top', offset: [0, -(p.risk === 'high' ? 13 : 10)],
    })

    marker.bindPopup(`
      <strong style="font-size:14px">${p.name}</strong><br>
      <span style="color:${color};font-weight:600">风险等级：${riskText}</span><br>
      类型：${p.type}<br>
      ${p.detail}
    `)

    marker.addTo(map)

    if (p.risk === 'high') {
      L.circle([p.lat, p.lng], {
        radius: p.radius || 800,
        color: color,
        weight: 2,
        opacity: 0.5,
        fillColor: color,
        fillOpacity: 0.12,
        dashArray: '8, 10',
      }).addTo(map)

      L.circle([p.lat, p.lng], {
        radius: (p.radius || 800) * 0.6,
        color: color,
        weight: 1,
        opacity: 0.3,
        fillColor: color,
        fillOpacity: 0.06,
        dashArray: '4, 6',
      }).addTo(map)
    }
  })

  props.cameraPoints.forEach(c => {
    const statusColor = c.status === 'online' ? '#2D3436' : c.status === 'alert' ? '#E17055' : '#B2BEC3'
    const icon = L.divIcon({
      className: 'ai-cam-icon',
      html: `<div style="width:18px;height:18px;background:${statusColor};border:3px solid #fff;border-radius:3px;box-shadow:0 3px 8px rgba(0,0,0,0.4);transition:all 0.3s ease;display:flex;align-items:center;justify-content:center;"><span style="color:#fff;font-size:8px;font-weight:700;">AI</span></div>`,
      iconSize: [18, 18],
      iconAnchor: [9, 9],
    })
    const marker = L.marker([c.lat, c.lng], { icon }).addTo(map)
    const statusText = c.status === 'online' ? '在线' : c.status === 'alert' ? '⚠ 告警' : '离线'
    marker.bindTooltip(c.name, { direction: 'top', offset: [0, -12] })
    marker.bindPopup(`<strong>${c.name}</strong><br>状态：${statusText}`)
    cameraMarkers.push({ marker, point: c })
  })

  L.marker([23.8, 108.5], {
    icon: L.divIcon({
      className: 'guangxi-label',
      html: '<div style="font-size:14px;font-weight:700;color:#E17055;text-shadow:0 0 6px rgba(255,255,255,0.9);white-space:nowrap;letter-spacing:4px">广 西</div>',
      iconSize: [80, 24],
      iconAnchor: [40, 12],
    }),
    interactive: false,
  }).addTo(map)
}

watch(() => props.cameraPoints, () => {
  renderMarkers()
}, { deep: true })

function handleResize() {
  if (map) setTimeout(() => map.invalidateSize(), 100)
}

onMounted(() => {
  initMap()
  window.addEventListener('resize', handleResize)
})

onUnmounted(() => {
  if (map) map.remove()
  cameraMarkers = []
  window.removeEventListener('resize', handleResize)
})
</script>

<style scoped>
.card {
  width: 100%; height: 100%;
  padding: 0;
  position: relative;
  overflow: hidden;
  background: linear-gradient(135deg, #FFFFFF 0%, #FAFBFC 100%);
  border-radius: 5px;
  box-shadow: 0 3px 12px rgba(0,0,0,0.06), 0 1px 3px rgba(0,0,0,0.04);
  border: 1px solid #E8ECF0;
}
.map-container {
  width: 100%; height: 100%;
}
.map-container :deep(.leaflet-control-zoom) {
  top: 12px; right: 12px;
}
.map-container :deep(.leaflet-control-zoom a) {
  border-radius: 3px !important;
  color: #1A1A2E !important;
}

.map-zoom-hint {
  position: absolute; top: 60px; right: 20px;
  background: rgba(45,52,54,0.88);
  color: #fff;
  padding: 6px 12px; border-radius: 99px;
  font-size: 11px;
  z-index: 1000;
  pointer-events: none;
  opacity: 0;
  transition: opacity 0.5s;
}
.map-zoom-hint.visible { opacity: 1; }

:deep(.leaflet-popup-content-wrapper) {
  border-radius: 3px !important;
  box-shadow: 0 4px 16px rgba(0,0,0,0.08) !important;
  font-family: "Microsoft YaHei", "PingFang SC", "Noto Sans SC", "Helvetica Neue", sans-serif !important;
}
:deep(.leaflet-popup-content) { font-size: 13px; line-height: 1.7; margin: 10px 14px !important; }
:deep(.leaflet-popup-content strong) { color: #1A1A2E; font-size: 14px; }
</style>