<template>
  <div :class="['warning-item', `level-${level}`]">
    <div class="warning-time">{{ time }}</div>
    <div class="warning-content">
      <div class="warning-location">
        <span v-if="ai" class="warning-tag ai">AI</span>
        <span v-if="level === 'high'" class="warning-tag high">高危</span>
        {{ location }}
      </div>
      <div class="warning-detail">{{ detail }}</div>
    </div>
  </div>
</template>

<script setup>
defineProps({
  time: { type: String, default: '' },
  location: { type: String, default: '' },
  detail: { type: String, default: '' },
  level: { type: String, default: 'low' },
  ai: { type: Boolean, default: false }
})
</script>

<style scoped>
.warning-item {
  display: flex; gap: 12px;
  padding: 12px 14px;
  border-radius: 5px;
  border-left: 4px solid transparent;
  background: #F8FAFC;
  font-size: 13px;
  line-height: 1.5;
  transition: all 0.3s ease;
  border: 1px solid #E2E8F0;
}
.warning-item:hover {
  transform: translateX(4px);
}
.warning-item.level-high { 
  border-left-color: #D63031; 
  background: linear-gradient(135deg, #FFF5F5 0%, #FFEEEE 100%); 
  border-color: #FFE4E6;
}
.warning-item.level-mid { 
  border-left-color: #E17055; 
  background: linear-gradient(135deg, #FFF8F0 0%, #FFFAF0 100%); 
  border-color: #FFECC9;
}
.warning-item.level-low { 
  border-left-color: #FDCB6E; 
  background: linear-gradient(135deg, #FFFDEB 0%, #FFFBEB 100%); 
  border-color: #FEF3C7;
}
.warning-time {
  font-family: "SF Mono", "DIN", "Consolas", "Courier New", monospace;
  font-size: 11px; color: #9CA3A8;
  white-space: nowrap;
  min-width: 44px;
}
.warning-content { flex: 1; }
.warning-location { font-weight: 600; color: #1A1A2E; }
.warning-detail { color: #636E72; font-size: 12px; margin-top: 2px; }
.warning-tag {
  display: inline-block;
  font-size: 10px; font-weight: 700;
  padding: 2px 8px; border-radius: 99px;
  letter-spacing: 0.5px;
  margin-right: 4px;
}
.warning-tag.ai { 
  background: linear-gradient(135deg, #2D3436 0%, #4A5568 100%); 
  color: #fff; 
}
.warning-tag.high { 
  background: linear-gradient(135deg, #D63031 0%, #E74C3C 100%); 
  color: #fff; 
}
</style>