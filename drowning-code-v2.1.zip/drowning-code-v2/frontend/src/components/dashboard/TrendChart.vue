<template>
  <div class="card">
    <div class="card-header"><span class="card-title warn">近30天预警趋势</span></div>
    <div class="mini-chart" ref="chartRef"></div>
  </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted } from 'vue'
import * as echarts from 'echarts'

const chartRef = ref(null)
let chart = null

function initChart() {
  if (!chartRef.value) return
  
  chart = echarts.init(chartRef.value)
  const days = [], highVals = [], midVals = [], lowVals = []
  for (let i = 29; i >= 0; i--) {
    const d = new Date()
    d.setDate(d.getDate() - i)
    days.push((d.getMonth() + 1) + '/' + d.getDate())
    highVals.push(Math.floor(Math.random() * 4) + 1)
    midVals.push(Math.floor(Math.random() * 5) + 2)
    lowVals.push(Math.floor(Math.random() * 3) + 3)
  }
  chart.setOption({
    tooltip: { 
      trigger: 'axis',
      backgroundColor: 'rgba(255,255,255,0.95)',
      borderColor: '#E8ECF0',
      borderWidth: 1,
      textStyle: { color: '#1A1A2E' }
    },
    legend: { bottom: 0, left: 'center', textStyle: { fontSize: 10, color: '#636E72' }, itemWidth: 12, itemHeight: 6, data: ['高危', '中危', '低危'] },
    grid: { top: 10, right: 10, bottom: 30, left: 35 },
    xAxis: { type: 'category', data: days, axisLine: { lineStyle: { color: '#E2E8F0' } }, axisTick: { show: false }, axisLabel: { fontSize: 9, color: '#94A3B8', interval: 6 } },
    yAxis: { type: 'value', splitLine: { lineStyle: { color: '#F1F5F9', type: 'dashed' } }, axisLabel: { fontSize: 9, color: '#94A3B8' } },
    series: [
      { name: '高危', type: 'line', data: highVals, symbol: 'none', smooth: true, lineStyle: { color: { type: 'linear', x: 0, y: 0, x2: 1, y2: 0, colorStops: [{ offset: 0, color: '#D63031' }, { offset: 1, color: '#E74C3C' }] }, width: 2.5 }, areaStyle: { color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{ offset: 0, color: 'rgba(214,48,49,0.25)' }, { offset: 1, color: 'rgba(214,48,49,0)' }]) } },
      { name: '中危', type: 'line', data: midVals, symbol: 'none', smooth: true, lineStyle: { color: { type: 'linear', x: 0, y: 0, x2: 1, y2: 0, colorStops: [{ offset: 0, color: '#E17055' }, { offset: 1, color: '#F39C12' }] }, width: 2.5 }, areaStyle: { color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{ offset: 0, color: 'rgba(225,112,85,0.20)' }, { offset: 1, color: 'rgba(225,112,85,0)' }]) } },
      { name: '低危', type: 'line', data: lowVals, symbol: 'none', smooth: true, lineStyle: { color: { type: 'linear', x: 0, y: 0, x2: 1, y2: 0, colorStops: [{ offset: 0, color: '#FDCB6E' }, { offset: 1, color: '#F9CA24' }] }, width: 2.5 }, areaStyle: { color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{ offset: 0, color: 'rgba(253,203,110,0.20)' }, { offset: 1, color: 'rgba(253,203,110,0)' }]) } },
    ]
  })
}

function handleResize() {
  if (chart) chart.resize()
}

onMounted(() => {
  initChart()
  window.addEventListener('resize', handleResize)
})

onUnmounted(() => {
  if (chart) chart.dispose()
  window.removeEventListener('resize', handleResize)
})
</script>

<style scoped>
.card {
  background: linear-gradient(135deg, #FFFFFF 0%, #FAFBFC 100%);
  border-radius: 5px;
  padding: 16px 18px;
  box-shadow: 0 3px 12px rgba(0,0,0,0.06), 0 1px 3px rgba(0,0,0,0.04);
  border: 1px solid #E8ECF0;
  transition: transform 0.2s ease, box-shadow 0.2s ease;
}
.card:hover {
  transform: translateY(-2px);
  box-shadow: 0 6px 20px rgba(0,0,0,0.1), 0 2px 6px rgba(0,0,0,0.06);
}
.card-header {
  display: flex; align-items: center; justify-content: space-between;
  margin-bottom: 12px;
}
.card-title {
  font-size: 15px; font-weight: 700;
  color: #1A1A2E;
  position: relative;
  padding-left: 12px;
}
.card-title::before {
  content: '';
  position: absolute; left: 0; top: 2px; bottom: 2px;
  width: 3px; background: #D63031;
  border-radius: 2px;
}
.card-title.warn::before { background: #E17055; }
.mini-chart { width: 100%; height: 150px; background: #FAFBFC; border-radius: 3px; padding: 4px; }
</style>