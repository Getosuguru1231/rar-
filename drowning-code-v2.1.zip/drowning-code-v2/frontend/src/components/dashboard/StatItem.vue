<template>
  <div class="stat-item">
    <div :class="['stat-value', type]">{{ value }}</div>
    <div class="stat-label">{{ label }}</div>
  </div>
</template>

<script setup>
defineProps({
  value: { type: [String, Number], default: '0' },
  label: { type: String, default: '' },
  type: { type: String, default: 'default' }
})
</script>

<style scoped>
.stat-item {
  background: linear-gradient(135deg, #F8FAFC 0%, #F1F5F9 100%);
  border-radius: 5px;
  padding: 14px 12px;
  text-align: center;
  border: 1px solid #E2E8F0;
  transition: all 0.2s ease;
}
.stat-item:hover {
  background: linear-gradient(135deg, #FFFFFF 0%, #F8FAFC 100%);
  border-color: #CBD5E1;
  box-shadow: 0 2px 8px rgba(0,0,0,0.04);
}
.stat-value {
  font-family: "SF Mono", "DIN", "Consolas", "Courier New", monospace;
  font-size: 30px; font-weight: 800;
  line-height: 1.1;
  text-shadow: 0 1px 2px rgba(0,0,0,0.05);
}
.stat-value.danger { color: #D63031; text-shadow: 0 0 10px rgba(214,48,49,0.2); }
.stat-value.warning { color: #E17055; text-shadow: 0 0 10px rgba(225,112,85,0.2); }
.stat-value.safe { color: #00B894; text-shadow: 0 0 10px rgba(0,184,148,0.2); }
.stat-value.ai { color: #2D3436; }
.stat-value.default { color: #636E72; }
.stat-label { font-size: 12px; color: #9CA3A8; margin-top: 4px; }
</style>