<template>
  <span class="ticker-item">
    <span :class="['ticker-dot', level]"></span>
    {{ text }}
  </span>
</template>

<script setup>
defineProps({
  text: { type: String, default: '' },
  level: { type: String, default: 'normal' }
})
</script>

<style scoped>
.ticker-item {
  display: flex; align-items: center; gap: 8px;
  font-size: 13px; color: #BDC3C7;
}
.ticker-dot {
  width: 8px; height: 8px; border-radius: 50%;
}
.ticker-dot.high { background: #D63031; box-shadow: 0 0 6px rgba(214,48,49,0.6); }
.ticker-dot.mid { background: #E17055; box-shadow: 0 0 6px rgba(225,112,85,0.6); }
.ticker-dot.low { background: #FDCB6E; }
.ticker-dot.normal { background: #00B894; }
</style>