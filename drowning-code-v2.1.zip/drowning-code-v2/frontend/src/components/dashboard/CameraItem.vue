<template>
  <div class="camera-item">
    <span :class="['camera-indicator', status]"></span>
    <span class="camera-name">{{ name }}</span>
    <span :class="['camera-status', status]">{{ statusText }}</span>
  </div>
</template>

<script setup>
import { computed } from 'vue'

const props = defineProps({
  name: { type: String, default: '' },
  status: { type: String, default: 'offline' }
})

const statusText = computed(() => {
  const map = { online: '在线', alert: '告警', offline: '离线' }
  return map[props.status] || '未知'
})
</script>

<style scoped>
.camera-item {
  display: flex; align-items: center; gap: 10px;
  padding: 10px 12px;
  background: linear-gradient(135deg, #F8FAFC 0%, #F1F5F9 100%);
  border-radius: 5px;
  font-size: 12px;
  border: 1px solid #E2E8F0;
  transition: all 0.2s ease;
}
.camera-item:hover {
  background: #FFFFFF;
  box-shadow: 0 2px 8px rgba(0,0,0,0.04);
}
.camera-indicator {
  width: 10px; height: 10px; border-radius: 50%;
  flex-shrink: 0;
}
.camera-indicator.online { 
  background: linear-gradient(135deg, #00B894 0%, #00CEC9 100%); 
  box-shadow: 0 0 6px rgba(0,184,148,0.4);
}
.camera-indicator.alert { 
  background: linear-gradient(135deg, #E17055 0%, #F39C12 100%); 
  animation: livePulse 1.5s ease-in-out infinite; 
  box-shadow: 0 0 8px rgba(225,112,85,0.5);
}
.camera-indicator.offline { background: #B2BEC3; }
.camera-name { flex: 1; color: #636E72; }
.camera-status { font-weight: 600; font-size: 11px; }
.camera-status.online { color: #00B894; }
.camera-status.alert { color: #E17055; }
.camera-status.offline { color: #9CA3A8; }

@keyframes livePulse {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.6; }
}
</style>