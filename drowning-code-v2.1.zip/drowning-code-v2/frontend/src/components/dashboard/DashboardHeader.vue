<template>
  <header class="header">
    <div class="header-left">
      <button class="back-button" @click="$emit('goBack')">← 返回监控</button>
      <div class="header-emblem">防</div>
      <div>
        <div class="header-title">AI<span>溺水防控</span>监测系统</div>
      </div>
    </div>
    <div class="header-center">
      <span class="header-badge ai">AI 智能监测</span>
      <span class="header-badge live">● 系统运行中</span>
    </div>
    <div class="header-right">
      <div style="text-align:right">
        <div class="header-time">{{ headerTime }}</div>
        <div class="header-date">{{ headerDate }}</div>
      </div>
    </div>
  </header>
</template>

<script setup>
import { ref, onMounted, onUnmounted } from 'vue'

defineEmits(['goBack'])

const headerTime = ref('--:--:--')
const headerDate = ref('----年--月--日')
let clockInterval = null

function formatTime(d) {
  return d.toTimeString().slice(0, 8)
}

function formatDate(d) {
  const weekDays = ['日', '一', '二', '三', '四', '五', '六']
  return `${d.getFullYear()}年${(d.getMonth() + 1).toString().padStart(2, '0')}月${d.getDate().toString().padStart(2, '0')}日 星期${weekDays[d.getDay()]}`
}

function updateClock() {
  const now = new Date()
  headerTime.value = formatTime(now)
  headerDate.value = formatDate(now)
}

onMounted(() => {
  updateClock()
  clockInterval = setInterval(updateClock, 1000)
})

onUnmounted(() => {
  if (clockInterval) clearInterval(clockInterval)
})
</script>

<style scoped>
.header {
  grid-area: header;
  background: linear-gradient(135deg, #FFFFFF 0%, #FAFBFC 100%);
  border-bottom: 2px solid #E8ECF0;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 32px;
  z-index: 10;
  box-shadow: 0 2px 12px rgba(0,0,0,0.08);
}
.header-left { display: flex; align-items: center; gap: 16px; }
.back-button {
  padding: 8px 16px;
  background: linear-gradient(135deg, #636E72 0%, #747D8C 100%);
  color: white;
  border: none;
  border-radius: 5px;
  font-size: 13px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s ease;
  display: flex;
  align-items: center;
  gap: 6px;
  box-shadow: 0 2px 8px rgba(99,110,114,0.3);
}
.back-button:hover {
  background: linear-gradient(135deg, #747D8C 0%, #8395A7 100%);
  box-shadow: 0 4px 12px rgba(99,110,114,0.4);
  transform: translateY(-1px);
}
.back-button:active { transform: translateY(0); }
.header-emblem {
  width: 44px; height: 44px;
  background: linear-gradient(135deg, #D63031 0%, #E74C3C 100%);
  display: flex; align-items: center; justify-content: center;
  color: white; font-size: 22px; font-weight: 900;
  border-radius: 5px;
  box-shadow: 0 4px 12px rgba(214,48,49,0.3);
}
.header-title {
  font-size: 26px; font-weight: 700;
  letter-spacing: 2px;
  color: #1A1A2E;
}
.header-title span { color: #D63031; }
.header-center { display: flex; align-items: center; gap: 12px; }
.header-badge {
  font-size: 12px; font-weight: 700;
  padding: 4px 12px; border-radius: 99px;
  letter-spacing: 1px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.15);
}
.header-badge.ai { 
  background: linear-gradient(135deg, #2D3436 0%, #4A5568 100%); 
  color: #fff; 
}
.header-badge.live {
  background: linear-gradient(135deg, #00B894 0%, #00CEC9 100%); 
  color: #fff;
  animation: livePulse 2s ease-in-out infinite;
  box-shadow: 0 0 12px rgba(0,184,148,0.4);
}
@keyframes livePulse {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.6; }
}
.header-right {
  display: flex; align-items: center; gap: 24px;
  font-size: 14px; color: #636E72;
}
.header-time {
  font-family: "SF Mono", "DIN", "Consolas", "Courier New", monospace;
  font-size: 22px; font-weight: 600;
  color: #1A1A2E;
  letter-spacing: 1px;
}
.header-date { font-size: 13px; color: #9CA3A8; }
</style>