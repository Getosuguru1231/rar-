<template>
  <div class="ticker-bar">
    <span class="ticker-label">⚠ 实时告警</span>
    <div class="ticker-content">
      <div class="ticker-track" :class="{ animate: isAnimating }">
        <template v-for="(item, index) in displayItems" :key="index">
          <TickerItem :text="item.text" :level="item.level" />
        </template>
        <template v-for="(item, index) in displayItems" :key="'dup-' + index">
          <TickerItem :text="item.text" :level="item.level" />
        </template>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, watch, onMounted, onUnmounted } from 'vue'
import TickerItem from './TickerItem.vue'

const props = defineProps({
  items: { type: Array, default: () => [] }
})

const isAnimating = ref(true)

const displayItems = computed(() => {
  if (props.items.length === 0) {
    return [{ text: '系统运行正常，暂无告警信息', level: 'normal' }]
  }
  return props.items.map(item => ({
    text: `${item.location} · ${item.detail}`,
    level: item.level
  }))
})

let pauseTimer = null

watch(() => props.items.length, (newLen) => {
  if (newLen > 0) {
    isAnimating.value = true
  }
})

onMounted(() => {
  isAnimating.value = true
})

onUnmounted(() => {
  if (pauseTimer) clearTimeout(pauseTimer)
})
</script>

<style scoped>
.ticker-bar {
  grid-area: ticker;
  background: linear-gradient(135deg, #1A1A2E 0%, #2D3436 100%);
  display: flex; align-items: center; gap: 16px;
  padding: 8px 32px;
  overflow: hidden;
  position: relative;
  border-top: 1px solid rgba(255,255,255,0.1);
}
.ticker-label {
  font-size: 12px; font-weight: 700;
  color: #E17055;
  white-space: nowrap;
  flex-shrink: 0;
  padding-right: 16px;
  border-right: 1px solid rgba(255,255,255,0.2);
}
.ticker-content {
  flex: 1; overflow: hidden;
  position: relative;
}
.ticker-track {
  display: flex; align-items: center; gap: 40px;
  white-space: nowrap;
  animation: tickerScroll 40s linear infinite;
}
.ticker-track:hover {
  animation-play-state: paused;
}
@keyframes tickerScroll {
  0% { transform: translateX(0); }
  100% { transform: translateX(-50%); }
}
</style>