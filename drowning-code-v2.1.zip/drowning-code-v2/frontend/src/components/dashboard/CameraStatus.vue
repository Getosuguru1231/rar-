<template>
  <div class="card">
    <div class="card-header">
      <span class="card-title safe">AI摄像头状态</span>
      <span style="font-size:11px;color:#9CA3A8">在线率 <strong style="color:#00B894">{{ onlineRate }}</strong></span>
    </div>
    <div class="camera-grid">
      <CameraItem 
        v-for="(c, index) in cameras" 
        :key="index" 
        :name="c.name"
        :status="c.status"
      />
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import CameraItem from './CameraItem.vue'

const props = defineProps({
  cameras: { type: Array, default: () => [] }
})

const onlineRate = computed(() => {
  const onlineCount = props.cameras.filter(c => c.status !== 'offline').length
  return Math.round(onlineCount / props.cameras.length * 100) + '%'
})
</script>

<style scoped>
.card {
  background: linear-gradient(135deg, #FFFFFF 0%, #FAFBFC 100%);
  border-radius: 5px;
  padding: 16px 18px;
  box-shadow: 0 3px 12px rgba(0,0,0,0.06), 0 1px 3px rgba(0,0,0,0.04);
  border: 1px solid #E8ECF0;
  transition: transform 0.2s ease, box-shadow 0.2s ease;
}
.card:hover {
  transform: translateY(-2px);
  box-shadow: 0 6px 20px rgba(0,0,0,0.1), 0 2px 6px rgba(0,0,0,0.06);
}
.card-header {
  display: flex; align-items: center; justify-content: space-between;
  margin-bottom: 12px;
}
.card-title {
  font-size: 15px; font-weight: 700;
  color: #1A1A2E;
  position: relative;
  padding-left: 12px;
}
.card-title::before {
  content: '';
  position: absolute; left: 0; top: 2px; bottom: 2px;
  width: 3px; background: #D63031;
  border-radius: 2px;
}
.card-title.safe::before { background: #00B894; }

.camera-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
</style>