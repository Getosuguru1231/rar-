<template>
  <div class="card">
    <div class="card-header"><span class="card-title">风险等级分布</span></div>
    <div class="mini-chart" ref="chartRef"></div>
  </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted } from 'vue'
import * as echarts from 'echarts'

const props = defineProps({
  highCount: { type: Number, default: 8 },
  midCount: { type: Number, default: 9 },
  lowCount: { type: Number, default: 6 },
  safeCount: { type: Number, default: 27 }
})

const chartRef = ref(null)
let chart = null

function initChart() {
  if (!chartRef.value) return
  
  chart = echarts.init(chartRef.value)
  chart.setOption({
    tooltip: { 
      trigger: 'item', 
      formatter: '{b}: {c}处 ({d}%)',
      backgroundColor: 'rgba(255,255,255,0.95)',
      borderColor: '#E8ECF0',
      borderWidth: 1,
      textStyle: { color: '#1A1A2E' }
    },
    series: [{
      type: 'pie', radius: ['55%', '78%'], center: ['50%', '52%'],
      avoidLabelOverlap: false,
      itemStyle: { borderRadius: 4, borderColor: '#fff', borderWidth: 2 },
      label: { show: false },
      emphasis: { label: { show: true, fontSize: 16, fontWeight: 'bold', color: '#1A1A2E' }, scaleSize: 8 },
      data: [
        { value: props.highCount, name: '高危', itemStyle: { color: '#D63031' } },
        { value: props.midCount, name: '中危', itemStyle: { color: '#E17055' } },
        { value: props.lowCount, name: '低危', itemStyle: { color: '#FDCB6E' } },
        { value: props.safeCount, name: '安全', itemStyle: { color: '#00B894' } },
      ]
    }]
  })
}

function handleResize() {
  if (chart) chart.resize()
}

onMounted(() => {
  initChart()
  window.addEventListener('resize', handleResize)
})

onUnmounted(() => {
  if (chart) chart.dispose()
  window.removeEventListener('resize', handleResize)
})
</script>

<style scoped>
.card {
  background: linear-gradient(135deg, #FFFFFF 0%, #FAFBFC 100%);
  border-radius: 5px;
  padding: 16px 18px;
  box-shadow: 0 3px 12px rgba(0,0,0,0.06), 0 1px 3px rgba(0,0,0,0.04);
  border: 1px solid #E8ECF0;
  transition: transform 0.2s ease, box-shadow 0.2s ease;
}
.card:hover {
  transform: translateY(-2px);
  box-shadow: 0 6px 20px rgba(0,0,0,0.1), 0 2px 6px rgba(0,0,0,0.06);
}
.card-header {
  display: flex; align-items: center; justify-content: space-between;
  margin-bottom: 12px;
}
.card-title {
  font-size: 15px; font-weight: 700;
  color: #1A1A2E;
  position: relative;
  padding-left: 12px;
}
.card-title::before {
  content: '';
  position: absolute; left: 0; top: 2px; bottom: 2px;
  width: 3px; background: #D63031;
  border-radius: 2px;
}
.mini-chart { width: 100%; height: 150px; background: #FAFBFC; border-radius: 3px; padding: 4px; }
</style>