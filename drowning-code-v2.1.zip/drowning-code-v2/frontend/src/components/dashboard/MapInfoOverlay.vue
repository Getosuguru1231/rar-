<template>
  <div class="map-info-overlay">
    聚焦区域：<strong>{{ region }}</strong><br>
    监测覆盖：<span :style="{ color: highlightColor }">{{ count }}</span> 处高危场所
  </div>
</template>

<script setup>
defineProps({
  region: { type: String, default: '广西 · 玉林' },
  count: { type: [String, Number], default: 0 },
  highlightColor: { type: String, default: '#D63031' }
})
</script>

<style scoped>
.map-info-overlay {
  position: absolute; top: 16px; right: 20px;
  background: linear-gradient(135deg, rgba(255,255,255,0.98) 0%, rgba(248,250,252,0.98) 100%);
  padding: 12px 16px; border-radius: 5px;
  box-shadow: 0 4px 16px rgba(0,0,0,0.1), 0 1px 4px rgba(0,0,0,0.06);
  z-index: 1000;
  font-size: 13px;
  color: #636E72;
  line-height: 1.7;
  border: 1px solid #E8ECF0;
}
.map-info-overlay strong { color: #D63031; font-size: 16px; font-weight: 700; }
</style>