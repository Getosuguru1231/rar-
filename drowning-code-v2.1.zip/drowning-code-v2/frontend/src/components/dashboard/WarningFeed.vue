<template>
  <div class="card">
    <div class="card-header">
      <span class="card-title">实时预警推送</span>
      <span style="font-size:11px;color:#9CA3A8">共 <strong style="color:#D63031">{{ warnings.length }}</strong> 条</span>
    </div>
    <div class="warning-list">
      <WarningItem 
        v-for="(w, index) in warnings" 
        :key="index" 
        :time="w.time"
        :location="w.location"
        :detail="w.detail"
        :level="w.level"
        :ai="w.ai"
      />
    </div>
  </div>
</template>

<script setup>
import WarningItem from './WarningItem.vue'

defineProps({
  warnings: { type: Array, default: () => [] }
})
</script>

<style scoped>
.card {
  background: linear-gradient(135deg, #FFFFFF 0%, #FAFBFC 100%);
  border-radius: 5px;
  padding: 16px 18px;
  box-shadow: 0 3px 12px rgba(0,0,0,0.06), 0 1px 3px rgba(0,0,0,0.04);
  border: 1px solid #E8ECF0;
  transition: transform 0.2s ease, box-shadow 0.2s ease;
}
.card:hover {
  transform: translateY(-2px);
  box-shadow: 0 6px 20px rgba(0,0,0,0.1), 0 2px 6px rgba(0,0,0,0.06);
}
.card-header {
  display: flex; align-items: center; justify-content: space-between;
  margin-bottom: 12px;
}
.card-title {
  font-size: 15px; font-weight: 700;
  color: #1A1A2E;
  position: relative;
  padding-left: 12px;
}
.card-title::before {
  content: '';
  position: absolute; left: 0; top: 2px; bottom: 2px;
  width: 3px; background: #D63031;
  border-radius: 2px;
}

.warning-list { display: flex; flex-direction: column; gap: 10px; max-height: 320px; overflow-y: auto; }
</style>