<template>
  <div class="top-spot-item">
    <span :class="['top-spot-rank', rank <= 3 ? 'top' : '']">{{ rank }}</span>
    <span class="top-spot-name">{{ name }}</span>
    <span class="top-spot-score">{{ score }}</span>
  </div>
</template>

<script setup>
defineProps({
  rank: { type: Number, default: 1 },
  name: { type: String, default: '' },
  score: { type: [String, Number], default: 0 }
})
</script>

<style scoped>
.top-spot-item {
  display: flex; align-items: center; gap: 8px;
  padding: 4px 0;
  border-bottom: 1px solid #ECF0F1;
  font-size: 12px;
  color: #636E72;
  line-height: 2;
}
.top-spot-rank {
  display: inline-flex; align-items: center; justify-content: center;
  width: 18px; height: 18px;
  border-radius: 3px;
  font-size: 10px;
  font-weight: 700;
  color: #fff;
  background: #E17055;
}
.top-spot-rank.top {
  background: #D63031;
}
.top-spot-name { flex: 1; }
.top-spot-score {
  font-family: "SF Mono", "DIN", "Consolas", "Courier New", monospace;
  font-weight: 600;
  color: #D63031;
}
</style>