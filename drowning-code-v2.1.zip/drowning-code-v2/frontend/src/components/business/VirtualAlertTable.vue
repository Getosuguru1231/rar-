<template>
  <div class="virtual-alert-table">
    <div class="table-header">
      <div class="table-cell cell-checkbox">
        <el-checkbox 
          :model-value="allSelected" 
          @change="handleSelectAll"
          :disabled="alerts.length === 0"
        />
      </div>
      <div class="table-cell cell-id">告警ID</div>
      <div class="table-cell cell-level">告警级别</div>
      <div class="table-cell cell-reason">告警原因</div>
      <div class="table-cell cell-camera">摄像头</div>
      <div class="table-cell cell-area">区域</div>
      <div class="table-cell cell-time">时间</div>
      <div class="table-cell cell-status">状态</div>
      <div class="table-cell cell-actions">操作</div>
    </div>
    
    <RecycleScroller
      class="alert-table-scroller"
      :items="alerts"
      :item-size="itemHeight"
      key-field="alertId"
      v-slot="{ item, index }"
    >
      <div
        class="table-row"
        :class="{ 
          active: selectedIndex === index, 
          selected: selectedAlerts.includes(item.alertId),
          unread: !item.read && !item.acknowledged
        }"
        @click="handleRowClick(item, index)"
      >
        <div class="table-cell cell-checkbox" @click.stop="">
          <el-checkbox 
            :model-value="selectedAlerts.includes(item.alertId)" 
            @change="handleSelectRow(item)"
          />
        </div>
        <div class="table-cell cell-id">
          <span class="alert-id">{{ item.id || item.alertId }}</span>
        </div>
        <div class="table-cell cell-level">
          <el-tag :type="getLevelTagType(item.level)" size="small">
            {{ getLevelText(item.level) }}
          </el-tag>
        </div>
        <div class="table-cell cell-reason">{{ item.reason }}</div>
        <div class="table-cell cell-camera">
          <span class="camera-badge">
            <el-icon><VideoCamera /></el-icon>
            {{ item.cameraId }}
          </span>
        </div>
        <div class="table-cell cell-area">{{ item.area }}</div>
        <div class="table-cell cell-time">{{ formatTime(item.time) }}</div>
        <div class="table-cell cell-status">
          <el-tag :type="item.acknowledged ? 'success' : 'warning'" size="small">
            {{ item.acknowledged ? '已处理' : '待处理' }}
          </el-tag>
          <el-tag v-if="item.read" type="info" size="small" style="margin-left: 4px;">已读</el-tag>
        </div>
        <div class="table-cell cell-actions">
          <el-button
            size="small"
            @click.stop="handleViewDetail(item)"
          >
            <el-icon><Search /></el-icon>
            查看详情
          </el-button>
          <el-button
            v-if="!item.acknowledged"
            size="small"
            type="primary"
            @click.stop="handleConfirm(item, index)"
            :loading="processingIndex === index"
          >
            <el-icon><Check /></el-icon>
            处理
          </el-button>
          <el-button
            size="small"
            type="danger"
            @click.stop="handleDelete(item)"
          >
            <el-icon><Delete /></el-icon>
            删除
          </el-button>
        </div>
      </div>
    </RecycleScroller>
    
    <div v-if="alerts.length === 0" class="table-empty">
      <el-empty description="暂无告警数据" />
    </div>
  </div>
</template>

<script setup>
import { VideoCamera, Search, Check, Delete } from '@element-plus/icons-vue'
import { computed } from 'vue'

const props = defineProps({
  alerts: {
    type: Array,
    default: () => []
  },
  selectedIndex: {
    type: Number,
    default: -1
  },
  processingIndex: {
    type: Number,
    default: -1
  },
  selectedAlerts: {
    type: Array,
    default: () => []
  },
  itemHeight: {
    type: Number,
    default: 60
  }
})

const emit = defineEmits(['row-click', 'view-detail', 'confirm', 'delete', 'select-row', 'select-all'])

const allSelected = computed(() => {
  return props.alerts.length > 0 && props.alerts.every(alert => props.selectedAlerts.includes(alert.alertId))
})

const handleSelectAll = (value) => {
  emit('selectAll', value)
}

const handleSelectRow = (item) => {
  emit('selectRow', item)
}

const getLevelTagType = (level) => {
  const types = {
    high: 'danger',
    medium: 'warning',
    low: 'success'
  }
  return types[level] || 'info'
}

const getLevelText = (level) => {
  const texts = {
    high: '高风险',
    medium: '中风险',
    low: '低风险'
  }
  return texts[level] || '未知'
}

const formatTime = (timeStr) => {
  if (!timeStr) return '-'
  try {
    const date = new Date(timeStr)
    return date.toLocaleString('zh-CN', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    })
  } catch {
    return timeStr
  }
}

const handleRowClick = (item, index) => {
  emit('row-click', item, index)
}

const handleViewDetail = (item) => {
  emit('view-detail', item)
}

const handleConfirm = (item, index) => {
  emit('confirm', item, index)
}

const handleDelete = (item) => {
  emit('delete', item)
}
</script>

<style scoped>
.virtual-alert-table {
  border: 1px solid #ebeef5;
  border-radius: 4px;
  overflow: hidden;
}

.table-header {
  display: flex;
  background-color: #f5f7fa;
  border-bottom: 1px solid #ebeef5;
  font-weight: 500;
  color: #909399;
}

.table-cell {
  padding: 12px 10px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 14px;
}

.cell-checkbox {
  width: 50px;
  min-width: 50px;
}

.cell-id {
  width: 120px;
  min-width: 120px;
}

.cell-level {
  width: 100px;
  min-width: 100px;
}

.cell-reason {
  flex: 1;
  min-width: 200px;
  justify-content: flex-start;
}

.cell-camera {
  width: 120px;
  min-width: 120px;
}

.cell-area {
  width: 120px;
  min-width: 120px;
}

.cell-time {
  width: 180px;
  min-width: 180px;
}

.cell-status {
  width: 140px;
  min-width: 140px;
}

.cell-actions {
  width: 260px;
  min-width: 260px;
  gap: 8px;
}

.alert-table-scroller {
  max-height: 500px;
}

.table-row {
  display: flex;
  border-bottom: 1px solid #ebeef5;
  transition: all 0.2s;
  cursor: pointer;
  position: relative;
}

.table-row:hover {
  background-color: #f5f7fa;
}

.table-row.active {
  background-color: #ecf5ff;
}

.table-row.selected {
  background-color: #f0f5ff;
  border-left: 3px solid #409eff;
}

.table-row.unread {
  position: relative;
}

.table-row.unread::before {
  content: '';
  position: absolute;
  top: 50%;
  left: 2px;
  width: 8px;
  height: 8px;
  background: #ff4d4f;
  border-radius: 50%;
  transform: translateY(-50%);
  animation: pulse 2s infinite;
}

@keyframes pulse {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.5; }
}

.alert-id {
  font-family: 'Monaco', 'Menlo', monospace;
  color: #409eff;
  font-size: 13px;
}

.camera-badge {
  display: flex;
  align-items: center;
  gap: 4px;
  color: #409eff;
  font-size: 13px;
}

.table-empty {
  padding: 40px 0;
}
</style>
