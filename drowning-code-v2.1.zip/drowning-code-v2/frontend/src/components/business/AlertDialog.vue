<!-- frontend/src/components/AlertDialog.vue -->
<template>
  <el-dialog
    v-model="visible"
    :title="title"
    :width="width"
    :close-on-click-modal="false"
    :close-on-press-escape="false"
    :before-close="handleBeforeClose"
    class="alert-dialog-component"
  >
    <div class="alert-dialog-content">
      <!-- 告警基本信息：优化v-if判断，避免冗余逻辑 -->
      <div class="dialog-item" v-if="alertData.time">
        <span class="label">触发时间：</span>
        <span>{{ alertData.time }}</span>
      </div>
      <div class="dialog-item" v-if="alertData.cameraId || alertData.area">
        <span class="label">摄像头/区域：</span>
        <span>
          <span v-if="alertData.cameraId">摄像头{{ alertData.cameraId }}</span>
          <span v-if="alertData.cameraId && alertData.area"> - </span>
          <span v-if="alertData.area">{{ alertData.area }}</span>
        </span>
      </div>
      <div class="dialog-item" v-if="alertData.level">
        <span class="label">危险等级：</span>
        <el-tag :type="getRiskTagType(alertData.level)" class="risk-tag">
          {{ getRiskText(alertData.level) }}
        </el-tag>
      </div>
      <div class="dialog-item" v-if="alertData.reason">
        <span class="label">触发原因：</span>
        <span class="reason-text">{{ alertData.reason }}</span>
      </div>
      <div class="dialog-item" v-if="alertData.riskScore !== undefined && alertData.riskScore !== null">
        <span class="label">危险系数：</span>
        <span class="risk-score">{{ alertData.riskScore }}%</span>
      </div>
      
      <!-- 告警预览图：添加加载失败兜底，优化响应式 -->
      <div class="dialog-preview" v-if="alertData.previewUrl">
        <img 
          :src="alertData.previewUrl" 
          alt="告警截图" 
          class="preview-img"
          @error="handleImgError"
          :class="{ 'img-error': imgLoadFailed }"
        >
        <div class="img-error-text" v-if="imgLoadFailed">截图加载失败</div>
      </div>
    </div>
    
    <template #footer>
      <slot name="footer">
        <el-button @click="handleIgnore" :disabled="isProcessing">忽略</el-button>
        <el-button type="primary" @click="handleConfirm" :disabled="isProcessing">
          <el-icon v-if="isProcessing" class="is-loading"></el-icon>
          确认处理
        </el-button>
      </slot>
    </template>
  </el-dialog>
</template>

<script setup>
import { ref, computed, watch } from 'vue'
import { ElMessage } from 'element-plus'
// 简化导入路径（默认导入 index.js，无需显式书写）
import { getRiskTagType, getRiskText } from '@/utils'

// Props：强化校验，避免无效数据导致异常
const props = defineProps({
  modelValue: {
    type: Boolean,
    default: false
  },
  alertData: {
    type: Object,
    default: () => ({}),
    // 校验核心字段格式，避免渲染异常
    validator: (val) => {
      const requiredTypes = {
        time: ['string', 'undefined', 'null'],
        cameraId: ['number', 'string', 'undefined', 'null'],
        area: ['string', 'undefined', 'null'],
        level: ['string', 'undefined', 'null'],
        reason: ['string', 'undefined', 'null'],
        riskScore: ['number', 'undefined', 'null'],
        previewUrl: ['string', 'undefined', 'null']
      }
      return Object.entries(requiredTypes).every(([key, types]) => 
        types.includes(typeof val[key])
      )
    }
  },
  title: {
    type: String,
    default: '紧急告警'
  },
  width: {
    type: String,
    default: '500px',
    // 校验宽度格式，避免无效值
    validator: (val) => /^\d+(px|vw|%)$/.test(val)
  },
  autoClose: {
    type: Boolean,
    default: true
  }
})

// Emits：明确事件参数类型
const emit = defineEmits(['update:modelValue', 'confirm', 'ignore'])

// 响应式状态：新增加载状态，防止重复点击
const visible = computed({
  get: () => props.modelValue,
  set: (val) => emit('update:modelValue', val)
})
const isProcessing = ref(false) // 处理中状态
const imgLoadFailed = ref(false) // 预览图加载失败状态

// 监听告警数据变化，重置状态
watch(() => props.alertData, () => {
  imgLoadFailed.value = false
  isProcessing.value = false
}, { deep: true })

// 方法：优化提示信息，添加防重复点击
const handleConfirm = () => {
  if (isProcessing.value) return
  isProcessing.value = true
  
  emit('confirm', props.alertData)
  // 拼接具体告警信息，提升用户体验
  const alertInfo = props.alertData.cameraId ? `摄像头${props.alertData.cameraId}` : '未知设备'
  ElMessage.success(`告警已确认处理（${alertInfo}）`)
  
  if (props.autoClose) {
    setTimeout(() => {
      visible.value = false
      isProcessing.value = false
    }, 500)
  } else {
    isProcessing.value = false
  }
}

const handleIgnore = () => {
  if (isProcessing.value) return
  isProcessing.value = true
  
  emit('ignore', props.alertData)
  const alertInfo = props.alertData.cameraId ? `摄像头${props.alertData.cameraId}` : '未知设备'
  ElMessage.warning(`已忽略该告警（${alertInfo}）`)
  
  if (props.autoClose) {
    setTimeout(() => {
      visible.value = false
      isProcessing.value = false
    }, 500)
  } else {
    isProcessing.value = false
  }
}

// 预览图加载失败处理
const handleImgError = () => {
  imgLoadFailed.value = true
  console.warn('告警预览图加载失败：', props.alertData.previewUrl)
}

// 弹窗关闭前拦截，防止误操作
const handleBeforeClose = (done) => {
  if (isProcessing.value) {
    ElMessage.info('处理中，请稍后')
    return
  }
  done()
}
</script>

<style scoped>
/* 基础样式：保留原有风格，优化响应式与可读性 */
.alert-dialog-component {
  --el-dialog-header-text-color: #fff;
  --el-dialog-header-bg-color: #f56c6c;
  --el-dialog-border-radius: 8px;
  --el-dialog-content-padding: 20px;
}

.alert-dialog-component .el-dialog__header {
  background-color: #f56c6c;
  padding: 15px 20px;
  border-radius: 8px 8px 0 0;
}

.alert-dialog-component .el-dialog__title {
  color: #fff;
  font-weight: 600;
  font-size: 16px;
}

.alert-dialog-component .el-dialog__body {
  padding: var(--el-dialog-content-padding);
}

.alert-dialog-content {
  color: #333;
  line-height: 1.6;
}

/* 信息项样式：优化间距，提升可读性 */
.dialog-item {
  margin-bottom: 14px;
  display: flex;
  align-items: flex-start;
  flex-wrap: wrap;
}

.dialog-item:last-child {
  margin-bottom: 0;
}

.dialog-item .label {
  width: 100px;
  font-weight: 600;
  color: #666;
  flex-shrink: 0;
}

/* 危险系数样式：强化视觉提示 */
.risk-score {
  font-size: 22px;
  font-weight: 600;
  color: #f56c6c;
  letter-spacing: 1px;
}

/* 危险等级标签：优化间距 */
.risk-tag {
  margin-top: 2px;
}

/* 触发原因：防止文本溢出 */
.reason-text {
  flex: 1;
  word-break: break-all;
}

/* 预览图样式：响应式适配，添加失败兜底 */
.dialog-preview {
  margin-top: 18px;
  border-radius: 4px;
  overflow: hidden;
  position: relative;
}

.preview-img {
  width: 100%;
  height: auto;
  max-height: 300px;
  object-fit: cover;
  border-radius: 4px;
}

/* 预览图加载失败样式 */
.preview-img.img-error {
  background-color: #f5f5f5;
  display: flex;
  justify-content: center;
  align-items: center;
  height: 180px;
  color: #999;
}

.img-error-text {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  color: #999;
  font-size: 14px;
}

/* 适配小屏幕：优化宽度响应式 */
@media (max-width: 768px) {
  .alert-dialog-component {
    --el-dialog-content-padding: 15px;
  }
  
  .dialog-item {
    margin-bottom: 12px;
  }
  
  .dialog-item .label {
    width: 90px;
    font-size: 13px;
  }
  
  .risk-score {
    font-size: 20px;
  }
  
  .preview-img {
    max-height: 220px;
  }
}
</style>