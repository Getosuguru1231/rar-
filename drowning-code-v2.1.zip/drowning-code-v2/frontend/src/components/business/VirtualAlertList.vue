<template>
  <div class="virtual-alert-list">
    <RecycleScroller
      class="alert-scroller"
      :items="alerts"
      :item-size="itemHeight"
      key-field="alertId"
      v-slot="{ item, index }"
    >
      <div
        class="alert-card-item"
        :class="[
          `level-${item.level}`, 
          { 
            active: activeIndex === index, 
            acknowledged: item.acknowledged
          }
        ]"
        @click="handleItemClick(item, index)"
        v-memo="[item.alertId, item.acknowledged, item.level, activeIndex === index, processingIndex === index]"
      >
        <div class="alert-card-content">
          <div class="alert-header">
            <div class="alert-type">
              <el-icon><WarningFilled /></el-icon>
              <span>{{ item.reason || '未知告警' }}</span>
            </div>
            <span class="level-badge" :class="getAlertLevelClass(item.level)">
              {{ getRiskText(item.level) }}
            </span>
          </div>
          
          <div class="alert-camera-info">
            <div class="camera-id">
              <el-icon><VideoCamera /></el-icon>
              <span>摄像头 {{ item.cameraId }}</span>
            </div>
            <div class="camera-area">
              <span>📍</span>
              <span>{{ item.area }}</span>
            </div>
          </div>
          
          <div class="alert-footer">
            <div class="alert-time">
              <span>⏰ {{ getFormattedTime(item) }}</span>
            </div>
            <div class="alert-actions" v-if="!item.acknowledged">
              <button
                class="resolve-btn"
                :class="{ loading: processingIndex === index }"
                @click.stop="handleConfirm(item, index)"
              >
                {{ processingIndex === index ? '处理中...' : '处理' }}
              </button>
              <button
                class="delete-btn"
                @click.stop="handleDelete(item)"
                title="删除告警"
              >
                <el-icon><Delete /></el-icon>
              </button>
            </div>
            <div v-else class="alert-actions">
              <div class="alert-status">
                <el-icon><CircleCheck /></el-icon>
                已处理
              </div>
              <button
                class="delete-btn"
                @click.stop="handleDelete(item)"
                title="删除告警"
              >
                <el-icon><Delete /></el-icon>
              </button>
            </div>
          </div>
        </div>
      </div>
    </RecycleScroller>

    <div v-if="alerts.length === 0" class="alert-empty-state">
      <h4>暂无告警</h4>
      <p>系统运行正常，没有检测到任何异常</p>
    </div>
  </div>
</template>

<script setup>
import { WarningFilled, VideoCamera, CircleCheck, Delete } from '@element-plus/icons-vue'
import { computed } from 'vue'

const props = defineProps({
  alerts: {
    type: Array,
    default: () => []
  },
  activeIndex: {
    type: Number,
    default: -1
  },
  processingIndex: {
    type: Number,
    default: -1
  },
  itemHeight: {
    type: Number,
    default: 140
  }
})

const emit = defineEmits(['item-click', 'confirm', 'delete'])

// 时间格式化缓存
const timeCache = new Map()

const getRiskText = (level) => {
  const texts = {
    high: '高风险',
    medium: '中风险',
    low: '低风险'
  }
  return texts[level] || '未知'
}

const getAlertLevelClass = (level) => {
  switch (level) {
    case 'high': return 'level-high'
    case 'medium': return 'level-medium'
    case 'low': return 'level-low'
    default: return 'level-medium'
  }
}

// 优化的时间格式化函数，带缓存
const getFormattedTime = (item) => {
  const timeStr = item.time || item.timestamp
  if (!timeStr) return '未知时间'
  
  // 使用缓存避免重复计算
  if (timeCache.has(timeStr)) {
    return timeCache.get(timeStr)
  }
  
  let date
  try {
    date = new Date(timeStr)
    if (isNaN(date.getTime())) {
      return '未知时间'
    }
  } catch (e) {
    return '未知时间'
  }
  
  // 始终显示精确的日期时间
  const formatted = date.toLocaleString('zh-CN', {
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit'
  })
  
  // 限制缓存大小
  if (timeCache.size > 100) {
    timeCache.clear()
  }
  timeCache.set(timeStr, formatted)
  
  return formatted
}

const handleItemClick = (item, index) => {
  emit('item-click', item, index)
}

const handleConfirm = (item, index) => {
  emit('confirm', item, index)
}

const handleDelete = (item) => {
  emit('delete', item)
}
</script>

<style scoped>
.virtual-alert-list {
  height: 100%;
  display: flex;
  flex-direction: column;
  background: transparent;
  contain: layout size; /* CSS性能优化 */
}

.alert-scroller {
  flex: 1;
  overflow-y: auto;
  padding: 8px;
  will-change: scroll-position; /* 提示浏览器优化滚动 */
}

.alert-card-item {
  display: flex;
  padding: 12px 16px;
  margin-bottom: 8px;
  margin-left: 4px;
  margin-right: 4px;
  border-radius: 12px;
  background: linear-gradient(135deg, #2d3748 0%, #1a202c 100%);
  border-left: 4px solid #4a5568;
  cursor: pointer;
  transition: transform 0.2s ease, box-shadow 0.2s ease;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
  min-height: 110px;
  box-sizing: border-box;
  border: 1px solid rgba(255, 255, 255, 0.1);
  contain: layout style;
}

.alert-card-item:hover {
  box-shadow: 0 6px 20px rgba(0, 0, 0, 0.4);
  transform: translateY(-2px);
}

.alert-card-item.active {
  background: linear-gradient(135deg, #1e3a5f 0%, #152238 100%);
  border-left-color: #4299e1;
  border-color: rgba(66, 153, 225, 0.3);
}

.alert-card-item.acknowledged {
  background: linear-gradient(135deg, #1a3a2a 0%, #0d2116 100%);
  border-left-color: #48bb78;
  opacity: 0.85;
  border-color: rgba(72, 187, 120, 0.2);
}

.alert-card-item.level-high {
  border-left-color: #fc8181;
  background: linear-gradient(135deg, #4a1a1a 0%, #2d0d0d 100%);
}

.alert-card-item.level-medium {
  border-left-color: #fbd38d;
  background: linear-gradient(135deg, #4a3a1a 0%, #2d240d 100%);
}

.alert-card-item.level-low {
  border-left-color: #68d391;
  background: linear-gradient(135deg, #1a4a2a 0%, #0d2d16 100%);
}

.alert-card-item.level-high.acknowledged {
  border-left-color: #48bb78;
  background: linear-gradient(135deg, #1a3a2a 0%, #0d2116 100%);
}

.alert-card-item.level-medium.acknowledged {
  border-left-color: #48bb78;
  background: linear-gradient(135deg, #1a3a2a 0%, #0d2116 100%);
}

.alert-card-content {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.alert-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.alert-type {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 13px;
  font-weight: 600;
  color: #e2e8f0;
}

.level-badge {
  padding: 4px 10px;
  border-radius: 20px;
  font-size: 11px;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

.level-badge.level-high {
  background: linear-gradient(135deg, rgba(252, 129, 129, 0.3) 0%, rgba(239, 68, 68, 0.2) 100%);
  color: #fc8181;
  border: 1px solid rgba(252, 129, 129, 0.3);
}

.level-badge.level-medium {
  background: linear-gradient(135deg, rgba(251, 211, 141, 0.3) 0%, rgba(249, 115, 22, 0.2) 100%);
  color: #fbd38d;
  border: 1px solid rgba(251, 211, 141, 0.3);
}

.level-badge.level-low {
  background: linear-gradient(135deg, rgba(104, 211, 145, 0.3) 0%, rgba(34, 197, 94, 0.2) 100%);
  color: #68d391;
  border: 1px solid rgba(104, 211, 145, 0.3);
}

.alert-camera-info {
  display: flex;
  flex-direction: column;
  gap: 3px;
}

.camera-id,
.camera-area {
  display: flex;
  align-items: center;
  gap: 5px;
  font-size: 11px;
  color: #a0aec0;
}

.alert-footer {
  display: flex;
  justify-content: space-between;
  align-items: center;
  flex-wrap: wrap;
  gap: 6px;
}

.alert-time,
.drowning-time,
.acknowledged-time {
  font-size: 10px;
  color: #718096;
  display: flex;
  align-items: center;
  gap: 4px;
}

.alert-actions {
  display: flex;
  gap: 6px;
  align-items: center;
}

.resolve-btn {
  padding: 6px 12px;
  border: none;
  border-radius: 8px;
  background: linear-gradient(135deg, #48bb78 0%, #38a169 100%);
  color: white;
  font-size: 11px;
  font-weight: 500;
  cursor: pointer;
  transition: transform 0.2s, box-shadow 0.2s;
  box-shadow: 0 2px 8px rgba(72, 187, 120, 0.3);
}

.resolve-btn:hover {
  background: linear-gradient(135deg, #68d391 0%, #48bb78 100%);
  box-shadow: 0 4px 12px rgba(72, 187, 120, 0.4);
  transform: translateY(-1px);
}

.resolve-btn:active {
  transform: translateY(0);
}

.resolve-btn.loading {
  opacity: 0.7;
  cursor: not-allowed;
}

.delete-btn {
  padding: 8px;
  border: none;
  border-radius: 8px;
  background: rgba(252, 129, 129, 0.1);
  color: #fc8181;
  cursor: pointer;
  transition: transform 0.2s, background 0.2s;
  display: flex;
  align-items: center;
  justify-content: center;
}

.delete-btn:hover {
  background: rgba(252, 129, 129, 0.2);
  transform: scale(1.05);
}

.alert-status {
  display: flex;
  align-items: center;
  gap: 5px;
  font-size: 13px;
  font-weight: 500;
  color: #68d391;
  background: rgba(104, 211, 145, 0.1);
  padding: 6px 12px;
  border-radius: 20px;
}

.alert-empty-state {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  color: #718096;
  text-align: center;
  padding: 60px 20px;
  contain: layout paint;
}

.alert-empty-state h4 {
  margin: 0 0 10px 0;
  font-size: 18px;
  font-weight: 600;
  color: #a0aec0;
}

.alert-empty-state p {
  margin: 0;
  font-size: 14px;
  color: #718096;
}
</style>
