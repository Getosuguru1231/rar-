<template>
  <el-card shadow="hover" class="video-stream-monitor">
    <template #header>
      <div class="card-header">
        <span>视频流状态监控</span>
        <el-button 
          size="small" 
          type="primary" 
          @click="refreshStats"
          :loading="loading"
        >
          刷新
        </el-button>
      </div>
    </template>
    
    <div class="monitor-content">
      <!-- 整体状态 -->
      <el-alert
        :title="healthStatus.status === 'healthy' ? '视频流服务正常' : '视频流服务异常'"
        :type="healthStatus.status === 'healthy' ? 'success' : 'warning'"
        :closable="false"
        show-icon
        style="margin-bottom: 15px;"
      />
      
      <!-- 连接统计 -->
      <el-descriptions :column="2" border size="small">
        <el-descriptions-item label="总连接数">
          {{ stats.connections?.total || 0 }}
        </el-descriptions-item>
        <el-descriptions-item label="活跃流">
          <el-tag :type="stats.connections?.active > 0 ? 'success' : 'info'">
            {{ stats.connections?.active || 0 }}
          </el-tag>
        </el-descriptions-item>
        <el-descriptions-item label="累计帧数">
          {{ formatNumber(stats.frames?.total_sent || 0) }}
        </el-descriptions-item>
        <el-descriptions-item label="运行时间">
          {{ stats.uptime || 'N/A' }}
        </el-descriptions-item>
      </el-descriptions>
      
      <!-- 性能指标 -->
      <div class="performance-section" style="margin-top: 15px;">
        <h4 style="margin: 0 0 10px 0; font-size: 14px;">性能指标</h4>
        <el-row :gutter="10">
          <el-col :span="8">
            <div class="metric-card">
              <div class="metric-label">平均FPS</div>
              <div class="metric-value">{{ stats.frames?.avg_fps?.toFixed(1) || '0.0' }}</div>
            </div>
          </el-col>
          <el-col :span="8">
            <div class="metric-card">
              <div class="metric-label">最高FPS</div>
              <div class="metric-value" style="color: #67C23A;">
                {{ stats.frames?.max_fps?.toFixed(1) || '0.0' }}
              </div>
            </div>
          </el-col>
          <el-col :span="8">
            <div class="metric-card">
              <div class="metric-label">最低FPS</div>
              <div class="metric-value" style="color: #F56C6C;">
                {{ stats.frames?.min_fps === 999 ? 'N/A' : stats.frames?.min_fps?.toFixed(1) }}
              </div>
            </div>
          </el-col>
        </el-row>
      </div>
      
      <!-- Redis状态 -->
      <div class="redis-status" style="margin-top: 15px;">
        <el-descriptions :column="1" border size="small">
          <el-descriptions-item label="Redis状态">
            <el-tag :type="healthStatus.redis_status === 'connected' ? 'success' : 'danger'">
              {{ healthStatus.redis_status }}
            </el-tag>
          </el-descriptions-item>
          <el-descriptions-item label="最新帧" v-if="healthStatus.latest_frame">
            <span v-if="healthStatus.latest_frame.available">
              {{ healthStatus.latest_frame.size_bytes }} bytes
            </span>
            <el-tag v-else type="warning" size="small">无数据</el-tag>
          </el-descriptions-item>
        </el-descriptions>
      </div>
      
      <!-- 最近错误 -->
      <div class="errors-section" style="margin-top: 15px;" v-if="stats.recent_errors?.length > 0">
        <h4 style="margin: 0 0 10px 0; font-size: 14px;">
          最近错误 ({{ stats.recent_errors.length }})
        </h4>
        <el-timeline>
          <el-timeline-item
            v-for="(error, index) in stats.recent_errors.slice(-5)"
            :key="index"
            :timestamp="formatTime(error.timestamp)"
            placement="top"
            type="danger"
          >
            {{ error.message }}
          </el-timeline-item>
        </el-timeline>
      </div>
    </div>
  </el-card>
</template>

<script setup>
import { ref, onMounted, onUnmounted } from 'vue'

import { axios } from '@/utils/index.js'
import { getBackendUrl } from '@/utils/monitorHelpers.js'

const loading = ref(false)
const healthStatus = ref({
  status: 'unknown',
  redis_status: 'unknown',
  latest_frame: null
})
const stats = ref({
  connections: { total: 0, active: 0 },
  frames: { total_sent: 0, avg_fps: 0, max_fps: 0, min_fps: 999 },
  uptime: 'N/A',
  recent_errors: []
})

let refreshInterval = null

// 获取健康状态
const fetchHealth = async () => {
  try {
    const response = await axios.get('/video/health')
    healthStatus.value = response.data
  } catch (error) {
    console.error('[VideoMonitor] 获取健康状态失败:', error)
    healthStatus.value.status = 'error'
  }
}

// 获取详细统计
const fetchStats = async () => {
  try {
    const response = await axios.get('/video/stats')
    if (response.data.code === 200) {
      stats.value = response.data.data
    }
  } catch (error) {
    console.error('[VideoMonitor] 获取统计数据失败:', error)
  }
}

// 刷新所有数据
const refreshStats = async () => {
  loading.value = true
  try {
    await Promise.all([fetchHealth(), fetchStats()])
  } finally {
    loading.value = false
  }
}

// 格式化数字
const formatNumber = (num) => {
  if (num >= 1000000) {
    return (num / 1000000).toFixed(1) + 'M'
  } else if (num >= 1000) {
    return (num / 1000).toFixed(1) + 'K'
  }
  return num.toString()
}

// 格式化时间
const formatTime = (timestamp) => {
  if (!timestamp) return 'N/A'
  const date = new Date(timestamp)
  return date.toLocaleTimeString('zh-CN', { hour12: false })
}

// 定时刷新
const startAutoRefresh = () => {
  refreshInterval = setInterval(() => {
    fetchHealth()
    fetchStats()
  }, 10000) // 每10秒刷新一次
}

const stopAutoRefresh = () => {
  if (refreshInterval) {
    clearInterval(refreshInterval)
    refreshInterval = null
  }
}

onMounted(() => {
  refreshStats()
  startAutoRefresh()
})

onUnmounted(() => {
  stopAutoRefresh()
})
</script>

<style scoped>
.video-stream-monitor {
  margin-top: 10px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.monitor-content {
  padding: 5px 0;
}

.metric-card {
  background: #f5f7fa;
  padding: 12px;
  border-radius: 6px;
  text-align: center;
}

.metric-label {
  font-size: 12px;
  color: #909399;
  margin-bottom: 5px;
}

.metric-value {
  font-size: 20px;
  font-weight: bold;
  color: #303133;
}
</style>
