/**
 * 组件统一导出入口
 * 【核心规范】
 * 1. 导出名必须与 .vue 文件名完全一致(大小写敏感),避免导入路径报错
 * 2. 按功能分类组织:common(通用)、business(业务)、video(视频)
 * 3. 新增组件需按「组件名首字母大写」格式添加,保持排序一致
 */

// ========== 通用组件 (common/) ==========
export { default as Login } from './common/Login.vue'
export { default as StatsPanel } from './common/StatsPanel.vue'

// ========== 业务组件 (business/) ==========
export { default as AlertDialog } from './business/AlertDialog.vue'

// ========== 视频组件 (video/) ==========
export { default as VideoPlayer } from './video/VideoPlayer.vue'
export { default as RDK X5 EdgeVideoPlayer } from './video/RDK X5 EdgeVideoPlayer.vue'

// ========== 批量导出对象 ==========
// 通用组件集合
export const CommonComponents = {
  Login,
  StatsPanel
}

// 业务组件集合
export const BusinessComponents = {
  AlertDialog
}

// 视频组件集合
export const VideoComponents = {
  VideoPlayer,
  RDK X5 EdgeVideoPlayer
}

// 所有组件集合
export const AllComponents = {
  ...CommonComponents,
  ...BusinessComponents,
  ...VideoComponents
}
