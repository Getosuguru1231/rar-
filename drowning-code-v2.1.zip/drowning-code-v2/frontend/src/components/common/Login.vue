<template>
  <div class="login-container">
    <div class="login-form">
      <div class="login-header">
        <div class="logo-icon">防</div>
        <h2>AI溺水防控监测系统</h2>
        <p class="subtitle">{{ isRegisterMode ? '请注册新账号' : '请登录以访问系统' }}</p>
      </div>
      
      <div class="mode-toggle">
        <el-button 
          :type="isRegisterMode ? 'default' : 'primary'" 
          @click="isRegisterMode = false"
          :class="{ 'mode-button': true, 'active': !isRegisterMode, 'btn-hover-effect': true, 'ripple-effect': true }"
        >
          登录
        </el-button>
        <el-button 
          :type="isRegisterMode ? 'primary' : 'default'" 
          @click="isRegisterMode = true"
          :class="{ 'mode-button': true, 'active': isRegisterMode, 'btn-hover-effect': true, 'ripple-effect': true }"
        >
          注册
        </el-button>
      </div>
      
      <el-form :model="form" :rules="rules" ref="loginFormRef" label-width="80px">
        <el-form-item label="用户名" prop="username">
          <el-input 
            v-model="form.username" 
            placeholder="请输入用户名"
            prefix-icon="User"
            :class="{ 'input-focus': focus.username }"
            @focus="focus.username = true"
            @blur="focus.username = false"
          ></el-input>
        </el-form-item>
        
        <el-form-item label="密码" prop="password">
          <el-input 
            v-model="form.password" 
            :type="showPassword ? 'text' : 'password'"
            placeholder="请输入密码"
            prefix-icon="Lock"
            :class="{ 'input-focus': focus.password }"
            @focus="focus.password = true"
            @blur="focus.password = false"
          >
            <template #suffix>
              <el-icon @click="showPassword = !showPassword" class="password-toggle">
                {{ showPassword ? 'View' : 'Hide' }}
              </el-icon>
            </template>
          </el-input>
        </el-form-item>
        
        <el-form-item v-if="isRegisterMode" label="确认密码" prop="confirmPassword">
          <el-input 
            v-model="form.confirmPassword" 
            :type="showPassword ? 'text' : 'password'"
            placeholder="请再次输入密码"
            prefix-icon="Lock"
            :class="{ 'input-focus': focus.confirmPassword }"
            @focus="focus.confirmPassword = true"
            @blur="focus.confirmPassword = false"
          >
            <template #suffix>
              <el-icon @click="showPassword = !showPassword" class="password-toggle">
                {{ showPassword ? 'View' : 'Hide' }}
              </el-icon>
            </template>
          </el-input>
        </el-form-item>
        
        <el-form-item v-if="isRegisterMode" label="用户类型" prop="userType">
          <el-select v-model="form.userType" placeholder="请选择用户类型">
            <el-option label="普通用户" value="user"></el-option>
            <el-option label="管理员" value="admin"></el-option>
          </el-select>
        </el-form-item>
        
        <el-form-item v-if="!isRegisterMode" class="remember-password">
          <el-checkbox v-model="form.remember">记住密码</el-checkbox>
        </el-form-item>
        
        <el-form-item>
          <el-button 
            type="primary" 
            @click="submitForm" 
            :loading="loading"
            class="login-button btn-hover-effect ripple-effect"
          >
            {{ loading ? (isRegisterMode ? '注册中...' : '登录中...') : (isRegisterMode ? '注册' : '登录') }}
          </el-button>
        </el-form-item>
      </el-form>
      
      <div class="system-notice" v-if="!isRegisterMode">
        <el-alert
          title="系统提示"
          type="info"
          :closable="false"
          show-icon
          class="notice-alert"
        >
          <p><strong>管理员账号：</strong>admin / 123456（完整权限）</p>
          <p><strong>普通用户：</strong>user / 123456（只读监控）</p>
        </el-alert>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted, computed } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { User, Lock, VideoCamera, View, Hide } from '@element-plus/icons-vue'
import { axios } from '@/utils/index.js'
import { getBackendUrl } from '@/utils/monitorHelpers.js'

// 导入背景图片
import loginBg from '@/assets/login_bg.jpg'

const router = useRouter()
const loginFormRef = ref()
const loading = ref(false)
const isRegisterMode = ref(false)
const showPassword = ref(false)
const focus = reactive({
  username: false,
  password: false,
  confirmPassword: false
})

const form = reactive({
  username: '',
  password: '',
  confirmPassword: '',
  userType: 'user',
  remember: false
})

// 动态验证规则
const rules = computed(() => ({
  username: [
    { required: true, message: '请输入用户名', trigger: 'blur' },
    { min: 4, max: 12, message: '用户名长度应在4-12个字符之间', trigger: 'blur' },
    {
      validator: (rule, value, callback) => {
        const usernameRegex = /^[a-zA-Z0-9_]+$/;
        if (!usernameRegex.test(value)) {
          callback(new Error('用户名只能由字母、数字或下划线组成'));
        } else {
          callback();
        }
      },
      trigger: 'blur'
    }
  ],
  password: [
    { required: true, message: '请输入密码', trigger: 'blur' },
    { min: 6, max: 20, message: '密码长度应在6-20个字符之间', trigger: 'blur' }
  ],
  confirmPassword: [
    { required: isRegisterMode.value, message: '请再次输入密码', trigger: 'blur' },
    { 
      validator: (rule, value, callback) => {
        if (isRegisterMode.value && value !== form.password) {
          callback(new Error('两次输入的密码不一致'))
        } else {
          callback()
        }
      }, 
      trigger: 'blur' 
    }
  ],
  userType: [
    { required: isRegisterMode.value, message: '请选择用户类型', trigger: 'change' }
  ]
}))

// 加载记住的密码
const loadRememberedPassword = () => {
  const savedUsername = localStorage.getItem('rememberedUsername')
  const savedPassword = localStorage.getItem('rememberedPassword')
  if (savedUsername && savedPassword) {
    form.username = savedUsername
    form.password = savedPassword
    form.remember = true
  }
}

const submitForm = async () => {
  try {
    await loginFormRef.value.validate()
    
    loading.value = true
    
    if (isRegisterMode.value) {
      // 注册逻辑
      const response = await axios.post('/register', {
        username: form.username,
        password: form.password,
        userType: form.userType
      })
      
      if (response.data.success) {
        ElMessage.success({
          message: '注册成功，请登录',
          duration: 2000
        })
        
        // 切换到登录模式
        isRegisterMode.value = false
      } else {
        ElMessage.error(response.data.message || '注册失败')
      }
    } else {
      // 登录逻辑
      const response = await axios.post('/login', {
        username: form.username,
        password: form.password
      })
      
      if (response.data.success) {
        // 存储用户信息
        localStorage.setItem('token', response.data.token)
        localStorage.setItem('userType', response.data.userType)
        localStorage.setItem('username', response.data.username)
        
        // 记住密码
        if (form.remember) {
          localStorage.setItem('rememberedUsername', form.username)
          localStorage.setItem('rememberedPassword', form.password)
        } else {
          localStorage.removeItem('rememberedUsername')
          localStorage.removeItem('rememberedPassword')
        }
        
        ElMessage.success({
          message: '登录成功',
          duration: 2000 // 2 秒后自动关闭
        })
        
        // 根据用户类型跳转到不同页面
        setTimeout(() => {
          if (response.data.userType === 'admin') {
            router.push('/admin')  // 管理员跳转到管理面板
          } else {
            router.push('/monitor')  // 普通用户跳转到监控页面
          }
        }, 500)
      } else {
        ElMessage.error(response.data.message || '登录失败')
      }
    }
  } catch (error) {
    console.error(error)
    ElMessage.error(isRegisterMode.value ? '注册失败' : '登录失败')
  } finally {
    loading.value = false
  }
}

// 页面加载时检查是否有记住的密码
onMounted(() => {
  loadRememberedPassword()
})

</script>

<style scoped>
.login-container {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  background: #F0F2F5;
}

.login-form {
  width: 400px;
  padding: 40px;
  background: #FFFFFF;
  border-radius: 4px;
  border: 1px solid #DFE6E9;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
}

.login-header {
  text-align: center;
  margin-bottom: 30px;
}

.logo-icon {
  width: 80px;
  height: 80px;
  margin: 0 auto 20px;
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: #DC3545;
  color: #FFFFFF;
  font-size: 48px;
  font-weight: bold;
  border-radius: 4px;
}

.login-header h2 {
  margin: 0 0 10px;
  color: #2D3436;
  font-size: 24px;
  font-weight: 600;
  font-family: 'Microsoft YaHei', 'PingFang SC', sans-serif;
}

.subtitle {
  margin: 0;
  color: #636E72;
  font-size: 14px;
  font-weight: 400;
}

.input-focus {
  border-color: #0984E3 !important;
  box-shadow: 0 0 0 2px rgba(9, 132, 227, 0.15) !important;
  transition: all 0.3s ease;
}

.password-toggle {
  cursor: pointer;
  color: #636E72;
  transition: color 0.3s ease;
}

.password-toggle:hover {
  color: #0984E3;
}

.remember-password {
  margin-bottom: 20px;
}

.login-button {
  width: 100%;
  height: 45px;
  font-size: 16px;
  font-weight: 600;
  background: #D63031;
  border: none;
  border-radius: 4px;
  transition: all 0.3s ease;
}

.login-button:hover {
  background: #C0392B;
}

.login-button:active {
  background: #A93226;
}

.system-notice {
  margin-top: 25px;
}

.notice-alert {
  border-radius: 4px;
  border: 1px solid #DFE6E9;
}

.system-notice .el-alert p {
  margin: 5px 0;
  font-size: 13px;
  line-height: 1.6;
}

.system-notice .el-alert strong {
  color: #0984E3;
  font-weight: 600;
}

.mode-toggle {
  display: flex;
  margin-bottom: 25px;
  border-radius: 4px;
  overflow: hidden;
  border: 1px solid #DFE6E9;
  background: #F0F2F5;
}

.mode-button {
  flex: 1;
  border-radius: 0;
  border: none;
  transition: all 0.3s ease;
}

.mode-button.active {
  background: #D63031;
  color: white;
  font-weight: 600;
}

@media (max-width: 480px) {
  .login-form {
    width: 90%;
    padding: 30px;
  }
  
  .login-header h2 {
    font-size: 20px;
  }
  
  .logo {
    width: 60px;
    height: 60px;
  }
  
  .logo-icon {
    font-size: 30px;
  }
  
  .mode-toggle {
    margin-bottom: 20px;
  }
  
  .mode-button {
    font-size: 14px;
  }
}
</style>
