<!-- src/components/common/PeopleCount.vue -->
<template>
  <el-card shadow="always" class="people-count-component" body-style="display: flex; flex-direction: column; flex: 1; min-height: 0;">
    <template #header>
      <div class="card-header">
        <span>{{ title }}</span>
        <!-- 刷新按钮：仅展示时渲染，简化逻辑 -->
        <el-button 
          v-if="showRefresh" 
          size="small" 
          type="primary" 
          icon="Refresh"
          circle
          @click="handleRefresh"
          class="refresh-btn"
        ></el-button>
      </div>
    </template>
    <div class="people-count-content" style="flex: 1; overflow-y: auto; min-height: 0;">
      <!-- 总人数统计 -->
      <div class="stats-item">
        <div class="stats-label">
          <el-icon><User /></el-icon>
          {{ totalPeopleLabel }}
        </div>
        <div class="stats-value">{{ totalPeopleCount }}</div>
      </div>
      
      <!-- 区域人数分布 -->
      <div class="stats-item" v-if="showAreaDistribution && areaDistribution.length > 0">
        <div class="stats-label">
          <el-icon><Location /></el-icon>
          {{ areaDistributionLabel }}
        </div>
        <div class="area-distribution">
          <div 
            v-for="area in areaDistribution" 
            :key="area.name"
            class="area-item"
          >
            <span class="area-name">{{ area.name }}</span>
            <el-tag 
              :type="getAreaTagType(area.count)"
              size="small"
              effect="plain"
            >
              {{ area.count }}人
            </el-tag>
          </div>
        </div>
      </div>
      
      <!-- 人数趋势图 -->
      <div class="stats-item" v-if="showTrend && peopleTrend.length > 0">
        <div class="stats-label">
          <el-icon><TrendCharts /></el-icon>
          {{ trendLabel }}
        </div>
        <div class="trend-chart">
          <canvas ref="trendCanvas" width="100%" height="120"></canvas>
        </div>
      </div>
      
      <!-- 状态统计 -->
      <div class="stats-item" v-if="showStatusStats && statusStats">
        <div class="stats-label">
          <el-icon><DataAnalysis /></el-icon>
          {{ statusStatsLabel }}
        </div>
        <div class="status-stats">
          <div class="status-item" v-for="(count, status) in statusStats" :key="status">
            <span class="status-name">{{ getStatusName(status) }}</span>
            <el-tag 
              :type="getStatusTagType(status)"
              size="small"
              effect="plain"
            >
              {{ count }}人
            </el-tag>
          </div>
        </div>
      </div>
      
      <!-- 自定义插槽：保留扩展能力 -->
      <slot name="custom"></slot>
    </div>
  </el-card>
</template>

<script setup>
import { ref, onMounted, watch, nextTick } from 'vue'
// 按需导入 Element Plus 图标，无冗余导入
import { 
  User, Location, TrendCharts, DataAnalysis, Refresh 
} from '@element-plus/icons-vue'

// Props：强化类型校验，精简默认值定义
const props = defineProps({
  title: {
    type: String,
    default: '人数统计'
  },
  showRefresh: {
    type: Boolean,
    default: true
  },
  showAreaDistribution: {
    type: Boolean,
    default: true
  },
  showTrend: {
    type: Boolean,
    default: false
  },
  showStatusStats: {
    type: Boolean,
    default: false
  },
  totalPeopleLabel: {
    type: String,
    default: '当前总人数'
  },
  areaDistributionLabel: {
    type: String,
    default: '区域人数分布'
  },
  trendLabel: {
    type: String,
    default: '人数趋势'
  },
  statusStatsLabel: {
    type: String,
    default: '状态统计'
  },
  totalPeopleCount: {
    type: Number,
    default: 0,
    validator: val => val >= 0 // 校验非负
  },
  areaDistribution: {
    type: Array,
    default: () => [],
    validator: val => val.every(item => item.name && typeof item.count === 'number')
  },
  peopleTrend: {
    type: Array,
    default: () => [],
    validator: val => val.every(item => item.time && typeof item.count === 'number')
  },
  statusStats: {
    type: Object,
    default: () => ({}),
    validator: val => {
      return typeof val === 'object' && Object.values(val).every(count => typeof count === 'number')
    }
  }
})

// 自定义事件
const emit = defineEmits(['refresh'])

// 趋势图画布引用
const trendCanvas = ref(null)

// 区域人数标签类型判断
const getAreaTagType = (count) => {
  if (count === 0) return 'info'
  if (count <= 5) return 'success'
  if (count <= 10) return 'warning'
  return 'danger'
}

// 状态名称映射
const getStatusName = (status) => {
  const statusMap = {
    in_water: '水中',
    in_water2: '水中（状态2）',
    out_of_water: '水外',
    drowning: '溺水'
  }
  return statusMap[status] || status
}

// 状态标签类型判断
const getStatusTagType = (status) => {
  const typeMap = {
    in_water: 'success',
    in_water2: 'warning',
    out_of_water: 'info',
    drowning: 'danger'
  }
  return typeMap[status] || 'info'
}

// 绘制趋势图
const drawTrendChart = () => {
  if (!trendCanvas.value || props.peopleTrend.length === 0) return
  
  const canvas = trendCanvas.value
  const ctx = canvas.getContext('2d')
  const width = canvas.width
  const height = canvas.height
  
  // 清空画布
  ctx.clearRect(0, 0, width, height)
  
  // 数据准备
  const data = props.peopleTrend.map(item => item.count)
  const labels = props.peopleTrend.map(item => item.time)
  
  if (data.length === 0) return
  
  // 计算最大值和最小值
  const maxCount = Math.max(...data)
  const minCount = Math.min(...data)
  const range = maxCount - minCount || 1
  
  // 绘制网格
  ctx.strokeStyle = '#e0e0e0'
  ctx.lineWidth = 1
  
  // 绘制水平线
  for (let i = 0; i <= 5; i++) {
    const y = height - (i * height / 5)
    ctx.beginPath()
    ctx.moveTo(0, y)
    ctx.lineTo(width, y)
    ctx.stroke()
  }
  
  // 绘制垂直线
  for (let i = 0; i < data.length; i++) {
    const x = (i * width) / (data.length - 1) || 0
    ctx.beginPath()
    ctx.moveTo(x, 0)
    ctx.lineTo(x, height)
    ctx.stroke()
  }
  
  // 绘制数据线
  ctx.strokeStyle = '#409eff'
  ctx.lineWidth = 2
  ctx.beginPath()
  
  data.forEach((count, index) => {
    const x = (index * width) / (data.length - 1) || 0
    const y = height - ((count - minCount) / range) * height
    
    if (index === 0) {
      ctx.moveTo(x, y)
    } else {
      ctx.lineTo(x, y)
    }
  })
  
  ctx.stroke()
  
  // 绘制数据点
  ctx.fillStyle = '#409eff'
  data.forEach((count, index) => {
    const x = (index * width) / (data.length - 1) || 0
    const y = height - ((count - minCount) / range) * height
    
    ctx.beginPath()
    ctx.arc(x, y, 4, 0, Math.PI * 2)
    ctx.fill()
  })
  
  // 绘制标签
  ctx.fillStyle = '#666'
  ctx.font = '12px Arial'
  ctx.textAlign = 'center'
  
  labels.forEach((label, index) => {
    const x = (index * width) / (data.length - 1) || 0
    ctx.fillText(label, x, height - 5)
  })
}

// 刷新事件
const handleRefresh = () => {
  emit('refresh')
}

// 监听数据变化，重新绘制趋势图
watch(
  () => props.peopleTrend,
  () => {
    nextTick(() => {
      drawTrendChart()
    })
  },
  { deep: true }
)

// 组件挂载后绘制趋势图
onMounted(() => {
  nextTick(() => {
    drawTrendChart()
  })
})
</script>

<style scoped>
/* 全局样式：统一盒模型，适配项目整体规范 */
* {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}

.people-count-component {
  height: 100%;
  border-radius: 8px;
  overflow: hidden;
  display: flex;
  flex-direction: column;
}

/* 深度选择器：修改Element Plus卡片内部body的高度 */
.people-count-component :deep(.el-card__body) {
  flex: 1;
  overflow-y: auto;
  min-height: 0;
}

/* 确保内容不会溢出 */
.people-count-content {
  flex: 1;
  overflow-y: auto;
  min-height: 0;
  padding: 12px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0 10px;
  flex-shrink: 0;
}

.refresh-btn {
  flex-shrink: 0;
}

.stats-item {
  margin-bottom: 20px;
}

.stats-label {
  display: flex;
  align-items: center;
  margin-bottom: 10px;
  font-size: 14px;
  color: #606266;
}

.stats-label el-icon {
  margin-right: 5px;
}

.stats-value {
  font-size: 24px;
  font-weight: bold;
  color: #409eff;
}

.area-distribution {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
}

.area-item {
  display: flex;
  align-items: center;
  gap: 5px;
  margin-right: 15px;
  margin-bottom: 10px;
}

.area-name {
  font-size: 14px;
  color: #606266;
}

.trend-chart {
  margin-top: 10px;
}

.status-stats {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
}

.status-item {
  display: flex;
  align-items: center;
  gap: 5px;
  margin-right: 15px;
  margin-bottom: 10px;
}

.status-name {
  font-size: 14px;
  color: #606266;
}

/* 响应式设计 */
@media (max-width: 768px) {
  .area-distribution,
  .status-stats {
    flex-direction: column;
    align-items: flex-start;
  }
  
  .area-item,
  .status-item {
    margin-right: 0;
  }
}
</style>