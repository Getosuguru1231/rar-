<!-- src/components/StatsPanel.vue -->
<template>
  <el-card shadow="always" class="stats-panel-component">
    <template #header>
      <div class="card-header">
        <span>{{ title }}</span>
        <!-- 刷新按钮：仅展示时渲染，简化逻辑 -->
        <el-button 
          v-if="showRefresh" 
          size="small" 
          type="primary" 
          icon="Refresh"
          circle
          @click="handleRefresh"
          class="refresh-btn"
        ></el-button>
      </div>
    </template>
    <div class="stats-content">
      <!-- 今日告警统计 -->
      <div class="stats-item" v-if="showAlertStats">
        <div class="stats-label">
          <el-icon><Warning /></el-icon>
          {{ alertStatsLabel }}
        </div>
        <div class="alert-stats">
          <div class="stat-row" v-for="(val, key) in alertStatsMap" :key="key">
            <span class="stat-label">{{ val.label }}：</span>
            <el-tag :type="val.type" effect="plain">{{ todayAlertStats[key] }}{{ val.suffix }}</el-tag>
          </div>
        </div>
      </div>
      <!-- 自定义插槽：保留扩展能力 -->
      <slot name="custom"></slot>
    </div>
  </el-card>
</template>

<script setup>
import { ref } from 'vue'
// 按需导入 Element Plus 图标，无冗余导入
import { 
  Warning, Refresh 
} from '@element-plus/icons-vue'

// Props：强化类型校验，精简默认值定义，删除冗余注释
const props = defineProps({
  title: {
    type: String,
    default: '实时统计'
  },
  showRefresh: {
    type: Boolean,
    default: true
  },
  showAlertStats: {
    type: Boolean,
    default: true
  },
  alertStatsLabel: {
    type: String,
    default: '今日告警统计'
  },
  todayAlertStats: {
    type: Object,
    default: () => ({ total: 0, handled: 0, pending: 0 }),
    validator: val => {
      // 支持多种统计字段格式
      return typeof val.total === 'number' && 
             (val.handled !== undefined || val.falseAlarm !== undefined) &&
             (val.pending !== undefined || val.avgResponse !== undefined)
    }
  }
})

// 自定义事件：仅保留刷新事件，无冗余定义
const emit = defineEmits(['refresh'])

// 告警统计映射：抽离硬编码，删除模板冗余重复逻辑
const alertStatsMap = ref({
  total: { label: '总触发次数', type: 'danger', suffix: '' },
  handled: { label: '已处理', type: 'success', suffix: '' },
  pending: { label: '未处理', type: 'warning', suffix: '' }
})



// 刷新事件：核心逻辑，精简无冗余
const handleRefresh = () => {
  emit('refresh')
}
</script>

<style scoped>
/* 全局样式：统一盒模型，适配项目整体规范，删除冗余样式属性 */
* {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}

.stats-panel-component {
  height: 100%;
  border-radius: 8px;
  overflow: hidden;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-weight: 600;
  color: #333;
}

/* 刷新按钮：添加鼠标样式，提升交互体验 */
.refresh-btn {
  cursor: pointer;
}

.stats-content {
  max-height: calc(100dvh - 200px); /* 适配移动端视口，替换vh为dvh */
  overflow-y: auto;
  padding: 4px 0;
}

/* 优化滚动条样式，删除冗余滚动配置 */
.stats-content::-webkit-scrollbar {
  width: 6px;
}
.stats-content::-webkit-scrollbar-thumb {
  background-color: #e6e6e6;
  border-radius: 3px;
}

.stats-item {
  margin-bottom: 15px;
  padding-bottom: 10px;
  border-bottom: 1px solid #f0f0f0;
}

/* 最后一个项取消底边框，删除冗余重复的v-if判断 */
.stats-item:last-child {
  border-bottom: none;
  margin-bottom: 0;
  padding-bottom: 0;
}

.stats-label {
  font-size: 14px;
  color: #666;
  margin-bottom: 6px;
  display: flex;
  align-items: center;
  gap: 6px;
}



/* 环境参数：合并重复样式，统一布局规范 */
.env-params {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.env-item {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 13px;
  color: #333;
  padding: 4px 8px;
  background-color: #f0f9eb;
  border-radius: 4px;
}

/* 告警统计：删除模板重复代码后，样式更精简 */
.alert-stats {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.stat-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.stat-label {
  font-size: 13px;
  color: #666;
}
</style>