<template>
  <div class="html-renderer">
    <div v-if="loading" class="loading-state">
      <svg class="loading-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <circle cx="12" cy="12" r="10"></circle>
        <polyline points="12 6 12 12 16 14"></polyline>
      </svg>
      <span class="loading-text">{{ loadingText }}</span>
    </div>

    <div v-else-if="error" class="error-state">
      <svg class="error-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <circle cx="12" cy="12" r="10"></circle>
        <line x1="15" y1="9" x2="9" y2="15"></line>
        <line x1="9" y1="9" x2="15" y2="15"></line>
      </svg>
      <span class="error-text">{{ error }}</span>
      <el-button size="small" @click="reload">重新加载</el-button>
    </div>

    <div v-else-if="!htmlContent" class="empty-state">
      <svg class="empty-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
        <polyline points="14 2 14 8 20 8"></polyline>
        <line x1="16" y1="13" x2="8" y2="13"></line>
        <line x1="16" y1="17" x2="8" y2="17"></line>
        <polyline points="10 9 9 9 8 9"></polyline>
      </svg>
      <span class="empty-text">暂无内容</span>
    </div>

    <div v-else class="html-content" v-html="sanitizedHtml"></div>
  </div>
</template>

<script setup>
import { ref, computed, watch, onMounted } from 'vue'

const props = defineProps({
  htmlContent: {
    type: String,
    default: ''
  },
  url: {
    type: String,
    default: ''
  },
  loadingText: {
    type: String,
    default: '加载中...'
  },
  sanitize: {
    type: Boolean,
    default: true
  }
})

const emit = defineEmits(['loaded', 'error'])

const loading = ref(false)
const error = ref('')
const fetchedContent = ref('')

const sanitizedHtml = computed(() => {
  const content = props.htmlContent || fetchedContent.value
  if (!props.sanitize) return content
  return sanitizeContent(content)
})

const sanitizeContent = (html) => {
  if (!html) return ''
  const allowedTags = ['div', 'span', 'p', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 
                       'ul', 'ol', 'li', 'a', 'img', 'table', 'tr', 'td', 'th',
                       'strong', 'em', 'b', 'i', 'br', 'hr', 'blockquote',
                       'pre', 'code', 'small', 'big', 'sub', 'sup']
  
  const allowedAttributes = ['href', 'src', 'alt', 'title', 'target', 'class', 'id']
  
  const tagPattern = /<([a-z][a-z0-9]*)([^>]*)>/gi
  const attrPattern = /([a-z][a-z0-9]*)\s*=\s*["']([^"']*)["']/gi
  
  return html.replace(tagPattern, (match, tag, attrs) => {
    tag = tag.toLowerCase()
    if (!allowedTags.includes(tag)) {
      return ''
    }
    
    let cleanAttrs = ''
    let attrMatch
    const usedAttrs = new Set()
    
    while ((attrMatch = attrPattern.exec(attrs)) !== null) {
      const attrName = attrMatch[1].toLowerCase()
      const attrValue = attrMatch[2]
      
      if (allowedAttributes.includes(attrName) && !usedAttrs.has(attrName)) {
        usedAttrs.add(attrName)
        
        if (attrName === 'href' || attrName === 'src') {
          const url = attrValue.toLowerCase()
          if (url.startsWith('http://') || url.startsWith('https://') || 
              url.startsWith('/') || url.startsWith('#')) {
            cleanAttrs += ` ${attrName}="${attrValue}"`
          }
        } else {
          cleanAttrs += ` ${attrName}="${attrValue}"`
        }
      }
    }
    
    return `<${tag}${clean