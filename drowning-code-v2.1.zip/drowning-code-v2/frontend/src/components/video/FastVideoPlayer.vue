<template>
  <div class="fast-video-player" ref="containerRef">
    <canvas 
      ref="canvasRef" 
      class="video-canvas"
      :class="{ 'buffering': isBuffering }"
    ></canvas>
    
    <div v-if="isBuffering" class="buffering-overlay">
      <el-icon class="is-loading"><Loading /></el-icon>
      <span>加载中...</span>
    </div>
    
    <div v-if="hasError" class="error-overlay" @click="handleReconnect">
      <span>{{ errorMessage }}</span>
      <span class="retry-text">点击重试</span>
    </div>
    
    <div class="video-controls" v-if="showControls">
      <el-button type="primary" size="small" @click="togglePlay" v-if="!isPlaying">播放</el-button>
      <el-button type="warning" size="small" @click="togglePlay" v-else>暂停</el-button>
      <el-select v-model="quality" size="small" @change="handleQualityChange" style="width: 100px;">
        <el-option label="超清" value="ultra" />
        <el-option label="高清" value="high" />
        <el-option label="标清" value="medium" />
        <el-option label="流畅" value="low" />
      </el-select>
      <span class="stats">FPS: {{ displayFps }}</span>
    </div>
    
    <div class="video-info">
      <span class="quality-badge">{{ qualityLabels[quality] }}</span>
      <span class="latency">延迟: {{ latencyMs }}ms</span>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted, watch, computed, markRaw, shallowRef } from 'vue'
import { Loading } from '@element-plus/icons-vue'
import { getVideoWsUrl } from '@/config/websocket.js'

const props = defineProps({
  cameraId: {
    type: Number,
    default: 0
  },
  autoPlay: {
    type: Boolean,
    default: true
  },
  showControls: {
    type: Boolean,
    default: true
  },
  targetFps: {
    type: Number,
    default: 15
  }
})

const emit = defineEmits(['frame-update', 'error', 'stats'])

const containerRef = ref(null)
const canvasRef = ref(null)
const isPlaying = ref(false)
const isBuffering = ref(true)
const hasError = ref(false)
const errorMessage = ref('')
const quality = ref('high')
const latencyMs = ref(0)

// 使用shallowRef优化性能
const _currentFps = ref(0)
const displayFps = computed(() => _currentFps.value.toFixed(1))

const qualityLabels = {
  ultra: '超清',
  high: '高清',
  medium: '标清',
  low: '流畅'
}

const qualityConfig = {
  ultra: { quality: 85, width: 1280, height: 960 },
  high: { quality: 80, width: 960, height: 720 },
  medium: { quality: 75, width: 640, height: 480 },
  low: { quality: 60, width: 480, height: 360 }
}

// 使用markRaw标记非响应式对象
let ws = null
let frameQueue = []
let animationId = null
let frameCount = 0
let lastFpsTime = Date.now()
let lastFrameTime = 0
let reconnectTimer = null
let reconnectCount = 0
const MAX_RECONNECTS = 5
let lastRenderTime = 0
const TARGET_FRAME_INTERVAL = 1000 / props.targetFps

// 防抖的resize处理
let resizeTimer = null

// 初始化WebSocket连接
const initWebSocket = () => {
  if (ws) {
    ws.close()
    ws = null
  }
  
  isBuffering.value = true
  hasError.value = false
  
  const config = qualityConfig[quality.value]
  const wsUrl = getVideoWsUrl(props.cameraId, {
    quality: config.quality,
    width: config.width,
    height: config.height,
    fps: props.targetFps
  })
  
  ws = new WebSocket(wsUrl)
  
  ws.binaryType = 'arraybuffer'
  
  ws.onopen = () => {
    console.log('[FastVideo] WebSocket连接成功')
    isBuffering.value = false
    isPlaying.value = true
    reconnectCount = 0
  }
  
  ws.onmessage = (event) => {
    if (event.data instanceof ArrayBuffer) {
      processFrame(event.data)
    } else {
      try {
        const data = JSON.parse(event.data)
        if (data.type === 'stats') {
          latencyMs.value = data.latency || 0
        }
      } catch (e) {
        console.warn('[FastVideo] 无法解析消息:', e)
      }
    }
  }
  
  ws.onerror = (error) => {
    console.error('[FastVideo] WebSocket错误:', error)
    handleError('连接错误')
  }
  
  ws.onclose = (event) => {
    console.log('[FastVideo] WebSocket关闭:', event.code, event.reason)
    if (event.code !== 1000) {
      scheduleReconnect()
    }
  }
}

// 处理接收到的帧数据 - 优化版本
const processFrame = (buffer) => {
  const now = Date.now()
  
  // 计算延迟
  if (lastFrameTime > 0) {
    latencyMs.value = Math.round(now - lastFrameTime)
  }
  lastFrameTime = now
  
  // 智能队列管理 - 最多保持3帧（提高流畅度）
  if (frameQueue.length >= 3) {
    // 丢弃最旧的帧
    const oldest = frameQueue.shift()
    if (oldest.bitmap) {
      try {
        oldest.bitmap.close()
      } catch (e) {
        console.warn('[FastVideo] 关闭旧bitmap失败:', e)
      }
    }
  }
  
  // 使用requestIdleCallback延迟处理非关键路径
  const decodeAndPush = () => {
    createImageBitmap(new Blob([buffer], { type: 'image/jpeg' }), {
      resizeWidth: canvasRef.value?.width,
      resizeHeight: canvasRef.value?.height,
      resizeQuality: 'medium'  // 使用中等质量提升解码速度
    }).then((bitmap) => {
      frameQueue.push({ bitmap, timestamp: now })
      
      // 如果队列中有新帧且未在渲染，触发立即渲染
      if (frameQueue.length === 1 && !animationId) {
        startRenderLoop()
      }
    }).catch((err) => {
      console.error('[FastVideo] 帧解码失败:', err)
    })
  }
  
  if ('requestIdleCallback' in window) {
    requestIdleCallback(decodeAndPush, { timeout: 16 })  // 降低超时时间到16ms（约60fps）
  } else {
    // 降级方案：直接解码
    setTimeout(decodeAndPush, 0)
  }
  
  // 更新FPS - 降低更新频率到每2秒一次
  frameCount++
  if (now - lastFpsTime >= 2000) {
    _currentFps.value = frameCount / 2  // 计算2秒内的平均fps
    frameCount = 0
    lastFpsTime = now
    emit('stats', { fps: _currentFps.value, latency: latencyMs.value })
  }
}

// 渲染循环 - 优化版本
const renderLoop = (timestamp) => {
  const canvas = canvasRef.value
  if (!canvas) return
  
  // 帧率控制 - 自适应帧率
  const elapsed = timestamp - lastRenderTime
  const dynamicInterval = TARGET_FRAME_INTERVAL * (frameQueue.length > 1 ? 0.8 : 1)  // 队列积压时加快渲染
  
  if (elapsed >= dynamicInterval) {
    const ctx = canvas.getContext('2d', { 
      alpha: false,  // 禁用alpha通道提升性能
      desynchronized: true  // 启用低延迟模式
    })
    
    // 如果队列中有多个帧，跳过中间帧直接渲染最新的
    let frame
    if (frameQueue.length > 2) {
      // 丢弃中间的帧，只保留最新的
      while (frameQueue.length > 1) {
        const dropped = frameQueue.shift()
        if (dropped.bitmap) {
          try {
            dropped.bitmap.close()
          } catch (e) {
            console.warn('[FastVideo] 丢弃帧失败:', e)
          }
        }
      }
      frame = frameQueue.shift()
    } else {
      frame = frameQueue.shift()
    }
    
    if (frame && frame.bitmap) {
      try {
        // 使用硬件加速绘制
        ctx.drawImage(frame.bitmap, 0, 0, canvas.width, canvas.height)
        frame.bitmap.close()
        
        emit('frame-update', { timestamp: frame.timestamp })
      } catch (e) {
        console.error('[FastVideo] 渲染帧失败:', e)
      }
    }
    
    lastRenderTime = timestamp
  }
  
  // 继续下一帧
  animationId = requestAnimationFrame(renderLoop)
}

// 启动渲染循环
const startRenderLoop = () => {
  if (animationId) {
    cancelAnimationFrame(animationId)
  }
  lastRenderTime = performance.now()
  animationId = requestAnimationFrame(renderLoop)
}

// 停止渲染循环
const stopRenderLoop = () => {
  if (animationId) {
    cancelAnimationFrame(animationId)
    animationId = null
  }
}

// 处理错误
const handleError = (message) => {
  hasError.value = true
  errorMessage.value = message
  isPlaying.value = false
  stopRenderLoop()
  emit('error', { message })
}

// 调度重连
const scheduleReconnect = () => {
  if (reconnectCount >= MAX_RECONNECTS) {
    handleError('已达到最大重连次数')
    return
  }
  
  reconnectCount++
  const delay = Math.pow(2, reconnectCount) * 1000
  
  reconnectTimer = setTimeout(() => {
    initWebSocket()
  }, delay)
}

// 重新连接
const handleReconnect = () => {
  reconnectCount = 0
  initWebSocket()
}

// 切换播放状态
const togglePlay = () => {
  if (isPlaying.value) {
    stopRenderLoop()
    isPlaying.value = false
  } else {
    startRenderLoop()
    isPlaying.value = true
  }
}

// 切换画质
const handleQualityChange = () => {
  if (ws) {
    ws.close()
  }
  initWebSocket()
}

// 调整画布大小 - 防抖版本
const resizeCanvas = () => {
  if (resizeTimer) {
    cancelAnimationFrame(resizeTimer)
  }
  
  resizeTimer = requestAnimationFrame(() => {
    const container = containerRef.value
    const canvas = canvasRef.value
    if (!container || !canvas) return
    
    const rect = container.getBoundingClientRect()
    // 使用devicePixelRatio优化清晰度
    const dpr = window.devicePixelRatio || 1
    canvas.width = rect.width * dpr
    canvas.height = rect.height * dpr
    
    const ctx = canvas.getContext('2d')
    ctx.scale(dpr, dpr)
  })
}

// 监听画质变化
watch(quality, () => {
  handleQualityChange()
})

// 监听cameraId变化
watch(() => props.cameraId, () => {
  if (ws) {
    ws.close()
  }
  initWebSocket()
})

onMounted(() => {
  resizeCanvas()
  window.addEventListener('resize', resizeCanvas, { passive: true })
  
  if (props.autoPlay) {
    initWebSocket()
    startRenderLoop()
  }
})

onUnmounted(() => {
  window.removeEventListener('resize', resizeCanvas)
  
  if (ws) {
    ws.close()
    ws = null
  }
  
  stopRenderLoop()
  
  if (reconnectTimer) {
    clearTimeout(reconnectTimer)
    reconnectTimer = null
  }
  
  if (resizeTimer) {
    cancelAnimationFrame(resizeTimer)
  }
  
  // 清理帧队列中的ImageBitmap
  frameQueue.forEach(frame => {
    if (frame.bitmap) {
      frame.bitmap.close()
    }
  })
  frameQueue = []
})
</script>

<style scoped>
.fast-video-player {
  width: 100%;
  height: 100%;
  position: relative;
  background-color: #000;
  overflow: hidden;
  contain: layout paint size; /* CSS性能优化 */
}

.video-canvas {
  width: 100%;
  height: 100%;
  object-fit: contain;
  image-rendering: auto; /* 更平滑的渲染 */
  transform: translateZ(0); /* GPU加速 */
  will-change: transform; /* 提示浏览器优化 */
}

.video-canvas.buffering {
  opacity: 0.5;
}

.buffering-overlay,
.error-overlay {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 10px;
  color: #fff;
  background: rgba(0, 0, 0, 0.8);
  padding: 20px 40px;
  border-radius: 8px;
  z-index: 10;
  contain: layout paint;
}

.error-overlay {
  cursor: pointer;
}

.retry-text {
  font-size: 12px;
  color: #409eff;
}

.video-controls {
  position: absolute;
  bottom: 15px;
  right: 15px;
  display: flex;
  gap: 10px;
  background: rgba(0, 0, 0, 0.6);
  padding: 10px;
  border-radius: 8px;
  z-index: 20;
  contain: layout paint;
}

.stats {
  color: #fff;
  font-size: 12px;
  line-height: 28px;
  padding: 0 10px;
}

.video-info {
  position: absolute;
  top: 10px;
  left: 10px;
  display: flex;
  gap: 15px;
  background: rgba(0, 0, 0, 0.6);
  padding: 5px 12px;
  border-radius: 4px;
  z-index: 10;
  contain: layout paint;
}

.quality-badge {
  color: #67c23a;
  font-size: 12px;
  font-weight: bold;
}

.latency {
  color: #fff;
  font-size: 12px;
}
</style>
