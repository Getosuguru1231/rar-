<template>
  <div class="webrtc-player" ref="containerRef">
    <!-- 直接显示视频元素 - 移除Canvas层以提高性能 -->
    <video
      ref="videoRef"
      class="video-element"
      autoplay
      playsinline
      muted
      preload="none"
      :playsinline="true"
      :webkit-playsinline="true"
      disablepictureinpicture
      controlslist="nodownload"
      disableRemotePlayback
      :webkitVideoDecoding="true"
      :webkitAudioDecoding="true"
      style="videoDelay: low;"
    ></video>
    
    <!-- 性能统计显示 -->
    <div v-if="showStats" class="perf-stats-panel">
      <div class="perf-stat">
        <span class="perf-label">状态:</span>
        <span class="perf-value" :class="isConnected ? 'good' : 'warning'">
          {{ isConnected ? '已连接' : isConnecting ? '连接中...' : '已断开' }}
        </span>
      </div>
      <div v-if="isConnected && stats" class="perf-stat">
        <span class="perf-label">帧率:</span>
        <span class="perf-value">{{ stats.video?.fps || 0 }} fps</span>
      </div>
      <div v-if="isConnected && stats" class="perf-stat">
        <span class="perf-label">丢包:</span>
        <span class="perf-value">{{ stats.video?.packetsLost || 0 }}</span>
      </div>
      <div v-if="isConnected && stats" class="perf-stat">
        <span class="perf-label">抖动:</span>
        <span class="perf-value">{{ stats.video?.jitter || 0 }}ms</span>
      </div>
      <div v-if="isConnected && stats" class="perf-stat">
        <span class="perf-label">延迟:</span>
        <span class="perf-value">{{ stats.video?.delay || 0 }}ms</span>
      </div>
      <div v-if="isConnected && stats" class="perf-stat">
        <span class="perf-label">RTT:</span>
        <span class="perf-value">{{ stats.roundTripTime || 0 }}ms</span>
      </div>
      <div v-if="reconnectAttempts > 0" class="perf-stat">
        <span class="perf-label">重连:</span>
        <span class="perf-value warning">{{ reconnectAttempts }}/{{ maxReconnectAttempts }}</span>
      </div>
    </div>
    
    <!-- 连接状态覆盖层 -->
    <div v-if="!isConnected && !isConnecting" class="video-overlay">
      <div class="overlay-content" @click="handleConnect">
        <span class="connect-text">点击连接WebRTC</span>
      </div>
    </div>
    
    <div v-if="isConnecting" class="video-overlay">
      <div class="overlay-content">
        <div class="loading-spinner"></div>
        <span class="connect-text">正在建立连接...</span>
        <span v-if="reconnectAttempts > 0" class="retry-text">
          第 {{ reconnectAttempts }} 次重试
        </span>
      </div>
    </div>
    
    <div v-if="error" class="video-overlay error-overlay">
      <div class="overlay-content" @click="handleReconnect">
        <span class="error-text">{{ error }}</span>
        <span class="reconnect-text">点击重试</span>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, watch, onMounted, onUnmounted, nextTick } from 'vue'
import { useWebRTC } from '@/composables/useWebRTC.js'
import { showSuccess, showError } from '@/utils/index.js'

const props = defineProps({
  cameraId: {
    type: [Number, String],
    required: true
  },
  autoConnect: {
    type: Boolean,
    default: true
  },
  showStats: {
    type: Boolean,
    default: false
  }
})

const emit = defineEmits([
  'connected',
  'disconnected',
  'error',
  'stats'
])

const containerRef = ref(null)
const videoRef = ref(null)

// 性能监控
const showPerfStats = ref(true)

const {
  remoteStream,
  connectionState,
  iceConnectionState,
  isConnected,
  isConnecting,
  reconnectAttempts,
  maxReconnectAttempts,
  error,
  stats,
  connect,
  disconnect,
  toggleConnection,
  restart,
  resetReconnectAttempts
} = useWebRTC(props.cameraId)

watch(remoteStream, (stream) => {
  console.log('[WebRTCPlayer] remoteStream changed:', !!stream, stream ? `tracks: ${stream.getTracks?.().length || 'unknown'}` : 'null');
  console.log('[WebRTCPlayer] videoRef exists:', !!videoRef.value);
  
  // 使用 nextTick 确保 DOM 更新后再操作
  nextTick(() => {
    if (!videoRef.value) {
      console.warn('[WebRTCPlayer] videoRef 未就绪，等待...');
      return;
    }

    if (stream) {
      console.log('[WebRTCPlayer] 设置视频源开始');
      
      // 验证 stream 是有效的 MediaStream
      let isValidStream = false;
      let tracksCount = 0;
      try {
        isValidStream = stream && typeof stream.getTracks === 'function';
        if (isValidStream) {
          const tracks = stream.getTracks();
          tracksCount = tracks.length;
          console.log('[WebRTCPlayer] 流包含轨道数:', tracksCount);
          tracks.forEach((track, idx) => {
            console.log(`[WebRTCPlayer] 轨道${idx}: kind=${track.kind}, readyState=${track.readyState}`);
          });
        }
      } catch (e) {
        console.error('[WebRTCPlayer] 验证MediaStream失败:', e);
      }
      
      if (isValidStream && videoRef.value.srcObject !== stream) {
        try {
          // 先安全地停止旧的轨道
          if (videoRef.value.srcObject) {
            try {
              const oldTracks = videoRef.value.srcObject.getTracks();
              if (oldTracks && Array.isArray(oldTracks)) {
                oldTracks.forEach(track => {
                  if (track && typeof track.stop === 'function') {
                    track.stop();
                  }
                });
              }
            } catch (cleanErr) {
              console.warn('[WebRTCPlayer] 清理旧轨道失败:', cleanErr);
            }
          }
          
          // 设置新的源
          videoRef.value.srcObject = stream;
          console.log('[WebRTCPlayer] 视频源已设置');
          
          // 低延迟播放优化
          videoRef.value.playbackRate = 1.0;
          videoRef.value.defaultPlaybackRate = 1.0;
          
          // 尝试播放视频 - 添加更多错误处理
          videoRef.value.play().then(() => {
            console.log('[WebRTCPlayer] 视频播放成功');
            console.log('[WebRTCPlayer] 视频元素状态:', {
              paused: videoRef.value.paused,
              ended: videoRef.value.ended,
              readyState: videoRef.value.readyState,
              buffered: videoRef.value.buffered.length
            });
          }).catch((error) => {
            console.warn('[WebRTCPlayer] 视频自动播放失败:', error.name, error.message);
            // 如果自动播放失败，尝试静音后播放
            if (error.name === 'NotAllowedError') {
              console.log('[WebRTCPlayer] 尝试静音播放');
              videoRef.value.muted = true;
              videoRef.value.play().catch(e => {
                console.warn('[WebRTCPlayer] 静音播放也失败:', e.name, e.message);
              });
            }
          });
        } catch (e) {
          console.error('[WebRTCPlayer] 设置视频源失败:', e);
        }
      }
      
      emit('connected', { cameraId: props.cameraId, stream });
    } else {
      console.log('[WebRTCPlayer] 流为空，清除视频源');
      try {
        if (videoRef.value.srcObject) {
          const tracks = videoRef.value.srcObject.getTracks();
          if (tracks && Array.isArray(tracks)) {
            tracks.forEach(track => {
              if (track && typeof track.stop === 'function') {
                track.stop();
              }
            });
          }
        }
        videoRef.value.srcObject = null;
      } catch (e) {
        console.warn('[WebRTCPlayer] 清除视频源时出错:', e);
      }
    }
  });
})

watch(isConnected, (connected) => {
  if (connected) {
    showSuccess(`摄像头 ${props.cameraId} WebRTC连接成功`)
    emit('connected', { cameraId: props.cameraId })
  } else {
    emit('disconnected', { cameraId: props.cameraId })
  }
})

watch(error, (err) => {
  if (err) {
    showError(err)
    emit('error', { cameraId: props.cameraId, error: err })
  }
})

const handleConnect = () => {
  connect()
}

const handleReconnect = () => {
  disconnect()
  resetReconnectAttempts()
  setTimeout(() => {
    connect()
  }, 100)
}

onMounted(() => {
  console.log('[WebRTCPlayer] 组件已挂载')
  
  if (props.autoConnect) {
    console.log('[WebRTCPlayer] 500ms后自动连接...')
    setTimeout(() => {
      connect()
    }, 500)
  }
})

onUnmounted(() => {
  disconnect()
})

defineExpose({
  connect,
  disconnect,
  toggleConnection,
  isConnected,
  isConnecting
})
</script>

<style scoped>
.webrtc-player {
  position: relative;
  width: 100%;
  height: 100%;
  background: #000000;
  overflow: hidden;
}

.video-element {
  width: 100%;
  height: 100%;
  object-fit: cover;
  display: block;
}

.video-overlay {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: rgba(0, 0, 0, 0.7);
  z-index: 10;
}

.overlay-content {
  text-align: center;
  color: #fff;
  cursor: pointer;
}

.connect-icon,
.error-icon,
.loading-icon {
  display: block;
  margin: 0 auto 10px;
}

.loading-spinner {
  width: 40px;
  height: 40px;
  border: 4px solid rgba(255, 255, 255, 0.3);
  border-top-color: #409eff;
  border-radius: 50%;
  animation: spin 1s linear infinite;
  margin: 0 auto 15px;
}

@keyframes spin {
  to { transform: rotate(360deg); }
}

.connect-text,
.error-text {
  font-size: 14px;
  display: block;
  margin-bottom: 5px;
}

.reconnect-text {
  font-size: 12px;
  color: #888;
}

.error-overlay {
  background-color: rgba(100, 0, 0, 0.7);
}

/* 性能统计面板 */
.perf-stats-panel {
  position: absolute;
  top: 50px;
  right: 10px;
  background-color: rgba(0, 0, 0, 0.9);
  padding: 12px 16px;
  border-radius: 8px;
  font-family: monospace;
  font-size: 13px;
  z-index: 20;
  min-width: 140px;
}

.perf-stat {
  display: flex;
  justify-content: space-between;
  gap: 20px;
  margin-bottom: 8px;
  align-items: center;
}

.perf-stat:last-child {
  margin-bottom: 0;
}

.perf-label {
  color: rgba(255, 255, 255, 0.7);
  flex-shrink: 0;
}

.perf-value {
  color: #fff;
  font-weight: bold;
  min-width: 60px;
  text-align: right;
}

.perf-value.good {
  color: #6bcb77;
}

.perf-value.warning {
  color: #ffd43b;
}

.retry-text {
  font-size: 12px;
  color: #ffd43b;
  display: block;
  margin-top: 5px;
}
</style>
