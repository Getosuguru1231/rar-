<template>
  <div class="mjpeg-player" ref="containerRef">
    <img
      ref="imgRef"
      :src="streamUrl"
      class="video-image"
      :class="{ 'loading': isLoading }"
      @load="handleLoad"
      @error="handleError"
      crossorigin="anonymous"
    />
    
    <!-- 加载状态覆盖层 -->
    <div v-if="isLoading" class="video-overlay">
      <div class="overlay-content">
        <div class="loading-spinner"></div>
        <span class="overlay-text">正在加载视频流...</span>
      </div>
    </div>
    
    <!-- 错误状态覆盖层 -->
    <div v-if="hasError" class="video-overlay error-overlay">
      <div class="overlay-content" @click="handleRetry">
        <span class="error-text">视频加载失败</span>
        <span class="reconnect-text">点击重试</span>
      </div>
    </div>
    
    <!-- 性能统计显示 -->
    <div v-if="showStats" class="perf-stats-panel">
      <div class="perf-stat">
        <span class="perf-label">状态:</span>
        <span class="perf-value" :class="!hasError ? 'good' : 'warning'">
          {{ !hasError ? '正常' : '错误' }}
        </span>
      </div>
      <div class="perf-stat">
        <span class="perf-label">模式:</span>
        <span class="perf-value">MJPEG</span>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, onUnmounted } from 'vue'
import { buildVideoStreamUrl } from '@/utils/monitorHelpers.js'

const props = defineProps({
  cameraId: {
    type: [Number, String],
    required: true
  },
  quality: {
    type: String,
    default: 'high'
  },
  fps: {
    type: Number,
    default: 25
  },
  showStats: {
    type: Boolean,
    default: false
  },
  useDirectStream: {
    type: Boolean,
    default: false
  }
})

const emit = defineEmits([
  'connected',
  'error'
])

const containerRef = ref(null)
const imgRef = ref(null)
const isLoading = ref(true)
const hasError = ref(false)
const retryCount = ref(0)
const maxRetryCount = 5
const retryTimer = ref(null)

const streamUrl = computed(() => {
  if (props.useDirectStream) {
    return '/api/remote_video'
  }
  return buildVideoStreamUrl({
    camera: props.cameraId,
    quality: props.quality,
    fps: props.fps
  })
})

const handleLoad = () => {
  console.log('[MJPEGPlayer] 视频流加载成功')
  isLoading.value = false
  hasError.value = false
  retryCount.value = 0
  clearTimeout(retryTimer.value)
  emit('connected', { cameraId: props.cameraId })
}

const handleError = (error) => {
  console.error('[MJPEGPlayer] 视频流加载失败:', error)
  isLoading.value = false
  hasError.value = true
  emit('error', { cameraId: props.cameraId, error: '视频流加载失败' })
  
  if (retryCount.value < maxRetryCount) {
    retryCount.value++
    const delay = Math.min(retryCount.value * 2000, 10000)
    console.log(`[MJPEGPlayer] ${delay}ms后自动重试第${retryCount.value}次`)
    retryTimer.value = setTimeout(() => {
      handleRetry()
    }, delay)
  } else {
    console.error('[MJPEGPlayer] 达到最大重试次数，停止自动重试')
  }
}

const handleRetry = () => {
  console.log('[MJPEGPlayer] 重试加载视频流')
  isLoading.value = true
  hasError.value = false
  if (imgRef.value) {
    const originalSrc = imgRef.value.src
    imgRef.value.src = ''
    setTimeout(() => {
      if (imgRef.value) {
        imgRef.value.src = streamUrl.value + '&t=' + Date.now()
      }
    }, 100)
  }
}

onMounted(() => {
  console.log('[MJPEGPlayer] 组件已挂载，流地址:', streamUrl.value)
})

onUnmounted(() => {
  console.log('[MJPEGPlayer] 组件已卸载')
  clearTimeout(retryTimer.value)
})
</script>

<style scoped>
.mjpeg-player {
  position: relative;
  width: 100%;
  height: 100%;
  background: #000000;
  overflow: hidden;
}

.video-image {
  width: 100%;
  height: 100%;
  object-fit: contain;
  display: block;
}

.video-image.loading {
  opacity: 0.5;
}

.video-overlay {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  background: rgba(0, 0, 0, 0.7);
  z-index: 10;
}

.overlay-content {
  text-align: center;
  color: white;
}

.loading-spinner {
  width: 40px;
  height: 40px;
  border: 3px solid rgba(255, 255, 255, 0.3);
  border-top-color: #00d4ff;
  border-radius: 50%;
  animation: spin 1s linear infinite;
  margin: 0 auto 15px;
}

@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}

.overlay-text {
  font-size: 14px;
  color: rgba(255, 255, 255, 0.8);
}

.error-overlay {
  cursor: pointer;
}

.error-overlay:hover {
  background: rgba(0, 0, 0, 0.8);
}

.error-text {
  color: #ff6b6b;
  font-size: 14px;
  display: block;
  margin-bottom: 10px;
}

.reconnect-text {
  font-size: 12px;
  color: rgba(255, 255, 255, 0.6);
}

.perf-stats-panel {
  position: absolute;
  top: 50px;
  right: 10px;
  background: rgba(0, 0, 0, 0.9);
  padding: 12px 16px;
  border-radius: 8px;
  font-size: 13px;
  z-index: 20;
  min-width: 140px;
}

.perf-stat {
  display: flex;
  justify-content: space-between;
  gap: 20px;
  margin-bottom: 8px;
  color: white;
  align-items: center;
}

.perf-stat:last-child {
  margin-bottom: 0;
}

.perf-label {
  color: rgba(255, 255, 255, 0.7);
  flex-shrink: 0;
}

.perf-value {
  font-weight: bold;
  min-width: 60px;
  text-align: right;
}

.perf-value.good {
  color: #00ff88;
}

.perf-value.warning {
  color: #ffa502;
}
</style>
