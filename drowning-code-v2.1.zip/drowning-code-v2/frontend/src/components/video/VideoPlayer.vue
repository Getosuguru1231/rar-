<!-- src/components/VideoPlayer.vue -->
<template>
  <div class="video-player-component">
    <div class="zoom-container" ref="zoomContainerRef">
      <div 
        class="video-wrapper"
        :class="{ 'has-error': videoError, 'has-alert': hasAlert, 'buffering': isBuffering }"
      >
        <!-- WebRTC视频流（固定使用WebRTC，防止MJPEG干扰） -->
        <video
          ref="videoRef"
          class="video-stream"
          :class="{ 'video-loaded': webrtcConnected }"
          autoplay
          muted
          playsinline
          preload="none"
          @error="handleVideoError"
        />

        <!-- 错误提示 -->
        <div v-if="videoError" class="video-error" @click="handleReconnect">
          <span>{{ errorMsg }}</span>
          <span>点击重新加载</span>
        </div>

        <!-- 缓冲提示 -->
        <div v-if="isBuffering" class="video-buffering">
          <el-icon class="is-loading"><Loading /></el-icon>
          <span>加载中...</span>
        </div>

        <!-- AI检测框 -->
        <div 
          v-for="box in aiBoxList" 
          :key="box.id"
          class="ai-box"
          :style="{
            left: box.x + 'px',
            top: box.y + 'px',
            width: box.width + 'px',
            height: box.height + 'px',
            border: `2px solid ${box.color}`
          }"
        >
          <div class="ai-box-label">{{ box.label }}</div>
        </div>

        <!-- 告警覆盖层 -->
        <div v-if="hasAlert" class="alert-overlay"></div>
        
        <!-- 视频信息 -->
        <div class="video-info" v-if="showStats">
          <span class="fps-info">FPS: {{ displayFps.toFixed(1) }}</span>
          <span class="quality-info">质量: {{ qualityLabel }}</span>
          <span class="latency-info">延迟: {{ avgLatency.toFixed(1) }}ms</span>
        </div>
      </div>
    </div>

    <div class="video-controls">
      <el-button type="primary" size="small" @click="handlePlay" v-if="!isPlaying">播放</el-button>
      <el-button type="warning" size="small" @click="handlePause" v-else>暂停</el-button>
      <el-button type="info" size="small" @click="handleReconnect">重连</el-button>
      <el-button type="success" size="small" @click="handleFullscreen">全屏</el-button>
      <el-select v-model="videoQuality" size="small" @change="handleQualityChange" style="width: 100px;">
        <el-option label="超清" value="ultra" />
        <el-option label="高清" value="high" />
        <el-option label="标清" value="medium" />
        <el-option label="流畅" value="low" />
      </el-select>
      <el-switch
        v-model="useWebRTCMode"
        active-text="WebRTC"
        inactive-text="WebSocket"
        @change="handleConnectionModeChange"
        style="width: 120px;"
      />
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, onUnmounted, watch, markRaw, nextTick } from 'vue'
import { toggleFullscreen, showError, showInfo, showSuccess } from '@/utils'
import { Loading } from '@element-plus/icons-vue'
import { useVideoStream } from '../../composables/useVideoStream.js'
import { useWebRTC } from '../../composables/useWebRTC.js'
import { getVideoWsUrl, VIDEO_STREAM_CONFIG } from '@/config/websocket.js'

// WebSocket连接变量
let ws = null
let wsReconnectTimer = null
const wsConnected = ref(false)
const wsUrl = ref('')

// 视频质量配置
const videoQuality = ref('high')

// 连接模式标志
const useWebRTCMode = ref(true)
const useWebSocketMode = ref(false)

// 缓冲区配置常量
const DOUBLE_BUFFER_SIZE = 5
const FRAME_BUFFER_SIZE = 10

// 视频质量配置映射
const qualityConfig = {
  ultra: { quality: 95, fps: 30 },
  high: { quality: 85, fps: 25 },
  medium: { quality: 70, fps: 15 },
  low: { quality: 50, fps: 10 }
}

// 视频统计数据
const videoStats = ref({
  fps: 0,
  quality: 'high',
  droppedFrames: 0,
  totalFrames: 0,
  avgFrameTime: 0,
  frameTimeHistory: []
})

// 视频源引用
const videoSrc = ref('')

const props = defineProps({
  cameraId: {
    type: Number,
    default: 1
  },
  useWebRTC: {
    type: Boolean,
    default: true
  },
  useDirectStream: {
    type: Boolean,
    default: false
  }
})

const emit = defineEmits(['video-loaded', 'video-error', 'video-stats'])

// 统一的视频流加载处理基函数
const handleImageLoadBase = (cameraId, event) => {
  console.log(`[VideoPlayer] 通用加载处理 - 摄像头${cameraId}`)
}

// 统一的视频流错误处理基函数
const handleImageErrorBase = (cameraId, event) => {
  console.log(`[VideoPlayer] 通用错误处理 - 摄像头${cameraId}`)
}

const webrtcInstance = ref(null)

const initWebRTCInstance = () => {
  if (webrtcInstance.value) {
    webrtcInstance.value.disconnect()
  }
  webrtcInstance.value = useWebRTC(props.cameraId)
  return webrtcInstance.value
}

const getWebRTCInstance = () => {
  if (!webrtcInstance.value) {
    initWebRTCInstance()
  }
  return webrtcInstance.value
}

const webrtcStream = computed(() => {
  const instance = webrtcInstance.value
  return instance?.remoteStream?.value || null
})

const webrtcConnected = computed(() => {
  const instance = webrtcInstance.value
  return instance?.isConnected?.value || false
})

const webrtcConnecting = computed(() => {
  const instance = webrtcInstance.value
  return instance?.isConnecting?.value || false
})

const webrtcError = computed(() => {
  const instance = webrtcInstance.value
  return instance?.error?.value || null
})

const webrtcConnect = () => {
  const instance = getWebRTCInstance()
  if (instance) {
    instance.connect()
  }
}

const webrtcDisconnect = () => {
  if (webrtcInstance.value) {
    webrtcInstance.value.disconnect()
    webrtcInstance.value = null
  }
}

const videoRef = ref(null)
const zoomContainerRef = ref(null)
const videoError = ref(false)
const errorMsg = ref('视频加载失败')
const isPlaying = ref(false)
const hasAlert = ref(false)
const videoLoaded = ref(false)
const isBuffering = ref(false)

// 使用 markRaw 避免响应式开销
const aiBoxList = ref([])

// 性能优化变量
let statsUpdateTimer = null
let lastStatsUpdate = 0
const STATS_UPDATE_INTERVAL = 2000



// 性能监控集成
let performanceCheckTimer = null

// 网络状态监测（使用 markRaw 避免不必要的响应式）
const networkStatus = markRaw({
  isOnline: navigator.onLine,
  connectionType: navigator.connection?.effectiveType || 'unknown',
  downlink: navigator.connection?.downlink || 0
})

// 事件监听器引用，用于清理
const eventListeners = []

// 性能统计数据（使用 ref 代替响应式对象，减少内存占用）
const fpsHistory = ref([])
const latencyHistory = ref([])
const totalFrames = ref(0)
const droppedFrames = ref(0)

// 计算属性：显示FPS（使用移动平均）
const displayFps = computed(() => {
  if (fpsHistory.value.length === 0) return 0
  const sum = fpsHistory.value.reduce((a, b) => a + b, 0)
  return sum / fpsHistory.value.length
})

// 计算属性：平均延迟
const avgLatency = computed(() => {
  if (latencyHistory.value.length === 0) return 0
  const sum = latencyHistory.value.reduce((a, b) => a + b, 0)
  return sum / latencyHistory.value.length
})

// 计算属性：质量标签
const qualityLabel = computed(() => {
  const labels = { ultra: '超清', high: '高清', medium: '标清', low: '流畅' }
  return labels[videoQuality.value] || videoQuality.value
})

// 计算属性：是否显示统计信息
const showStats = computed(() => videoLoaded.value && !videoError.value)

// 自适应质量调整
const adjustVideoQuality = () => {
  if (networkStatus.connectionType === '4g' && networkStatus.downlink >= 5) {
    videoQuality.value = 'high'
  } else if (networkStatus.connectionType === '3g' || networkStatus.downlink < 3) {
    videoQuality.value = 'low'
  } else {
    videoQuality.value = 'medium'
  }
}

// 智能自适应质量调整（基于性能指标）
const smartAdjustQuality = () => {
  const avgFrameTime = videoStats.value.avgFrameTime || 0
  const dropRate = videoStats.value.droppedFrames / (videoStats.value.totalFrames || 1)
  
  // 如果平均帧时间超过100ms，降低质量
  if (avgFrameTime > 100 && videoQuality.value !== 'low') {
    const qualities = ['ultra', 'high', 'medium', 'low']
    const currentIndex = qualities.indexOf(videoQuality.value)
    if (currentIndex < qualities.length - 1) {
      videoQuality.value = qualities[currentIndex + 1]
      showInfo(`性能优化：自动降低画质为${getQualityLabel(videoQuality.value)}`)
      return true
    }
  }
  
  // 如果丢帧率超过20%，降低质量
  if (dropRate > 0.2 && videoQuality.value !== 'low') {
    const qualities = ['ultra', 'high', 'medium', 'low']
    const currentIndex = qualities.indexOf(videoQuality.value)
    if (currentIndex < qualities.length - 1) {
      videoQuality.value = qualities[currentIndex + 1]
      showInfo(`网络波动：自动降低画质为${getQualityLabel(videoQuality.value)}`)
      return true
    }
  }
  
  // 如果性能良好，可以提升质量（需要稳定的网络）
  if (avgFrameTime < 30 && dropRate < 0.05 && networkStatus.downlink > 5) {
    const qualities = ['ultra', 'high', 'medium', 'low']
    const currentIndex = qualities.indexOf(videoQuality.value)
    if (currentIndex > 0 && consecutiveFrameLoss === 0) {
      videoQuality.value = qualities[currentIndex - 1]
      showInfo(`网络良好：提升画质为${getQualityLabel(videoQuality.value)}`)
      return true
    }
  }
  
  return false
}

// 启动性能检查
const startPerformanceCheck = () => {
  if (performanceCheckTimer) {
    clearInterval(performanceCheckTimer)
  }
  
  performanceCheckTimer = setInterval(() => {
    // 检查是否需要调整质量
    smartAdjustQuality()
  }, 10000) // 每10秒检查一次
}

// 停止性能检查
const stopPerformanceCheck = () => {
  if (performanceCheckTimer) {
    clearInterval(performanceCheckTimer)
    performanceCheckTimer = null
  }
}

// 安全添加事件监听器
const addSafeEventListener = (target, event, handler, options) => {
  target.addEventListener(event, handler, options)
  eventListeners.push({ target, event, handler, options })
}

// 初始化网络状态监测
const initNetworkMonitor = () => {
  addSafeEventListener(window, 'online', () => {
    networkStatus.isOnline = true
    requestIdleCallback(() => adjustVideoQuality())
  })
  
  addSafeEventListener(window, 'offline', () => {
    networkStatus.isOnline = false
  })
  
  if (navigator.connection) {
    addSafeEventListener(navigator.connection, 'change', () => {
      networkStatus.connectionType = navigator.connection.effectiveType
      networkStatus.downlink = navigator.connection.downlink
      requestIdleCallback(() => adjustVideoQuality())
    })
  }
  
  adjustVideoQuality()
}

// 帧缓存，用于优化渲染性能
const frameCache = {
  lastFrameData: null,
  lastFrameTime: 0,
  frameCount: 0
}

// 双缓冲管理器
const doubleBufferManager = {
  buffer: [],
  maxSize: DOUBLE_BUFFER_SIZE,
  
  addFrame(frameData) {
    this.buffer.push({
      data: frameData,
      timestamp: Date.now()
    })
    
    if (this.buffer.length > this.maxSize) {
      this.buffer.shift()
    }
  },
  
  getLatestFrame() {
    if (this.buffer.length === 0) return null
    return this.buffer[this.buffer.length - 1]
  },
  
  clear() {
    this.buffer = []
  },
  
  getBufferStatus() {
    return {
      size: this.buffer.length,
      maxSize: this.maxSize,
      isReady: this.buffer.length > 0
    }
  }
}

// WebRTC失败后自动降级到WebSocket
let webrtcFailedCount = 0
const MAX_WEBRTC_RETRIES = 2

// 初始化视频播放器（简化版本，无防抖）
const initVideoPlayer = () => {
  videoError.value = false
  isBuffering.value = true
  
  // 检查网络状态
  if (!networkStatus.isOnline) {
    videoError.value = true
    errorMsg.value = '网络连接已断开，请检查网络后重试'
    showError(errorMsg.value)
    return
  }
  
  // 启动心跳检测
  startHeartbeat()
  
  // 固定使用WebRTC连接（防止MJPEG干扰）
  console.log('[VideoPlayer] 使用WebRTC视频流模式（固定）')
  initWebRTCPlayer()
}

// WebRTC视频流初始化
const initWebRTCPlayer = () => {
  console.log(`[VideoPlayer] 初始化WebRTC播放器，摄像头ID: ${props.cameraId}`)
  
  if (!webrtcInstance.value) {
    console.log('[VideoPlayer] WebRTC实例不存在，初始化...')
    initWebRTCInstance()
  }
  
  if (webrtcConnecting.value) {
    console.log('[VideoPlayer] WebRTC已在连接中')
    return
  }
  
  if (webrtcConnected.value) {
    console.log('[VideoPlayer] WebRTC已连接')
    videoLoaded.value = true
    isPlaying.value = true
    
    const stream = webrtcStream.value
    if (stream && videoRef.value) {
      videoRef.value.srcObject = stream
      videoRef.value.play().catch(e => console.warn('[VideoPlayer] 播放失败:', e))
    }
    return
  }
  
  isBuffering.value = true
  webrtcConnect()
}

// 监听WebRTC连接状态
watch(webrtcStream, async (stream) => {
  if (stream) {
    await nextTick()
    if (videoRef.value) {
      try {
        const videoEl = videoRef.value
        
        videoEl.autoplay = true
        videoEl.muted = true
        videoEl.playsInline = true
        videoEl.preload = 'none'
        
        if ('playbackRate' in videoEl) {
          videoEl.playbackRate = 1.0
        }
        
        videoEl.srcObject = stream
        
        try {
          await videoEl.play()
        } catch (playError) {
          console.warn('[VideoPlayer] 自动播放失败:', playError)
        }
        
        videoLoaded.value = true
        isPlaying.value = true
        isBuffering.value = false
        videoError.value = false
        emit('video-loaded', { cameraId: props.cameraId, stream })
        console.log(`[VideoPlayer] WebRTC视频流已设置到video元素，摄像头ID: ${props.cameraId}`)
      } catch (e) {
        console.error(`[VideoPlayer] 设置视频流失败，摄像头ID: ${props.cameraId}`, e)
        videoError.value = true
        errorMsg.value = '设置视频流失败: ' + e.message
      }
    } else {
      console.warn(`[VideoPlayer] video元素未挂载，摄像头ID: ${props.cameraId}`)
      setTimeout(() => {
        if (videoRef.value && stream) {
          videoRef.value.srcObject = stream
        }
      }, 500)
    }
  }
})

watch(webrtcConnected, (connected) => {
  if (connected) {
    showSuccess(`摄像头 ${props.cameraId} WebRTC连接成功`)
    videoLoaded.value = true
    isPlaying.value = true
    isBuffering.value = false
    videoError.value = false
    reconnectCount.value = 0
    emit('video-loaded', { cameraId: props.cameraId })
    
    const stream = webrtcStream.value
    if (stream && videoRef.value) {
      videoRef.value.srcObject = stream
      videoRef.value.play().catch(e => console.warn('[VideoPlayer] 播放失败:', e))
      console.log(`[VideoPlayer] WebRTC连接成功，设置视频流到video元素，摄像头ID: ${props.cameraId}`)
    }
  }
})

watch(webrtcError, (err) => {
  if (err) {
    videoError.value = true
    isPlaying.value = false
    errorMsg.value = err
    showError(err)
    emit('video-error', { cameraId: props.cameraId, error: err })
    
    // WebRTC失败，增加失败计数，准备降级
    webrtcFailedCount++
    console.log(`[VideoPlayer] WebRTC失败次数: ${webrtcFailedCount}/${MAX_WEBRTC_RETRIES}`)
    
    // 如果达到最大重试次数，自动切换到WebSocket模式
    if (webrtcFailedCount >= MAX_WEBRTC_RETRIES) {
      // 更新模式标志，使模板能正确显示对应的元素
      useWebRTCMode.value = false
      useWebSocketMode.value = true
      
      // 延迟后重新初始化，使用降级模式
      setTimeout(() => {
        initVideoPlayer()
      }, 1000)
    }
  }
})

// 销毁视频播放器
const destroyVideoPlayer = () => {
  // 清理定时器
  if (statsUpdateTimer) {
    clearTimeout(statsUpdateTimer)
    statsUpdateTimer = null
  }
  
  // 清理心跳定时器
  if (heartbeatTimer) {
    clearInterval(heartbeatTimer)
    heartbeatTimer = null
  }
  
  // 关闭WebSocket连接
  closeWebSocket()
  
  // 停止帧缓冲区管理器
  frameBufferManager.stop()
  
  // 关闭WebRTC连接
  if (useWebRTCMode.value) {
    webrtcDisconnect()
  }
  
  if (videoRef.value) {
    videoRef.value.pause()
    videoRef.value.srcObject = null
    videoRef.value.src = ''
    videoRef.value.load()
  }
  
  // 清理事件监听器
  eventListeners.forEach(({ target, event, handler, options }) => {
    try {
      target.removeEventListener(event, handler, options)
    } catch (e) {
      console.warn('清理事件监听器失败:', e)
    }
  })
  eventListeners.length = 0
  
  // 重置性能统计
  fpsHistory.value = []
  latencyHistory.value = []
  totalFrames.value = 0
  droppedFrames.value = 0
  
  isPlaying.value = false
  videoLoaded.value = false
}

// 心跳检测
const startHeartbeat = () => {
  if (heartbeatTimer) {
    clearInterval(heartbeatTimer)
  }
  lastHeartbeatTime = Date.now()
  
  heartbeatTimer = setInterval(() => {
    const now = Date.now()
    const timeSinceLastHeartbeat = now - lastHeartbeatTime
    
    // 如果超过心跳超时时间，认为连接已断开
    if (timeSinceLastHeartbeat > HEARTBEAT_TIMEOUT && !videoError.value) {
      console.warn('[VideoPlayer] 心跳超时，尝试重连...')
      handleImageError(props.cameraId, new Error('Heartbeat timeout'))
    }
  }, HEARTBEAT_INTERVAL)
}

// FPS 计算
let frameCount = 0
let lastFpsTime = Date.now()
let lastFrameTime = Date.now() // 用于计算帧加载时间

// 帧时间戳，用于帧去重
let lastFrameTimestamp = 0
const MIN_FRAME_INTERVAL = 33 // 最小帧间隔（约30fps）

// 处理WebSocket流加载成功
const handleImageLoad = (cameraId, event) => {
  // 调用统一的视频流加载处理
  handleImageLoadBase(cameraId, event)
  
  const now = Date.now()
  
  // 更新心跳时间
  lastHeartbeatTime = now
  
  // 帧去重：避免在短时间内渲染相同的帧
  if (now - lastFrameTimestamp < MIN_FRAME_INTERVAL) {
    return
  }
  lastFrameTimestamp = now
  
  frameCount++
  
  // 重置连续丢帧计数
  consecutiveFrameLoss = 0
  reconnectCount.value = 0
  
  // 计算帧加载时间
  const frameTime = now - lastFrameTime
  lastFrameTime = now
  
  // 更新帧时间历史（保留最近30个样本）
  videoStats.value.frameTimeHistory.push(frameTime)
  if (videoStats.value.frameTimeHistory.length > 30) {
    videoStats.value.frameTimeHistory.shift()
  }
  
  // 计算平均帧时间
  const sum = videoStats.value.frameTimeHistory.reduce((a, b) => a + b, 0)
  videoStats.value.avgFrameTime = sum / videoStats.value.frameTimeHistory.length
  videoStats.value.totalFrames++
  
  
  
  // 立即更新状态，避免加载中提示持续显示
  videoLoaded.value = true
  videoError.value = false
  isBuffering.value = false
  isPlaying.value = true
  
  // 使用requestAnimationFrame更新FPS统计，避免阻塞主线程
  requestAnimationFrame(() => {
    // 更新FPS统计
    if (now - lastFpsTime >= 1000) {
      videoStats.value.fps = Math.round(frameCount * 1000 / (now - lastFpsTime))
      videoStats.value.quality = videoQuality.value
      frameCount = 0
      lastFpsTime = now
      
      // 节流更新统计事件
      if (now - lastStatsUpdate >= STATS_UPDATE_INTERVAL) {
        lastStatsUpdate = now
        emit('video-stats', videoStats.value)
      }
    }
  })
  
  // 使用 requestIdleCallback 发送事件，避免阻塞渲染
  requestIdleCallback(() => {
    emit('video-loaded', { cameraId: props.cameraId })
  })
}

// 重连计数器
const reconnectCount = ref(0)
const MAX_RECONNECTS = 10
const reconnectDelay = ref(500)
const MIN_RECONNECT_DELAY = 500
const MAX_RECONNECT_DELAY = 8000
let reconnectTimer = null

// 帧丢失检测
let consecutiveFrameLoss = 0
const MAX_CONSECUTIVE_LOSS = 8

// 心跳检测
let heartbeatTimer = null
let lastHeartbeatTime = 0
const HEARTBEAT_INTERVAL = 3000 // 3秒心跳
const HEARTBEAT_TIMEOUT = 10000 // 10秒超时

// 处理WebSocket流加载失败
const handleImageError = (cameraId, event) => {
  // 调用统一的视频流错误处理
  handleImageErrorBase(cameraId, event)
  
  videoError.value = true
  isPlaying.value = false
  isBuffering.value = false
  
  consecutiveFrameLoss++
  
  if (reconnectTimer) {
    clearTimeout(reconnectTimer)
    reconnectTimer = null
  }
  
  // 自适应降质：如果连续丢帧过多，自动降低画质
  if (consecutiveFrameLoss >= MAX_CONSECUTIVE_LOSS && videoQuality.value !== 'low') {
    const qualities = ['ultra', 'high', 'medium', 'low']
    const currentIndex = qualities.indexOf(videoQuality.value)
    if (currentIndex < qualities.length - 1) {
      videoQuality.value = qualities[currentIndex + 1]
      showInfo(`网络不稳定，自动降低画质为：${getQualityLabel(videoQuality.value)}`)
      consecutiveFrameLoss = 0
    }
  }
  
  // 检查网络状态
  if (!networkStatus.isOnline) {
    errorMsg.value = '网络连接已断开，请检查网络后重试'
  } else if (reconnectCount.value >= MAX_RECONNECTS) {
    errorMsg.value = '视频加载失败，已达到最大重试次数，请手动刷新页面'
  } else {
    errorMsg.value = `视频加载失败，正在尝试重新连接... (${reconnectCount.value + 1}/${MAX_RECONNECTS})`
  }
  
  // 只在第一次错误时显示错误消息
  if (reconnectCount.value === 0) {
    showError(errorMsg.value)
  }
  
  requestIdleCallback(() => {
    emit('video-error', { cameraId: props.cameraId, error: errorMsg.value })
  })
  
  // 自动重试 - 使用指数退避策略
  if (reconnectCount.value < MAX_RECONNECTS) {
    reconnectCount.value++
    const backoffDelay = Math.min(
      MIN_RECONNECT_DELAY * Math.pow(2, reconnectCount.value - 1),
      MAX_RECONNECT_DELAY
    )
    reconnectTimer = setTimeout(() => {
      if (videoError.value) {
        initVideoPlayer()
      }
    }, backoffDelay)
  }
}

// 获取质量标签
const getQualityLabel = (quality) => {
  const labels = {
    ultra: '超清',
    high: '高清',
    medium: '标清',
    low: '流畅'
  }
  return labels[quality] || quality
}

// 处理视频流错误
const handleVideoError = (e) => {
  videoError.value = true
  isPlaying.value = false
  isBuffering.value = false
  errorMsg.value = '视频加载失败，请检查地址'
  showError(errorMsg.value)
  emit('video-error', { cameraId: props.cameraId, error: errorMsg.value })
}

// 处理视频可播放
const handleVideoCanPlay = () => {
  videoLoaded.value = true
  videoError.value = false
  isBuffering.value = false
  isPlaying.value = true
  emit('video-loaded', { cameraId: props.cameraId })
}

// 处理视频正在播放
const handleVideoPlaying = () => {
  isPlaying.value = true
  isBuffering.value = false
}

// 处理视频暂停
const handleVideoPause = () => {
  isPlaying.value = false
}

// 处理视频缓冲
const handleVideoWaiting = () => {
  isBuffering.value = true
}

// 处理视频结束
const handleVideoEnded = () => {
  isPlaying.value = false
  setTimeout(() => {
    initVideoPlayer()
  }, 1000)
}

// 播放视频
const handlePlay = () => {
  if (!videoRef.value || videoError.value) return
  videoRef.value.play().then(() => {
    isPlaying.value = true
    showSuccess('视频开始播放')
  }).catch(err => {
    errorMsg.value = '播放失败：' + err.message
    videoError.value = true
  })
}

// 暂停视频
const handlePause = () => {
  if (!videoRef.value) return
  videoRef.value.pause()
  isPlaying.value = false
  showInfo('视频已暂停')
}

// 重新连接
const handleReconnect = () => {
  if (reconnectTimer) {
    clearTimeout(reconnectTimer)
    reconnectTimer = null
  }
  
  reconnectCount.value = 0
  reconnectDelay.value = 1000
  
  if (!networkStatus.isOnline) {
    showInfo('网络连接已断开，请检查网络后重试')
    return
  }
  
  videoError.value = false
  isBuffering.value = true
  showInfo('正在重新加载视频...')
}

// 全屏
const handleFullscreen = () => {
  toggleFullscreen(zoomContainerRef.value)
}

// 帧缓冲区管理器（优化延迟 - 立即渲染）
const frameBufferManager = {
  buffer: [],
  maxSize: FRAME_BUFFER_SIZE,
  isPlaying: false,
  lastRenderTime: 0,
  renderInterval: 1000 / 10,  // 与后端帧率匹配
  
  addFrame(blobData) {
    const newFrame = {
      data: blobData,
      timestamp: Date.now()
    }
    
    if (this.buffer.length >= this.maxSize) {
      const oldest = this.buffer.shift()
      if (oldest.data instanceof Blob) {
        URL.revokeObjectURL(oldest.url)
      }
      droppedFrames.value++
    }
    
    this.buffer.push(newFrame)
    totalFrames.value++
    
    if (!this.isPlaying) {
      this.startRendering()
    } else {
      this.tryRenderImmediately()
    }
  },
  
  tryRenderImmediately() {
    if (this.buffer.length > 0) {
      const now = Date.now()
      // 如果有多个帧等待，立即渲染；否则按间隔控制
      if (this.buffer.length > 1 || now - this.lastRenderTime >= this.renderInterval / 2) {
        this.renderNextFrame()
      }
    }
  },
  
  startRendering() {
    if (this.isPlaying) return
    this.isPlaying = true
    this.renderNextFrame()
  },
  
  renderNextFrame() {
    if (!this.isPlaying || this.buffer.length === 0) {
      this.isPlaying = false
      return
    }
    
    const frame = this.buffer.shift()
    if (!frame) {
      this.isPlaying = false
      return
    }
    
    const now = Date.now()
    this.lastRenderTime = now
    
    try {
      const blobUrl = URL.createObjectURL(frame.data)
      videoSrc.value = blobUrl
      
      setTimeout(() => {
        try {
          URL.revokeObjectURL(blobUrl)
        } catch (e) {}
      }, 300)  // 缩短清理时间
      
      // 更新性能统计
      const latency = now - frame.timestamp
      updatePerformanceStats(latency)
      
    } catch (e) {
      console.warn('[VideoPlayer] 渲染帧失败:', e)
    }
    
    if (this.buffer.length > 0) {
      requestAnimationFrame(() => this.renderNextFrame())
    } else {
      this.isPlaying = false
    }
  },
  
  stop() {
    this.isPlaying = false
    this.buffer.forEach(frame => {
      if (frame.url) {
        URL.revokeObjectURL(frame.url)
      }
    })
    this.buffer = []
  },
  
  getStats() {
    return {
      bufferSize: this.buffer.length,
      maxSize: this.maxSize,
      isPlaying: this.isPlaying,
      droppedFrames: droppedFrames.value,
      totalFrames: totalFrames.value
    }
  }
}

// 更新性能统计
let frameCount = 0
let lastFpsTime = Date.now()
const updatePerformanceStats = (latency) => {
  frameCount++
  const now = Date.now()
  
  latencyHistory.value.push(latency)
  if (latencyHistory.value.length > 10) {
    latencyHistory.value.shift()
  }
  
  if (now - lastFpsTime >= 1000) {
    const fps = frameCount * 1000 / (now - lastFpsTime)
    fpsHistory.value.push(fps)
    if (fpsHistory.value.length > 10) {
      fpsHistory.value.shift()
    }
    frameCount = 0
    lastFpsTime = now
    
    if (now - lastStatsUpdate >= STATS_UPDATE_INTERVAL) {
      lastStatsUpdate = now
      emit('video-stats', {
        fps: displayFps.value,
        quality: videoQuality.value,
        droppedFrames: droppedFrames.value,
        avgFrameTime: avgLatency.value,
        totalFrames: totalFrames.value
      })
    }
  }
}

// WebSocket视频流连接（方案一：低延迟视频流）
const connectWebSocket = (cameraId, quality, fps) => {
  closeWebSocket()
  
  wsUrl.value = getVideoWsUrl(cameraId, { quality, fps })
  
  console.log(`[VideoPlayer] 连接WebSocket视频流: ${wsUrl.value}`)
  
  frameBufferManager.renderInterval = 1000 / fps
  
  try {
    ws = new WebSocket(wsUrl.value)
    ws.binaryType = 'blob'
    
    ws.onopen = (event) => {
      console.log('[VideoPlayer] WebSocket连接已建立')
      wsConnected.value = true
      videoError.value = false
      isBuffering.value = false
      isPlaying.value = true
      reconnectCount.value = 0
      showSuccess('WebSocket视频流连接成功')
    }
    
    ws.onmessage = (event) => {
      if (!videoRef.value) return
      
      lastHeartbeatTime = Date.now()
      
      if (event.data instanceof Blob) {
        frameBufferManager.addFrame(event.data)
        videoLoaded.value = true
        isBuffering.value = false
      }
    }
    
    ws.onerror = (error) => {
      console.error('[VideoPlayer] WebSocket错误:', error)
      handleWsError('WebSocket连接错误')
    }
    
    ws.onclose = (event) => {
      console.log(`[VideoPlayer] WebSocket连接关闭: code=${event.code}, reason=${event.reason}`)
      wsConnected.value = false
      frameBufferManager.stop()
      
      if (event.code !== 1000) {
        handleWsError('WebSocket连接断开')
      }
    }
    
  } catch (error) {
    console.error('[VideoPlayer] 创建WebSocket连接失败:', error)
    handleWsError('创建WebSocket连接失败')
  }
}

// 处理WebSocket错误
const handleWsError = (message) => {
  videoError.value = true
  isPlaying.value = false
  consecutiveFrameLoss++
  
  // 自适应降质
  if (consecutiveFrameLoss >= MAX_CONSECUTIVE_LOSS && videoQuality.value !== 'low') {
    const qualities = ['ultra', 'high', 'medium', 'low']
    const currentIndex = qualities.indexOf(videoQuality.value)
    if (currentIndex < qualities.length - 1) {
      videoQuality.value = qualities[currentIndex + 1]
      showInfo(`网络不稳定，自动降低画质为：${getQualityLabel(videoQuality.value)}`)
      consecutiveFrameLoss = 0
    }
  }
  
  if (reconnectCount.value < MAX_RECONNECTS) {
    reconnectCount.value++
    const backoffDelay = Math.min(
      MIN_RECONNECT_DELAY * Math.pow(2, reconnectCount.value - 1),
      MAX_RECONNECT_DELAY
    )
    
    errorMsg.value = `${message}，${reconnectCount.value}/${MAX_RECONNECTS} 秒后重试...`
    
    wsReconnectTimer = setTimeout(() => {
      if (videoError.value && networkStatus.isOnline) {
        initVideoPlayer()
      }
    }, backoffDelay)
  } else {
    errorMsg.value = '视频流连接失败，已达到最大重试次数'
    showError(errorMsg.value)
  }
  
  emit('video-error', { cameraId: props.cameraId, error: errorMsg.value })
}

// 关闭WebSocket连接
const closeWebSocket = () => {
  if (ws) {
    try {
      ws.close(1000, '正常关闭')
    } catch (e) {
      console.warn('关闭WebSocket失败:', e)
    }
    ws = null
  }
  wsConnected.value = false
  
  if (wsReconnectTimer) {
    clearTimeout(wsReconnectTimer)
    wsReconnectTimer = null
  }
}

// 切换视频质量
const handleQualityChange = () => {
  showInfo(`切换视频质量为：${getQualityLabel(videoQuality.value)}`)
  initVideoPlayer()
}

// 模式切换处理
const handleConnectionModeChange = (newMode) => {
  console.log('[VideoPlayer] 模式切换:', newMode ? 'WebRTC' : 'WebSocket')
  
  useWebRTCMode.value = newMode
  useWebSocketMode.value = !newMode
  
  webrtcFailedCount = 0
  
  if (newMode) {
    closeWebSocket()
    webrtcDisconnect()
    videoLoaded.value = false
    isBuffering.value = true
    nextTick(() => {
      initWebRTCInstance()
      webrtcConnect()
    })
  } else {
    webrtcDisconnect()
    closeWebSocket()
    videoLoaded.value = false
    isBuffering.value = true
    nextTick(() => {
      const config = qualityConfig[videoQuality.value]
      const fps = config.fps || 12
      const quality = config.quality || 40
      connectWebSocket(props.cameraId, quality, fps)
    })
  }
}

// 监听cameraId变化
watch(() => props.cameraId, (newCameraId) => {
  requestIdleCallback(() => {
    // 销毁旧连接
    destroyVideoPlayer()
    // 重新初始化
    initVideoPlayer()
  })
})

// 监听useWebRTC变化
watch(() => props.useWebRTC, (newValue) => {
  useWebRTCMode.value = newValue
  useWebSocketMode.value = !newValue && !props.useDirectStream
  useDirectStreamMode.value = false
  requestIdleCallback(() => {
    destroyVideoPlayer()
    initVideoPlayer()
  })
})

// 监听useDirectStream变化
watch(() => props.useDirectStream, (newValue) => {
  useDirectStreamMode.value = newValue
  useWebSocketMode.value = !newValue && !props.useWebRTC
  useWebRTCMode.value = false
  requestIdleCallback(() => {
    destroyVideoPlayer()
    initVideoPlayer()
  })
})

onMounted(() => {
  initNetworkMonitor()
  initVideoPlayer()
  startPerformanceCheck() // 启动性能检查
})

onUnmounted(() => {
  destroyVideoPlayer()
  stopPerformanceCheck() // 停止性能检查
})
</script>

<style scoped>
.video-player-component {
  width: 100%;
  height: 100%;
  position: relative;
  overflow: hidden;
  box-sizing: border-box;
}

.zoom-container {
  width: 100%;
  height: 100%;
  position: relative;
  transform-origin: center center;
}

.video-wrapper {
  width: 100%;
  height: 100%;
  position: relative;
  background-color: #000;
  overflow: hidden;
  transition: all 0.3s ease;
}

.video-wrapper.buffering {
  background-color: #111;
}

.video-stream {
  width: 100%;
  height: 100%;
  object-fit: contain;
  outline: none;
  border: none;
  transition: opacity 0.3s ease;
}

.video-error {
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  color: #fff;
  font-size: 16px;
  cursor: pointer;
  background-color: #333;
  gap: 12px;
  position: absolute;
  top: 0;
  left: 0;
  z-index: 15;
}

.video-buffering {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 10px;
  color: #fff;
  background: rgba(0, 0, 0, 0.7);
  padding: 20px;
  border-radius: 8px;
  z-index: 15;
}

.video-buffering .el-icon {
  font-size: 32px;
  color: #409eff;
}

.ai-box {
  position: absolute;
  box-sizing: border-box;
  border-radius: 4px;
  pointer-events: none;
  z-index: 5;
}

.ai-box-label {
  position: absolute;
  top: -25px;
  left: 0;
  background-color: rgba(0,0,0,0.8);
  color: #fff;
  padding: 2px 8px;
  border-radius: 4px;
  font-size: 12px;
  white-space: nowrap;
}

.alert-overlay {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  border: 3px solid #f56c6c;
  pointer-events: none;
  z-index: 10;
  animation: pulse 1s infinite;
}

@keyframes pulse {
  0% {
    border-color: #f56c6c;
    opacity: 1;
  }
  50% {
    border-color: #f56c6c;
    opacity: 0.5;
  }
  100% {
    border-color: #f56c6c;
    opacity: 1;
  }
}

.video-info {
  position: absolute;
  top: 10px;
  left: 10px;
  display: flex;
  gap: 15px;
  background: rgba(0, 0, 0, 0.6);
  padding: 5px 10px;
  border-radius: 4px;
  font-size: 12px;
  color: #fff;
  z-index: 10;
}

.fps-info, .quality-info, .latency-info {
  display: flex;
  align-items: center;
  gap: 5px;
}

.latency-info {
  color: #67c23a;
}

.video-controls {
  position: absolute;
  bottom: 15px;
  right: 15px;
  display: flex;
  gap: 10px;
  z-index: 20;
  background: rgba(0,0,0,0.5);
  padding: 8px;
  border-radius: 8px;
  backdrop-filter: blur(10px);
}

.video-controls .el-select {
  color: #fff;
}

.video-controls .el-select .el-input__inner {
  color: #fff;
  background-color: rgba(255, 255, 255, 0.1);
  border-color: rgba(255, 255, 255, 0.3);
}

.video-controls .el-switch .el-switch__label {
  font-size: 12px;
}

.video-controls .el-switch .el-switch__label--left {
  color: #67c23a;
}

.video-controls .el-switch .el-switch__label--right {
  color: #409eff;
}

.video-controls .el-switch .el-switch__label.is-active {
  color: #409eff;
}

.video-wrapper.webrtc-mode {
  background-color: #0a0a1a;
}
</style>