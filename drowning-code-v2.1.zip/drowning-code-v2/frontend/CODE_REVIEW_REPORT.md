# 溺水监测系统前端代码审查报告

> 审查范围: `frontend/src/` 全部核心文件（26,379 行代码）
> 审查日期: 2026-07-02

---

## 一、代码统计

| 目录 | 行数 | 占比 |
|------|------|------|
| views/ | 11,070 | 42% |
| components/ | 7,280 | 27.5% |
| composables/ | 4,530 | 17% |
| utils/ | 2,254 | 8.5% |
| stores/ | 711 | 2.7% |
| api/ | 168 | 0.6% |
| util/ | 144 | 0.5% |
| config/ | 69 | 0.3% |
| **合计** | **26,379** | **100%** |

### Top 10 最大文件

| 文件 | 行数 |
|------|------|
| Monitor.vue | 4,852 |
| AdminPanel.vue | 1,704 |
| Dashboard.vue | 1,476 |
| VideoPlayer.vue | 1,410 |
| AlertManagement.vue | 1,407 |
| useVideoStream.js | 1,084 |
| useMonitor.js | 1,068 |
| DetectionHistory.vue | 923 |
| utils/index.js | 879 |
| useWebRTC.js | 833 |

---

## 二、问题清单（按文件分组）

### 2.1 入口与配置

#### `main.js` (12 行)

| 严重度 | 类型 | 行号 | 问题描述 | 修复建议 |
|--------|------|------|----------|----------|
| P1 | ⚠️ 性能 | 全文件 | Element Plus 全量导入 (`import ElementPlus from 'element-plus'`)，打包体积过大 | 使用 `unplugin-vue-components` + `unplugin-auto-import` 按需自动导入 |
| P1 | 🐛 Bug | 全文件 | 未注册 Pinia，但项目存在 stores 目录且 `deviceData.js` 有完整 store 结构 | 安装 Pinia 并在 `main.js` 注册，或统一 store 方案 |

#### `App.vue` (20 行)

| 严重度 | 类型 | 行号 | 问题描述 | 修复建议 |
|--------|------|------|----------|----------|
| P2 | 🧹 维护性 | 4-7 | 全局 `*` 选择器 CSS reset (`margin:0;padding:0;box-sizing:border-box`) 会覆盖 Element Plus 组件默认样式 | 使用更精确的选择器或 `normalize.css`，避免全局通配符 |

#### `router/index.js` (124 行)

| 严重度 | 类型 | 行号 | 问题描述 | 修复建议 |
|--------|------|------|----------|----------|
| P2 | 🧹 维护性 | 69,87,95,103 | 路由守卫中大量 `console.log` 调试语句留在生产代码中 | 删除所有调试 console.log，或用 `import.meta.env.DEV` 条件控制 |
| P0 | 🔒 安全 | ~82 | `/test-webrtc` 路由设置了 `requiresAuth: false`，绕过认证 | 删除该路由或添加认证要求 |
| P1 | 🐛 Bug | 118-119 | `router.onError` 中遇到重定向循环时清空 **所有** localStorage (`localStorage.clear()`)，不仅清除 token，还会清除用户偏好等数据 | 只清除 `token`、`username`、`userType` 三个字段 |
| P2 | 🧹 维护性 | 118 | `error.message.includes('Redirected')` 依赖错误消息字符串匹配，脆弱 | 使用 `error.code` 或 `error.type` 判断，避免依赖不确定的消息格式 |

#### `vite.config.js` (51 行)

| 严重度 | 类型 | 行号 | 问题描述 | 修复建议 |
|--------|------|------|----------|----------|
| P0 | 🔒 安全 | 21 | 后端代理地址硬编码 `http://10.64.90.195:8899`，任何使用此代码的人都能看到内部 IP | 使用 `import.meta.env.VITE_API_URL` 或 `.env` 文件管理 |
| P1 | 🐛 Bug | 21-29 | `/api/remote_video` 和 `/api` 代理规则重叠：`/api` 匹配所有 `/api/*` 路径，`/api/remote_video` 作为 `/api` 子路径会被 `/api` 规则先匹配 | 将 `/api/remote_video` 放在 `/api` 之前（Vite proxy 按顺序匹配），或调整路径 |
| P2 | ⚠️ 性能 | 21 | `host: '0.0.0.0'` 开发服务器监听所有网络接口，开发时可能暴露到局域网 | 开发时使用 `localhost`，仅需要外部访问时改为 `0.0.0.0` |

#### `package.json` (52 行)

| 严重度 | 类型 | 行号 | 问题描述 | 修复建议 |
|--------|------|------|----------|----------|
| P1 | 🐛 Bug | 依赖区 | 未安装 Pinia 但有 stores 文件，且手动管理响应式 | 添加 `pinia` 依赖或完全移除 store 文件 |
| P2 | ⚠️ 性能 | 依赖区 | `vue-virtual-scroller: ^2.0.0-beta.8` 使用 beta 版本，稳定性风险 | 锁定已知稳定版本或评估是否真正需要 |
| P2 | 🧹 维护性 | 依赖区 | 缺少 ESLint / Prettier 等代码质量工具 | 添加 `eslint` + `prettier` + `eslint-plugin-vue` |
| P2 | ⚠️ 性能 | 依赖区 | `echarts: ^6.0.0` 从 ^5 直接跳到 ^6，存在 API 变更风险 | 确认 ECharts 6 兼容性，必要时降级到 ^5 |

---

### 2.2 核心视图

#### `Dashboard.vue` (~1,476 行)

| 严重度 | 类型 | 行号 | 问题描述 | 修复建议 |
|--------|------|------|----------|----------|
| P1 | ⚠️ 性能 | 712 | `updateTimelineChart()` 使用 `Math.random()` 生成统计数据，每次调用数据不同，图表跳动 | 使用真实 API 数据或固定的模拟数据 |
| P1 | ⚠️ 性能 | 785 | `registerGuangxiMap()` 每次调用 `initGuangxiMap` 都重新注册地图，已注册时会导致覆盖和性能浪费 | 先检查 `echarts.getMap('guangxi')` 是否存在，避免重复注册 |
| P1 | ⚠️ 性能 | 258-301 | `fetchStats()` 顺序发起 4 个独立 API 请求，串行等待 | 使用 `Promise.all` 并行请求 |
| P2 | 🧹 维护性 | 878-954 | GeoJSON 数据硬编码在组件内 (~75 行) | 移到 `assets/guangxi.json` 外部文件 |
| P2 | 🧹 维护性 | 296 | 魔法数字 `Math.round(100 - data.model.avg_inference_time * 10)` 计算处理率 | 抽取为具名常量和计算函数 |
| P2 | 🧹 维护性 | 362-434 | Dashboard 自己手写 WebSocket 连接，未使用项目已有的 `useWebSocket` composable | 使用 `useWebSocket` 统一 WebSocket 管理 |

#### `Monitor.vue` (~4,852 行)

| 严重度 | 类型 | 行号 | 问题描述 | 修复建议 |
|--------|------|------|----------|----------|
| P0 | 🧹 维护性 | 全文件 | **4852 行单文件组件**，严重违反单一职责原则，可维护性极差 | 拆分为 MonitorLayout + 多个子组件（VideoPanel、AlertPanel、StatsPanel等） |

#### `DrowningDashboard.vue` (~135 行)

| 严重度 | 类型 | 行号 | 问题描述 | 修复建议 |
|--------|------|------|----------|----------|
| P2 | 🐛 Bug | 73-77 | `statPatrols`, `statWarnings` 等本地 ref 未连接任何数据源，始终为初始值 | 删除这些无用变量，或连接实际数据 |
| P1 | 🧹 维护性 | 89 | `<style>` 未加 `scoped`，`.dashboard` grid 规则泄漏到全局 | 添加 `<style scoped>` |

#### `AlertManagement.vue` (~1,407 行)

| 严重度 | 类型 | 行号 | 问题描述 | 修复建议 |
|--------|------|------|----------|----------|
| P0 | 🔒 安全 | 688-700 | CSV 导出未对字段做转义处理，特殊字符（逗号、引号、`=+@`）可导致 CSV 注入攻击 | 对每个字段添加双引号包裹，转义内部双引号，过滤 `=+@-\t\r` 开头字符 |
| P1 | ⚠️ 性能 | 697 | `URL.createObjectURL(blob)` 创建的 Blob URL 未在导出完成后 revoke，每次导出泄漏一个 URL | 导出完成后调用 `URL.revokeObjectURL(url)` |
| P2 | 🧹 维护性 | 522-525 | `notificationSettings` 使用 computed setter 模式操作 store，不常规 | 改用 store 的 action 方法 |

#### `DetectionHistory.vue` (~923 行)

| 严重度 | 类型 | 行号 | 问题描述 | 修复建议 |
|--------|------|------|----------|----------|
| P1 | 🔒 安全 | 177 | Base64 图片直接渲染为 `<img :src="'data:image/jpeg;base64,' + frame">`，未做 sanitize | 虽然 base64 XSS 风险较低，但仍应使用 `isValidBase64` 校验后再渲染 |
| P2 | 🐛 Bug | 136 | `deleteTaskConfirm` 函数已定义但模板中使用的是 `deleteTask`，函数未被调用 | 删除 `deleteTaskConfirm` 或将模板改为调用它 |
| P2 | 🧹 维护性 | 477-483 | `playVideo` / `pauseVideo` 为空壳函数，仅显示"功能开发中" | 要么实现功能，要么移除按钮和函数 |

---

### 2.3 API 与工具层

#### `api/data.js` (165 行)

| 严重度 | 类型 | 行号 | 问题描述 | 修复建议 |
|--------|------|------|----------|----------|
| P1 | 🐛 Bug | 31-148 | `eventSource`、`reconnectTimer`、`shouldReconnect` 为模块级单例，SPA 导航时不会自动清理，导致旧 SSE 连接残留 | 提供 `closeSSE()` 清理函数，在路由切换时调用 |
| P2 | 🐛 Bug | 45 | `clientId = Date.now()` 不唯一，快速重连时可能冲突 | 使用 `crypto.randomUUID()` 或 `${Date.now()}_${Math.random().toString(36).slice(2)}` |
| P2 | ⚠️ 性能 | 121 | `onopen` 中 `dynamic import('element-plus')` 每次连接时动态导入已安装的包 | Element Plus 应在顶层静态导入 |
| P2 | 🧹 维护性 | 87-92 | 导入 `wgs84ToGcj02` 但坐标转换代码被注释掉 | 删除无用导入或恢复功能 |

#### `api/boat.js` (1 行)

| 严重度 | 类型 | 行号 | 问题描述 | 修复建议 |
|--------|------|------|----------|----------|
| P2 | 🧹 维护性 | 全文件 | 空文件，仅 import request，完全无用途 | 删除此文件 |

#### `util/request.js` (21 行)

| 严重度 | 类型 | 行号 | 问题描述 | 修复建议 |
|--------|------|------|----------|----------|
| P1 | 🐛 Bug | 全文件 | 与 `utils/index.js` 存在两套独立的 axios 实例，request.js 无 token 拦截器，index.js 有；项目混用两套 | 统一为一套 axios 实例（保留 index.js 的带拦截器版本），删除 request.js |
| P2 | 🧹 维护性 | 全文件 | 仅 21 行，功能被 `utils/index.js` 完全覆盖 | 合并到 `utils/index.js` |

#### `utils/api.js` (~259 行)

| 严重度 | 类型 | 行号 | 问题描述 | 修复建议 |
|--------|------|------|----------|----------|
| P1 | 🐛 Bug | 43-44,92-93 | axios config 中自定义 `retry` 和 `retryDelay` 字段，axios 不支持这些字段，会被静默忽略，重试机制不生效 | 使用 axios-retry 库或在拦截器中手动实现重试（index.js 已实现） |
| P2 | 🐛 Bug | 52-54 | `apiCache` Map 手动 LRU 实现不正确：只检查 size > maxSize 后删除第一个，但没有按访问频率排序 | 使用真正的 LRU 实现（如 `lru-cache` 包）或简化为 TTL-only 缓存 |
| P2 | 🧹 维护性 | 1 | `import from './index.js'` 导致 api.js 与 index.js 循环依赖 | 解耦，api.js 不应依赖 index.js |
| P2 | 🧹 维护性 | 235 | `isValidBase64` regex 过于严格，拒绝包含空白字符的合法 base64 | 放宽正则，或先 strip whitespace 再校验 |

#### `utils/index.js` (~879 行)

| 严重度 | 类型 | 行号 | 问题描述 | 修复建议 |
|--------|------|------|----------|----------|
| P2 | ⚠️ 性能 | 全文件 | 879 行的"万能工具文件"，包含常量、axios、格式化、消息弹窗、防抖节流、音频播放、全屏、LLM API — 严重违反单一职责 | 拆分为独立模块：`constants.js`、`axios.js`、`format.js`、`messages.js`、`debounce.js`、`audio.js`、`fullscreen.js`、`llm.js` |
| P2 | 🐛 Bug | 157 | 请求 ID 使用 `Date.now() + Math.random().toString(36).substr(2, 9)`，`substr` 已被 deprecated | 使用 `substring` 替代 `substr` |
| P2 | 🧹 维护性 | 876 | `askLLMQuestion = askQuestion` 别名函数，增加混乱 | 只保留一个命名，需要兼容时用 export 别名 |

#### `utils/performance.js` (~387 行)

| 严重度 | 类型 | 行号 | 问题描述 | 修复建议 |
|--------|------|------|----------|----------|
| P2 | 🧹 维护性 | 387 | `globalMemoryCleaner` 单例导出但从未在任何组件中实际调用清理 | 在需要的地方调用 `globalMemoryCleaner.cleanup()`，或移除无用代码 |
| P2 | ⚠️ 性能 | 63-77 | `lazyLoadImage` 创建 IntersectionObserver 但如果 img 在 observer 回调前被移除，observer 永不 disconnect | 在组件 onUnmounted 中调用 `observer.disconnect()` |
| P2 | 🧹 维护性 | 189 | `VideoStreamManager.onFrameRender` 默认只 console.warn，不抛错也不处理 | 明确默认行为策略（静默忽略或抛错） |

#### `utils/monitorHelpers.js` (~197 行)

| 严重度 | 类型 | 行号 | 问题描述 | 修复建议 |
|--------|------|------|----------|----------|
| P1 | 🐛 Bug | 25 | `formatTime` 对秒级时间戳乘 1000，但部分调用者传入毫秒级时间戳，行为不一致 | 统一时间戳单位，或根据值大小自动判断（>1e12 视为毫秒） |
| P2 | 🧹 维护性 | ~120,~130 | `getVideoStreamUrl` 和 `buildVideoStreamUrl` 功能几乎重复 | 合并为一个函数 |
| P2 | 🐛 Bug | 137 | `getBackendUrl()` 返回空字符串，误导调用者 | 要么返回实际 URL，要么删除函数 |

#### `utils/webrtc.js` (~345 行)

| 严重度 | 类型 | 行号 | 问题描述 | 修复建议 |
|--------|------|------|----------|----------|
| P0 | 🔒 安全 | 16-21 | TURN 服务器硬编码凭证 `username: 'webrtc'`, `credential: 'webrtc123'`，任何查看源码的人可获取 | 使用临时凭证 API（TURN REST API）动态生成，或从环境变量读取 |
| P2 | ⚠️ 性能 | 4-14 | 列出 11 个公共 STUN 服务器，大部分冗余且增加 ICE 探测时间 | 精简为 2-3 个可靠的 STUN 服务器 |
| P2 | 🐛 Bug | 51-56 | `DEFAULT_CONFIG` 包含 `iceMinPriority`, `iceMaxPriority`, `rtcpFeedback`, `peerIdentity` — 这些不是合法 RTCPeerConnection 配置字段，被浏览器静默忽略 | 删除这些无效字段 |
| P2 | 🧹 维护性 | 271-323 | `setLowLatencySDP` 手动修改 SDP 字符串，解析脆弱 | 使用 `RTCRtpReceiver.getParameters()` 等 API，或使用 `sdp-transform` 库 |

#### `config/websocket.js` (69 行)

| 严重度 | 类型 | 行号 | 问题描述 | 修复建议 |
|--------|------|------|----------|----------|
| P2 | 🧹 维护性 | 17 | `P2P_CONFIG.backendHost: '127.0.0.1'` 硬编码 | 使用环境变量 |

---

### 2.4 Stores 与 Composables

#### `stores/alertStore.js` (~561 行)

| 严重度 | 类型 | 行号 | 问题描述 | 修复建议 |
|--------|------|------|----------|----------|
| P0 | 🐛 Bug | 全文件 | **不使用 Pinia**，手动 class 单例管理响应式，每次修改需 `splice` 触发更新，无法享受 Pinia 的 devtools、SSR、HMR 支持 | 重写为 Pinia store |
| P1 | ⚠️ 性能 | ~40 | `alertCounter` Map 声明但从未使用 — 死代码 | 删除 |
| P1 | ⚠️ 性能 | `addAlert`+`updateStats` | `generateTrendData` 在每条告警变更时重新计算趋势，O(n) per alert，告警密集时卡顿 | 改为增量更新趋势数据，或降低调用频率 |
| P2 | 🐛 Bug | `listeners` | 自定义事件系统 `listeners` Map 的回调从未在组件中 `off` 清理，组件卸载后回调仍残留 | 提供 `off` 方法，组件 onUnmounted 时调用 |
| P2 | 🧹 维护性 | 427 | `stats.cameraStats` 用 bracket notation 写 reactive 对象属性，可能不触发响应式 | 使用 `Vue.set` 或重新赋值整个对象 |

#### `stores/deviceData.js` (106 行)

| 严重度 | 类型 | 行号 | 问题描述 | 修复建议 |
|--------|------|------|----------|----------|
| P1 | 🧹 维护性 | 3 | **生产代码导入 `./test` 中的 `startMockSSE`**，测试代码混入生产 | 将 mock 功能移到独立开发工具或删除 |
| P1 | 🐛 Bug | 38,47 | `ElMessageBox.alert` 直接在数据 store 中调用 UI 方法，违反关注点分离 | 将 UI 通知移到组件层，store 只管理数据 |
| P2 | 🐛 Bug | 13 | `listeners` 数组用 push/filter 管理，无去重机制 | 添加去重检查 |

#### `stores/waypoint.js` (47 行)

无重大问题，代码简洁干净。

#### `composables/useWebSocket.js` (159 行)

| 严重度 | 类型 | 行号 | 问题描述 | 修复建议 |
|--------|------|------|----------|----------|
| P2 | 🐛 Bug | `sendMessage` | `sendMessage` 返回 boolean 而非 Promise，调用者无法 await 确认发送成功 | 改为返回 Promise |
| P2 | ⚠️ 性能 | 重连逻辑 | `Math.pow(2, attempts)` 指数退避，attempts=10 时延迟 1024 秒 (~17 分钟) | 设置最大延迟上限（如 30 秒） |

#### `composables/useWebRTC.js` (~834 行)

| 严重度 | 类型 | 行号 | 问题描述 | 修复建议 |
|--------|------|------|----------|----------|
| P2 | 🧹 维护性 | 全文件 | **数百个 console.log** 散布，生产环境日志量巨大 | 使用条件日志 `if (import.meta.env.DEV)` 或建立统一 logger |
| P2 | 🐛 Bug | 275-298 | `jitterBufferTarget`、`playoutDelayHint` 等为 Chrome 专属 API，其他浏览器静默失败 | 添加 `if ('jitterBufferTarget' in RTCRtpReceiver.prototype)` 条件检查 |
| P2 | 🧹 维护性 | 834 行 | 单 composable 过大 | 拆分为 signaling + peerConnection + stats 三个子模块 |

#### `composables/useVideoDetection.js` (~725 行)

| 严重度 | 类型 | 行号 | 问题描述 | 修复建议 |
|--------|------|------|----------|----------|
| P1 | 🐛 Bug | 311-321 | `frameCache`、`framePreloadQueue`、`frameTimestamps`、`frameLoadStatus` 为模块级普通对象（非 reactive），跨组件实例共享且不随组件卸载清理 | 改为 composable 内部的 ref 或 reactive，或提供清理函数 |
| P2 | 🐛 Bug | 78 | `consecutiveFailures` 模块级变量跨组件 remount 持久化，卸载后重挂载时错误计数不归零 | 改为 composable 内部 ref，onUnmounted 重置 |
| P2 | 🐛 Bug | 323-329 | `apiErrorStats` 模块级对象累积跨组件生命周期，永不重置 | 同上 |

#### `composables/useVideoStream.js` (~1,084 行)

| 严重度 | 类型 | 行号 | 问题描述 | 修复建议 |
|--------|------|------|----------|----------|
| P2 | ⚠️ 性能 | 53-57 | `globalCache` Map 在模块级别创建，跨所有组件实例共享，组件卸载后不清理 | 在 composable 内创建，或提供 `clearAllCache()` 并在路由切换时调用 |
| P2 | 🧹 维护性 | 772-799 | `saveFrameToCache`、`getFrameFromCache`、`clearCameraCache`、`clearAllCameraCache` 四个空函数（注释说"已移除本地缓存"），毫无用途 | 删除这些空函数 |
| P2 | ⚠️ 性能 | 681 | `avgFrameTime` 每 10 帧才更新且直接赋值单个帧时间而非真正平均 | 使用滚动平均值算法 |
| P2 | 🧹 维护性 | 1084 行 | 单 composable 过大，包含 PerformanceMonitor 类、AdaptiveQualityController 类、LocalCacheManager 类、网络检测等 | 拆分为 `performanceMonitor.js`、`adaptiveQuality.js`、`localCache.js` 独立模块 |

#### `composables/useVideoUpload.js` (16 行)

| 严重度 | 类型 | 行号 | 问题描述 | 修复建议 |
|--------|------|------|----------|----------|
| P2 | 🧹 维护性 | 全文件 | 仅 16 行代码片段，不完整，似乎是 `useVideoDetection` 的一部分被单独截出 | 合并回 `useVideoDetection` 或补完完整逻辑 |

#### `composables/useCameraState.js` (129 行)

| 严重度 | 类型 | 行号 | 问题描述 | 修复建议 |
|--------|------|------|----------|----------|
| P2 | 🧹 维护性 | 68-73 | `updateCameraAlertStatus` 接收整个 alertStore 作为参数，耦合过重 | 只传入 alerts 数组即可 |

#### `composables/useDashboardData.js` (79 行)

| 严重度 | 类型 | 行号 | 问题描述 | 修复建议 |
|--------|------|------|----------|----------|
| P1 | 🐛 Bug | 62 | `topSpots` computed 中使用 `Math.random()` 生成分数，每次访问值不同 | 使用固定模拟数据或真实数据 |

#### `composables/useTimer.js` (136 行)

| 严重度 | 类型 | 行号 | 问题描述 | 修复建议 |
|--------|------|------|----------|----------|
| P2 | 🐛 Bug | 6-8,40-42 | `setInterval`/`setTimeout` 使用 `key` 参数时先 `clearInterval(key)`，但 key 对应的是 timerId 而非 interval 自身，逻辑混淆 | key 和 timerId 管理逻辑需要更清晰 |
| P2 | 🧹 维护性 | 95-136 | `useSafeInterval` 与 `useTimer` 功能重叠 | 合二为一或明确分工 |

---

### 2.5 视频组件

#### `WebRTCPlayer.vue` (411 行)

| 严重度 | 类型 | 行号 | 问题描述 | 修复建议 |
|--------|------|------|----------|----------|
| P2 | 🧹 维护性 | 132-232 | `watch(remoteStream)` 内有大量 console.log 调试输出 | 生产环境应移除或条件控制 |
| P2 | 🐛 Bug | 16-18 | `<video>` 标签使用 `:webkitVideoDecoding`、`:webkitAudioDecoding`、`style="videoDelay: low;"` — 这些是无效的 HTML 属性/样式 | 删除无效属性 |

#### `VideoPlayer.vue` (1,410 行)

| 严重度 | 类型 | 行号 | 问题描述 | 修复建议 |
|--------|------|------|----------|----------|
| P0 | 🧹 维护性 | 全文件 | **1,410 行单组件**，混合 WebRTC/WebSocket/MJPEG 三种模式、帧缓冲管理、性能监控、心跳检测、自适应质量调整 — 远超单一职责 | 拆分为 VideoPlayerCore + 模式策略组件 |
| P1 | 🐛 Bug | 629,992 | `let frameCount = 0` 和 `let lastFpsTime = Date.now()` **声明两次**（行 629 和 992），后者覆盖前者，FPS 计算逻辑冲突 | 删除重复声明，统一 FPS 计算逻辑 |
| P2 | 🐛 Bug | 1191 | `useDirectStreamMode` 被引用但未定义（仅定义了 `useWebRTCMode` 和 `useWebSocketMode`） | 添加 `useDirectStreamMode` ref 或删除引用 |
| P2 | ⚠️ 性能 | 575 | `frameBufferManager.stop()` 中 `frame.url` 检查，但 `addFrame` 中 URL 创建在 `renderNextFrame`，frame 对象没有 `url` 属性 | 修复帧缓冲的 URL 生命周期管理 |

#### `FastVideoPlayer.vue` (508 行)

| 严重度 | 类型 | 行号 | 问题描述 | 修复建议 |
|--------|------|------|----------|----------|
| P2 | 🧹 维护性 | 92-102 | 多个 `let` 变量（ws、frameQueue、animationId 等）声明在 `<script setup>` 顶层但未用 ref/reactive 管理 | 对于非响应式变量用 `markRaw` 或明确标注为组件内部状态 |
| P2 | ⚠️ 性能 | 189 | `createImageBitmap` 每帧创建新 Blob 再解码，CPU 密集 | 考虑批量处理或使用 OffscreenCanvas worker |

#### `RDK X5 EdgeVideoPlayer.vue` (476 行)

| 严重度 | 类型 | 行号 | 问题描述 | 修复建议 |
|--------|------|------|----------|----------|
| P2 | 🔒 安全 | 99 | 导入 `isValidBase64` from `@/utils/api.js` 而非 `@/utils/index.js`，引入了包含重试逻辑和缓存的 API 工具文件只为一个函数 | 改为从 `@/utils/index.js` 导入（那里也有更好的验证逻辑）或抽离 `isValidBase64` 为独立模块 |
| P2 | 🐛 Bug | 143 | `formatTimestamp(timestamp)` 用 `timestamp * 1000`，假设 timestamp 为秒级，但 WebSocket 数据的 timestamp 单位不明确 | 确认后端 timestamp 单位并统一 |
| P2 | ⚠️ 性能 | 354 | `onMounted` 自动 `connect()` 且 `setInterval(fetchStats, 5000)`，即使组件在后台也持续请求 | 添加 visibility 检查（`document.hidden`）暂停后台请求 |

#### `VideoStreamMonitor.vue` (242 行)

| 严重度 | 类型 | 行号 | 问题描述 | 修复建议 |
|--------|------|------|----------|----------|
| P2 | 🧹 维护性 | 116 | 导入 `getBackendUrl` 但该函数返回空字符串（如前述问题） | 删除导入或修复 `getBackendUrl` |

#### `MJPEGPlayer.vue` (271 行)

| 严重度 | 类型 | 行号 | 问题描述 | 修复建议 |
|--------|------|------|----------|----------|
| P2 | 🐛 Bug | 132 | `streamUrl.value + '&t=' + Date.now()` — 如果原始 URL 用 `?` 参数则正确，但如果是无参数 URL 则拼接出 `&t=` 导致无效 URL | 检查 URL 是否已有 `?` 参数，使用 `?` 或 `&` |

---

## 三、问题统计（按严重度分类）

| 严重度 | 数量 | 说明 |
|--------|------|------|
| **P0** | 7 | 必须立即修复：安全漏洞、关键 Bug |
| **P1** | 18 | 重要问题：性能瓶颈、数据 Bug、架构缺陷 |
| **P2** | 42 | 一般问题：代码质量、维护性、小 Bug |

### 按类型分类

| 类型 | 数量 |
|------|------|
| 🐛 Bug | 25 |
| ⚠️ 性能 | 12 |
| 🔒 安全 | 5 |
| 🧹 维护性 | 33 |
| 💡 优化 | 0 (归入其他类别) |

---

## 四、Top 10 必修复问题

| # | 严重度 | 文件 | 问题 | 影响 |
|---|--------|------|------|------|
| 1 | **P0** | `utils/webrtc.js:16-21` | TURN 服务器硬编码凭证 `webrtc/webrtc123` | 源码泄露即泄露凭证，攻击者可滥用 TURN 服务 |
| 2 | **P0** | `AlertManagement.vue:688-700` | CSV 导出无转义处理 | CSV 注入攻击，打开 CSV 的用户可能被执行恶意公式 |
| 3 | **P0** | `router/index.js:~82` | `/test-webrtc` 路由跳过认证 | 任何人可访问测试页面，可能暴露 WebRTC 功能 |
| 4 | **P0** | `vite.config.js:21` | 后端代理硬编码内部 IP `10.64.90.195` | 源码泄露即暴露内部网络拓扑 |
| 5 | **P0** | `stores/alertStore.js:全文件` | 手动 class 单例 store 替代 Pinia | 响应式管理脆弱、无 devtools 支持、维护成本极高 |
| 6 | **P0** | `Monitor.vue:全文件` | 4,852 行巨型单文件组件 | 无法维护、无法测试、新开发者接手困难 |
| 7 | **P0** | `VideoPlayer.vue:全文件` | 1,410 行巨型单文件组件，混合三种视频模式 | 同上 |
| 8 | **P1** | `VideoPlayer.vue:629,992` | `frameCount` 和 `lastFpsTime` 变量声明两次，后者覆盖前者 | FPS 统计不准确，影响性能监控 |
| 9 | **P1** | `api/data.js:31-148` | SSE 模块级单例不随 SPA 导航清理 | 路由切换后旧 SSE 连接残留，内存泄漏+数据混乱 |
| 10 | **P1** | `useVideoDetection.js:311-329` | `frameCache` 等模块级对象跨组件实例共享且不清理 | 组件卸载后数据残留，再次挂载时状态污染 |

---

## 五、全局性架构建议

1. **统一 Store 方案**: 项目一半用 Pinia（未安装），一半手动 class 单例。要么全面迁移 Pinia，要么坚持手动但统一模式。目前两种并存是最大架构混乱。

2. **统一 HTTP 层**: `util/request.js` 和 `utils/index.js` 各有一套 axios 实例，拦截器配置不一致。保留 `index.js` 的（有 token 注入、401 处理、重试逻辑），删除 `request.js`。

3. **巨型组件拆分**: Monitor.vue (4852行) 和 VideoPlayer.vue (1410行) 是维护噩梦。按功能拆分子组件，每个子组件不超过 300 行。

4. **消除模块级泄漏**: 多个 composable 使用模块级变量/对象（useVideoDetection 的 frameCache、useVideoStream 的 globalCache、api/data.js 的 eventSource），这些在 SPA 中不会随组件卸载而清理。所有状态应放在 composable 内部或提供显式清理入口。

5. **安全加固**: TURN 凭证、CSV 导出、硬编码 IP、未认证路由 — 这些安全问题应在上线前全部解决。

6. **引入代码质量工具**: 项目缺少 ESLint、Prettier、TypeScript。至少应添加 ESLint + eslint-plugin-vue 基础配置。
