// vue.config.js
module.exports = {
  devServer: {
    port: 8080, // 前端运行端口（可自定义）
    proxy: {
      // 匹配所有以/api开头的请求，转发到后端
      '/api': {
        target: 'http://10.64.90.195:5002', // 后端接口地址
        changeOrigin: true, // 开启跨域
        // 不重写路径，因为后端路由也有/api前缀
      },
      // WebSocket代理
      '/ws': {
        target: 'http://10.64.90.195:5002',
        changeOrigin: true,
        ws: true, // 启用WebSocket代理
      }
    }   
  }
}