import subprocess
import os

result = subprocess.run(['netstat', '-ano'], capture_output=True, text=True)
lines = result.stdout.split('\n')

with open('port_check.txt', 'w', encoding='utf-8') as f:
    for line in lines:
        if '3000' in line:
            f.write(line + '\n')
            parts = line.split()
            if len(parts) >= 5:
                pid = parts[-1]
                f.write(f"PID: {pid}\n")
                
                try:
                    subprocess.run(['taskkill', '/F', '/PID', pid], capture_output=True, text=True)
                    f.write(f"已终止进程 {pid}\n")
                except Exception as e:
                    f.write(f"终止进程失败: {e}\n")

f.close()
print("Done")
