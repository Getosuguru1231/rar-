@echo off
chcp 65001 >nul
echo ================================================
echo           智能溺水检测系统 - React前端启动脚本
echo ================================================
echo.

set "NODE_VERSION_REQUIRED=18.0.0"
set "FRONTEND_PORT=5173"

cd /d "%~dp0react"

echo [检查Node.js版本]
node --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] 未找到Node.js，请先安装 Node.js ^>= %NODE_VERSION_REQUIRED%
    pause
    exit /b 1
)

echo.
echo [检查npm依赖]
if not exist "node_modules" (
    echo 未找到node_modules，正在安装依赖...
    npm install
    if %errorlevel% neq 0 (
        echo [ERROR] npm依赖安装失败
        pause
        exit /b 1
    )
    echo [OK] npm依赖安装成功
)

echo.
echo [启动React开发服务器]
echo 服务端口: %FRONTEND_PORT%
echo 访问地址: http://localhost:%FRONTEND_PORT%
echo.
npm run dev

pause