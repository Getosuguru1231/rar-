#!/bin/bash
set -e

echo "================================================"
echo "           智能溺水检测系统 - 后端启动脚本"
echo "================================================"
echo ""

VENV_DIR="venv"
PYTHON_EXE="python3"
UVICORN_PORT="8001"

cd "$(dirname "$0")/backend"

echo "[检查虚拟环境]"
if [ ! -d "$VENV_DIR" ]; then
    echo "未找到虚拟环境，正在创建..."
    $PYTHON_EXE -m venv $VENV_DIR
    echo "[OK] 虚拟环境创建成功"
fi

echo ""
echo "[激活虚拟环境]"
source $VENV_DIR/bin/activate
echo "[OK] 虚拟环境已激活"

echo ""
echo "[检查依赖]"
if ! pip list | grep -qi "fastapi\|uvicorn\|redis"; then
    echo "缺少依赖，正在安装..."
    pip install -r requirements.txt
    echo "[OK] 依赖安装成功"
fi

echo ""
echo "[启动后端服务]"
echo "服务端口: $UVICORN_PORT"
echo "访问地址: http://localhost:$UVICORN_PORT"
echo "Swagger文档: http://localhost:$UVICORN_PORT/docs"
echo ""
uvicorn main:app --host 0.0.0.0 --port $UVICORN_PORT --reload