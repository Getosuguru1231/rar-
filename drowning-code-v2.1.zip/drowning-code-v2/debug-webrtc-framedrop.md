# Debug Session: WebRTC Video Frame Drop Issue

## Status: [RESOLVED]

### Session Metadata
- **Session ID**: webrtc-framedrop
- **Created**: 2026-05-26
- **Target**: WebRTC视频流失帧和掉帧导致卡顿问题

---

## 1. Symptom Analysis

**Reported Issue**: WebRTC视频流出现卡顿现象，表现为画面一卡一卡

**Expected Behavior**: 视频流应平滑播放，无明显卡顿

**Actual Behavior**: 视频流存在失帧/掉帧现象，画面间歇性停顿

---

## 2. Root Cause Analysis

### 已识别的主要问题：

| # | 问题 | 影响 |
|---|------|------|
| 1 | 帧率不匹配：config.py FPS=30，detect.py实际捕获15fps | 编码器时间轴混乱，播放抖动 |
| 2 | 缺少帧时间戳：av.VideoFrame未设置pts/time_base | WebRTC播放器无法正确同步帧 |
| 3 | 带宽设置过高：max_video_bitrate=8Mbps | 网络拥塞导致丢包增加 |
| 4 | JPEG编码质量过高：95%质量导致编码耗时过长 | 单帧处理时间超过帧间隔 |
| 5 | 未定义变量：_previous_frame, _frame_queue等未初始化 | 运行时错误导致卡顿 |

---

## 3. Fix Summary

### 修复1: 添加帧时间戳 (`video_handler.py`)
```python
video_frame = av.VideoFrame.from_ndarray(frame_data, format="bgr24")
video_frame.pts = self._frame_timestamp
video_frame.time_base = self._time_base
self._frame_timestamp += 1
```

### 修复2: 统一帧率配置 (`config.py`)
- `default_fps`: 30 → 15
- `max_video_bitrate`: 8000000 → 3000000

### 修复3: 修复未定义变量 (`video_handler.py`)
- 添加 `_previous_frame`, `_max_mean_diff`, `_consecutive_bad_frames`, `_max_bad_frames`
- 添加 `_frame_queue`, `_max_queue_size`, `_queue_lock`

### 修复4: 优化帧率控制 (`detect.py`)
- 降低JPEG编码质量从95%到85%
- 添加处理过载检测和警告
- 修复时间变量复用问题

### 修复5: SDP动态帧率配置 (`peer_manager.py`)
- 使用配置文件中的帧率动态生成SDP

---

## 4. Files Modified

| File | Changes |
|------|---------|
| `backend/webrtc/video_handler.py` | 添加时间戳、修复未定义变量、性能监控 |
| `backend/webrtc/config.py` | 调整帧率和带宽配置 |
| `backend/webrtc/peer_manager.py` | SDP动态帧率配置 |
| `backend/detect.py` | 优化帧率控制、降低JPEG质量、过载检测 |

---

## 5. Verification

```
✅ video_handler模块导入成功
✅ WebRTCVideoTrack创建成功，FPS=15
✅ Redis连接成功
```

配置验证:
```
FPS: 15
Max Bitrate: 3000000 (3Mbps)
Video Config: {'width': 640, 'height': 480, 'fps': 15, ...}
```

---

## 6. Cleanup

待用户确认修复有效后清理调试日志代码。
