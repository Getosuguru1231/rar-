const WebSocket = require('ws');

const ws = new WebSocket('ws://localhost:8002/ws/webrtc/0');

ws.on('open', function open() {
  console.log('✅ WebSocket 连接成功!');
  ws.close();
});

ws.on('error', function error(err) {
  console.error('❌ WebSocket 连接错误:', err.message);
});

ws.on('close', function close() {
  console.log('WebSocket 连接已关闭');
});
