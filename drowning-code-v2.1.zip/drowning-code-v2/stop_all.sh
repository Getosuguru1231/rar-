#!/bin/bash
set -e

echo "================================================"
echo "           智能溺水检测系统 - 停止服务脚本"
echo "================================================"
echo ""

echo "[停止uvicorn进程]"
if pgrep -f "uvicorn" &> /dev/null; then
    echo "正在停止后端服务..."
    pkill -f "uvicorn"
    echo "[OK] 后端服务已停止"
else
    echo "[INFO] 未找到运行中的后端服务"
fi

echo ""
echo "[停止Node.js进程]"
if pgrep -f "node" &> /dev/null; then
    echo "正在停止前端服务..."
    pkill -f "node"
    echo "[OK] 前端服务已停止"
else
    echo "[INFO] 未找到运行中的前端服务"
fi

echo ""
echo "[停止Redis进程]"
if pgrep -f "redis-server" &> /dev/null; then
    echo "正在停止Redis服务..."
    pkill -f "redis-server"
    echo "[OK] Redis服务已停止"
else
    echo "[INFO] 未找到运行中的Redis服务"
fi

echo ""
echo "[停止Docker容器]"
if docker ps | grep -q "backend\|frontend\|redis"; then
    echo "正在停止Docker容器..."
    docker-compose down
    echo "[OK] Docker容器已停止"
else
    echo "[INFO] 未找到运行中的Docker容器"
fi

echo ""
echo "================================================"
echo "           所有服务已停止"
echo "================================================"