# 智能溺水检测系统 - 环境配置与部署指南

## 📋 目录
- [系统要求](#系统要求)
- [快速开始](#快速开始)
- [详细安装步骤](#详细安装步骤)
- [Python 3.13 兼容性说明](#python-313-兼容性说明)
- [常见问题排查](#常见问题排查)
- [依赖管理](#依赖管理)

---

## 系统要求

### 必需软件
- **Python**: 3.8+ (推荐 3.13)
- **Node.js**: 18+ 
- **MySQL**: 8.0+ (可选,用于数据持久化)
- **Redis**: 7.0+ (必需,用于实时数据缓存)

### 硬件要求
- CPU: 4核心以上
- 内存: 8GB+ (推荐16GB)
- 存储: 10GB可用空间
- 摄像头: USB摄像头或IP摄像头(可选)

### 外部服务要求
- **MySQL**: 8.0+ (默认端口3306)
  - 用户: `root`
  - 密码: `root`
  - 数据库: `drowning_db` (自动创建)
- **Redis**: 7.0+ (默认端口6379)
- 摄像头设备 (可选,用于实时监控)

---

## 快速开始

### 方式1: 一键启动(推荐)
```bash
# 在项目根目录执行
start.bat
```

### 方式2: 手动启动

#### 后端
```powershell
cd backend
$env:PYDANTIC_V1_COMPATIBILITY_WARNING="ignore"
.\yolo_env\Scripts\python.exe main.py
```

#### 前端
```powershell
cd frontend
npm run dev
```

---

## 详细安装步骤

### 1. 克隆项目
```bash
git clone <repository-url>
cd 132456
```

### 2. 后端环境配置

#### 2.1 创建虚拟环境
```powershell
cd backend
python -m venv yolo_env
```

#### 2.2 激活虚拟环境
```powershell
# PowerShell
.\yolo_env\Scripts\Activate.ps1

# CMD
yolo_env\Scripts\activate.bat
```

#### 2.3 安装依赖
```powershell
pip install -r requirements.txt
```

**重要**: Python 3.13用户必须确保以下版本:
- pydantic==2.12.5
- pydantic_core==2.41.5

#### 2.4 初始化数据库
```powershell
# 确保MySQL服务正在运行
python initdb.py
```

或使用批处理文件:
```bash
..\init_database.bat
```

### 3. 前端环境配置

```powershell
cd ../frontend
npm install
```

### 4. 启动服务

#### 4.1 启动Redis
```powershell
# Windows (如已安装Redis)
redis-server

# 或使用Docker
docker run -d -p 6379:6379 redis:latest
```

#### 4.2 启动后端
```powershell
cd backend
$env:PYDANTIC_V1_COMPATIBILITY_WARNING="ignore"
.\yolo_env\Scripts\python.exe main.py
```

后端将在 http://localhost:8000 启动

#### 4.3 启动前端
```powershell
cd frontend
npm run dev
```

前端将在 http://localhost:3000 启动(端口被占用时自动切换)

---

## Python 3.13 兼容性说明

### ⚠️ 重要提示

Python 3.13引入了更严格的正则表达式引擎,导致Pydantic v1兼容层出现问题。

### 解决方案

#### 方案1: 设置环境变量(推荐)
```powershell
$env:PYDANTIC_V1_COMPATIBILITY_WARNING="ignore"
```

或在 `start.bat` 中已自动设置。

#### 方案2: 使用兼容的Pydantic版本
确保安装:
```bash
pip install pydantic==2.12.5 pydantic-core==2.41.5
```

### 验证兼容性
```powershell
cd backend
.\yolo_env\Scripts\python.exe check_env.py
```

---

## 常见问题排查

### 1. Pydantic v1 兼容错误

**症状**:
```
File "pydantic\v1\datetime_parse.py", line 30, in <module>
    date_re = re.compile(f'{date_expr}$')
...
re.error: bad character in group name
```

**解决**:
```powershell
$env:PYDANTIC_V1_COMPATIBILITY_WARNING="ignore"
.\yolo_env\Scripts\python.exe main.py
```

### 2. 端口被占用

**症状**: 前端无法访问或显示其他端口

**解决**:
```powershell
# 查看实际运行端口
netstat -ano | findstr :3000

# 或检查Vite输出
# VITE v6.4.1 ready in xxx ms
# ➜ Local: http://localhost:3002/  <-- 注意实际端口
```

### 3. Redis连接失败

**症状**:
```
✗ Redis 连接失败: Error connecting to localhost:6379
```

**解决**:
```powershell
# 检查Redis是否运行
redis-cli ping
# 应返回: PONG

# 如未安装,使用Docker
docker run -d -p 6379:6379 redis:latest
```

### 4. MySQL连接失败

**症状**:
```
✗ MySQL 连接失败: Access denied for user 'root'@'localhost'
```

**解决**:
1. 确认MySQL服务正在运行
2. 检查密码配置(当前配置: 用户=root, 密码=root)
3. 修改 `backend/settings.py` 中的 `MYSQL_CONFIG`:
   ```python
   MYSQL_CONFIG = {
       "host": "localhost",
       "user": "root",
       "password": "root",  # 修改为您的MySQL密码
       "database": "drowning_db",
       "charset": "utf8mb4"
   }
   ```
4. 重新运行初始化:
   ```powershell
   cd backend
   .\yolo_env\Scripts\python.exe initdb.py
   ```

### 5. 虚拟环境不存在

**症状**:
```
找不到 python.exe
```

**解决**:
```powershell
cd backend
python -m venv yolo_env
.\yolo_env\Scripts\Activate.ps1
pip install -r requirements.txt
```

或使用:
```bash
setup_env.bat
```

### 6. YOLO模型加载失败

**症状**:
```
❌ YOLO 模型加载失败
```

**解决**:
1. 检查 `backend/models_dir/best.pt` 是否存在
2. 如不存在,系统会自动回退到yolov8n.pt
3. 下载训练好的模型并放置到正确位置

### 7. 摄像头无法访问

**症状**:
```
⚠️ 摄像头不可用或未连接
```

**解决**:
1. 确认摄像头已连接
2. 检查摄像头权限
3. 测试摄像头:
```powershell
python test_camera.py
```

---

## 依赖管理

### 查看当前依赖
```powershell
cd backend
.\yolo_env\Scripts\Activate.ps1
pip list
```

### 更新requirements.txt
```powershell
pip freeze > requirements.txt
```

### 安装特定版本
```powershell
pip install package==version
```

### 升级所有依赖
```powershell
pip install --upgrade -r requirements.txt
```

### 环境检查工具
```powershell
python check_env.py           # 检查环境
python check_env.py --fix     # 自动修复问题
```

---

## 生产环境部署

### 后端部署

#### 1. 使用Gunicorn(推荐)
```powershell
pip install gunicorn
gunicorn main:app -w 4 -k uvicorn.workers.UvicornWorker --bind 0.0.0.0:8000
```

#### 2. 使用Nginx反向代理
``nginx
server {
    listen 80;
    server_name your-domain.com;

    location /api/ {
        proxy_pass http://localhost:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }

    location / {
        root /path/to/frontend/dist;
        try_files $uri $uri/ /index.html;
    }
}
```

### 前端部署

#### 1. 构建生产版本
```powershell
cd frontend
npm run build
```

#### 2. 部署dist目录
将 `frontend/dist` 目录内容部署到Web服务器。

---

## 性能优化建议

### 1. YOLO推理优化
- 降低图像尺寸: `IMGSZ = 320` (最快) 或 `480` (平衡)
- 启用跳帧: `FRAME_SKIP_RATE = 2`
- 降低JPEG质量: `VIDEO_QUALITY = 40-50`

### 2. 数据库优化
- 定期清理历史记录
- 添加索引优化查询
- 使用连接池

### 3. Redis优化
- 设置合理的过期时间
- 监控内存使用
- 定期清理无用键

---

## 技术支持

### 日志位置
- 后端日志: `backend/logs/`
- 前端控制台: 浏览器开发者工具

### 诊断工具
```powershell
# 全面检查
python check_env.py

# 测试摄像头
python test_camera.py

# 测试延迟
python test_latency.py

# 检查视频存储
python check_video_results.py
```

### 获取帮助
1. 查看日志文件
2. 运行诊断工具
3. 查阅相关文档:
   - `CAMERA_CONNECTION_GUIDE.md`
   - `PERFORMANCE_OPTIMIZATION_GUIDE.md`
   - `DATABASE_DESIGN.md`

---

## 更新日志

### v1.0.0 (2026-04-07)
- ✅ 添加Python 3.13兼容性支持
- ✅ 创建自动化环境检查脚本
- ✅ 改进启动流程
- ✅ 完善依赖管理
- ✅ 添加故障排除指南

---

## 许可证

本项目仅供学习和研究使用。
