# 用户端视频上传检测功能使用指南

## 📋 功能概述

本系统为用户提供了**视频上传与溺水检测**功能,允许用户上传本地视频文件进行离线分析,系统会自动检测视频中是否存在可疑的溺水行为。

---

## 🎯 核心功能

### 1. **视频上传**
- 支持格式: MP4、AVI、MOV
- 文件大小限制: 最大 100MB
- 拖拽或点击上传
- 实时显示上传进度

### 2. **智能检测**
- 后台异步处理,不阻塞主界面
- 使用 YOLOv8 + ECA 注意力模型
- 自动识别人体并分析行为
- 每5帧采样一次以提高效率

### 3. **结果展示**
- 实时进度条显示检测进度
- 时间轴展示所有可疑事件
- 详细的事件信息(时间戳、置信度、位置)
- 历史记录管理

### 4. **任务管理**
- 查看所有历史检测任务
- 查看已完成任务的结果
- 删除不需要的任务和文件

---

## 💻 使用方法

### 步骤1: 上传视频

1. 登录系统后进入**监控页面** (`/monitor`)
2. 点击右上角的 **"📹 上传视频检测"** 按钮
3. 在弹出的对话框中:
   - 拖拽视频文件到上传区域,或
   - 点击"点击上传"选择文件
4. 确认文件格式和大小符合要求
5. 点击 **"开始检测"** 按钮

### 步骤2: 等待检测

- 上传完成后,系统会自动开始检测
- 对话框关闭,后台开始处理
- 每2秒自动刷新检测进度
- 检测完成后自动弹出结果

### 步骤3: 查看结果

检测结果对话框会显示:

**基本信息:**
- 文件名
- 检测状态(等待中/检测中/已完成/失败)
- 总帧数和处理帧数
- 检测进度百分比
- 可疑事件数量

**可疑事件时间轴:**
- 每个事件的时间戳(分:秒格式)
- 对应的帧号
- 检测置信度
- 目标位置坐标

### 步骤4: 管理历史任务

1. 在结果对话框点击 **"查看历史任务"**
2. 或直接再次点击上传按钮,然后选择查看历史
3. 任务列表显示:
   - 任务ID
   - 文件名
   - 当前状态
   - 完成进度
   - 创建时间
4. 可以:
   - **查看结果**: 重新查看已完成的检测结果
   - **删除**: 删除任务及其关联的视频文件

---

## 🔧 技术实现

### 后端API

#### 1. 上传视频
```
POST /api/video/upload
Content-Type: multipart/form-data

参数:
- file: 视频文件

响应:
{
  "success": true,
  "task_id": "uuid-string",
  "message": "视频上传成功,开始检测",
  "estimated_time": "根据视频长度,预计需要1-5分钟"
}
```

#### 2. 查询结果
```
GET /api/video/result/{task_id}

响应:
{
  "success": true,
  "data": {
    "task_id": "uuid",
    "status": "completed",
    "filename": "xxx.mp4",
    "total_frames": 3000,
    "processed_frames": 3000,
    "progress": 100.0,
    "drowning_events": [
      {
        "frame": 150,
        "timestamp": 5.0,
        "confidence": 0.856,
        "bbox": [100.5, 200.3, 300.2, 450.8],
        "type": "person_detected"
      }
    ],
    "created_at": "2024-01-01T12:00:00",
    "completed_at": "2024-01-01T12:05:00"
  }
}
```

#### 3. 任务列表
```
GET /api/video/tasks

响应:
{
  "success": true,
  "data": [
    {
      "task_id": "uuid",
      "status": "completed",
      "filename": "xxx.mp4",
      "progress": 100.0,
      "created_at": "2024-01-01T12:00:00"
    }
  ]
}
```

#### 4. 删除任务
```
DELETE /api/video/task/{task_id}

响应:
{
  "success": true,
  "message": "任务已删除"
}
```

### 前端组件

**关键状态变量:**
```javascript
const showUploadDialog = ref(false)        // 上传对话框
const showResultDialog = ref(false)        // 结果对话框
const showTasksDialog = ref(false)         // 任务列表对话框
const selectedFile = ref(null)             // 选中的文件
const isUploading = ref(false)             // 上传状态
const uploadProgress = ref(0)              // 上传进度
const currentTaskId = ref('')              // 当前任务ID
const detectionResult = ref(null)          // 检测结果
const taskList = ref([])                   // 任务列表
```

**核心函数:**
- `handleFileChange()`: 文件选择处理
- `startUpload()`: 开始上传
- `pollDetectionResult()`: 轮询检测结果
- `viewTaskResult()`: 查看任务结果
- `deleteTask()`: 删除任务
- `loadTaskList()`: 加载任务列表

---

## ⚙️ 配置说明

### 后端配置

在 [`api_video_detection.py`](file://c:\Users\shuang\Desktop\132456\backend\api_video_detection.py) 中可以调整:

**文件大小限制:**
```python
if file_size > 100 * 1024 * 1024:  # 100MB
    raise HTTPException(...)
```

**检测采样频率:**
```python
if frame_count % 5 == 0:  # 每5帧检测一次
    # 执行检测
```
- 改为 `% 1`: 每帧都检测(最精确,但最慢)
- 改为 `% 10`: 每10帧检测一次(最快,但可能遗漏)

**人员检测置信度阈值:**
```python
if cls == 0 and conf > 0.6:  # person类别,置信度>60%
    # 标记为可疑事件
```

**存储路径:**
```python
UPLOAD_DIR = os.path.join(os.path.dirname(__file__), "uploads")
```

### 前端配置

在 [`Monitor.vue`](file://c:\Users\shuang\Desktop\132456\frontend\src\views\Monitor.vue) 中可以调整:

**轮询间隔:**
```javascript
pollingTimer.value = setInterval(async () => {
  // 每2秒查询一次
}, 2000)
```

**接受的文件类型:**
```vue
accept=".mp4,.avi,.mov"
```

---

## 📊 性能指标

| 指标 | 值 | 说明 |
|------|-----|------|
| **最大文件大小** | 100 MB | 可配置 |
| **支持格式** | MP4/AVI/MOV | 常见视频格式 |
| **检测速度** | ~5-10 FPS | 取决于硬件和分辨率 |
| **采样策略** | 每5帧 | 平衡速度与精度 |
| **轮询间隔** | 2秒 | 实时更新进度 |
| **存储位置** | backend/uploads/ | 自动清理 |

---

## 🐛 常见问题

### Q1: 上传失败,提示"不支持的视频格式"?

**原因:** 文件格式不在白名单中

**解决:** 
- 确保文件扩展名为 `.mp4`、`.avi` 或 `.mov`
- 使用视频转换工具转换为MP4格式
- 检查文件的MIME类型是否正确

### Q2: 上传后一直显示"检测中"?

**原因:** 
1. 视频过长,检测需要时间
2. 后台任务出错但未正确更新状态
3. 浏览器网络问题导致轮询失败

**解决:**
1. 耐心等待,查看控制台日志
2. 刷新页面,点击"查看历史任务"查看最新状态
3. 检查浏览器开发者工具的Network标签,确认API请求正常

### Q3: 检测结果没有可疑事件?

**说明:** 
- 当前逻辑仅检测"人员"(person类别)
- 如需真正的溺水检测,需要:
  1. 训练专门的溺水检测模型
  2. 添加姿态分析算法
  3. 结合水域区域检测

**改进建议:**
```python
# 在 api_video_detection.py 的 run_detection 函数中
# 添加更复杂的判断逻辑:
if cls == 0 and conf > 0.6:
    # 检查是否在水中(需要水域分割模型)
    # 分析人体姿态(需要姿态估计模型)
    # 判断是否有挣扎动作(需要时序分析)
    if is_in_water and abnormal_pose:
        drowning_events.append({...})
```

### Q4: 如何清理上传的文件?

**自动清理:** 
- 删除任务时会自动删除关联文件
- 建议定期手动清理 `backend/uploads/` 目录

**手动清理:**
```bash
# Windows PowerShell
Remove-Item backend\uploads\* -Recurse

# 或删除特定任务的文件
Remove-Item backend\uploads\<task_id>_*.mp4
```

### Q5: 检测速度慢怎么办?

**优化方案:**

1. **降低视频分辨率**
   ```python
   # 在检测前缩小帧
   frame = cv2.resize(frame, (320, 240))
   ```

2. **增加采样间隔**
   ```python
   if frame_count % 10 == 0:  # 改为每10帧
   ```

3. **使用GPU加速**
   ```python
   model = YOLO(MODEL_PATH).to('cuda')
   ```

4. **降低模型尺寸**
   ```python
   # 使用 yolov8n.pt (nano) 而非 yolov8m.pt (medium)
   ```

---

## 🔒 安全注意事项

1. **文件验证:**
   - ✅ 检查文件扩展名
   - ✅ 检查MIME类型
   - ✅ 限制文件大小
   - ⚠️ 建议添加病毒扫描

2. **存储安全:**
   - 使用UUID命名避免路径遍历攻击
   - 定期清理过期文件
   - 限制并发上传数量

3. **权限控制:**
   - 当前所有登录用户都可上传
   - 如需限制,添加角色检查:
   ```python
   if user_type != 'admin':
       raise HTTPException(status_code=403, detail="无权访问")
   ```

---

## 🚀 未来改进方向

### 1. **增强检测精度**
- [ ] 集成专门的溺水检测模型
- [ ] 添加人体姿态估计
- [ ] 结合水域语义分割
- [ ] 使用时序动作识别

### 2. **优化用户体验**
- [ ] WebSocket实时推送进度
- [ ] 检测完成后邮件通知
- [ ] 批量上传多个视频
- [ ] 导出检测报告(PDF/Excel)

### 3. **性能优化**
- [ ] Redis缓存检测结果
- [ ] 分布式任务队列(Celery)
- [ ] GPU集群并行处理
- [ ] 视频分片并行检测

### 4. **数据管理**
- [ ] 数据库持久化任务记录
- [ ] 自动清理7天前的文件
- [ ] 存储空间配额管理
- [ ] 检测统计报表

---

## 📝 相关文件

**后端:**
- [`api_video_detection.py`](file://c:\Users\shuang\Desktop\132456\backend\api_video_detection.py) - 视频检测API
- [`main.py`](file://c:\Users\shuang\Desktop\132456\backend\main.py) - API路由注册
- `backend/uploads/` - 上传文件存储目录

**前端:**
- [`Monitor.vue`](file://c:\Users\shuang\Desktop\132456\frontend\src\views\Monitor.vue) - 监控页面(含上传功能)

---

## ✨ 总结

✅ **已实现功能:**
- 视频文件上传(MP4/AVI/MOV,最大100MB)
- 后台异步YOLO检测
- 实时进度轮询
- 结果可视化展示
- 历史任务管理
- 文件和任务删除

✅ **技术亮点:**
- FastAPI BackgroundTasks异步处理
- Element Plus Upload组件
- 自动轮询机制
- 响应式状态管理
- 完善的错误处理

✅ **使用场景:**
- 事后视频分析
- 离线溺水检测
- 视频质量评估
- 数据集标注辅助

现在用户可以方便地上传视频进行溺水检测,系统会自动分析并展示结果!🎉
