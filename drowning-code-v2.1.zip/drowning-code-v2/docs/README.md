# 项目文档中心

## 📚 文档分类

### [RDK X5 Edge设备集成](./rdk_x5/)
RDK X5 Edge监测设备的WebSocket视频流集成文档

- `RDK X5 Edge_IMPLEMENTATION_REPORT.md` - 完整实现报告
- `RDK X5 Edge_INTEGRATION_EXAMPLE.md` - 集成示例代码
- `RDK X5 Edge_QUICK_START.md` - 快速启动指南
- `RDK X5 Edge_WEBSOCKET_GUIDE.md` - WebSocket API文档

### [视频流优化](./video/)
视频上传检测实时流的稳定性优化文档

- `VIDEO_STREAM_QUICK_GUIDE.md` - 快速使用指南
- `VIDEO_STREAM_STABILITY_OPTIMIZATION.md` - 详细优化报告

### [前端开发](./frontend/)
前端组件、API工具和使用指南

- `API_UTILS_GUIDE.md` - API工具函数使用指南
- `COMPONENT_IMPORT_CHEATSHEET.md` - 组件导入速查表
- `COMPONENT_REFACTORING_GUIDE.md` - 组件重构迁移指南
- `COMPONENT_REFACTORING_SUMMARY.md` - 组件重构完成报告
- `INTEGRATION_REPORT.md` - 系统集成报告

### [后端开发](./backend/)
后端代码重构和架构文档

- `CODE_REFACTORING_REPORT.md` - 代码重构详细报告

---

## 🎯 快速导航

### 新手入门
1. [主README](../README.md) - 项目概述
2. [RDK X5 Edge快速启动](./rdk_x5/RDK X5 Edge_QUICK_START.md) - 设备集成
3. [视频流快速指南](./video/VIDEO_STREAM_QUICK_GUIDE.md) - 功能使用

### 开发者
1. [组件重构指南](./frontend/COMPONENT_REFACTORING_GUIDE.md) - 前端规范
2. [API工具指南](./frontend/API_UTILS_GUIDE.md) - 工具函数
3. [代码重构报告](./backend/CODE_REFACTORING_REPORT.md) - 后端优化

### 运维人员
1. [RDK X5 Edge WebSocket指南](./rdk_x5/RDK X5 Edge_WEBSOCKET_GUIDE.md) - 服务配置
2. [视频流优化报告](./video/VIDEO_STREAM_STABILITY_OPTIMIZATION.md) - 性能调优

---

## 📖 文档规范

### 命名约定
- 文件名: `UPPERCASE_WITH_UNDERSCORES.md`
- 标题: 使用清晰的中文描述
- 分类: 按功能模块组织

### 内容结构
每个文档应包含:
1. **概述** - 功能简介
2. **快速开始** - 5分钟上手
3. **详细说明** - 完整技术文档
4. **常见问题** - FAQ
5. **更新日志** - 版本历史

### 维护原则
- ✅ 保持文档与代码同步
- ✅ 定期审查过时内容
- ✅ 提供可运行的示例代码
- ✅ 添加清晰的截图和图表

---

## 🔄 更新流程

### 新增文档
1. 确定文档分类 (rdk_x5/video/frontend/backend)
2. 创建Markdown文件
3. 在本README中添加链接
4. 更新相关文档的交叉引用

### 修改文档
1. 更新内容
2. 更新"最后更新"日期
3. 如有重大变更,更新版本号
4. 通知团队成员

### 删除文档
1. 确认文档已过时
2. 检查是否有其他文档引用
3. 移动到`archive/`目录(而非直接删除)
4. 更新本README

---

## 📊 文档统计

| 分类 | 文档数量 | 最后更新 |
|------|----------|----------|
| RDK X5 Edge | 4 | 2026-04-10 |
| Video | 2 | 2026-04-10 |
| Frontend | 5 | 2026-04-10 |
| Backend | 1 | 2026-04-10 |
| **总计** | **12** | **2026-04-10** |

---

## 💡 贡献指南

### 编写建议
- 使用简洁明了的语言
- 提供具体的代码示例
- 添加必要的截图说明
- 标注适用版本和环境

### 格式规范
```markdown
# 一级标题

## 二级标题

### 三级标题

- 列表项
- 使用短横线

1. 有序列表
2. 使用数字

**粗体** 用于强调
`代码` 用反引号

```python
# 代码块指定语言
print("Hello")
```

> 引用文本

| 表格 | 列1 | 列2 |
|------|-----|-----|
| 行1  | A   | B   |
```

---

## 📞 反馈与支持

如发现文档问题:
1. 提交Issue到GitHub
2. 联系文档维护者
3. 直接提交Pull Request修正

---

**维护团队**: 智能溺水检测系统项目组  
**最后更新**: 2026-04-10  
**版本**: v1.0.0
