# 智能溺水检测系统 - 数据库设计文档

## 📊 数据库表总览

| 序号 | 表名 | 中文名 | 用途 | 数据量级 |
|------|------|--------|------|----------|
| 1 | `users` | 用户表 | 存储系统用户信息 | 小（<1000） |
| 2 | `alert_log` | 告警日志表 | 基础告警记录 | 大（>100 万） |
| 3 | `alert_details` | 告警详情表 | 详细告警信息和处理记录 | 大（>100 万） |
| 4 | `cameras` | 摄像头配置表 | 摄像头设备配置 | 小（<100） |
| 5 | `detection_records` | 检测记录表 | 每帧检测结果统计 | 超大（>1000 万） |
| 6 | `environment_data` | 环境数据表 | 水质环境监测数据 | 中（>10 万） |
| 7 | `video_clips` | 视频片段表 | 录制的视频文件索引 | 大（>10 万） |
| 8 | `screenshots` | 截图记录表 | 截图文件索引 | 中（>10 万） |
| 9 | `operation_logs` | 操作日志表 | 系统操作审计日志 | 大（>100 万） |
| 10 | `water_areas` | 水域配置表 | 监控区域配置 | 小（<100） |
| 11 | `dataset` | 数据集表 | YOLO 训练数据集 | 中（>10 万） |

---

## 📋 详细表结构

### 1. users - 用户表

**用途**: 存储系统用户账户信息，支持登录认证

| 字段 | 类型 | 约束 | 说明 |
|------|------|------|------|
| `id` | BIGINT | PRIMARY KEY | 用户 ID |
| `username` | VARCHAR(50) | UNIQUE NOT NULL | 用户名 |
| `password` | VARCHAR(100) | NOT NULL | 密码（建议加密存储） |
| `user_type` | VARCHAR(20) | DEFAULT 'user' | 用户类型：admin/user |
| `created_at` | DATETIME | DEFAULT CURRENT_TIMESTAMP | 创建时间 |
| `updated_at` | DATETIME | DEFAULT CURRENT_TIMESTAMP ON UPDATE | 更新时间 |

**索引**:
- PRIMARY KEY (`id`)
- UNIQUE (`username`)

**默认数据**:
- admin / admin123 (管理员)

---

### 2. alert_log - 告警日志表

**用途**: 基础告警记录，用于快速查询和统计

| 字段 | 类型 | 约束 | 说明 |
|------|------|------|------|
| `id` | INT | AUTO_INCREMENT PRIMARY KEY | 告警 ID |
| `alert_time` | DATETIME | NOT NULL | 告警发生时间 |
| `video_path` | VARCHAR(255) | NOT NULL | 关联视频文件路径 |
| `status` | VARCHAR(20) | DEFAULT 'pending' | 状态：pending/processing/completed |
| `camera_id` | INT | DEFAULT 1 | 摄像头 ID |
| `area_name` | VARCHAR(100) | NULL | 区域名称 |
| `is_false_alarm` | BOOLEAN | DEFAULT FALSE | 是否误报 |
| `response_time` | DECIMAL(5,2) | NULL | 响应时间（秒） |
| `created_at` | DATETIME | DEFAULT CURRENT_TIMESTAMP | 记录创建时间 |

**索引**:
- PRIMARY KEY (`id`)
- INDEX (`alert_time`)
- INDEX (`camera_id`)

**数据来源**: 
- 后端自动检测触发
- [`detect.py`](c:\Users\whz42\Desktop\132456\backend\detect.py) 中的 [`save_alert_log`](file://c:\Users\whz42\Desktop\132456\backend\components\utils.py#L110-L134) 函数

---

### 3. alert_details - 告警详情表

**用途**: 详细的告警信息和处理流程记录

| 字段 | 类型 | 约束 | 说明 |
|------|------|------|------|
| `id` | BIGINT | AUTO_INCREMENT PRIMARY KEY | 详情 ID |
| `alert_log_id` | INT | NOT NULL FK | 关联的告警日志 ID |
| `camera_id` | INT | NOT NULL | 摄像头 ID |
| `area_name` | VARCHAR(100) | NULL | 区域名称 |
| `alert_level` | VARCHAR(20) | NOT NULL | 告警级别：high/medium/low |
| `risk_score` | DECIMAL(5,2) | NULL | 风险评分 (0-100) |
| `alert_reason` | VARCHAR(500) | NULL | 告警原因 |
| `people_data` | JSON | NULL | 现场人员数据 JSON |
| `confirmed_by` | BIGINT | NULL FK | 确认处理的用户 ID |
| `confirm_time` | DATETIME | NULL | 确认时间 |
| `is_false_alarm` | BOOLEAN | DEFAULT FALSE | 是否误报 |
| `false_alarm_reason` | VARCHAR(500) | NULL | 误报原因 |
| `response_time` | DECIMAL(5,2) | NULL | 响应时间（秒） |
| `handle_notes` | TEXT | NULL | 处理备注 |
| `created_at` | DATETIME | DEFAULT CURRENT_TIMESTAMP | 创建时间 |
| `updated_at` | DATETIME | DEFAULT CURRENT_TIMESTAMP ON UPDATE | 更新时间 |

**索引**:
- PRIMARY KEY (`id`)
- FOREIGN KEY (`alert_log_id`) REFERENCES `alert_log(id)` ON DELETE CASCADE
- FOREIGN KEY (`confirmed_by`) REFERENCES `users(id)` ON DELETE SET NULL
- INDEX (`alert_level`)
- INDEX (`confirmed_by`, `confirm_time`)

**JSON 字段示例** (`people_data`):
```json
{
  "total": 5,
  "drowning": 1,
  "warning": 2,
  "normal": 2,
  "boxes": [
    {"x": 20, "y": 30, "w": 15, "h": 30, "status": "drowning", "confidence": 0.95}
  ]
}
```

---

### 4. cameras - 摄像头配置表

**用途**: 管理所有摄像头设备的配置信息

| 字段 | 类型 | 约束 | 说明 |
|------|------|------|------|
| `id` | INT | AUTO_INCREMENT PRIMARY KEY | 摄像头 ID |
| `name` | VARCHAR(100) | NOT NULL | 摄像头名称 |
| `area_name` | VARCHAR(100) | NULL | 监控区域名称 |
| `source` | VARCHAR(255) | NOT NULL | 视频源地址（设备索引或 RTSP 地址） |
| `status` | TINYINT | DEFAULT 1 | 状态：0-停止，1-运行中 |
| `position_x` | DECIMAL(5,2) | DEFAULT 0 | 安装位置 X 坐标 |
| `position_y` | DECIMAL(5,2) | DEFAULT 0 | 安装位置 Y 坐标 |
| `created_at` | DATETIME | DEFAULT CURRENT_TIMESTAMP | 创建时间 |
| `updated_at` | DATETIME | DEFAULT CURRENT_TIMESTAMP ON UPDATE | 更新时间 |

**默认数据**:
- 4 个默认摄像头配置（泳池 1-4 号区域）

---

### 5. detection_records - 检测记录表

**用途**: 记录每一帧的检测统计结果，用于数据分析和模型优化

| 字段 | 类型 | 约束 | 说明 |
|------|------|------|------|
| `id` | BIGINT | AUTO_INCREMENT PRIMARY KEY | 记录 ID |
| `camera_id` | INT | NOT NULL | 摄像头 ID |
| `frame_time` | DATETIME | NOT NULL | 帧时间 |
| `person_count` | INT | DEFAULT 0 | 检测人数 |
| `drowning_count` | INT | DEFAULT 0 | 溺水人数 |
| `warning_count` | INT | DEFAULT 0 | 预警人数 |
| `normal_count` | INT | DEFAULT 0 | 正常人数 |
| `detection_data` | JSON | NULL | 检测结果 JSON（包含所有检测框信息） |
| `created_at` | DATETIME | DEFAULT CURRENT_TIMESTAMP | 创建时间 |

**索引**:
- PRIMARY KEY (`id`)
- INDEX (`camera_id`, `frame_time`) - 联合索引
- INDEX (`frame_time`)

**JSON 字段示例** (`detection_data`):
```json
{
  "frame_id": "20260328_154530_cam1",
  "inference_time_ms": 45.2,
  "boxes": [
    {
      "class": "drowning",
      "confidence": 0.95,
      "bbox": [100, 200, 150, 280]
    }
  ]
}
```

**注意**: 此表数据量巨大，建议定期归档或使用分区表

---

### 6. environment_data - 环境数据表

**用途**: 记录水质和环境监测数据

| 字段 | 类型 | 约束 | 说明 |
|------|------|------|------|
| `id` | BIGINT | AUTO_INCREMENT PRIMARY KEY | 记录 ID |
| `area_name` | VARCHAR(100) | NOT NULL | 区域名称 |
| `temperature` | DECIMAL(5,2) | NULL | 水温 (°C) |
| `ph_value` | DECIMAL(4,2) | NULL | PH 值 |
| `chlorine_level` | DECIMAL(5,2) | NULL | 余氯浓度 (mg/L) |
| `turbidity` | DECIMAL(5,2) | NULL | 浊度 (NTU) |
| `record_time` | DATETIME | NOT NULL | 记录时间 |
| `created_at` | DATETIME | DEFAULT CURRENT_TIMESTAMP | 创建时间 |

**索引**:
- PRIMARY KEY (`id`)
- INDEX (`area_name`, `record_time`) - 联合索引

**前端展示**: [`Monitor.vue`](c:\Users\whz42\Desktop\132456\frontend\src\views\Monitor.vue) 中的 `envData`

---

### 7. video_clips - 视频片段表

**用途**: 管理录制的视频片段和告警录像

| 字段 | 类型 | 约束 | 说明 |
|------|------|------|------|
| `id` | BIGINT | AUTO_INCREMENT PRIMARY KEY | 片段 ID |
| `camera_id` | INT | NOT NULL | 摄像头 ID |
| `clip_name` | VARCHAR(255) | NOT NULL | 视频片段名称 |
| `video_path` | VARCHAR(500) | NOT NULL | 视频文件路径 |
| `start_time` | DATETIME | NOT NULL | 片段开始时间 |
| `end_time` | DATETIME | NOT NULL | 片段结束时间 |
| `duration_seconds` | INT | NULL | 时长（秒） |
| `file_size` | BIGINT | NULL | 文件大小（字节） |
| `clip_type` | VARCHAR(50) | DEFAULT 'manual' | 类型：manual-手动保存，auto-自动录制 |
| `related_alert_id` | BIGINT | NULL FK | 关联的告警 ID |
| `download_count` | INT | DEFAULT 0 | 下载次数 |
| `created_at` | DATETIME | DEFAULT CURRENT_TIMESTAMP | 创建时间 |

**索引**:
- PRIMARY KEY (`id`)
- FOREIGN KEY (`related_alert_id`) REFERENCES `alert_details(id)` ON DELETE SET NULL
- INDEX (`camera_id`, `start_time`)

---

### 8. screenshots - 截图记录表

**用途**: 管理抓拍的截图文件

| 字段 | 类型 | 约束 | 说明 |
|------|------|------|------|
| `id` | BIGINT | AUTO_INCREMENT PRIMARY KEY | 截图 ID |
| `camera_id` | INT | NOT NULL | 摄像头 ID |
| `image_path` | VARCHAR(500) | NOT NULL | 图片文件路径 |
| `capture_time` | DATETIME | NOT NULL | 截图时间 |
| `person_count` | INT | DEFAULT 0 | 图中人数 |
| `drowning_count` | INT | DEFAULT 0 | 溺水人数 |
| `file_size` | BIGINT | NULL | 文件大小（字节） |
| `resolution` | VARCHAR(20) | NULL | 分辨率（如 1920x1080） |
| `created_at` | DATETIME | DEFAULT CURRENT_TIMESTAMP | 创建时间 |

**索引**:
- PRIMARY KEY (`id`)
- INDEX (`camera_id`, `capture_time`)

---

### 9. operation_logs - 操作日志表

**用途**: 记录所有用户操作，用于审计和安全分析

| 字段 | 类型 | 约束 | 说明 |
|------|------|------|------|
| `id` | BIGINT | AUTO_INCREMENT PRIMARY KEY | 日志 ID |
| `user_id` | BIGINT | NULL FK | 操作用户 ID |
| `username` | VARCHAR(50) | NULL | 操作用户名 |
| `operation_type` | VARCHAR(50) | NOT NULL | 操作类型：login/view/export/delete等 |
| `operation_module` | VARCHAR(50) | NULL | 操作模块：monitor/camera/alert等 |
| `operation_desc` | VARCHAR(500) | NULL | 操作描述 |
| `request_params` | JSON | NULL | 请求参数 |
| `response_status` | INT | NULL | 响应状态码 |
| `ip_address` | VARCHAR(50) | NULL | IP 地址 |
| `user_agent` | VARCHAR(500) | NULL | 用户代理 |
| `execute_time_ms` | INT | NULL | 执行时长（毫秒） |
| `created_at` | DATETIME | DEFAULT CURRENT_TIMESTAMP | 创建时间 |

**索引**:
- PRIMARY KEY (`id`)
- FOREIGN KEY (`user_id`) REFERENCES `users(id)` ON DELETE SET NULL
- INDEX (`user_id`, `created_at`) - 联合索引
- INDEX (`operation_type`)

---

### 10. water_areas - 水域配置表

**用途**: 配置和管理监控的水域区域

| 字段 | 类型 | 约束 | 说明 |
|------|------|------|------|
| `id` | INT | AUTO_INCREMENT PRIMARY KEY | 区域 ID |
| `area_name` | VARCHAR(100) | UNIQUE NOT NULL | 水域名称 |
| `area_code` | VARCHAR(50) | UNIQUE | 区域编码 |
| `description` | VARCHAR(500) | NULL | 区域描述 |
| `camera_ids` | VARCHAR(255) | NULL | 关联的摄像头 IDs（逗号分隔） |
| `risk_level` | VARCHAR(20) | DEFAULT 'medium' | 风险等级：high/medium/low |
| `max_capacity` | INT | NULL | 最大容纳人数 |
| `depth` | DECIMAL(5,2) | NULL | 水深（米） |
| `status` | TINYINT | DEFAULT 1 | 状态：0-关闭，1-开放 |
| `created_at` | DATETIME | DEFAULT CURRENT_TIMESTAMP | 创建时间 |
| `updated_at` | DATETIME | DEFAULT CURRENT_TIMESTAMP ON UPDATE | 更新时间 |

**默认数据**:
- 4 个默认水域配置（泳池 1-4 号区域）

---

### 11. dataset - 数据集表

**用途**: 存储 YOLO 模型训练用的标注数据集

| 字段 | 类型 | 约束 | 说明 |
|------|------|------|------|
| `id` | INT | AUTO_INCREMENT PRIMARY KEY | 数据 ID |
| `img_path` | VARCHAR(255) | NOT NULL | 图像文件路径 |
| `label_path` | VARCHAR(255) | NOT NULL | 标注文件路径 |
| `category` | VARCHAR(20) | NOT NULL | 类别：drowning/normal |
| `create_time` | DATETIME | DEFAULT CURRENT_TIMESTAMP | 创建时间 |

---

## 🔗 表关系图

```
┌─────────────┐
│    users    │
│ (用户表)     │
└──────┬──────┘
       │
       │ confirmed_by (FK)
       ▼
┌─────────────────┐         ┌──────────────┐
│ alert_details   │◄────────│  alert_log   │
│ (告警详情表)     │         │  (告警日志表) │
└────────┬────────┘         └──────────────┘
         │
         │ related_alert_id (FK)
         ▼
┌─────────────────┐
│  video_clips    │
│ (视频片段表)     │
└─────────────────┘

┌─────────────┐
│   cameras   │
│ (摄像头表)   │
└──────┬──────┘
       │ camera_id (多个表引用)
       ├──────────────────────────────────┐
       ▼                                  ▼
┌─────────────────────┐        ┌──────────────────┐
│ detection_records   │        │    screenshots   │
│  (检测记录表)        │        │    (截图表)       │
└─────────────────────┘        └──────────────────┘

┌───────────────┐
│ water_areas   │
│  (水域配置表)  │
└───────────────┘

┌──────────────────────┐
│ environment_data     │
│   (环境数据表)        │
└──────────────────────┘

┌──────────────────────┐
│  operation_logs      │
│   (操作日志表)        │
└──────────────────────┘
```

---

## 📊 数据存储完整性检查

### ✅ 已覆盖的数据存储需求

| 数据类型 | 存储表 | 字段 | 状态 |
|---------|--------|------|------|
| **用户信息** | `users` | username, password, user_type | ✅ |
| **登录认证** | `users` + Redis token | token 存储在 Redis | ✅ |
| **告警记录** | `alert_log` + `alert_details` | 完整告警信息和处理流程 | ✅ |
| **视频流** | Redis 实时缓存 | `camera_{id}_frame` | ✅ |
| **录像文件** | `video_clips` | video_path 索引 | ✅ |
| **截图** | `screenshots` | image_path 索引 | ✅ |
| **检测统计** | `detection_records` | 人数统计、检测结果 | ✅ |
| **环境数据** | `environment_data` | 温度、PH、余氯等 | ✅ |
| **摄像头配置** | `cameras` | 设备信息、状态 | ✅ |
| **水域配置** | `water_areas` | 区域信息、风险等级 | ✅ |
| **操作审计** | `operation_logs` | 所有用户操作记录 | ✅ |
| **训练数据** | `dataset` | 标注数据集 | ✅ |

### ⚠️ 需要注意的数据

1. **Redis 缓存数据**（非持久化）:
   - `current_frame` / `camera_{id}_frame`: 实时视频帧
   - `alert_event`: 待推送的告警事件
   - `token:{token}`: 用户登录 token
   - `total_people_count`: 实时人数统计
   - `stop_detection`: 检测停止信号

2. **文件系统存储**:
   - 视频文件：`data/video/` 目录
   - 截图文件：需配置专门目录
   - 模型文件：`backend/models_dir/`

---

## 🎯 数据库优化建议

### 1. 性能优化

```sql
-- 1. 为常用查询添加索引
CREATE INDEX idx_alert_time_camera ON alert_log(alert_time, camera_id);
CREATE INDEX idx_detect_camera_time ON detection_records(camera_id, frame_time);

-- 2. 分区表（针对大数据量表）
-- detection_records 按月分区
ALTER TABLE detection_records 
PARTITION BY RANGE (YEAR(frame_time) * 100 + MONTH(frame_time)) (
    PARTITION p202603 VALUES LESS THAN (202604),
    PARTITION p202604 VALUES LESS THAN (202605),
    ...
);

-- 3. 定期清理旧数据
DELETE FROM detection_records WHERE frame_time < DATE_SUB(NOW(), INTERVAL 3 MONTH);
```

### 2. 数据安全

```sql
-- 1. 密码加密（应用层实现）
-- 使用 bcrypt 或 Argon2 加密存储

-- 2. 敏感数据加密
ALTER TABLE users ADD COLUMN password_salt VARCHAR(50);

-- 3. 备份策略
mysqldump -u root -p drowning_db > backup_$(date +%Y%m%d).sql
```

### 3. 数据归档

```sql
-- 创建归档表
CREATE TABLE alert_log_archive LIKE alert_log;

-- 迁移 3 个月前的数据
INSERT INTO alert_log_archive 
SELECT * FROM alert_log WHERE alert_time < DATE_SUB(NOW(), INTERVAL 3 MONTH);

DELETE FROM alert_log WHERE alert_time < DATE_SUB(NOW(), INTERVAL 3 MONTH);
```

---

## 📝 使用示例

### 插入告警记录

```python
# 1. 插入基础告警日志
cursor.execute("""
    INSERT INTO alert_log (alert_time, video_path, camera_id, area_name)
    VALUES (%s, %s, %s, %s)
""", (datetime.now(), '/path/to/video.mp4', 1, '泳池 1 号区域'))

alert_log_id = cursor.lastrowid

# 2. 插入告警详情
cursor.execute("""
    INSERT INTO alert_details (alert_log_id, camera_id, alert_level, risk_score, alert_reason, people_data)
    VALUES (%s, %s, %s, %s, %s, %s)
""", (alert_log_id, 1, 'high', 99.0, '检测到溺水行为', json.dumps(people_data)))
```

### 查询统计数据

```sql
-- 今日告警统计
SELECT 
    COUNT(*) as total,
    SUM(is_false_alarm) as false_alarm_count,
    AVG(response_time) as avg_response_time
FROM alert_log 
WHERE DATE(alert_time) = CURDATE();

-- 各区域人数分布
SELECT 
    area_name,
    SUM(person_count) as total_people
FROM detection_records 
WHERE DATE(frame_time) = CURDATE()
GROUP BY area_name;

-- 摄像头活跃度
SELECT 
    c.name,
    COUNT(dr.id) as detection_count,
    AVG(dr.person_count) as avg_people
FROM cameras c
LEFT JOIN detection_records dr ON c.id = dr.camera_id
WHERE DATE(dr.frame_time) = CURDATE()
GROUP BY c.id;
```

---

**最后更新**: 2026-03-28  
**数据库版本**: MySQL 5.7+ / 8.0+  
**字符集**: utf8mb4
