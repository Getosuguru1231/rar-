# 组件目录重构迁移指南

## 📋 重构概述

为了提升代码可维护性和可扩展性,我们对组件目录进行了重新组织,按功能分类存放。

---

## 🔄 变更内容

### 1. 目录结构调整

**之前:**
```
components/
├── AlertDialog.vue
├── RDK X5 EdgeVideoPlayer.vue
├── Login.vue
├── StatsPanel.vue
├── VideoPlayer.vue
└── index.js
```

**之后:**
```
components/
├── common/          # 通用组件
│   ├── Login.vue
│   └── StatsPanel.vue
├── business/        # 业务组件
│   └── AlertDialog.vue
├── video/           # 视频组件
│   ├── VideoPlayer.vue
│   └── RDK X5 EdgeVideoPlayer.vue
├── index.js         # 统一导出(已更新)
└── README.md        # 使用文档(新增)
```

---

## ✅ 已完成的修改

### 1. 文件移动

- ✅ `Login.vue` → `common/Login.vue`
- ✅ `StatsPanel.vue` → `common/StatsPanel.vue`
- ✅ `AlertDialog.vue` → `business/AlertDialog.vue`
- ✅ `VideoPlayer.vue` → `video/VideoPlayer.vue`
- ✅ `RDK X5 EdgeVideoPlayer.vue` → `video/RDK X5 EdgeVideoPlayer.vue`

### 2. 导出文件更新

**`components/index.js`** 已更新为:
```javascript
// 通用组件
export { default as Login } from './common/Login.vue'
export { default as StatsPanel } from './common/StatsPanel.vue'

// 业务组件
export { default as AlertDialog } from './business/AlertDialog.vue'

// 视频组件
export { default as VideoPlayer } from './video/VideoPlayer.vue'
export { default as RDK X5 EdgeVideoPlayer } from './video/RDK X5 EdgeVideoPlayer.vue'

// 批量导出对象
export const CommonComponents = { Login, StatsPanel }
export const BusinessComponents = { AlertDialog }
export const VideoComponents = { VideoPlayer, RDK X5 EdgeVideoPlayer }
export const AllComponents = { ...CommonComponents, ...BusinessComponents, ...VideoComponents }
```

### 3. 引用路径更新

**`Monitor.vue`** 中的导入已更新:
```javascript
// 之前
import AlertDialog from '../components/AlertDialog.vue'

// 之后
import AlertDialog from '../components/business/AlertDialog.vue'
```

---

## 🔧 需要检查的文件

如果你的项目中有其他文件引用了这些组件,需要更新导入路径:

### 检查清单

- [ ] 搜索所有 `.vue` 和 `.js` 文件
- [ ] 查找旧的导入路径
- [ ] 更新为新的路径或使用统一导入

### 自动搜索命令

```bash
# PowerShell
cd c:\Users\shuang\Desktop\132456\frontend\src
Get-ChildItem -Recurse -Include *.vue,*.js | Select-String "from.*components.*(AlertDialog|StatsPanel|VideoPlayer|Login)"

# 或
grep -r "from.*components.*AlertDialog" src/
grep -r "from.*components.*StatsPanel" src/
grep -r "from.*components.*VideoPlayer" src/
grep -r "from.*components.*Login" src/
```

---

## 💡 推荐的导入方式

### 方式1: 统一导入 (推荐)

```javascript
// 从统一入口导入
import { AlertDialog, StatsPanel, VideoPlayer } from '@/components'
```

**优势:**
- ✅ 路径简洁
- ✅ 易于维护
- ✅ IDE自动补全友好

### 方式2: 直接路径导入

```javascript
// 通用组件
import Login from '@/components/common/Login.vue'

// 业务组件
import AlertDialog from '@/components/business/AlertDialog.vue'

// 视频组件
import VideoPlayer from '@/components/video/VideoPlayer.vue'
```

**优势:**
- ✅ 明确的组件来源
- ✅ 便于追溯

---

## 📝 迁移步骤

### 如果你在开发新功能

1. **确定组件分类**
   - 通用UI → `common/`
   - 业务逻辑 → `business/`
   - 视频相关 → `video/`

2. **创建组件文件**
   ```bash
   # 示例: 创建新的业务组件
   touch src/components/business/MyNewComponent.vue
   ```

3. **更新导出文件**
   ```javascript
   // components/index.js
   export { default as MyNewComponent } from './business/MyNewComponent.vue'
   
   export const BusinessComponents = {
     AlertDialog,
     MyNewComponent  // 添加到这里
   }
   ```

4. **在页面中使用**
   ```javascript
   import { MyNewComponent } from '@/components'
   ```

---

## ⚠️ 注意事项

### 1. 大小写敏感

文件名必须与导出名完全一致:
```javascript
// ✅ 正确
export { default as AlertDialog } from './business/AlertDialog.vue'

// ❌ 错误 (大小写不匹配)
export { default as Alertdialog } from './business/Alertdialog.vue'
```

### 2. 路径别名

确保 `vite.config.js` 中配置了 `@` 别名:
```javascript
// vite.config.js
import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import path from 'path'

export default defineConfig({
  plugins: [vue()],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, 'src')
    }
  }
})
```

### 3. TypeScript支持 (如果未来迁移)

如果使用TypeScript,需要创建类型声明:
```typescript
// components/types.ts
export interface AlertDialogProps {
  alertData: object
}

export interface StatsPanelProps {
  totalPeopleCount: number
  areaDistribution: Array<{name: string, count: number}>
}
```

---

## 🧪 测试验证

### 1. 启动开发服务器

```bash
cd frontend
npm run dev
```

### 2. 检查控制台

打开浏览器开发者工具,查看是否有导入错误:
- ❌ `Failed to resolve import`
- ❌ `Module not found`

### 3. 功能测试

- [ ] Monitor页面正常加载
- [ ] 告警对话框正常显示
- [ ] 统计面板数据正确
- [ ] 视频流正常播放

---

## 🐛 常见问题

### Q1: 导入报错 "Module not found"?

**A:** 检查以下几点:
1. 文件是否在正确的文件夹中
2. 文件名大小写是否正确
3. `index.js` 是否已更新
4. 路径是否正确 (`@/components` vs `../components`)

**解决方案:**
```javascript
// 尝试清除缓存后重启
npm run dev  // 或
rm -rf node_modules/.vite  // Linux/Mac
Remove-Item -Recurse -Force node_modules\.vite  // Windows
```

### Q2: VSCode智能提示失效?

**A:** 重启VSCode的TypeScript服务:
1. `Ctrl+Shift+P` (Windows/Linux) 或 `Cmd+Shift+P` (Mac)
2. 输入 `TypeScript: Restart TS Server`
3. 回车执行

### Q3: 构建失败?

**A:** 检查:
```bash
# 清理构建缓存
npm run build  # 查看详细错误信息

# 如果是路径问题,检查 vite.config.js 中的 alias 配置
```

---

## 📊 影响范围

### 已修改的文件
- ✅ `components/index.js` - 更新导出
- ✅ `views/Monitor.vue` - 更新导入路径
- ✅ 所有组件文件位置已调整

### 未受影响的文件
- ✅ 组件内部逻辑 (无修改)
- ✅ 组件样式 (无修改)
- ✅ 路由配置 (无修改)
- ✅ API工具函数 (无修改)

---

## 🎯 后续优化建议

### 短期 (1-2周)
- [ ] 为所有组件添加JSDoc注释
- [ ] 编写组件单元测试
- [ ] 创建组件Storybook文档

### 中期 (1-2月)
- [ ] 提取更多可复用组件
- [ ] 实现组件懒加载
- [ ] 添加组件性能监控

### 长期 (3-6月)
- [ ] 迁移到TypeScript
- [ ] 建立组件设计规范
- [ ] 实现组件自动化测试

---

## 📞 技术支持

如遇到问题:

1. **查看文档**: `components/README.md`
2. **检查日志**: 浏览器控制台 + 终端输出
3. **回滚方案**: Git恢复到重构前的版本
   ```bash
   git log --oneline  # 查看提交历史
   git checkout <commit-hash>  # 回滚到指定版本
   ```

---

**重构日期**: 2026-04-10  
**版本**: v1.0.0  
**状态**: ✅ 已完成
