# 组件导入速查表

## 🚀 快速导入

### 通用组件 (common/)

```javascript
import { Login, StatsPanel } from '@/components'
```

**包含:**
- `Login.vue` - 登录表单
- `StatsPanel.vue` - 统计面板

---

### 业务组件 (business/)

```javascript
import { AlertDialog } from '@/components'
```

**包含:**
- `AlertDialog.vue` - 告警对话框

---

### 视频组件 (video/)

```javascript
import { VideoPlayer, RDK X5 EdgeVideoPlayer } from '@/components'
```

**包含:**
- `VideoPlayer.vue` - 标准视频播放器
- `RDK X5 EdgeVideoPlayer.vue` - RDK X5 Edge专用播放器

---

## 📋 完整示例

### Monitor.vue 中的使用

```vue
<script setup>
// 方式1: 统一导入 (推荐)
import { AlertDialog } from '@/components'

// 方式2: 直接路径
import AlertDialog from '../components/business/AlertDialog.vue'
</script>

<template>
  <AlertDialog 
    v-model="showAlert"
    :alert-data="currentAlert"
    @confirm="handleConfirm"
  />
</template>
```

---

## 🎯 选择指南

| 场景 | 推荐方式 | 示例 |
|------|----------|------|
| **日常开发** | 统一导入 | `import { X } from '@/components'` |
| **明确来源** | 直接路径 | `import X from '@/components/common/X.vue'` |
| **批量使用** | 集合对象 | `const { X, Y } = CommonComponents` |
| **懒加载** | defineAsyncComponent | `defineAsyncComponent(() => import(...))` |

---

## ⚡ 常用组合

### 监控页面

```javascript
import { AlertDialog, StatsPanel } from '@/components'
```

### 管理页面

```javascript
import { Login, StatsPanel } from '@/components'
```

### 视频页面

```javascript
import { VideoPlayer, RDK X5 EdgeVideoPlayer } from '@/components'
```

---

## 🔍 查找组件

### 按功能查找

- **登录相关** → `common/Login.vue`
- **数据统计** → `common/StatsPanel.vue`
- **告警提示** → `business/AlertDialog.vue`
- **视频播放** → `video/VideoPlayer.vue`
- **RDK X5 Edge设备** → `video/RDK X5 EdgeVideoPlayer.vue`

### 按分类查找

- **通用UI** → `common/` 文件夹
- **业务逻辑** → `business/` 文件夹
- **视频功能** → `video/` 文件夹

---

## ❓ 常见问题

### Q: 导入报错怎么办?

**A:** 检查三点:
1. 文件名大小写是否正确
2. `index.js` 是否已导出
3. 路径别名 `@` 是否配置

### Q: 如何新增组件?

**A:** 四步走:
1. 确定分类 (common/business/video)
2. 创建文件 (PascalCase命名)
3. 更新 `index.js` 导出
4. 在页面中导入使用

### Q: 旧代码需要修改吗?

**A:** 
- ✅ 新代码: 使用新路径
- ⚠️ 旧代码: 逐步迁移
- ❌ 不必立即全部修改

---

## 📖 详细文档

- **完整说明**: [components/README.md](./frontend/src/components/README.md)
- **迁移指南**: [COMPONENT_REFACTORING_GUIDE.md](./frontend/COMPONENT_REFACTORING_GUIDE.md)
- **重构报告**: [COMPONENT_REFACTORING_SUMMARY.md](./frontend/COMPONENT_REFACTORING_SUMMARY.md)

---

**最后更新**: 2026-04-10  
**版本**: v1.0.0
