# API工具函数 - 快速使用指南

## 📦 新增文件

**`frontend/src/utils/api.js`** - 统一的API请求和工具函数库

---

## 🚀 快速开始

### 1. 导入工具函数

```javascript
import { 
  apiGet, 
  apiPost, 
  apiDelete,
  createSafeInterval,
  clearAllTimers,
  showSuccess,
  showError,
  safeExecute,
  executeWithRetry,
  preloadImage
} from '@/utils/api.js'
```

### 2. 基础用法

#### HTTP请求
```javascript
// GET请求
const users = await apiGet('/api/users')

// POST请求
const newUser = await apiPost('/api/users', { name: 'John', age: 25 })

// DELETE请求
await apiDelete('/api/users/123')
```

#### 消息提示
```javascript
showSuccess('操作成功!')
showError('操作失败,请重试')
showWarning('请注意此操作不可逆')
```

#### 定时器管理
```javascript
import { ref } from 'vue'
const myTimer = ref(null)

// 创建安全定时器(自动清理旧的)
createSafeInterval(() => {
  console.log('每2秒执行一次')
}, 2000, myTimer)

// 批量清除
clearAllTimers(myTimer, anotherTimer, thirdTimer)
```

---

## 💡 常用场景

### 场景1: 替换原有的axios调用

**之前:**
```javascript
try {
  const response = await axios.get('/api/data')
  if (response.data.success) {
    data.value = response.data.data
  } else {
    throw new Error(response.data.message)
  }
} catch (error) {
  console.error('获取数据失败:', error)
  ElMessage.error('获取数据失败')
}
```

**之后:**
```javascript
data.value = await apiGet('/api/data')
```

---

### 场景2: 安全的异步操作

**之前:**
```javascript
try {
  await someAsyncOperation()
  ElMessage.success('操作成功')
} catch (error) {
  console.error('操作失败:', error)
  ElMessage.error('操作失败: ' + error.message)
}
```

**之后:**
```javascript
await safeExecute(
  async () => {
    await someAsyncOperation()
  },
  {
    successMessage: '操作成功',
    errorMessage: '操作失败'
  }
)
```

---

### 场景3: 带重试的请求

**之前:**
```javascript
let retries = 0
const maxRetries = 3

while (retries < maxRetries) {
  try {
    const data = await apiGet('/api/unstable-endpoint')
    break
  } catch (error) {
    retries++
    if (retries >= maxRetries) throw error
    await new Promise(r => setTimeout(r, 2000))
  }
}
```

**之后:**
```javascript
const data = await executeWithRetry(
  () => apiGet('/api/unstable-endpoint'),
  { maxRetries: 3, retryDelay: 2000 }
)
```

---

### 场景4: 图片预加载防闪烁

**之前:**
```javascript
liveFrameData.value = {
  frame: base64Data,
  frameLoaded: true
}
// 可能导致闪烁
```

**之后:**
```javascript
const loaded = await preloadImage(base64Data)
if (loaded) {
  liveFrameData.value = {
    frame: base64Data,
    frameLoaded: true
  }
}
```

---

## 📋 API参考

### `apiGet(url, options?)`

发起GET请求,自动处理错误和超时。

**参数:**
- `url` (string): 请求URL
- `options` (Object, 可选): axios配置项

**返回:**
- Promise<any>: 响应数据(data字段)

**示例:**
```javascript
const user = await apiGet('/api/users/123')
const data = await apiGet('/api/data', { timeout: 5000 })
```

---

### `apiPost(url, data, options?)`

发起POST请求,自动处理错误和超时。

**参数:**
- `url` (string): 请求URL
- `data` (Object): 请求体数据
- `options` (Object, 可选): axios配置项

**返回:**
- Promise<any>: 响应数据(data字段)

**示例:**
```javascript
const newUser = await apiPost('/api/users', { name: 'John' })
const result = await apiPost('/api/upload', formData, {
  headers: { 'Content-Type': 'multipart/form-data' }
})
```

---

### `apiDelete(url, options?)`

发起DELETE请求,自动处理错误和超时。

**参数:**
- `url` (string): 请求URL
- `options` (Object, 可选): axios配置项

**返回:**
- Promise<any>: 响应数据(data字段)

**示例:**
```javascript
await apiDelete('/api/users/123')
```

---

### `createSafeInterval(callback, interval, timerRef)`

创建安全的定时器,自动清理旧定时器并捕获错误。

**参数:**
- `callback` (Function): 回调函数(可以是async)
- `interval` (number): 间隔时间(ms)
- `timerRef` (Ref): Vue的ref对象,存储定时器ID

**返回:**
- Function: 停止定时器的函数

**示例:**
```javascript
const timer = ref(null)

const stop = createSafeInterval(async () => {
  const data = await fetchData()
  console.log(data)
}, 2000, timer)

// 手动停止
stop()
```

---

### `clearAllTimers(...timerRefs)`

批量清除多个定时器。

**参数:**
- `...timerRefs` (Ref[]): 定时器ref对象列表

**示例:**
```javascript
const timer1 = ref(null)
const timer2 = ref(null)
const timer3 = ref(null)

// 一次性清除所有
clearAllTimers(timer1, timer2, timer3)
```

---

### `showSuccess(message?)`

显示成功消息提示。

**参数:**
- `message` (string, 可选): 提示消息,默认"操作成功"

**示例:**
```javascript
showSuccess() // "操作成功"
showSuccess('保存成功!')
```

---

### `showError(message?)`

显示错误消息提示。

**参数:**
- `message` (string, 可选): 提示消息,默认"操作失败"

**示例:**
```javascript
showError() // "操作失败"
showError('网络连接失败')
```

---

### `showWarning(message?)`

显示警告消息提示。

**参数:**
- `message` (string, 可选): 提示消息,默认"请注意"

**示例:**
```javascript
showWarning() // "请注意"
showWarning('此操作不可撤销')
```

---

### `safeExecute(asyncFn, options?)`

安全执行异步函数,自动处理错误和消息提示。

**参数:**
- `asyncFn` (Function): 异步函数
- `options` (Object, 可选):
  - `successMessage` (string): 成功消息
  - `errorMessage` (string): 错误消息前缀
  - `showError` (boolean): 是否显示错误,默认true

**返回:**
- Promise<any>: 函数执行结果

**示例:**
```javascript
await safeExecute(
  async () => {
    await saveData()
  },
  {
    successMessage: '保存成功',
    errorMessage: '保存失败'
  }
)

// 不显示错误消息(自己处理)
try {
  await safeExecute(
    async () => { /* ... */ },
    { showError: false }
  )
} catch (error) {
  // 自定义错误处理
}
```

---

### `executeWithRetry(requestFn, options?)`

带重试机制的执行器。

**参数:**
- `requestFn` (Function): 请求函数
- `options` (Object, 可选):
  - `maxRetries` (number): 最大重试次数,默认3
  - `retryDelay` (number): 重试延迟(ms),默认2000

**返回:**
- Promise<any>: 执行结果

**示例:**
```javascript
const data = await executeWithRetry(
  () => apiGet('/api/unstable-endpoint'),
  { maxRetries: 5, retryDelay: 3000 }
)
```

---

### `preloadImage(base64Data)`

预加载base64图片,避免显示闪烁。

**参数:**
- `base64Data` (string): base64编码的图片数据

**返回:**
- Promise<boolean>: 是否加载成功

**示例:**
```javascript
const loaded = await preloadImage(base64String)
if (loaded) {
  imageUrl.value = 'data:image/jpeg;base64,' + base64String
}
```

---

## ⚠️ 注意事项

### 1. 超时时间

- `apiGet`: 默认10秒
- `apiPost`: 默认30秒(考虑上传大文件)
- `apiDelete`: 默认10秒

可通过options覆盖:
```javascript
await apiGet('/api/slow-endpoint', { timeout: 60000 })
```

### 2. 错误处理

工具函数会自动记录错误到console,但仍建议在业务层捕获:

```javascript
try {
  const data = await apiGet('/api/data')
  // 处理数据
} catch (error) {
  // 业务特定的恢复逻辑
  fallbackToCache()
}
```

### 3. 定时器清理

组件卸载时必须清理定时器:

```javascript
onUnmounted(() => {
  clearAllTimers(timer1, timer2, timer3)
})
```

### 4. 并发请求

工具函数支持并发,无需额外处理:

```javascript
const [users, posts] = await Promise.all([
  apiGet('/api/users'),
  apiGet('/api/posts')
])
```

---

## 🔍 调试技巧

### 查看网络请求

打开浏览器DevTools → Network标签,可以看到:
- 请求URL和方法
- 请求/响应头
- 响应数据
- 耗时

### 查看错误日志

打开Console标签,工具函数会输出:
```
[API GET] /api/users 失败: Network Error
[Interval] 定时器回调执行失败: TypeError: ...
[Retry] 第1次尝试失败: Timeout
```

### 性能监控

在Performance标签中记录:
- 函数执行时间
- 内存占用
- 定时器数量

---

## 📊 对比总结

| 特性 | 原生axios | 封装后 |
|------|-----------|--------|
| **代码量** | 10-15行 | 1-3行 |
| **错误处理** | 手动try-catch | 自动处理 |
| **超时控制** | 需手动配置 | 默认配置 |
| **响应校验** | 手动检查 | 自动校验 |
| **重试机制** | 需自行实现 | 内置支持 |
| **可维护性** | 分散在各处 | 集中管理 |

---

## 🎯 最佳实践

1. **始终使用封装函数**: 除非有特殊需求
2. **合理设置超时**: 根据接口特性调整
3. **及时清理资源**: 组件卸载时清除定时器
4. **适度重试**: 不是所有请求都需要重试
5. **用户友好**: 提供清晰的错误提示

---

**最后更新**: 2026-04-10  
**版本**: v1.0.0
