# 前端界面整合报告

## 📋 整合概述

本次重构将原有的多个独立界面（监控界面、管理员面板）整合为一个**统一的综合监控界面**，实现所有功能的集中管理和便捷操作。

---

## 🎯 整合目标

### 原有问题
- ❌ 功能分散：需要在不同页面间切换
- ❌ 交互复杂：监控、管理、设置分离
- ❌ 用户体验不佳：频繁跳转页面
- ❌ 代码冗余：重复的组件和逻辑

### 整合后优势
- ✅ **一站式界面**：所有功能集中在一个界面
- ✅ **侧边栏选项卡**：快速切换查看警报、统计、日志、系统信息
- ✅ **沉浸式监控**：主区域专注视频监控，支持多分屏
- ✅ **便捷操作**：系统设置、退出登录触手可及

---

## 🏗️ 界面架构

### 布局结构

```
┌─────────────────────────────────────────────────────┐
│                  顶部导航栏                          │
│  系统 Logo | 全屏 | 刷新 | 分屏 | 设置 | 退出        │
├──────────┬──────────────────────────────────────────┤
│          │                                          │
│  左侧    │           主内容区                        │
│  功能    │         (视频监控墙)                      │
│  面板    │                                          │
│          │   ┌─────┬─────┬─────┬─────┐             │
│  [警报]  │   │ CAM1│ CAM2│ CAM3│ CAM4│             │
│  [统计]  │   ├─────┼─────┼─────┼─────┤             │
│  [日志]  │   │ CAM5│ CAM6│ CAM7│ CAM8│             │
│  [系统]  │   └─────┴─────┴─────┴─────┘             │
│          │                                          │
└──────────┴──────────────────────────────────────────┘
```

---

## ✨ 核心功能模块

### 1️⃣ **顶部导航栏**

**功能**：
- 🖥️ **全屏模式**：一键进入沉浸式监控
- 🔄 **刷新所有画面**：重置所有摄像头状态
- 📺 **多分屏切换**：1/4/9/16 分屏自由切换
- ⚙️ **系统设置**：快速打开配置对话框
- 🚪 **退出登录**：安全退出系统

**技术实现**：
```vue
<el-header class="header">
  <el-button @click="toggleFullscreen">全屏模式</el-button>
  <el-button @click="refreshAll">刷新所有画面</el-button>
  <el-dropdown @command="changeSplitScreen">
    <el-dropdown-menu>
      <el-dropdown-item command="1">1 分屏</el-dropdown-item>
      <el-dropdown-item command="4">4 分屏</el-dropdown-item>
      <!-- ... -->
    </el-dropdown-menu>
  </el-dropdown>
</el-header>
```

---

### 2️⃣ **左侧功能面板（选项卡式）**

#### **Tab 1: 实时警报**
- 📋 显示所有未处理/已处理警报
- 🔴 高风险告警红色高亮
- 🖱️ 点击跳转到对应摄像头
- ✅ 快速确认处理状态

**数据结构**：
```javascript
alertList: [{
  time: '2026-03-30 22:05:22',
  cameraId: 1,
  area: '主游泳池',
  level: 'high',
  reason: '检测到溺水行为',
  acknowledged: false
}]
```

#### **Tab 2: 统计数据**
- 👥 **总人数统计**：实时在泳人数
- 📊 **区域分布**：各泳池人数分布
- 🌡️ **环境数据**：水温监测
- 📈 **今日警报**：总数/已处理/待处理

**复用的组件**：
```vue
<StatsPanel 
  :total-people-count="totalPeopleCount"
  :area-distribution="areaDistribution"
  :env-data="envData"
  :today-alert-stats="todayAlertStats"
/>
```

#### **Tab 3: 活动日志**
- 📝 记录所有用户操作
- 🔍 时间、用户、操作、详情
- 📋 最多保留 100 条记录
- ⏰ 自动滚动到最新日志

**示例日志**：
```
2026-03-30 22:05:22 | admin | 登录系统 | IP: 192.168.1.100
2026-03-30 21:45:10 | admin | 查看监控 | 访问监控页面
2026-03-30 20:20:05 | admin | 处理警报 | 处理摄像头 1 警报
```

#### **Tab 4: 系统信息**
- 💻 **系统版本**：v1.0.0
- ⏱️ **运行时间**：实时计算
- 📹 **活跃摄像头**：4 个
- 🚨 **今日警报**：实时更新
- 🖥️ **资源使用率**：CPU 23% / 内存 45%

**使用 Element Plus Descriptions**：
```vue
<el-descriptions title="系统状态" :column="1" border>
  <el-descriptions-item label="系统版本">v1.0.0</el-descriptions-item>
  <el-descriptions-item label="运行时间">0 天 12 小时 30 分钟</el-descriptions-item>
</el-descriptions>
```

---

### 3️⃣ **主内容区 - 视频监控墙**

#### **多分屏支持**
- **1 分屏**：单摄像头全屏查看
- **4 分屏**：2x2 网格布局
- **9 分屏**：3x3 网格布局
- **16 分屏**：4x4 网格布局

#### **智能交互**
- 🖱️ **点击切换**：单屏模式下点击切换全屏
- 🔔 **告警高亮**：红色闪烁边框提示
- 📊 **人数显示**：实时叠加在画面上
- 🎥 **视频流播放**：使用 MJPEG 格式

**Grid 布局实现**：
```css
.split-4 {
  grid-template-columns: repeat(2, 1fr);
}

.split-9 {
  grid-template-columns: repeat(3, 1fr);
}
```

#### **告警覆盖层**
```vue
<div class="alert-overlay" v-if="camera.hasAlert">
  <el-tag type="danger" effect="dark">
    <el-icon><Bell /></el-icon>
    告警中
  </el-tag>
</div>
```

---

### 4️⃣ **系统设置对话框**

**配置项**：
- 📹 **视频源配置**：文件路径或摄像头 ID
- 🏊 **水域名称**：自定义监控区域名称
- ⏰ **告警延迟**：触发告警的时间阈值（秒）
- 🎯 **置信度阈值**：YOLO 检测置信度滑块（0-1）
- 🔊 **语音告警**：开启/关闭声音提示

```vue
<el-dialog v-model="showSettings" title="系统设置">
  <el-form label-width="120px">
    <el-form-item label="置信度阈值">
      <el-slider v-model="settings.confThreshold" 
                 :min="0" :max="1" :step="0.01"/>
    </el-form-item>
  </el-form>
</el-dialog>
```

---

## 🔧 技术实现

### 状态管理

**响应式数据**：
```javascript
// 基础状态
const activeTab = ref('alerts') // 当前激活的 Tab
const showSettings = ref(false) // 设置对话框
const splitScreen = ref(1) // 分屏数量
const isFullscreen = ref(false) // 全屏状态

// 业务数据
const cameras = ref([...]) // 摄像头列表
const alertList = ref([]) // 警报列表
const activityLogs = ref([...]) // 活动日志
```

### WebSocket 实时通信

**连接管理**：
```javascript
const connectWebSocket = () => {
  const wsUrl = `ws://${window.location.host}/ws/alert`
  ws = new WebSocket(wsUrl)
  
  ws.onmessage = (event) => {
    const data = JSON.parse(event.data)
    handleAlertEvent(data)
  }
  
  ws.onerror = () => {
    setTimeout(connectWebSocket, 3000) // 3 秒重连
  }
}
```

**心跳机制**：
```javascript
let heartbeatTimer = setInterval(() => {
  if (ws && ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify({ 
      type: 'heartbeat', 
      timestamp: Date.now() 
    }))
  }
}, 30000) // 30 秒一次
```

### 定时刷新

**5 秒自动刷新**：
```javascript
let refreshTimer = setInterval(() => {
  refreshCameraStatus()
  updateSystemUptime()
}, 5000)
```

---

## 🎨 UI/UX 优化

### 视觉设计

**渐变主题**：
```css
.header {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
}
```

**告警颜色编码**：
- 🔴 **高风险**：`#F56C6C` + 红色左边框
- 🟠 **中风险**：`#E6A23C` + 橙色左边框
- ⚪ **低风险**：`#909399` + 灰色左边框

**动画效果**：
```css
@keyframes blink {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.5; }
}

.alert-overlay .el-tag {
  animation: blink 1s infinite;
}
```

### 交互体验

**悬停效果**：
```css
.screen-item:hover {
  box-shadow: 0 0 20px rgba(64, 158, 255, 0.5);
  transform: translateX(5px);
}
```

**告警高亮**：
```css
.screen-item.highlight {
  box-shadow: 0 0 20px rgba(245, 108, 108, 0.8);
}
```

---

## 📊 性能优化

### 1. 组件复用
- ✅ 复用 `StatsPanel` 组件展示统计数据
- ✅ 复用 `AlertDialog` 组件处理告警确认

### 2. 按需加载
- ✅ 视频流使用懒加载（`@load` 事件）
- ✅ Tab 面板内容按需渲染

### 3. 内存管理
- ✅ 限制警报列表长度（最多 50 条）
- ✅ 限制活动日志长度（最多 100 条）
- ✅ 卸载时清理定时器和 WebSocket 连接

### 4. 防抖节流
```javascript
// TODO: 未来可添加
const debouncedRefresh = debounce(refreshAll, 500)
```

---

## 🔒 安全机制

### 1. 路由守卫
```javascript
router.beforeEach((to, from, next) => {
  const token = localStorage.getItem('token')
  
  if (to.meta.requiresAuth && !token) {
    next('/login')
    return
  }
  
  next()
})
```

### 2. 退出登录
```javascript
const handleLogout = () => {
  ElMessageBox.confirm('确定要退出登录吗？', '提示', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning'
  }).then(() => {
    localStorage.removeItem('token')
    localStorage.removeItem('username')
    router.push('/login')
  })
}
```

---

## 📁 文件变更

### 修改的文件

1. **[`Monitor.vue`](c:\Users\whz42\Desktop\132456\frontend\src\views\Monitor.vue)**
   - ✅ 重构为统一监控界面
   - ✅ 整合 AdminPanel 所有功能
   - ✅ 添加侧边栏选项卡
   - ✅ 集成系统设置对话框
   - ✅ 完善 WebSocket 通信
   - ✅ 添加心跳机制和定时刷新

2. **[`index.js`](c:\Users\whz42\Desktop\132456\frontend\src\router\index.js)**
   - ✅ 移除 AdminPanel 路由
   - ✅ 简化路由配置

### 删除的文件

3. **`AdminPanel.vue`**
   - ✅ 已删除（功能已整合到 Monitor.vue）

---

## 🎯 功能对照表

| 原 AdminPanel 功能 | 新 Monitor.vue 位置 | 状态 |
|-------------------|--------------------|------|
| 仪表盘统计 | 左侧 Tab - 系统信息 | ✅ 整合 |
| 警报管理表格 | 左侧 Tab - 实时警报 | ✅ 增强 |
| 活动日志表格 | 左侧 Tab - 活动日志 | ✅ 整合 |
| 系统信息显示 | 左侧 Tab - 系统信息 | ✅ 整合 |
| 用户管理 | 已移除 | ❌ 不再需要 |
| 系统设置 | 顶部按钮 -> 对话框 | ✅ 整合 |
| 退出登录 | 顶部按钮 | ✅ 整合 |
| 监控界面跳转 | 本身就是主界面 | ✅ 无需跳转 |

---

## 🚀 使用流程

### 正常监控流程

1. **登录系统** → `/login`
2. **自动跳转** → `/monitor`（统一监控界面）
3. **查看实时监控** → 主屏幕显示所有摄像头
4. **处理告警**：
   - 左侧"实时警报"Tab 收到推送
   - 点击告警项 → 弹出确认对话框
   - 确认处理 → 更新状态并记录日志
5. **查看统计** → 切换到"统计数据"Tab
6. **系统设置** → 点击右上角"系统设置"按钮

### 应急响应流程

```
告警发生
  ↓
WebSocket 推送消息
  ↓
自动添加到警报列表（红色高亮）
  ↓
播放声音提示
  ↓
摄像头画面红色闪烁
  ↓
用户点击告警
  ↓
确认处理
  ↓
记录到活动日志
  ↓
清除告警状态
```

---

## 🔮 未来扩展

### 可扩展功能

1. **多语言支持**
   ```javascript
   const i18n = createI18n({
     locale: 'zh-CN',
     messages: { 'zh-CN': {...}, 'en': {...} }
   })
   ```

2. **深色模式**
   ```css
   .dark-theme {
     --bg-color: #1a1a1a;
     --text-color: #ffffff;
   }
   ```

3. **自定义布局**
   - 拖拽调整分屏位置
   - 保存个性化布局配置

4. **高级搜索**
   - 按时间范围搜索录像
   - 按摄像头筛选告警
   - 导出历史数据

5. **移动端适配**
   ```css
   @media (max-width: 768px) {
     .alert-aside {
       width: 100%;
       position: fixed;
       z-index: 100;
     }
   }
   ```

---

## 📝 开发建议

### 代码规范

1. **组件命名**
   - 使用 PascalCase（如 `StatsPanel`, `AlertDialog`）
   - 文件名与组件名一致

2. **注释规范**
   ```javascript
   // ========== 基础状态 ==========
   const activeTab = ref('alerts')
   
   /**
    * 处理警报事件
    * @param {Object} data - WebSocket 推送的数据
    */
   const handleAlertEvent = (data) => { ... }
   ```

3. **错误处理**
   ```javascript
   try {
     await loadTodayAlertStats()
   } catch (error) {
     console.error('加载失败:', error)
     ElMessage.error('加载警报统计失败')
   }
   ```

### 性能监控

建议添加：
- 页面加载时间监控
- WebSocket 连接质量统计
- 视频流卡顿次数记录

---

## ✅ 测试验证

### 功能测试清单

- [x] 登录成功后跳转到监控界面
- [x] 左侧 4 个 Tab 正常切换
- [x] 实时警报列表接收和显示
- [x] 点击告警弹出确认对话框
- [x] 确认处理后更新状态
- [x] 统计数据正确显示
- [x] 活动日志实时更新
- [x] 系统信息准确展示
- [x] 分屏切换正常工作
- [x] 全屏模式正常切换
- [x] 系统设置保存成功
- [x] 退出登录功能正常
- [x] WebSocket 断线重连
- [x] 心跳机制正常工作
- [x] 定时刷新执行正常

### 兼容性测试

- Chrome ✅
- Firefox ✅
- Edge ✅
- Safari ⏳ 待测试

---

## 📚 相关文档

- [Vue 3 官方文档](https://v3.vuejs.org/)
- [Element Plus 组件库](https://element-plus.org/)
- [WebSocket API](https://developer.mozilla.org/en-US/docs/Web/API/WebSocket)
- [CSS Grid 布局](https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_Grid_Layout)

---

**最后更新**: 2026-03-30  
**维护者**: 系统开发团队  
**状态**: ✅ 已完成并测试通过
