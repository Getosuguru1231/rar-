# 溺水监测系统 - 连接配置文档

## 目录
- [系统架构](#系统架构)
- [端口配置](#端口配置)
- [前端配置](#前端配置)
- [后端配置](#后端配置)
- [API 路由映射](#api-路由映射)
- [WebSocket/WebRTC 连接](#websocketwebrtc-连接)
- [常见问题](#常见问题)

---

## 系统架构

```
┌─────────────┐
│   前端      │  (Vite)
│ Port: 3000  │
└──────┬──────┘
       │
       │ API / WebSocket
       │
┌──────▼──────┐
│   后端      │  (FastAPI)
│ Port: 8002  │
└──────┬──────┘
       │
       ├─ Redis (可选，视频帧缓存)
       └─ 摄像头数据源
```

---

## 端口配置

| 组件 | 端口 | 说明 | 配置文件 |
|------|------|------|----------|
| 前端 (Vite Dev Server) | 3000 | 用户界面、视频监控 | `frontend/vite.config.js` |
| 后端 (FastAPI) | 8002 | API 服务、WebRTC 信令、视频处理 | `backend/main.py` |
| Redis | 6379 | 视频帧缓存 (可选) | `backend/detect.py` |

---

## 前端配置

### 1. Vite 代理配置

**文件**: `frontend/vite.config.js`

```javascript
export default defineConfig({
  server: {
    port: 3000,
    proxy: {
      '/api': {
        target: 'http://localhost:8002',
        changeOrigin: true,
        rewrite: (path) => path
      },
      '/ws': {
        target: 'http://localhost:8002',
        ws: true,
        changeOrigin: true
      }
    }
  }
})
```

### 2. WebSocket 配置

**文件**: `frontend/src/config/websocket.js`

```javascript
export const WS_PATHS = {
  video: '/ws/video',
  webrtc: '/ws/webrtc',
  alerts: '/ws/alerts',
  rdk_x5: '/ws/rdk_x5/stream'
}

export const P2P_CONFIG = {
  enabled: true,  // 启用P2P模式，直接连接后端8002端口
  backendHost: 'localhost',
  backendPort: 8002
}
```

### 3. API 基础配置

**文件**: `frontend/src/utils/index.js`

```javascript
export const API_CONSTANTS = {
  BASE_URL: '/api',
  DEFAULT_TIMEOUT: 30000
}
```

---

## 后端配置

### 1. 后端服务端口

**文件**: `backend/main.py`

```python
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8002)  # 端口: 8002
```

### 2. WebRTC 视频配置

**文件**: `backend/webrtc/config.py`

```python
class VideoConfig:
    default_width: int = 1280
    default_height: int = 720
    default_fps: int = 15  # 目标帧率
    min_fps: int = 10
    max_fps: int = 20
```

### 3. 视频检测配置

**文件**: `backend/detect.py`

```python
target_fps = 15  # 提高目标帧率
detection_fps = 5  # 提高检测帧率
```

---

## API 路由映射

### 路由注册配置

**文件**: `backend/routes/__init__.py`

```python
api_router.include_router(health_router, tags=["health"])
api_router.include_router(alert_router, prefix="/api/alert", tags=["alert"])
api_router.include_router(camera_router, prefix="/camera", tags=["camera"])
api_router.include_router(monitoring_router, prefix="/api", tags=["monitoring"])
api_router.include_router(llm_router, tags=["llm"])
api_router.include_router(config_router, prefix="/config", tags=["config"])
api_router.include_router(video_router, prefix="/api/video", tags=["video"])
api_router.include_router(video_cleanup_router, prefix="/api/video", tags=["video"])
api_router.include_router(webrtc_signaling_router, tags=["webrtc"])
api_router.include_router(auth_router, tags=["auth"])
```

### API 端点示例

| 前端请求 | 后端路径 | 说明 |
|----------|----------|------|
| `/api/health` | `/health` | 健康检查 |
| `/api/people-count` | `/api/video/people-count` | 获取人数统计 |
| `/api/alert/list` | `/api/alert/list` | 获取告警列表 |
| `/llm/config` | `/llm/config` | 获取LLM配置 |

---

## WebSocket/WebRTC 连接

### WebSocket 端点

| 端点 | 说明 | 配置文件 |
|------|------|----------|
| `/ws/webrtc/{camera_id}` | WebRTC 信令通道 | `backend/routes/webrtc_signaling.py` |

### WebRTC 连接流程

```
1. 前端调用 useWebRTC(cameraId)
   ↓
2. 前端获取 WebSocket URL:
   - 启用 P2P: ws://localhost:8002/ws/webrtc/{cameraId}
   - 禁用 P2P: ws://localhost:3000/ws/webrtc/{cameraId} → 代理 → ws://localhost:8002
   ↓
3. 建立 WebSocket 连接
   ↓
4. 发送 SDP Offer
   ↓
5. 后端返回 SDP Answer + ICE Candidates
   ↓
6. 建立 P2P 连接并传输视频流
```

### 前端 WebRTC 调用

**文件**: `frontend/src/components/video/WebRTCPlayer.vue`

```vue
<script setup>
import { useWebRTC } from '@/composables/useWebRTC.js'

const {
  pc,
  remoteStream,
  connectionState,
  isConnected,
  connect,
  disconnect
} = useWebRTC(props.cameraId)
</script>
```

---

## 常见问题

### 问题 1: 前端连接不上后端
**症状**: 控制台显示网络错误

**排查步骤**:
1. 检查后端是否运行: `curl http://localhost:8002/health`
2. 检查 Vite 代理配置是否正确 (端口 8002)
3. 检查防火墙设置
4. 查看前端控制台 Network 标签页

### 问题 2: WebSocket 连接失败
**症状**: 信令无法建立

**排查步骤**:
1. 检查 `P2P_CONFIG.enabled` 配置
2. 检查后端 WebSocket 路由是否注册
3. 检查端口 8002 是否被占用

### 问题 3: 视频延迟过高
**症状**: 视频流卡顿或延迟明显

**优化建议**:
1. 检查 `target_fps` 和 `default_fps` 配置 (建议 ≥12fps)
2. 减少日志输出频率
3. 优化网络连接 (使用有线网络)
4. 降低视频分辨率

### 问题 4: 端口被占用
**解决方法**:
```bash
# Windows (查找占用8002端口的进程)
netstat -ano | findstr :8002

# 或使用 PowerShell
Get-NetTCPConnection -LocalPort 8002 -ErrorAction SilentlyContinue | Select-Object -Property State, OwningProcess | ForEach-Object { Get-Process -Id $_.OwningProcess }

# 终止进程 (谨慎使用)
taskkill /PID <进程ID> /F
```

---

## 启动顺序

### 开发环境启动

1. **启动后端** (端口 8002):
```bash
cd backend
python main.py
```

2. **启动前端** (端口 3000):
```bash
cd frontend
npm run dev
```

3. **访问页面**: 打开 http://localhost:3000

### 生产环境

建议配置反向代理 (如 Nginx)，统一暴露端口。
