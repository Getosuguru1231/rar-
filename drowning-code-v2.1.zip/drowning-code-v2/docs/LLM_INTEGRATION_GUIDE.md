# 语言大模型（LLM）集成指南

## 📋 目录
- [功能概述](#功能概述)
- [快速开始](#快速开始)
- [API接口说明](#api接口说明)
- [配置说明](#配置说明)
- [使用示例](#使用示例)
- [故障排查](#故障排查)

---

## 功能概述

本系统集成了语言大模型（LLM）功能，提供以下智能服务：

### 1. 溺水事件智能分析
- 自动分析检测到的溺水事件
- 评估风险等级（低/中/高/紧急）
- 生成专业的分析报告
- 提供应对建议

### 2. 预警消息生成
- 自动生成简洁的预警短信
- 适合推送到手机
- 包含关键信息，便于快速响应

### 3. 检测报告生成
- 根据检测结果生成专业报告
- 包含概况、风险分析、建议措施
- 可用于存档和汇报

### 4. 智能问答
- 回答用户关于系统的问题
- 提供安全建议
- 支持上下文理解

---

## 快速开始

### 步骤1: 安装依赖

```bash
cd backend
.\yolo_env\Scripts\Activate.ps1
pip install openai>=1.0.0
pip install dashscope>=1.14.0
```

或者更新所有依赖：

```bash
pip install -r requirements.txt
```

### 步骤2: 配置API密钥

复制配置示例文件：

```bash
copy .env.llm.example .env.llm
```

编辑 `.env.llm` 文件，选择你要使用的LLM提供商并填写API密钥。

**推荐：通义千问（阿里云）**

1. 注册阿里云账号：https://dashscope.console.aliyun.com/
2. 创建API密钥
3. 在 `.env.llm` 中配置：

```env
LLM_PROVIDER=qwen
LLM_API_KEY=sk-your-api-key-here
LLM_MODEL=qwen-turbo
```

### 步骤3: 设置环境变量

**Windows PowerShell:**
```powershell
$env:LLM_PROVIDER="qwen"
$env:LLM_API_KEY="sk-your-api-key-here"
$env:LLM_MODEL="qwen-turbo"
```

**或在启动脚本中添加：**

编辑 `start.bat` 或 `start.ps1`，在启动后端前添加环境变量设置。

### 步骤4: 测试连接

启动后端服务后，访问：

```
http://localhost:8000/api/llm/test
```

如果返回 `"success": true`，说明配置成功！

---

## API接口说明

### 1. 分析溺水事件

**接口**: `POST /api/llm/analyze`

**请求体**:
```json
{
  "timestamp": "2026-04-08 19:30:00",
  "location": "游泳池A区",
  "confidence": 0.85,
  "person_count": 1,
  "duration": 15.5,
  "behavior_description": "检测到人员在水中挣扎，头部多次没入水中"
}
```

**响应**:
```json
{
  "code": 200,
  "message": "分析成功",
  "data": {
    "success": true,
    "analysis": "【风险评估】紧急\n【检测置信度】85.00%\n【建议措施】建议立即启动应急救援程序...",
    "timestamp": "2026-04-08T19:30:15",
    "model": "qwen-turbo"
  }
}
```

### 2. 生成预警消息

**接口**: `POST /api/llm/generate-alert`

**请求体**: 同上

**响应**:
```json
{
  "code": 200,
  "message": "生成成功",
  "data": {
    "alert_message": "【溺水预警】19:30，游泳池A区检测到紧急异常行为，置信度85%，请立即前往救援！",
    "length": 45
  }
}
```

### 3. 生成检测报告

**接口**: `POST /api/llm/generate-report`

**请求体**:
```json
{
  "detection_results": [
    {
      "timestamp": "2026-04-08 19:30:00",
      "location": "游泳池A区",
      "confidence": 0.85,
      "status": "detected"
    },
    {
      "timestamp": "2026-04-08 19:35:00",
      "location": "游泳池B区",
      "confidence": 0.72,
      "status": "detected"
    }
  ]
}
```

**响应**:
```json
{
  "code": 200,
  "message": "报告生成成功",
  "data": {
    "report": "# 溺水检测报告\n\n## 检测概况\n本次检测共发现2起异常事件...\n\n## 风险分析\n...",
    "result_count": 2
  }
}
```

### 4. 智能问答

**接口**: `POST /api/llm/ask`

**请求体**:
```json
{
  "question": "如何提高溺水检测的准确率？",
  "context": "当前系统使用YOLOv8模型，置信度阈值为0.6"
}
```

**响应**:
```json
{
  "code": 200,
  "message": "回答成功",
  "data": {
    "answer": "提高溺水检测准确率可以从以下几个方面入手：\n1. 优化训练数据...\n2. 调整置信度阈值...",
    "question": "如何提高溺水检测的准确率？"
  }
}
```

### 5. 测试连接

**接口**: `GET /api/llm/test`

**响应**:
```json
{
  "code": 200,
  "message": "连接测试成功",
  "data": {
    "success": true,
    "message": "连接成功",
    "response": "连接成功",
    "config": {
      "provider": "qwen",
      "model": "qwen-turbo",
      "base_url": "https://dashscope.aliyuncs.com/api/v1"
    }
  }
}
```

### 6. 获取配置信息

**接口**: `GET /api/llm/config`

**响应**:
```json
{
  "code": 200,
  "message": "获取成功",
  "data": {
    "provider": "qwen",
    "model": "qwen-turbo",
    "base_url": "https://dashscope.aliyuncs.com/api/v1",
    "api_key_configured": true,
    "fallback_enabled": true
  }
}
```

---

## 配置说明

### 支持的LLM提供商

#### 1. 通义千问（推荐）
- **优点**: 中文理解能力强，性价比高
- **免费额度**: 新用户赠送一定免费token
- **文档**: https://help.aliyun.com/zh/dashscope/

**配置**:
```env
LLM_PROVIDER=qwen
LLM_API_KEY=sk-xxxxxxxxxxxxx
LLM_BASE_URL=https://dashscope.aliyuncs.com/api/v1
LLM_MODEL=qwen-turbo
```

**可用模型**:
- `qwen-turbo`: 快速响应，适合日常使用
- `qwen-plus`: 平衡性能和成本
- `qwen-max`: 最强性能，适合复杂任务

#### 2. 百度文心一言
- **优点**: 百度生态整合好
- **文档**: https://cloud.baidu.com/doc/WENXINWORKSHOP/index.html

**配置**:
```env
LLM_PROVIDER=ernie
LLM_API_KEY=your_api_key
LLM_BASE_URL=https://aip.baidubce.com/rpc/2.0/ai_custom/v1
LLM_MODEL=ernie-bot
```

#### 3. OpenAI兼容API
- **适用场景**: 本地部署的开源模型（如Qwen、Llama等）
- **优点**: 数据隐私性好，可离线使用

**配置**:
```env
LLM_PROVIDER=openai
LLM_API_KEY=your_api_key
LLM_BASE_URL=http://localhost:8000/v1
LLM_MODEL=qwen-7b-chat
```

### 降级策略

当LLM API不可用时，系统会自动使用预设模板生成分析结果，确保功能不中断。

**降级模板特点**:
- 基于置信度自动评估风险等级
- 提供标准化的建议措施
- 保证基本的预警功能

---

## 使用示例

### Python代码调用

```
import requests

# 1. 分析溺水事件
response = requests.post('http://localhost:8000/api/llm/analyze', json={
    'timestamp': '2026-04-08 19:30:00',
    'location': '游泳池A区',
    'confidence': 0.85,
    'person_count': 1,
    'duration': 15.5,
    'behavior_description': '检测到人员在水中挣扎'
})
print(response.json()['data']['analysis'])

# 2. 生成预警短信
response = requests.post('http://localhost:8000/api/llm/generate-alert', json={
    'timestamp': '2026-04-08 19:30:00',
    'location': '游泳池A区',
    'confidence': 0.85
})
alert_msg = response.json()['data']['alert_message']
print(f"预警消息: {alert_msg}")

# 3. 智能问答
response = requests.post('http://localhost:8000/api/llm/ask', json={
    'question': '检测到溺水后应该采取什么措施？'
})
print(response.json()['data']['answer'])
```

### JavaScript/前端调用

```
// 分析溺水事件
async function analyzeDrowning(eventData) {
  const response = await fetch('http://localhost:8000/api/llm/analyze', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(eventData)
  });
  const result = await response.json();
  return result.data.analysis;
}

// 生成预警消息
async function generateAlert(eventData) {
  const response = await fetch('http://localhost:8000/api/llm/generate-alert', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(eventData)
  });
  const result = await response.json();
  return result.data.alert_message;
}
```

---

## 故障排查

### 问题1: API返回401错误

**原因**: API密钥未配置或配置错误

**解决**:
1. 检查环境变量是否正确设置
2. 确认API密钥有效且未过期
3. 重启后端服务

### 问题2: API调用超时

**原因**: 网络连接问题或API服务繁忙

**解决**:
1. 检查网络连接
2. 尝试切换其他模型（如从qwen-max切换到qwen-turbo）
3. 系统会自动降级到预设模板

### 问题3: 返回结果为空

**原因**: API响应格式不符合预期

**解决**:
1. 查看后端日志: `backend/logs/`
2. 检查API提供商文档是否有更新
3. 启用降级策略

### 问题4: 中文乱码

**原因**: 编码设置问题

**解决**:
1. 确保终端支持UTF-8编码
2. Windows PowerShell执行: `[Console]::OutputEncoding = [System.Text.Encoding]::UTF8`

---

## 最佳实践

### 1. 成本控制
- 开发测试时使用 `qwen-turbo` 模型
- 生产环境根据需要选择合适模型
- 设置调用频率限制

### 2. 性能优化
- 缓存常用问题的答案
- 异步调用LLM API，避免阻塞主线程
- 合理设置 `max_tokens` 参数

### 3. 安全建议
- 不要在代码中硬编码API密钥
- 定期轮换API密钥
- 监控API调用日志，发现异常及时处理

### 4. 降级策略
- 始终启用降级策略（`fallback_enabled=true`）
- 定期检查API可用性
- 准备多个API提供商作为备份

---

## 相关文档

- [通义千问官方文档](https://help.aliyun.com/zh/dashscope/)
- [百度文心一言文档](https://cloud.baidu.com/doc/WENXINWORKSHOP/index.html)
- [OpenAI API文档](https://platform.openai.com/docs)

---

## 更新日志

### v1.0.0 (2026-04-08)
- ✨ 初始版本发布
- ✅ 支持通义千问、百度文心一言、OpenAI兼容API
- ✅ 提供溺水事件分析、预警生成、报告生成、智能问答功能
- ✅ 内置降级策略，确保服务稳定性
