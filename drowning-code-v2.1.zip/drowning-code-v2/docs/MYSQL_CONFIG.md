# MySQL 数据库配置说明

## 📋 当前配置

| 配置项 | 值 |
|--------|-----|
| 主机 | localhost |
| 端口 | 3306 |
| 用户 | root |
| **密码** | **root** |
| 数据库 | drowning_db |
| 字符集 | utf8mb4 |

## 🔧 配置文件位置

数据库配置位于 [`backend/settings.py`](backend/settings.py):

```python
# 数据库配置
MYSQL_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "root",  # MySQL root 密码
    "database": "drowning_db",
    "charset": "utf8mb4"
}
```

## 🚀 初始化数据库

### 方式1: 使用initdb.py脚本
```powershell
cd backend
.\yolo_env\Scripts\python.exe initdb.py
```

此脚本会:
- ✅ 自动创建 `drowning_db` 数据库(如不存在)
- ✅ 创建 `alert_log` 表(告警记录)
- ✅ 创建 `dataset` 表(数据集)
- ✅ 添加必要的字段和索引

### 方式2: 使用批处理文件
```bash
init_database.bat
```

## 📊 数据库表结构

### 1. alert_log (告警记录表)
```sql
CREATE TABLE IF NOT EXISTS alert_log (
    id INT AUTO_INCREMENT PRIMARY KEY,
    alert_time DATETIME NOT NULL,
    video_path VARCHAR(255) NOT NULL,
    status VARCHAR(20) DEFAULT 'pending',
    camera_id INT DEFAULT 1,
    area_name VARCHAR(100),
    is_false_alarm BOOLEAN DEFAULT FALSE,
    response_time DECIMAL(5,2),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
```

**字段说明**:
- `id`: 自增主键
- `alert_time`: 告警时间
- `video_path`: 视频文件路径
- `status`: 处理状态 (pending/confirmed/false_alarm)
- `camera_id`: 摄像头ID
- `area_name`: 区域名称
- `is_false_alarm`: 是否误报
- `response_time`: 响应时间(秒)
- `created_at`: 记录创建时间

### 2. dataset (数据集表)
```sql
CREATE TABLE IF NOT EXISTS dataset (
    id INT AUTO_INCREMENT PRIMARY KEY,
    img_path VARCHAR(255) NOT NULL,
    label VARCHAR(50) NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
```

## 🔍 验证连接

### 使用check_env.py
```powershell
cd backend
.\yolo_env\Scripts\python.exe check_env.py
```

应看到:
```
✓ MySQL 连接成功
```

### 手动测试
```powershell
cd backend
.\yolo_env\Scripts\python.exe -c "import mysql.connector; conn = mysql.connector.connect(host='localhost', user='root', password='root', database='drowning_db'); print('✅ 连接成功'); conn.close()"
```

## ⚠️ 常见问题

### 问题1: Access denied错误
**症状**:
```
✗ MySQL 连接失败: 1045 (28000): Access denied for user 'root'@'localhost'
```

**解决**:
1. 确认MySQL服务正在运行
2. 检查密码是否正确(当前为 `root`)
3. 修改 `backend/settings.py` 中的密码配置
4. 重新运行 `initdb.py`

### 问题2: 数据库不存在
**症状**:
```
Unknown database 'drowning_db'
```

**解决**:
```powershell
cd backend
.\yolo_env\Scripts\python.exe initdb.py
```

### 问题3: MySQL服务未启动
**症状**:
```
Can't connect to MySQL server on 'localhost'
```

**解决**:
```powershell
# Windows服务管理
net start MySQL80  # 或您的MySQL服务名

# 或使用Services.msc图形界面启动
```

### 问题4: 忘记密码
**解决**:
1. 停止MySQL服务
2. 使用 `--skip-grant-tables` 模式启动
3. 重置root密码
4. 更新 `backend/settings.py` 中的密码配置

## 🔐 安全建议

### 生产环境
1. **不要使用默认密码**: 修改为强密码
2. **创建专用用户**: 不要使用root用户
   ```sql
   CREATE USER 'drowning_user'@'localhost' IDENTIFIED BY 'strong_password';
   GRANT ALL PRIVILEGES ON drowning_db.* TO 'drowning_user'@'localhost';
   FLUSH PRIVILEGES;
   ```
3. **限制访问**: 仅允许本地连接
4. **定期备份**: 设置自动备份任务

### 开发环境
当前配置适用于开发环境,密码为 `root` 便于快速部署。

## 📝 修改密码步骤

如需修改MySQL密码:

1. **在MySQL中修改**:
   ```sql
   ALTER USER 'root'@'localhost' IDENTIFIED BY 'new_password';
   FLUSH PRIVILEGES;
   ```

2. **更新配置文件** (`backend/settings.py`):
   ```python
   MYSQL_CONFIG = {
       "host": "localhost",
       "user": "root",
       "password": "new_password",  # 新密码
       "database": "drowning_db",
       "charset": "utf8mb4"
   }
   ```

3. **验证连接**:
   ```powershell
   cd backend
   .\yolo_env\Scripts\python.exe check_env.py
   ```

## 🛠️ 维护命令

### 查看数据库大小
```sql
SELECT 
    table_schema AS 'Database',
    ROUND(SUM(data_length + index_length) / 1024 / 1024, 2) AS 'Size (MB)'
FROM information_schema.tables
WHERE table_schema = 'drowning_db'
GROUP BY table_schema;
```

### 清理旧数据
```sql
-- 删除30天前的告警记录
DELETE FROM alert_log WHERE alert_time < DATE_SUB(NOW(), INTERVAL 30 DAY);

-- 优化表
OPTIMIZE TABLE alert_log;
```

### 备份数据库
```powershell
mysqldump -u root -proot drowning_db > backup_$(Get-Date -Format 'yyyyMMdd').sql
```

### 恢复数据库
```powershell
mysql -u root -proot drowning_db < backup_20260407.sql
```

## 📚 相关文档

- [DEPLOYMENT_GUIDE.md](DEPLOYMENT_GUIDE.md) - 完整部署指南
- [DATABASE_DESIGN.md](DATABASE_DESIGN.md) - 数据库设计文档
- [ENVIRONMENT_CHECK_REPORT.md](ENVIRONMENT_CHECK_REPORT.md) - 环境检查报告

---

**最后更新**: 2026-04-07  
**当前密码**: root  
**状态**: ✅ 已验证连接正常
